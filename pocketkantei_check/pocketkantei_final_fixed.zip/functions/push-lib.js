// ニコからのメッセージ（プッシュ通知）の中身。関数本体は nico-push.mjs（毎時の予約）と nico-push-background.mjs（送信）。
// ・1日1回、利用者が選んだ時刻（その人の地域の時刻）に、ニコが短いメッセージを送る（「おはよう」「ご飯食べた？」「あの件どうなった？」など）。
// ・文面は毎回AI（軽量モデル）が、その人との距離感・会話のメモ・最近の会話・時間帯から作る。運勢の案内はしない。
// ・通知はロック画面に出るので、ほかの人の名前・健康・お金・恋愛の具体的な話・つらい話題は文面に入れない。
// ・送ったメッセージは受け取り箱（pi:<uid>）にも入れ、アプリを開いた時にニコの発言としてチャットに表示する。
// ・送信は Firebase Cloud Messaging（FCM HTTP v1）。iPhone も FCM 経由（Firebase に APNs 認証キーを登録しておく）。
//
// 保存先（Netlify Blobs ストア pk-accounts）
//   ps:<uid>          … 設定と記録 { on, token, platform, hour, tz, lang, bucket, lastDay, hist:[直近の文面], seen, updated }
//   pb:<UTCの時>:<uid> … その時刻（UTC）に送る人の目印（毎時、その時刻の人だけを読む）
//   pi:<uid>          … 受け取り箱 { items:[{ id, text, ts }] }（最新10件・7日まで）
//
// 環境変数
//   FCM_PROJECT_ID / FCM_CLIENT_EMAIL / FCM_PRIVATE_KEY … Firebase のサービスアカウント（秘密鍵は \n を含む1行のまま貼ってよい）
//   PK_PUSH_MODEL（任意） … 文面を作るモデル。既定は GEMINI_MODEL（軽量）
//   PK_PUSH_ACTIVE_DAYS（任意）… 最後にアプリを開いてから、この日数を過ぎた人には送らない。既定 {"free":14,"paid":45}
const crypto = require('crypto');

const LANGS = ['ja', 'en', 'zh', 'zt', 'ko', 'vi', 'es', 'pt', 'id', 'th'];
const LANG_NAME = { ja: 'Japanese', en: 'English', zh: 'Simplified Chinese', zt: 'Traditional Chinese (Taiwan)', ko: 'Korean', vi: 'Vietnamese', es: 'Spanish', pt: 'Portuguese (Brazil)', id: 'Indonesian', th: 'Thai' };
// 1通の長さの上限（文字数）。ロック画面で読み切れる長さ
const MAX_LEN = { ja: 70, zh: 55, zt: 55, ko: 80, th: 110, en: 150, es: 150, pt: 150, id: 150, vi: 150 };
const TITLE = 'Nico 🦉';
const HIST_KEEP = 10, INBOX_KEEP = 10, INBOX_DAYS = 7;
function jsonEnv(k) { try { return JSON.parse(process.env[k] || '{}'); } catch (e) { return {}; } }
const ACTIVE_DAYS = Object.assign({ free: 14, paid: 45 }, jsonEnv('PK_PUSH_ACTIVE_DAYS'));

// ---- 時刻（その人の地域） ----
function tzOk(tz) { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return !!tz; } catch (e) { return false; } }
function localParts(tz, ms) {
  const f = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23', weekday: 'long' });
  const p = {}; f.formatToParts(new Date(ms)).forEach(x => { p[x.type] = x.value; });
  return { day: `${p.year}-${p.month}-${p.day}`, hour: (+p.hour) % 24, minute: +p.minute, weekday: p.weekday };
}
// その人の「hour 時」が、UTC の何時の区切り（毎時0分の実行）に当たるか。夏時間の切り替えは送信のたびに付け直す
function utcHourFor(tz, hour, ms) {
  const base = Math.floor((ms || Date.now()) / 3600e3) * 3600e3;
  for (let k = 0; k < 24; k++) { const t = base + k * 3600e3; if (localParts(tz, t).hour === hour) return new Date(t).getUTCHours(); }
  return ((hour - 9) + 24) % 24;
}

// ---- 設定（auth.js の push_set から呼ぶ） ----
async function setPush(store, uid, o, now) {
  now = now || Date.now();
  const cur = (await store.get(`ps:${uid}`, { type: 'json' })) || {};
  const hour = Number.isInteger(+o.hour) && +o.hour >= 0 && +o.hour <= 23 ? +o.hour : (cur.hour != null ? cur.hour : 8);
  const tz = tzOk(String(o.tz || '')) ? String(o.tz) : (cur.tz || 'Asia/Tokyo');
  const token = o.token != null ? String(o.token).slice(0, 400) : (cur.token || '');
  const on = o.on != null ? !!o.on : !!cur.on;
  const lang = LANGS.includes(o.lang) ? o.lang : (cur.lang || 'ja');
  const platform = /^(ios|android)$/.test(o.platform) ? o.platform : (cur.platform || '');
  if (cur.bucket != null) await store.delete(`pb:${cur.bucket}:${uid}`);
  const next = Object.assign({}, cur, { on: on && !!token, token, hour, tz, lang, platform, updated: now, seen: now });
  next.bucket = next.on ? utcHourFor(tz, hour, now) : null;
  if (next.on) await store.set(`pb:${next.bucket}:${uid}`, '1');
  await store.setJSON(`ps:${uid}`, next);
  return { on: next.on, hour, tz };
}
// 受け取り箱：アプリを開いた時に呼ぶ。まだ表示していない分はアプリ側で id を見て足す。最後に開いた日時も記録する
async function takeInbox(store, uid, now) {
  now = now || Date.now();
  const box = (await store.get(`pi:${uid}`, { type: 'json' })) || { items: [] };
  const items = (box.items || []).filter(x => now - x.ts < INBOX_DAYS * 864e5);
  const ps = await store.get(`ps:${uid}`, { type: 'json' });
  if (ps) { ps.seen = now; await store.setJSON(`ps:${uid}`, ps); }
  return { items, push: ps ? { on: !!ps.on, hour: ps.hour } : { on: false } };
}
async function removeAll(store, uid) {
  const ps = await store.get(`ps:${uid}`, { type: 'json' }).catch(() => null);
  if (ps && ps.bucket != null) await store.delete(`pb:${ps.bucket}:${uid}`);
  await store.delete(`ps:${uid}`); await store.delete(`pi:${uid}`);
}

// ---- 文面づくり ----
function parse(s, d) { try { return JSON.parse(s); } catch (e) { return d; } }
function partOfDay(h) { return h < 5 ? 'late night' : h < 10 ? 'morning' : h < 14 ? 'around lunchtime' : h < 18 ? 'afternoon' : h < 22 ? 'evening' : 'night'; }
// 時間帯ごとに、触れてよいこと（朝8時に「お昼食べた？」とならないように）
const MOMENT = {
  'late night': 'It is late at night: only a soft "still up? rest well" kind of message. No meals, no "good morning".',
  morning: 'It is MORNING: a morning greeting, breakfast, sleep, or wishing them a good day. Never mention lunch, dinner, afternoon or evening.',
  'around lunchtime': 'It is around LUNCHTIME: lunch, a short break, or how the day is going. Never say good morning/evening or mention breakfast/dinner.',
  afternoon: 'It is AFTERNOON: a snack, a break, or cheering them through the rest of the day. Never say good morning or mention breakfast/dinner.',
  evening: 'It is EVENING: "good work today", dinner, or how the day went. Never say good morning or mention breakfast/lunch.',
  night: 'It is NIGHT: winding down, rest, sleep well. Never say good morning or mention breakfast/lunch.',
};
function stageOf(n) {
  if (n < 20) return 'NEW — you only recently met. Polite and warm (Japanese: です・ます; Korean: 존댓말 해요体; Chinese: gentle and polite). No teasing.';
  if (n < 60) return 'WARMING UP — you have talked a fair amount. Friendly and relaxed (Japanese: soft です・ます mixed with casual endings; Korean: friendly 해요体). A light joke is fine.';
  return 'CLOSE COMPANION — you are good friends. Casual (Japanese: タメ口; Korean: 반말; Thai: casual but kind). Gentle teasing is fine, like a close friend texting.';
}
// 名前は書かれたとおりに使う。返事の言語と文字が違う名前（中国語の返事に「Rie」など）は、訳したり音訳したりせず使わない
function nameLine(name, lang) {
  name = String(name || '').trim().slice(0, 30); if (!name) return '';
  const latin = /^[A-Za-z\s.'-]+$/.test(name), latinLang = ['en', 'es', 'pt', 'id', 'vi'].includes(lang);
  if (latin && !latinLang) return 'Do not use their name in this message.';
  return `Their name is "${name}". If you use it, write it exactly like that (never translate, transliterate or add particles to it), and only sometimes, not every time.`;
}
function buildPrompt(data, ps, now) {
  const lang = LANGS.includes(data.pk_lang) ? data.pk_lang : (ps.lang || 'ja');
  const prof = parse(data.pk_profile || '{}', {}) || {};
  const msgs = (parse(data.pk_msgs || '[]', []) || []).slice(-8).map(m => (m.role === 'me' ? 'USER: ' : 'NICO: ') + String(m.text || '').slice(0, 220)).join('\n');
  const lp = localParts(ps.tz || 'Asia/Tokyo', now);
  const hist = (ps.hist || []).map(x => '- ' + x).join('\n') || '(none yet)';
  const sex = prof.sex === 'male' ? 'male' : prof.sex === 'female' ? 'female' : '';
  const sys = [
    `You are Nico, the owl companion of the fortune-telling chat app "Pocket Kantei". You are sending ONE short push message to a user you know, the way a caring friend sends a text.`,
    `Write ONLY in ${LANG_NAME[lang]}. Output only the message itself — no quotes, no labels, no explanation.`,
    `Length: at most ${MAX_LEN[lang]} characters, one or two short sentences, at most one emoji.`,
    lang === 'es' ? 'Use Spanish punctuation: ¿…? and ¡…!.' : '',
    `Relationship stage: ${stageOf(+data.pk_tmsg || 0)}`,
    `It is ${lp.weekday}, ${lp.hour}:00 for them. ${MOMENT[partOfDay(lp.hour)]} Keep the time of day fixed; vary everything else.`,
    `About a third of the time, gently follow up on something from the notes or recent chat (an open item, a plan, a worry) — but in vague words only.`,
    `PRIVACY — this appears on the lock screen where family, coworkers or a partner may see it. Never name or hint at the specific topic: no people (no names, no family members like mother/father/partner/boss), no job interviews or job changes, no health, no money, no love or relationships, nothing painful. Only fully vague words: "that thing you mentioned", "how are things?", "hope it went okay". Wrong: "How is your mom?" / "Good luck with the interview!" Right: "How are things lately?" / "Hope that thing goes well."`,
    `If the notes or recent chat suggest they are going through something very hard (grief, thoughts of self-harm, deep exhaustion), send only a quiet, pressure-free message that you are here for them.`,
    `Do NOT: tell fortunes, mention luck, lucky colours, stars or elements, predict anything, give medical/legal/financial advice, promote plans or purchases, ask them to open the app, mention being an AI, or mention notes or memory.`,
    `Do NOT repeat or paraphrase any of the RECENT MESSAGES YOU SENT; start differently from each of them.`,
    nameLine(prof.name, lang),
    sex && (lang === 'es' || lang === 'pt') ? `The user is ${sex}; use matching grammatical gender.` : '',
  ].filter(Boolean).join('\n');
  const user = `[NOTES ABOUT THEM]\n${String(data.pk_mem || '(none)').slice(0, 1600)}\n\n[RECENT CHAT]\n${msgs || '(none)'}\n\n[RECENT MESSAGES YOU SENT]\n${hist}`;
  return { lang, sys, user };
}
// 書いた言語が合っているかの簡易チェック
function langOk(t, lang) {
  const kana = /[぀-ヿ]/.test(t), han = /[一-鿿]/.test(t), hangul = /[가-힯]/.test(t), thai = /[฀-๿]/.test(t), latin = /[A-Za-z]{3,}/.test(t);
  if (lang === 'ja') return kana && !hangul && !thai;
  if (lang === 'zh' || lang === 'zt') return han && !kana && !hangul && !thai;
  if (lang === 'ko') return hangul && !kana && !thai;
  if (lang === 'th') return thai && !kana && !hangul;
  if (lang === 'vi') return /[ăâđêôơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]/i.test(t) && !kana && !han && !hangul && !thai;
  if (!(latin && !kana && !han && !hangul && !thai)) return false;
  if (/[¿¡ñ]/i.test(t) && lang !== 'es') return false;
  if (/[ãõç]/i.test(t) && lang !== 'pt') return false;
  // 英語のはずがスペイン語になった時など：よく使う短い単語の数で見分ける
  const w = (' ' + t.toLowerCase().replace(/[^a-záéíóúâêôãõçñü\s']/g, ' ') + ' ').replace(/\s+/g, ' ');
  const score = k => WORDS[k].split(' ').reduce((n, x) => n + (w.includes(' ' + x + ' ') ? 1 : 0), 0);
  const sc = { en: score('en'), es: score('es'), pt: score('pt'), id: score('id') };
  const best = Object.keys(sc).sort((a, b) => sc[b] - sc[a])[0];
  return !(sc[best] >= 2 && best !== lang && sc[best] > (sc[lang] || 0));
}
const WORDS = {
  en: 'the you your have hope good morning did how are is to and it day today with that',
  es: 'que el la tu ya hola espero buenos días te con es un una cómo qué todo bien',
  pt: 'você que já bom dia oi tudo seu sua com um uma espero tá pra como',
  id: 'sudah ya semoga kamu selamat belum hari makan pagi siang malam udah apa kabar',
};
// 以前の文面と似すぎていないか（8文字のかたまりが6割以上重なる）
function tooSimilar(t, hist) {
  const g = s => { const x = String(s).replace(/\s+/g, ''); const o = new Set(); for (let i = 0; i + 8 <= x.length; i++) o.add(x.slice(i, i + 8)); return o; };
  const a = g(t); if (!a.size) return false;
  return (hist || []).some(h => { const b = g(h); let n = 0; a.forEach(x => { if (b.has(x)) n++; }); return n / a.size >= 0.6; });
}
function tidy(t) { return String(t || '').trim().replace(/^["'「『“]+|["'」』”]+$/g, '').replace(/\n+/g, ' ').trim(); }

async function generate(data, ps, now, fetchFn) {
  const key = process.env.GEMINI_API_KEY; if (!key) return { text: '', why: 'NO_KEY' };
  const model = process.env.PK_PUSH_MODEL || process.env.GEMINI_MODEL || 'gemini-2.5-flash-lite';
  const P = buildPrompt(data, ps, now);
  let yen = 0;
  for (let tries = 0; tries < 2; tries++) {
    const gc = { temperature: 1.0, maxOutputTokens: 220 };
    if (!/gemini-3/.test(model)) gc.thinkingConfig = { thinkingBudget: 0 };
    const body = { systemInstruction: { parts: [{ text: P.sys }] }, contents: [{ role: 'user', parts: [{ text: P.user }] }], generationConfig: gc };
    let j = null;
    try {
      const r = await fetchFn(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!r.ok) continue;
      j = await r.json();
    } catch (e) { continue; }
    yen += costYen(j && j.usageMetadata);
    const t = tidy((((j && j.candidates) || [])[0] || {}).content && j.candidates[0].content.parts.map(p => p.text || '').join(''));
    if (t && t.length <= MAX_LEN[P.lang] * 1.3 && langOk(t, P.lang) && !tooSimilar(t, ps.hist)) return { text: t, lang: P.lang, yen };
  }
  return { text: '', why: 'BAD_OUTPUT', yen };
}
function costYen(u) {
  u = u || {};
  let pr = { in: 0.10, out: 0.40 }; try { const p = JSON.parse(process.env.PK_AI_PRICES || '{}'); if (p.lite) pr = Object.assign(pr, p.lite); } catch (e) {}
  const fx = +process.env.PK_FX || 150;
  return ((+u.promptTokenCount || 0) * pr.in + ((+u.candidatesTokenCount || 0) + (+u.thoughtsTokenCount || 0)) * pr.out) / 1e6 * fx;
}

// ---- 送信（Firebase Cloud Messaging HTTP v1） ----
let _fcmTok = null;
function b64u(x) { return Buffer.from(x).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_'); }
function fcmCreds() {
  const project = process.env.FCM_PROJECT_ID, email = process.env.FCM_CLIENT_EMAIL, pk = String(process.env.FCM_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  return (project && email && /PRIVATE KEY/.test(pk)) ? { project, email, pk } : null;
}
async function fcmAccess(fetchFn, now) {
  if (_fcmTok && _fcmTok.exp > now + 60e3) return _fcmTok.tok;
  const c = fcmCreds(); if (!c) return '';
  const iat = Math.floor(now / 1000);
  const head = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = b64u(JSON.stringify({ iss: c.email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: 'https://oauth2.googleapis.com/token', iat, exp: iat + 3600 }));
  const sig = crypto.createSign('RSA-SHA256').update(`${head}.${claim}`).sign(c.pk).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
  const r = await fetchFn('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `grant_type=${encodeURIComponent('urn:ietf:params:oauth:grant-type:jwt-bearer')}&assertion=${head}.${claim}.${sig}` });
  if (!r.ok) return '';
  const j = await r.json();
  _fcmTok = { tok: j.access_token, exp: now + (+j.expires_in || 3600) * 1000 };
  return _fcmTok.tok;
}
async function fcmSend(fetchFn, token, text, id, now) {
  const c = fcmCreds(); if (!c) return { ok: false, code: 'NO_FCM' };
  const at = await fcmAccess(fetchFn, now); if (!at) return { ok: false, code: 'FCM_AUTH' };
  const message = {
    token,
    notification: { title: TITLE, body: text },
    data: { kind: 'nico', id },
    android: { priority: 'normal', notification: { tag: 'nico' } },
    apns: { payload: { aps: { sound: 'default', 'thread-id': 'nico' } } },
  };
  const r = await fetchFn(`https://fcm.googleapis.com/v1/projects/${c.project}/messages:send`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${at}` }, body: JSON.stringify({ message }) });
  if (r.ok) return { ok: true };
  let t = ''; try { t = await r.text(); } catch (e) {}
  // アプリを消した・通知を切った端末：以後は送らない
  const gone = r.status === 404 || /UNREGISTERED|registration-token-not-registered/i.test(t) || (r.status === 400 && /INVALID_ARGUMENT/.test(t) && /token/i.test(t));
  return { ok: false, gone, code: 'FCM_' + r.status };
}

// ---- 1人ぶんの処理 ----
async function processUser(store, usage, uid, now, deps) {
  const fetchFn = (deps && deps.fetch) || fetch;
  const ps = await store.get(`ps:${uid}`, { type: 'json' });
  if (!ps || !ps.on || !ps.token) { if (ps && ps.bucket != null) await store.delete(`pb:${ps.bucket}:${uid}`); return 'off'; }
  const lp = localParts(ps.tz, now);
  if (lp.hour !== ps.hour) {                                   // 夏時間などで時刻がずれた：正しい区切りに付け直す
    const nb = utcHourFor(ps.tz, ps.hour, now);
    if (nb !== ps.bucket) { await store.delete(`pb:${ps.bucket}:${uid}`); ps.bucket = nb; await store.set(`pb:${nb}:${uid}`, '1'); await store.setJSON(`ps:${uid}`, ps); }
    return 'moved';
  }
  if (ps.lastDay === lp.day) return 'done';
  const rec = await store.get(`u:${uid}`, { type: 'json' });
  if (!rec) { await removeAll(store, uid); return 'gone'; }
  const A = require('./auth.js')._t;
  const pi = A.planInfo(rec), paid = pi.plan !== 'free';
  const seen = +ps.seen || +rec.updated || 0;
  if (now - seen > (paid ? ACTIVE_DAYS.paid : ACTIVE_DAYS.free) * 864e5) return 'inactive';
  const g = await generate(rec.data || {}, ps, now, fetchFn);
  if (paid && usage && g.yen > 0) await addCost(usage, uid, pi, g.yen);
  if (!g.text) return 'nogen';
  const id = 'n' + now.toString(36) + crypto.randomBytes(3).toString('hex');
  const s = await fcmSend(fetchFn, ps.token, g.text, id, now);
  if (!s.ok) {
    if (s.gone) { ps.on = false; ps.token = ''; await store.delete(`pb:${ps.bucket}:${uid}`); ps.bucket = null; await store.setJSON(`ps:${uid}`, ps); return 'unregistered'; }
    return 'sendfail';
  }
  const box = (await store.get(`pi:${uid}`, { type: 'json' })) || { items: [] };
  box.items = (box.items || []).filter(x => now - x.ts < INBOX_DAYS * 864e5).concat([{ id, text: g.text, ts: now }]).slice(-INBOX_KEEP);
  await store.setJSON(`pi:${uid}`, box);
  // 送っている間に設定が変わっていても上書きしないよう、読み直してから記録する
  const ps2 = (await store.get(`ps:${uid}`, { type: 'json' })) || ps;
  ps2.lastDay = lp.day; ps2.hist = (ps2.hist || []).concat([g.text]).slice(-HIST_KEEP);
  await store.setJSON(`ps:${uid}`, ps2);
  return 'sent';
}
// 有料プランは、この文面の原価も1か月の「AI原価の上限」に含める（gemini.js と同じキー）
async function addCost(usage, uid, pi, yen) {
  try {
    const G = require('./gemini.js')._t;
    const day = new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 10);
    const ym = G.subWindow(pi.start, pi.expires, day).id, sen = Math.ceil(yen * 100);
    for (const k of [`c:${ym}:${uid}`, `cd:${day}:${uid}`]) { const v = await usage.get(k, { type: 'json' }).catch(() => null); await usage.setJSON(k, { n: ((v && v.n) || 0) + sen, t: Date.now() }); }
  } catch (e) {}
}
// ---- 毎時：この時刻（UTC）の人に送る ----
async function runHour(store, usage, utcHour, now, deps) {
  const t0 = Date.now(), limitMs = (deps && deps.limitMs) || 13 * 60e3;
  const list = await store.list({ prefix: `pb:${utcHour}:` });
  const uids = (list.blobs || []).map(b => b.key.split(':')[2]).filter(Boolean);
  const out = {};
  let i = 0;
  const worker = async () => {
    while (i < uids.length && Date.now() - t0 < limitMs) {
      const uid = uids[i++];
      let r; try { r = await processUser(store, usage, uid, now, deps); } catch (e) { r = 'error'; }
      out[r] = (out[r] || 0) + 1;
    }
  };
  await Promise.all(Array.from({ length: (deps && deps.concurrency) || 8 }, worker));
  return { total: uids.length, out };
}
function pushSecret() { return crypto.createHmac('sha256', process.env.AUTH_SECRET || '').update('nico-push').digest('hex'); }

module.exports = { setPush, takeInbox, removeAll, processUser, runHour, pushSecret, _t: { localParts, utcHourFor, buildPrompt, langOk, tooSimilar, tidy, stageOf, fcmSend, generate, MAX_LEN } };
