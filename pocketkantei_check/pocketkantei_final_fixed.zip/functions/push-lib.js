// ニコからのメッセージ（プッシュ通知）の中身。関数本体は nico-push.mjs（毎時の予約）と nico-push-background.mjs（送信）。
// ・1日1回、利用者が選んだ時刻（その人の地域の時刻）に、ニコが短いメッセージを送る（「おはよう」「ご飯食べた？」「あの件どうなった？」など）。
// ・文面は毎回AI（軽量モデル）が、その人との距離感・会話のメモ・最近の会話・時間帯から作る。運勢の案内はしない。
// ・通知はロック画面に出るので、ほかの人の名前・健康・お金・恋愛の具体的な話・つらい話題は文面に入れない。
// ・送ったメッセージは受け取り箱（pi:<uid>）にも入れ、アプリを開いた時にニコの発言としてチャットに表示する。
// ・送信は Firebase Cloud Messaging（FCM HTTP v1）。iPhone も FCM 経由（Firebase に APNs 認証キーを登録しておく）。
//
// 保存先（Netlify Blobs ストア pk-accounts）
//   ps:<uid>          … 設定と記録 { on, token, platform, hour, tz, lang, bucket, lastDay, hist:[直近の文面], seen, updated }
//   pb:<UTCの時>:<uid> … その時刻（UTC）に送る人の目印（毎時、その時刻の人だけを読む）
//   pi:<uid>          … 受け取り箱 { items:[{ id, text, ts }] }（最新10件・7日まで）
//
// 環境変数
//   FCM_PROJECT_ID / FCM_CLIENT_EMAIL / FCM_PRIVATE_KEY … Firebase のサービスアカウント（秘密鍵は \n を含む1行のまま貼ってよい）
//   PK_PUSH_MODEL（任意） … 文面を作るモデル。既定は GEMINI_MODEL（軽量）
//   PK_PUSH_ACTIVE_DAYS（任意）… 最後にアプリを開いてから、この日数を過ぎた人には送らない。既定 {"free":14,"paid":45}
const crypto = require('crypto');

const LANGS = ['ja', 'en', 'zh', 'zt', 'ko', 'vi', 'es', 'pt', 'id', 'th'];
const LANG_NAME = { ja: 'Japanese', en: 'English', zh: 'Simplified Chinese', zt: 'Traditional Chinese (Taiwan)', ko: 'Korean', vi: 'Vietnamese', es: 'Spanish', pt: 'Portuguese (Brazil)', id: 'Indonesian', th: 'Thai' };
// 1通の長さの上限（文字数）。ロック画面で読み切れる長さ
const MAX_LEN = { ja: 70, zh: 55, zt: 55, ko: 80, th: 110, en: 150, es: 150, pt: 150, id: 150, vi: 150 };
const TITLE = 'Nico 🦉';
const HIST_KEEP = 10, INBOX_KEEP = 10, INBOX_DAYS = 7;
function jsonEnv(k) { try { return JSON.parse(process.env[k] || '{}'); } catch (e) { return {}; } }
const ACTIVE_DAYS = Object.assign({ free: 14, paid: 45 }, jsonEnv('PK_PUSH_ACTIVE_DAYS'));

// ---- 時刻（その人の地域） ----
function tzOk(tz) { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return !!tz; } catch (e) { return false; } }
function localParts(tz, ms) {
  const f = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23', weekday: 'long' });
  const p = {}; f.formatToParts(new Date(ms)).forEach(x => { p[x.type] = x.value; });
  return { day: `${p.year}-${p.month}-${p.day}`, hour: (+p.hour) % 24, minute: +p.minute, weekday: p.weekday };
}
// その人の「hour 時」が、UTC の何時の区切り（毎時0分の実行）に当たるか。夏時間の切り替えは送信のたびに付け直す
function utcHourFor(tz, hour, ms) {
  const base = Math.floor((ms || Date.now()) / 3600e3) * 3600e3;
  for (let k = 0; k < 24; k++) { const t = base + k * 3600e3; if (localParts(tz, t).hour === hour) return new Date(t).getUTCHours(); }
  return ((hour - 9) + 24) % 24;
}

// ---- 送る時刻 ----
// mode: 'auto'（ニコにおまかせ＝毎日ちがう時間帯。既定）／'fixed'（決まった時刻 hour）
// おまかせは、朝・お昼・午後・夕方・夜の中から、前回と違う時間帯を選ぶ（その人の地域の 8〜21時。深夜・早朝は送らない）
const AUTO_SLOTS = [[8, 9], [12, 12], [15, 16], [18, 19], [20, 21]];
function slotOf(h) { return AUTO_SLOTS.findIndex(r => h >= r[0] && h <= r[1]); }
function pickAutoHour(lastHour, rnd) {
  rnd = rnd || Math.random;
  const last = slotOf(lastHour);
  const choices = AUTO_SLOTS.filter((r, i) => i !== last);
  const r = choices[Math.floor(rnd() * choices.length)];
  return r[0] + Math.floor(rnd() * (r[1] - r[0] + 1));
}
function aimHour(ps) { return ps.mode === 'fixed' ? ps.hour : ps.target; }
// 目印（pb:）を、その人の地域でその時刻になる UTC の区切りに付け直す
async function rebucket(store, uid, ps, now) {
  const nb = ps.on ? utcHourFor(ps.tz, aimHour(ps), now) : null;
  if (ps.bucket != null && ps.bucket !== nb) await store.delete(`pb:${ps.bucket}:${uid}`);
  if (nb != null) await store.set(`pb:${nb}:${uid}`, '1');
  ps.bucket = nb;
}

// ---- 設定（auth.js の push_set から呼ぶ） ----
async function setPush(store, uid, o, now) {
  now = now || Date.now();
  const cur = (await store.get(`ps:${uid}`, { type: 'json' })) || {};
  const hour = Number.isInteger(+o.hour) && +o.hour >= 0 && +o.hour <= 23 ? +o.hour : (cur.hour != null ? cur.hour : 8);
  const mode = o.mode === 'fixed' || o.mode === 'auto' ? o.mode : (cur.mode || 'auto');
  const tz = tzOk(String(o.tz || '')) ? String(o.tz) : (cur.tz || 'Asia/Tokyo');
  const token = o.token != null ? String(o.token).slice(0, 400) : (cur.token || '');
  const on = o.on != null ? !!o.on : !!cur.on;
  const lang = LANGS.includes(o.lang) ? o.lang : (cur.lang || 'ja');
  const platform = /^(ios|android)$/.test(o.platform) ? o.platform : (cur.platform || '');
  const next = Object.assign({}, cur, { on: on && !!token, token, mode, hour, tz, lang, platform, updated: now, seen: now });
  if (mode === 'auto' && next.target == null) next.target = pickAutoHour(localParts(tz, now).hour);
  await rebucket(store, uid, next, now);
  await store.setJSON(`ps:${uid}`, next);
  return { on: next.on, mode, hour, tz };
}
// 受け取り箱：アプリを開いた時に呼ぶ。まだ表示していない分はアプリ側で id を見て足す。
// 最後に開いた日時と、今いる地域（旅行・引っ越しで変わる）も記録し直す
async function takeInbox(store, uid, now, tz) {
  now = now || Date.now();
  const box = (await store.get(`pi:${uid}`, { type: 'json' })) || { items: [] };
  const items = (box.items || []).filter(x => now - x.ts < INBOX_DAYS * 864e5);
  const ps = await store.get(`ps:${uid}`, { type: 'json' });
  if (ps) {
    ps.seen = now;
    if (tz && tzOk(String(tz)) && String(tz) !== ps.tz) { ps.tz = String(tz); await rebucket(store, uid, ps, now); }
    await store.setJSON(`ps:${uid}`, ps);
  }
  return { items, push: ps ? { on: !!ps.on, mode: ps.mode || 'auto', hour: ps.hour } : { on: false } };
}
async function removeAll(store, uid) {
  const ps = await store.get(`ps:${uid}`, { type: 'json' }).catch(() => null);
  if (ps && ps.bucket != null) await store.delete(`pb:${ps.bucket}:${uid}`);
  await store.delete(`ps:${uid}`); await store.delete(`pi:${uid}`);
}

// ---- 文面づくり ----
function parse(s, d) { try { return JSON.parse(s); } catch (e) { return d; } }
function partOfDay(h) { return h < 5 ? 'late night' : h < 10 ? 'morning' : h < 14 ? 'around lunchtime' : h < 18 ? 'afternoon' : h < 22 ? 'evening' : 'night'; }
// 時間帯ごとに、触れてよいこと（朝8時に「お昼食べた？」とならないように）
const MOMENT = {
  'late night': 'It is late at night: only a soft "still up? rest well" kind of message. No meals, no "good morning".',
  morning: 'It is MORNING: a morning greeting, breakfast, sleep, or wishing them a good day. Never mention lunch, dinner, afternoon or evening.',
  'around lunchtime': 'It is around LUNCHTIME: lunch, a short break, or how the day is going. Never say good morning/evening or mention breakfast/dinner.',
  afternoon: 'It is AFTERNOON: a snack, a break, or cheering them through the rest of the day. Never say good morning or mention breakfast/dinner.',
  evening: 'It is EVENING: "good work today", dinner, or how the day went. Never say good morning or mention breakfast/lunch.',
  night: 'It is NIGHT: winding down, rest, sleep well. Never say good morning or mention breakfast/lunch.',
};
function stageOf(n) {
  if (n < 20) return 'NEW — you only recently met. Polite and warm (Japanese: です・ます; Korean: 존댓말 해요体; Chinese: gentle and polite). No teasing.';
  if (n < 60) return 'WARMING UP — you have talked a fair amount. Friendly and relaxed (Japanese: soft です・ます mixed with casual endings; Korean: friendly 해요体). A light joke is fine.';
  return 'CLOSE COMPANION — you are good friends. Casual (Japanese: タメ口; Korean: 반말; Thai: casual but kind). Gentle teasing is fine, like a close friend texting.';
}
// 名前は書かれたとおりに使う。返事の言語と文字が違う名前（中国語の返事に「Rie」など）は、訳したり音訳したりせず使わない
function nameLine(name, lang) {
  name = String(name || '').trim().slice(0, 30); if (!name) return '';
  const latin = /^[A-Za-z\s.'-]+$/.test(name), latinLang = ['en', 'es', 'pt', 'id', 'vi'].includes(lang);
  if (latin && !latinLang) return 'Do not use their name in this message.';
  return `Their name is "${name}". If you use it, write it exactly like that (never translate, transliterate or add particles to it), and only sometimes, not every time.`;
}
function buildPrompt(data, ps, now) {
  const lang = LANGS.includes(data.pk_lang) ? data.pk_lang : (ps.lang || 'ja');
  const prof = parse(data.pk_profile || '{}', {}) || {};
  const msgs = (parse(data.pk_msgs || '[]', []) || []).slice(-8).map(m => (m.role === 'me' ? 'USER: ' : 'NICO: ') + String(m.text || '').slice(0, 220)).join('\n');
  const lp = localParts(ps.tz || 'Asia/Tokyo', now);
  const hist = (ps.hist || []).map(x => '- ' + x).join('\n') || '(none yet)';
  const sex = prof.sex === 'male' ? 'male' : prof.sex === 'female' ? 'female' : '';
  const sys = [
    `You are Nico, the owl companion of the fortune-telling chat app "Pocket Kantei". You are sending ONE short push message to a user you know, the way a caring friend sends a text.`,
    `Write ONLY in ${LANG_NAME[lang]}. Output only the message itself — no quotes, no labels, no explanation.`,
    `Length: at most ${MAX_LEN[lang]} characters, one or two short sentences, at most one emoji.`,
    lang === 'es' ? 'Use Spanish punctuation: ¿…? and ¡…!.' : '',
    `Relationship stage: ${stageOf(+data.pk_tmsg || 0)}`,
    `It is ${lp.weekday}, ${lp.hour}:00 for them. ${MOMENT[partOfDay(lp.hour)]} Keep the time of day fixed; vary everything else.`,
    dayRule(lp.weekday, Math.random() < 0.25),
    `About a third of the time, gently follow up on something from the notes or recent chat (an open item, a plan, a worry) — but in vague words only.`,
    `PRIVACY — this appears on the lock screen where family, coworkers or a partner may see it. Never name or hint at the specific topic: no people (no names, no family members like mother/father/partner/boss), no job interviews or job changes, no health, no money, no love or relationships, nothing painful. Only fully vague words: "that thing you mentioned", "how are things?", "hope it went okay". Wrong: "How is your mom?" / "Good luck with the interview!" Right: "How are things lately?" / "Hope that thing goes well."`,
    `If the notes or recent chat suggest they are going through something very hard (grief, thoughts of self-harm, deep exhaustion), send only a quiet, pressure-free message that you are here for them.`,
    `Do NOT: tell fortunes, mention luck, lucky colours, stars or elements, predict anything, give medical/legal/financial advice, promote plans or purchases, ask them to open the app, mention being an AI, or mention notes or memory.`,
    `Do NOT repeat or paraphrase any of the RECENT MESSAGES YOU SENT; start differently from each of them.`,
    nameLine(prof.name, lang),
    sex && (lang === 'es' || lang === 'pt') ? `The user is ${sex}; use matching grammatical gender.` : '',
  ].filter(Boolean).join('\n');
  const user = `[NOTES ABOUT THEM]\n${String(data.pk_mem || '(none)').slice(0, 1600)}\n\n[RECENT CHAT]\n${msgs || '(none)'}\n\n[RECENT MESSAGES YOU SENT]\n${hist}`;
  return { lang, sys, user };
}
// 書いた言語が合っているかの簡易チェック
function langOk(t, lang) {
  const kana = /[぀-ヿ]/.test(t), han = /[一-鿿]/.test(t), hangul = /[가-힯]/.test(t), thai = /[฀-๿]/.test(t), latin = /[A-Za-z]{3,}/.test(t);
  if (lang === 'ja') return kana && !hangul && !thai;
  if (lang === 'zh' || lang === 'zt') return han && !kana && !hangul && !thai;
  if (lang === 'ko') return hangul && !kana && !thai;
  if (lang === 'th') return thai && !kana && !hangul;
  if (lang === 'vi') return /[ăâđêôơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]/i.test(t) && !kana && !han && !hangul && !thai;
  if (!(latin && !kana && !han && !hangul && !thai)) return false;
  if (/[¿¡ñ]/i.test(t) && lang !== 'es') return false;
  if (/[ãõç]/i.test(t) && lang !== 'pt') return false;
  // 英語のはずがスペイン語になった時など：よく使う短い単語の数で見分ける
  const w = (' ' + t.toLowerCase().replace(/[^a-záéíóúâêôãõçñü\s']/g, ' ') + ' ').replace(/\s+/g, ' ');
  const score = k => WORDS[k].split(' ').reduce((n, x) => n + (w.includes(' ' + x + ' ') ? 1 : 0), 0);
  const sc = { en: score('en'), es: score('es'), pt: score('pt'), id: score('id') };
  const best = Object.keys(sc).sort((a, b) => sc[b] - sc[a])[0];
  return !(sc[best] >= 2 && best !== lang && sc[best] > (sc[lang] || 0));
}
const WORDS = {
  en: 'the you your have hope good morning did how are is to and it day today with that',
  es: 'que el la tu ya hola espero buenos días te con es un una cómo qué todo bien',
  pt: 'você que já bom dia oi tudo seu sua com um uma espero tá pra como',
  id: 'sudah ya semoga kamu selamat belum hari makan pagi siang malam udah apa kabar',
};
// 時間帯に合わない言葉（夜の「おはよう」、朝の「晩ご飯」など）が入っていないか。入っていたら作り直す
const TIME_WORDS = {
  morning: { ja: /おはよ|朝ご?はん|朝ごはん|朝食/, en: /good morning|breakfast/i, zh: /早上好|早安|早餐|早饭/, zt: /早上好|早安|早餐/, ko: /좋은 아침|아침 (식사|밥)|아침은/, vi: /chào buổi sáng|ăn sáng|bữa sáng/i, es: /buenos d[ií]as|desayun/i, pt: /bom dia|caf[ée] da manh[ãa]/i, id: /selamat pagi|sarapan/i, th: /อรุณสวัสดิ์|สวัสดีตอนเช้า|มื้อเช้า|ข้าวเช้า/ },
  lunch: { ja: /お昼ご?はん|昼ご?はん|ランチ|お昼は/, en: /\blunch/i, zh: /午饭|午餐|午安/, zt: /午餐|午飯|午安/, ko: /점심/, vi: /ăn trưa|bữa trưa|buổi trưa/i, es: /almuerz|almorz/i, pt: /almo[çc]/i, id: /makan siang|selamat siang/i, th: /มื้อเที่ยง|ข้าวเที่ยง|ตอนเที่ยง/ },
  night: { ja: /こんばんは|おやすみ|晩ご?はん|夕ご?はん|夕飯|夜ご?はん/, en: /good (evening|night)|dinner/i, zh: /晚上好|晚安|晚饭|晚餐/, zt: /晚上好|晚安|晚飯|晚餐/, ko: /잘 자|좋은 밤|저녁/, vi: /buổi tối|ngủ ngon|ăn tối|bữa tối/i, es: /buenas noches|cen[ae]|cenaste/i, pt: /boa noite|jant/i, id: /selamat malam|makan malam/i, th: /ราตรีสวัสดิ์|ฝันดี|มื้อเย็น|ข้าวเย็น|ตอนเย็น/ },
};
// 曜日：言うなら正確に。「週の始まり」は月曜だけ、「週末」は木〜日曜だけ
const WD = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
function dayRule(weekday, mayMention) {
  // 曜日に触れるのは4回に1回くらい（毎回だと決まり文句に見える）。触れない回は、曜日も週末の話もしない
  if (!mayMention) return `(Today is ${weekday}.) In this message, do NOT mention any day of the week, the weekend, or the start of the week.`;
  const d = WD.indexOf(weekday);
  const ok = [d === 1 ? '"start of the week" is fine today' : 'do NOT say "start of the week" / "new week" (today is not Monday)',
    d >= 4 || d === 0 ? '"the weekend" is fine to mention' : 'do NOT mention the weekend (it is still mid-week)'];
  return `Today is ${weekday} — the ONLY correct day. If you mention a day of the week, it must be ${weekday}; never mention tomorrow's or any other day's name. ${ok.join('; ')}. When unsure, do not mention it at all.`;
}
// 各言語の曜日の言い方（日曜=0 … 土曜=6）と、「週の始まり」「週末」の言い方
const DAY_WORDS = {
  ja: [/日曜/, /月曜/, /火曜/, /水曜/, /木曜/, /金曜|花金/, /土曜/],
  en: [/sunday/i, /monday/i, /tuesday/i, /wednesday/i, /thursday/i, /friday|\bTGIF/i, /saturday/i],
  zh: [/(周|星期|礼拜)(日|天)/, /(周|星期|礼拜)一/, /(周|星期|礼拜)二/, /(周|星期|礼拜)三/, /(周|星期|礼拜)四/, /(周|星期|礼拜)五/, /(周|星期|礼拜)六/],
  zt: [/(週|周|星期|禮拜)(日|天)/, /(週|周|星期|禮拜)一/, /(週|周|星期|禮拜)二/, /(週|周|星期|禮拜)三/, /(週|周|星期|禮拜)四/, /(週|周|星期|禮拜)五/, /(週|周|星期|禮拜)六/],
  ko: [/일요일/, /월요일/, /화요일/, /수요일/, /목요일/, /금요일|불금/, /토요일/],
  vi: [/chủ nhật/i, /thứ hai/i, /thứ ba/i, /thứ tư/i, /thứ năm/i, /thứ sáu/i, /thứ bảy/i],
  es: [/domingo/i, /lunes/i, /martes/i, /mi[ée]rcoles/i, /jueves/i, /viernes/i, /s[áa]bado/i],
  pt: [/domingo/i, /segunda-feira|segundou/i, /ter[çc]a-feira/i, /quarta-feira/i, /quinta-feira/i, /sexta(-feira)?|sextou/i, /s[áa]bado/i],
  id: [/hari minggu/i, /senin/i, /selasa/i, /rabu/i, /kamis/i, /jum'?at/i, /sabtu/i],
  th: [/วันอาทิตย์/, /วันจันทร์/, /วันอังคาร/, /วันพุธ/, /วันพฤหัส/, /วันศุกร์|ศุกร์นี้/, /วันเสาร์/],
};
const WEEK_START = { ja: /週明け|週の(始|はじ)まり|新しい一週間/, en: /start of the week|new week|week ahead/i, zh: /新的一周|一周的开始|周初/, zt: /新的一週|一週的開始|週初/, ko: /한 주의 시작|새로운 한 주|새 한 주|월요병/, vi: /đầu tuần|tuần mới/i, es: /(comienzo|inicio|principio) de (la )?semana|nueva semana/i, pt: /(come[çc]o|in[íi]cio) da semana|nova semana/i, id: /awal (minggu|pekan)|minggu baru|pekan baru/i, th: /ต้นสัปดาห์|สัปดาห์ใหม่/ };
const WEEKEND = { ja: /週末|土日|休日|お休みの日/, en: /weekend/i, zh: /周末/, zt: /週末|周末/, ko: /주말/, vi: /cuối tuần/i, es: /fin de semana|finde/i, pt: /fim de semana|fds/i, id: /akhir (minggu|pekan)|weekend/i, th: /สุดสัปดาห์|วันหยุด/ };
function dayOk(t, lang, weekday) {
  const d = WD.indexOf(weekday); if (d < 0) return true;
  const list = DAY_WORDS[lang] || [];
  for (let i = 0; i < 7; i++) if (i !== d && list[i] && list[i].test(t)) return false;   // 今日ではない曜日の名前
  if (WEEK_START[lang] && WEEK_START[lang].test(t) && d !== 1) return false;               // 月曜以外に「週の始まり」
  if (WEEKEND[lang] && WEEKEND[lang].test(t) && !(d >= 4 || d === 0)) return false;       // 月〜水曜に「週末」
  return true;
}
function timeOk(t, lang, h) {
  const has = k => { const re = TIME_WORDS[k][lang]; return !!(re && re.test(t)); };
  if (has('morning') && !(h >= 4 && h <= 11)) return false;
  if (has('lunch') && !(h >= 11 && h <= 14)) return false;
  if (has('night') && !(h >= 17 || h <= 3)) return false;
  return true;
}
// 以前の文面と似すぎていないか（8文字のかたまりが6割以上重なる）
function tooSimilar(t, hist) {
  const g = s => { const x = String(s).replace(/\s+/g, ''); const o = new Set(); for (let i = 0; i + 8 <= x.length; i++) o.add(x.slice(i, i + 8)); return o; };
  const a = g(t); if (!a.size) return false;
  return (hist || []).some(h => { const b = g(h); let n = 0; a.forEach(x => { if (b.has(x)) n++; }); return n / a.size >= 0.6; });
}
function tidy(t) { return String(t || '').trim().replace(/^["'「『“]+|["'」』”]+$/g, '').replace(/\n+/g, ' ').trim(); }

async function generate(data, ps, now, fetchFn) {
  const key = process.env.GEMINI_API_KEY; if (!key) return { text: '', why: 'NO_KEY' };
  const model = process.env.PK_PUSH_MODEL || process.env.GEMINI_MODEL || 'gemini-2.5-flash-lite';
  const P = buildPrompt(data, ps, now);
  let yen = 0;
  for (let tries = 0; tries < 2; tries++) {
    const gc = { temperature: 1.0, maxOutputTokens: 220 };
    if (!/gemini-3/.test(model)) gc.thinkingConfig = { thinkingBudget: 0 };
    const body = { systemInstruction: { parts: [{ text: P.sys }] }, contents: [{ role: 'user', parts: [{ text: P.user }] }], generationConfig: gc };
    let j = null;
    try {
      const r = await fetchFn(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!r.ok) continue;
      j = await r.json();
    } catch (e) { continue; }
    yen += costYen(j && j.usageMetadata);
    const t = tidy((((j && j.candidates) || [])[0] || {}).content && j.candidates[0].content.parts.map(p => p.text || '').join(''));
    if (t && t.length <= MAX_LEN[P.lang] * 1.3 && langOk(t, P.lang) && timeOk(t, P.lang, localParts(ps.tz || 'Asia/Tokyo', now).hour) && dayOk(t, P.lang, localParts(ps.tz || 'Asia/Tokyo', now).weekday) && !tooSimilar(t, ps.hist)) return { text: t, lang: P.lang, yen };
  }
  return { text: '', why: 'BAD_OUTPUT', yen };
}
function costYen(u) {
  u = u || {};
  let pr = { in: 0.10, out: 0.40 }; try { const p = JSON.parse(process.env.PK_AI_PRICES || '{}'); if (p.lite) pr = Object.assign(pr, p.lite); } catch (e) {}
  const fx = +process.env.PK_FX || 150;
  return ((+u.promptTokenCount || 0) * pr.in + ((+u.candidatesTokenCount || 0) + (+u.thoughtsTokenCount || 0)) * pr.out) / 1e6 * fx;
}

// ---- 送信（Firebase Cloud Messaging HTTP v1） ----
let _fcmTok = null;
function b64u(x) { return Buffer.from(x).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_'); }
function fcmCreds() {
  const project = process.env.FCM_PROJECT_ID, email = process.env.FCM_CLIENT_EMAIL, pk = String(process.env.FCM_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  return (project && email && /PRIVATE KEY/.test(pk)) ? { project, email, pk } : null;
}
async function fcmAccess(fetchFn, now) {
  if (_fcmTok && _fcmTok.exp > now + 60e3) return _fcmTok.tok;
  const c = fcmCreds(); if (!c) return '';
  const iat = Math.floor(now / 1000);
  const head = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = b64u(JSON.stringify({ iss: c.email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: 'https://oauth2.googleapis.com/token', iat, exp: iat + 3600 }));
  const sig = crypto.createSign('RSA-SHA256').update(`${head}.${claim}`).sign(c.pk).toString('base64').replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
  const r = await fetchFn('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `grant_type=${encodeURIComponent('urn:ietf:params:oauth:grant-type:jwt-bearer')}&assertion=${head}.${claim}.${sig}` });
  if (!r.ok) return '';
  const j = await r.json();
  _fcmTok = { tok: j.access_token, exp: now + (+j.expires_in || 3600) * 1000 };
  return _fcmTok.tok;
}
async function fcmSend(fetchFn, token, text, id, now) {
  const c = fcmCreds(); if (!c) return { ok: false, code: 'NO_FCM' };
  const at = await fcmAccess(fetchFn, now); if (!at) return { ok: false, code: 'FCM_AUTH' };
  const message = {
    token,
    notification: { title: TITLE, body: text },
    data: { kind: 'nico', id },
    android: { priority: 'normal', notification: { tag: 'nico' } },
    apns: { payload: { aps: { sound: 'default', 'thread-id': 'nico' } } },
  };
  const r = await fetchFn(`https://fcm.googleapis.com/v1/projects/${c.project}/messages:send`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${at}` }, body: JSON.stringify({ message }) });
  if (r.ok) return { ok: true };
  let t = ''; try { t = await r.text(); } catch (e) {}
  // アプリを消した・通知を切った端末：以後は送らない
  const gone = r.status === 404 || /UNREGISTERED|registration-token-not-registered/i.test(t) || (r.status === 400 && /INVALID_ARGUMENT/.test(t) && /token/i.test(t));
  return { ok: false, gone, code: 'FCM_' + r.status };
}

// ---- 1人ぶんの処理 ----
async function processUser(store, usage, uid, now, deps) {
  const fetchFn = (deps && deps.fetch) || fetch;
  const ps = await store.get(`ps:${uid}`, { type: 'json' });
  if (!ps || !ps.on || !ps.token) { if (ps && ps.bucket != null) await store.delete(`pb:${ps.bucket}:${uid}`); return 'off'; }
  const lp = localParts(ps.tz, now);
  if (ps.mode !== 'fixed' && ps.target == null) ps.target = pickAutoHour(lp.hour);
  if (lp.hour !== aimHour(ps)) {                               // 夏時間などで時刻がずれた：正しい区切りに付け直す
    const old = ps.bucket; await rebucket(store, uid, ps, now);
    if (old !== ps.bucket) await store.setJSON(`ps:${uid}`, ps);
    return 'moved';
  }
  if (ps.lastDay === lp.day) return 'done';
  const rec = await store.get(`u:${uid}`, { type: 'json' });
  if (!rec) { await removeAll(store, uid); return 'gone'; }
  const A = require('./auth.js')._t;
  const pi = A.planInfo(rec), paid = pi.plan !== 'free';
  const seen = +ps.seen || +rec.updated || 0;
  if (now - seen > (paid ? ACTIVE_DAYS.paid : ACTIVE_DAYS.free) * 864e5) return 'inactive';
  const g = await generate(rec.data || {}, ps, now, fetchFn);
  if (paid && usage && g.yen > 0) await addCost(usage, uid, pi, g.yen);
  if (!g.text) return 'nogen';
  const id = 'n' + now.toString(36) + crypto.randomBytes(3).toString('hex');
  const s = await fcmSend(fetchFn, ps.token, g.text, id, now);
  if (!s.ok) {
    if (s.gone) { ps.on = false; ps.token = ''; await store.delete(`pb:${ps.bucket}:${uid}`); ps.bucket = null; await store.setJSON(`ps:${uid}`, ps); return 'unregistered'; }
    return 'sendfail';
  }
  const box = (await store.get(`pi:${uid}`, { type: 'json' })) || { items: [] };
  box.items = (box.items || []).filter(x => now - x.ts < INBOX_DAYS * 864e5).concat([{ id, text: g.text, ts: now }]).slice(-INBOX_KEEP);
  await store.setJSON(`pi:${uid}`, box);
  // 送っている間に設定が変わっていても上書きしないよう、読み直してから記録する
  const ps2 = (await store.get(`ps:${uid}`, { type: 'json' })) || ps;
  ps2.lastDay = lp.day; ps2.hist = (ps2.hist || []).concat([g.text]).slice(-HIST_KEEP);
  // おまかせ：次に送る時間帯を選び直す（今日の残りの時刻になっても、同じ日には二度送らない）
  if (ps2.mode !== 'fixed') { ps2.target = pickAutoHour(lp.hour); await rebucket(store, uid, ps2, now); }
  await store.setJSON(`ps:${uid}`, ps2);
  return 'sent';
}
// 有料プランは、この文面の原価も1か月の「AI原価の上限」に含める（gemini.js と同じキー）
async function addCost(usage, uid, pi, yen) {
  try {
    const G = require('./gemini.js')._t;
    const day = new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 10);
    const ym = G.subWindow(pi.start, pi.expires, day).id, sen = Math.ceil(yen * 100);
    for (const k of [`c:${ym}:${uid}`, `cd:${day}:${uid}`]) { const v = await usage.get(k, { type: 'json' }).catch(() => null); await usage.setJSON(k, { n: ((v && v.n) || 0) + sen, t: Date.now() }); }
  } catch (e) {}
}
// ---- 毎時：この時刻（UTC）の人に送る ----
async function runHour(store, usage, utcHour, now, deps) {
  const t0 = Date.now(), limitMs = (deps && deps.limitMs) || 13 * 60e3;
  const list = await store.list({ prefix: `pb:${utcHour}:` });
  const uids = (list.blobs || []).map(b => b.key.split(':')[2]).filter(Boolean);
  const out = {};
  let i = 0;
  const worker = async () => {
    while (i < uids.length && Date.now() - t0 < limitMs) {
      const uid = uids[i++];
      let r; try { r = await processUser(store, usage, uid, now, deps); } catch (e) { r = 'error'; }
      out[r] = (out[r] || 0) + 1;
    }
  };
  await Promise.all(Array.from({ length: (deps && deps.concurrency) || 8 }, worker));
  return { total: uids.length, out };
}
function pushSecret() { return crypto.createHmac('sha256', process.env.AUTH_SECRET || '').update('nico-push').digest('hex'); }

module.exports = { setPush, takeInbox, removeAll, processUser, runHour, pushSecret, _t: { dayOk, dayRule, timeOk, pickAutoHour, slotOf, AUTO_SLOTS, localParts, utcHourFor, buildPrompt, langOk, tooSimilar, tidy, stageOf, fcmSend, generate, MAX_LEN } };
