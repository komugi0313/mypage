// 毎時0分に動く予約関数：その時刻に「ニコからのメッセージ」を受け取る人の送信を、バックグラウンド関数に頼む。
// （予約関数は30秒で止まるため、送信そのものは最長15分動ける nico-push-background が行う）
import { createRequire } from 'module';
const require = createRequire(import.meta.url);
const L = require('./push-lib.js');

export default async () => {
  const site = process.env.URL || '';
  if (!site || !process.env.AUTH_SECRET) return new Response('not configured', { status: 200 });
  const hour = new Date().getUTCHours();
  try {
    await fetch(`${site}/.netlify/functions/nico-push-background`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-pk-push': L.pushSecret() }, body: JSON.stringify({ hour, at: Date.now() }) });
  } catch (e) {}
  return new Response('ok', { status: 200 });
};
export const config = { schedule: '0 * * * *' };
