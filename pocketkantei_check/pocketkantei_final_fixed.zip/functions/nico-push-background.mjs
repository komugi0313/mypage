// バックグラウンド関数（最長15分）：指定された時刻（UTC）の人に、ニコからのメッセージを作って送る。
// 呼べるのは nico-push（予約関数）だけ（合言葉 x-pk-push を確かめる）。中身は push-lib.js。
import { createRequire } from 'module';
import { getStore } from '@netlify/blobs';
const require = createRequire(import.meta.url);
const L = require('./push-lib.js');

export default async (req) => {
  if (!process.env.AUTH_SECRET || req.headers.get('x-pk-push') !== L.pushSecret()) return new Response('forbidden', { status: 403 });
  let b = {}; try { b = await req.json(); } catch (e) {}
  const hour = Number.isInteger(b.hour) ? b.hour : new Date().getUTCHours();
  const r = await L.runHour(getStore('pk-accounts'), getStore('pk-usage'), hour, Date.now());
  console.log('nico-push', hour, JSON.stringify(r));
  return new Response('ok');
};
