// Netlify Function：鑑定エンジン（Gemini）のサーバー中継＋サーバー側レート制限。
// ・APIキーは環境変数 GEMINI_API_KEY に保管し、ブラウザには一切出さない。
// ・回数制限は「サーバー側」で強制（localStorage は改ざん可能なので信用しない）。
//   端末ID(x-pk-device)＋IP を Netlify Blobs に日次カウントし、超過なら 429 を返し
//   Gemini を呼ばない＝API浪費を防ぐ。
// ・プランは、アカウントに記録された購読（App Store / Google Play → billing.js）で判定する。
// ※要設定：Site settings → Environment variables → GEMINI_API_KEY
//          Blobs は Netlify の通常デプロイ（Git連携 / netlify deploy）で自動有効。

// ハイブリッド運用：ふだんの会話は軽量Lite、恋愛・重い相談・理屈など「品質が要る」質問だけ上位DEEPモデル。
// クライアントが x-pk-deep: '1' を付けた時だけ DEEP を使う。どちらも環境変数で差し替え可能。
//   LITE 候補: gemini-2.5-flash-lite（最安・casual）
//   DEEP 候補: gemini-3.6-flash（現行flash・推奨。速度と品質のバランス）/ gemini-3.1-pro-preview（最高品質・低速高コスト）
//   ※ Gemini 3.x は thinkingConfig.thinkingBudget:0 が非対応（下で自動除去）。旧2.5系に戻す場合のみ thinkingBudget:0 が有効。
const MODEL_LITE = process.env.GEMINI_MODEL      || 'gemini-2.5-flash-lite';
const MODEL_DEEP = process.env.GEMINI_MODEL_DEEP || 'gemini-3.6-flash';

// ---- 回数の上限（料金設計 2026-09-03 決定）----
// 無料（お試し）：1日の回数（全メッセージ）。端末ごと＋同じIPの合計（悪用抑止）
const FREE = { device: 5, ip: 40 };
// 有料プラン：数えるのは「本格鑑定」（上位モデル）だけ。1か月（日本時間の暦月）あたりの回数
const DEEP_QUOTA = { std: 50, pro: 100, vip: 175 };
// 有料プランの雑談（軽量モデル）は回数に含めない。ただしbot・悪用対策として1日の安全上限を置く（ふつうの利用では届かない値）
const LITE_SAFETY = { device: 300, ip: 1000 };
// 話題の判定（x-pk-classify）の1日の上限。ほかの回数には数えないが、ここで上限を置かないと「無料で使い放題のAI」になってしまう
const CLASSIFY_DAILY = { free: { device: 30, ip: 200 }, paid: { device: 600, ip: 2000 } };
// 上位モデルだが本格鑑定には数えない呼び出し（「なぜ？」の説明・相づち・韓国語の雑談・作り直しなど）の1日の安全上限（アカウントごと）
const FREE_DEEP_DAILY = 100;
// ---- 1人あたり・1か月の「AI原価の上限」（利益65%を守る。運営決定 2026-09-26）----
// 手取りがいちばん少ない条件（年額プランの1か月分・アプリ手数料30%）で、手取りの35%までをAIに使える上限とする。
//   Standard：31,900円÷12÷1.1×0.7×0.35 ≒ ¥592 ／ Pro ≒ ¥1,204 ／ VIP ≒ ¥2,000
//   本格鑑定の回数（DEEP_QUOTA）は必ず使えるように、まだ使っていない本格鑑定の分を先に取っておき、
//   残りを雑談・「なぜ？」に「残り÷残りの日数」ずつ毎日割り当てる（月の途中で急に使えなくならないように）。
//   原価は、AIが返す実際の使用量（usageMetadata のトークン数）から1回ごとに計算して積み上げる。
function jsonEnv(k) { try { return JSON.parse(process.env[k] || '{}'); } catch (e) { return {}; } }
const COST_BUDGET = Object.assign({ std: 592, pro: 1204, vip: 2000 }, jsonEnv('PK_COST_BUDGET_JPY'));
// AIの料金（米ドル／100万トークン。cached＝キャッシュが効いた入力）。gemini-3.6-flash は仮の値（要確認）→ 環境変数 PK_AI_PRICES で差し替え
const AI_PRICES = Object.assign({ lite: { in: 0.10, out: 0.40, cached: 0.025 }, deep: { in: 0.50, out: 3.00, cached: 0.125 } }, jsonEnv('PK_AI_PRICES'));
const FX = +process.env.PK_FX || 150;                              // 1ドル＝円（安全側に。円安になったら上げる）
const DEEP_RESERVE_JPY = +process.env.PK_DEEP_RESERVE_JPY || 4;   // まだ使っていない本格鑑定1回ぶんとして取っておく原価（円）
const MAX_BODY = 12000; // ユーザーの1発言あたりの最大文字数（トークン浪費・悪用防止。※システムプロンプトは対象外）

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: { code: 'METHOD', message: 'Method Not Allowed' } });

  // 簡易オリジンチェック
  const site = process.env.URL || '';
  const origin = event.headers.origin || event.headers.referer || '';
  if (site && origin && !origin.startsWith(site)) return json(403, { error: { code: 'ORIGIN', message: 'Forbidden' } });

  // 極端に長い「ユーザー入力」だけを弾く（システムプロンプトは正規に大きいので、本文全体ではなく“ユーザーの最後の発言”の長さで判定する）
  try {
    var _pb = JSON.parse(event.body || '{}');
    var _contents = (_pb && _pb.contents) || [];
    var _lastUser = '';
    for (var _i = _contents.length - 1; _i >= 0; _i--) {
      var _m = _contents[_i];
      if (_m && _m.role === 'user') { _lastUser = (_m.parts && _m.parts[0] && _m.parts[0].text) || ''; break; }
    }
    if (_lastUser.length > MAX_BODY) return json(413, { error: { code: 'TOO_LONG', message: '入力が長すぎます' } });
  } catch (e) {}
  // 全体サイズの安全上限（プロンプト＋長い会話履歴）。極端な肥大化だけを弾く（Netlify関数の6MB上限より十分小さく）。
  if ((event.body || '').length > 900000) return json(413, { error: { code: 'TOO_LONG', message: 'リクエストが大きすぎます' } });

  const key = process.env.GEMINI_API_KEY;
  if (!key) return json(500, { error: { code: 'NO_KEY', message: 'サーバー設定が未完了です（GEMINI_API_KEY 未設定）' } });

  // 識別子
  const h = lower(event.headers || {});
  const device = clean(h['x-pk-device']) || 'nodev';
  const ip = clean(h['x-nf-client-connection-ip'] || h['x-forwarded-for'] || '').split(',')[0].trim() || 'noip';
  // プランは「アカウントに記録された購読」で決める（billing.js がストアの通知で書き込む）。
  // x-pk-plan は端末の自己申告で誰でも書き換えられるので使わない（テスト時だけ PK_TRUST_PLAN_HEADER=1 で有効）。
  const acct = await accountInfo(event, String(h['x-pk-auth'] || '').replace(/[\r\n]/g, '').slice(0, 400));
  if (process.env.PK_TRUST_PLAN_HEADER === '1') { const hp = (clean(h['x-pk-plan']) || 'free').toLowerCase(); acct.plan = hp; if (!acct.uid) acct.uid = 'dev-' + device; }
  const day = jstDay();
  // 数える期間：購読の更新日を基準にした1か月ごと（暦の月ではない。月の途中で買った人が2か月ぶん使えないように）
  const win = subWindow(acct.start, acct.expires, day);
  const ym = win.id;
  // 話題分類用の軽量呼び出し（x-pk-classify:1）は数えない（常に軽量モデルで安価）
  const isClassify = clean(h['x-pk-classify']) === '1';
  const wantDeep = clean(h['x-pk-deep']) === '1';
  // 上位モデルでも本格鑑定に数えない呼び出し：鑑定以外（「なぜ？」の説明・相づち・相談窓口が必要な時など。x-pk-nocount）と、品質のための作り直し（x-pk-retry）
  const freeDeep = wantDeep && (clean(h['x-pk-nocount']) === '1' || clean(h['x-pk-retry']) === '1');
  const paid = !!DEEP_QUOTA[acct.plan];

  // レート制限（Blobs が使えない環境ではフェイルオープン＝ヘッダで警告）
  const store = await getStore(event);
  let degraded = false, countKeys = [];
  if (store && !isClassify) {
    try {
      if (!paid) {
        const dKey = `d:${day}:${device}`, ipKey = `i:${day}:${ip}`;
        if (await readCount(store, dKey) >= FREE.device) return limitResp(FREE.device, 'device');
        if (await readCount(store, ipKey) >= FREE.ip) return limitResp(FREE.ip, 'ip');
        countKeys = [dKey, ipKey];
      } else if (wantDeep && !freeDeep) {
        const qKey = `q:${ym}:${acct.uid}`, quota = DEEP_QUOTA[acct.plan];
        if (await readCount(store, qKey) >= quota) return json(429, { error: { code: 'DEEP_QUOTA', limit: quota, plan: acct.plan, message: '今月の本格鑑定の回数を使い切りました。' } });
        countKeys = [qKey];
      } else if (freeDeep) {
        const fKey = `w:${day}:${acct.uid}`;
        if (await readCount(store, fKey) >= FREE_DEEP_DAILY) return limitResp(FREE_DEEP_DAILY, 'why');
        countKeys = [fKey];
      } else {
        const lKey = `l:${day}:${device}`, lipKey = `li:${day}:${ip}`;
        if (await readCount(store, lKey) >= LITE_SAFETY.device) return limitResp(LITE_SAFETY.device, 'fair');
        if (await readCount(store, lipKey) >= LITE_SAFETY.ip) return limitResp(LITE_SAFETY.ip, 'fair');
        countKeys = [lKey, lipKey];
      }
    } catch (e) { degraded = true; }
  } else if (store && isClassify) {
    try {
      const lim = paid ? CLASSIFY_DAILY.paid : CLASSIFY_DAILY.free;
      const kKey = `k:${day}:${device}`, kipKey = `ki:${day}:${ip}`;
      if (await readCount(store, kKey) >= lim.device) return limitResp(lim.device, 'classify');
      if (await readCount(store, kipKey) >= lim.ip) return limitResp(lim.ip, 'classify');
      countKeys = [kKey, kipKey];
    } catch (e) { degraded = true; }
  } else if (!store) { degraded = true; }

  // AI原価の上限（有料プランの雑談・「なぜ？」・作り直し）。本格鑑定（回数に数えるもの）と危機の相談は止めない
  const budgeted = paid && store && !degraded && !(wantDeep && !freeDeep);
  if (budgeted) {
    try {
      // この1回の見込み原価を足しても、今日の割り当てを超えない時だけ通す（最後の1回で上限を超えないように）。
      // つらい気持ちの相談もこの範囲で扱う。超えた時は、アプリが相談窓口つきの安全な返事を自分で出す（AI原価なし）
      const b = budgetToday(acct.plan, await readCount(store, `c:${ym}:${acct.uid}`), await readCount(store, `cd:${day}:${acct.uid}`), await readCount(store, `q:${ym}:${acct.uid}`), win.daysLeft);
      if (b.spentToday + estSen(wantDeep) > b.allowToday) return json(429, { error: { code: 'DAILY_BUDGET', plan: acct.plan, message: '今日の雑談の分を使い切りました。本格鑑定は引き続き使えます。' } });
    } catch (e) { degraded = true; }
  }

  // Gemini 呼び出し（ハイブリッド：深い質問だけ上位モデル）
  const MODEL = (!isClassify && clean(h['x-pk-deep']) === '1') ? MODEL_DEEP : MODEL_LITE;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(key)}`;
  // Gemini 3.x 互換：thinkingBudget:0 は 3.x で 400 になるため除去し、思考ぶんの出力トークンを確保する（クライアントが古い形で送ってきても安全に整える）
  let sendBody = event.body;
  // 話題の判定は出力を短く制限する（長い返事を作らせる悪用を防ぐ）
  if (isClassify) { try { const pj = JSON.parse(event.body || '{}'); pj.generationConfig = Object.assign({}, pj.generationConfig, { maxOutputTokens: Math.min(300, (pj.generationConfig && pj.generationConfig.maxOutputTokens) || 300) }); sendBody = JSON.stringify(pj); } catch (e) {} }
  if (/gemini-3/.test(MODEL)) {
    try {
      const pj = JSON.parse(event.body || '{}');
      pj.generationConfig = pj.generationConfig || {};
      if (pj.generationConfig.thinkingConfig) delete pj.generationConfig.thinkingConfig;
      const want = (clean(h['x-pk-deep']) === '1') ? 3200 : 2400;
      if (!pj.generationConfig.maxOutputTokens || pj.generationConfig.maxOutputTokens < want) pj.generationConfig.maxOutputTokens = want;
      sendBody = JSON.stringify(pj);
    } catch (e) {}
  }
  const usedDeep = (MODEL === MODEL_DEEP);
  let modelUsed = MODEL;
  let resp;
  try {
    let r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: sendBody });
    let text = await r.text();
    // DEEP(上位/3.x)が失敗（課金枯渇429・一時的な5xx等）したら、LITEに一度だけフォールバックして必ず返答を返す（ユーザーにエラーを見せない）
    if (usedDeep && !r.ok && MODEL_DEEP !== MODEL_LITE) {
      try {
        const url2 = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL_LITE}:generateContent?key=${encodeURIComponent(key)}`;
        const r2 = await fetch(url2, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: event.body });
        const text2 = await r2.text();
        if (r2.ok) { r = r2; text = text2; modelUsed = MODEL_LITE; }
      } catch (e2) {}
    }
    resp = { statusCode: r.status, headers: baseHeaders(degraded), body: text };
    // 正常応答のときだけカウント加算（失敗した回・分類用の軽量呼び出しは数えない）
    if (r.ok && store && !degraded) {
      try { for (const k of countKeys) await bump(store, k); } catch (e) {}
    }
    // アプリの「残り回数」表示用：今の区切りと、使った本格鑑定の回数
    if (paid && store && !degraded) {
      try { resp.headers['x-pk-win'] = win.id; resp.headers['x-pk-deep-used'] = String(await readCount(store, `q:${ym}:${acct.uid}`)); } catch (e) {}
    }
    // 有料プラン：実際の使用量から原価を計算して積み上げる（本格鑑定・分類の呼び出しも含む。原価の上限の計算に使う）
    if (r.ok && paid && store && !degraded) {
      try {
        const sen = Math.ceil(costYen(text, modelUsed) * 100);   // 1/100円単位で保存
        if (sen > 0) { await addTo(store, `c:${ym}:${acct.uid}`, sen); await addTo(store, `cd:${day}:${acct.uid}`, sen); }
      } catch (e) {}
    }
    return resp;
  } catch (e) {
    return json(502, { error: { code: 'UPSTREAM', message: 'AIサービスへの接続に失敗しました' } });
  }
};

// ---- レート制限の純ロジック（テスト用に分離） ----
async function readCount(store, k) {
  const v = await store.get(k, { type: 'json' }).catch(() => null);
  return (v && typeof v.n === 'number') ? v.n : 0;
}
async function bump(store, k) {
  const cur = await readCount(store, k);
  await store.setJSON(k, { n: cur + 1, t: Date.now() });
  return cur + 1;
}
function limitResp(limit, scope) {
  return json(429, { error: { code: 'LIMIT', scope, limit, message: '本日の無料相談の上限に達しました。プランに登録すると、もっと相談できます。' } });
}

// ---- AI原価の計算 ----
// 返答の usageMetadata（入力・キャッシュ済み入力・出力・思考のトークン数）から、この1回の原価（円）を出す
function costYen(respText, model) {
  let u = {}; try { u = (JSON.parse(respText) || {}).usageMetadata || {}; } catch (e) {}
  const pr = (model === MODEL_LITE) ? AI_PRICES.lite : AI_PRICES.deep;
  const inTok = +u.promptTokenCount || 0, cached = +u.cachedContentTokenCount || 0;
  const outTok = (+u.candidatesTokenCount || 0) + (+u.thoughtsTokenCount || 0);
  return ((inTok - cached) * pr.in + cached * (pr.cached != null ? pr.cached : pr.in) + outTok * pr.out) / 1e6 * FX;
}
// 1回の見込み原価（1/100円単位）：入力3万トークン、出力は雑談800・上位モデル3,500（考える分を含む）として多めに見積もる
function estSen(deep) { const pr = deep ? AI_PRICES.deep : AI_PRICES.lite; return Math.ceil((30000 * pr.in + (deep ? 3500 : 800) * pr.out) / 1e6 * FX * 100); }
// 今日、雑談・「なぜ？」に使える原価（1/100円単位）
function budgetToday(plan, spentMonth, spentToday, deepUsed, daysLeft) {
  const budget = (COST_BUDGET[plan] || 0) * 100;
  const reserve = Math.max(0, (DEEP_QUOTA[plan] || 0) - deepUsed) * DEEP_RESERVE_JPY * 100;
  daysLeft = Math.max(1, daysLeft || 1);
  const allowToday = Math.max(0, (budget - (spentMonth - spentToday) - reserve) / daysLeft);
  return { allowToday, spentToday, budget, reserve, daysLeft };
}
// 数える期間の区切り：今の支払い期間（start〜expires）。月額はその期間そのもの、年額は期間を12等分した1か月ずつ。
// 支払い期間が分からない時は、期限から1か月さかのぼった所を開始とみなす。期限も無い時（テスト等）は暦の月
const WIN_MS = 30.436875 * 864e5;
function subWindow(start, expires, day) {
  const now = Date.now();
  if (!(+expires > now)) { const y = +day.slice(0, 4), m = +day.slice(5, 7), d = +day.slice(8, 10); return { id: day.slice(0, 7), daysLeft: new Date(Date.UTC(y, m, 0)).getUTCDate() - d + 1 }; }
  if (!(+start > 0 && +start < +expires && now >= +start)) start = Math.min(now, expires - WIN_MS);
  const len = expires - start, n = Math.max(1, Math.round(len / WIN_MS)), seg = len / n;
  const k = Math.min(n - 1, Math.max(0, Math.floor((now - start) / seg)));
  const end = start + (k + 1) * seg;
  return { id: `${Math.round(start)}-${k}`, daysLeft: Math.max(1, Math.ceil((end - now) / 864e5)) };
}
async function addTo(store, k, n) {
  const cur = await readCount(store, k);
  await store.setJSON(k, { n: cur + n, t: Date.now() });
}

// ---- ユーティリティ ----
// ログイン中の利用者のトークン（x-pk-auth）を確かめ、アカウントの購読からプランを返す。未ログイン・不正・読めない時は free
async function accountInfo(event, tok) {
  const none = { plan: 'free', uid: '' };
  if (!tok) return none;
  try {
    const A = require('./auth.js')._t;
    const t = A.readToken(tok, process.env.AUTH_SECRET || '');
    if (!t) return none;
    const st = await A.getStore(event); if (!st) return none;
    const rec = await st.get(`u:${t.uid}`, { type: 'json' });
    if (!rec || rec.ver !== t.ver) return none;
    const pi = A.planInfo(rec);
    return { plan: pi.plan, uid: t.uid, expires: pi.expires || 0, start: pi.start || 0 };
  } catch (e) { return none; }
}
async function accountPlan(event, tok) { return (await accountInfo(event, tok)).plan; }
// Lambda互換（exports.handler）の関数では、Blobs を使う前に connectLambda(event) が必要（無いと本番で Blobs に繋がらずレート制限が効かない）
async function getStore(event) {
  try { const b = require('@netlify/blobs'); if (b.connectLambda && event && event.blobs) b.connectLambda(event); return b.getStore('pk-usage'); }
  catch (e) { return null; } // Blobs 未提供環境（手動zip等）ではフェイルオープン
}
function jstDay() { const d = new Date(Date.now() + 9 * 3600 * 1000); return d.toISOString().slice(0, 10); }
function lower(o) { const r = {}; for (const k in o) r[k.toLowerCase()] = o[k]; return r; }
function clean(s) { return (s == null ? '' : String(s)).replace(/[\r\n]/g, '').slice(0, 200); }
function baseHeaders(degraded) { const h = { 'Content-Type': 'application/json' }; if (degraded) h['x-pk-ratelimit'] = 'degraded'; return h; }
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(obj) }; }

// ---- テスト用エクスポート（本番動作には影響しない） ----
module.exports.__test = { readCount, bump, DEEP_QUOTA, FREE, jstDay };
exports._t = { accountPlan, accountInfo, DEEP_QUOTA, FREE, LITE_SAFETY, FREE_DEEP_DAILY, COST_BUDGET, AI_PRICES, costYen, budgetToday, subWindow };
