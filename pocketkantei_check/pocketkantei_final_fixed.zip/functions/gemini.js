// Netlify Function：鑑定エンジン（Gemini）のサーバー中継＋サーバー側レート制限。
// ・APIキーは環境変数 GEMINI_API_KEY に保管し、ブラウザには一切出さない。
// ・回数制限は「サーバー側」で強制（localStorage は改ざん可能なので信用しない）。
//   端末ID(x-pk-device)＋IP を Netlify Blobs に日次カウントし、超過なら 429 を返し
//   Gemini を呼ばない＝API浪費を防ぐ。
// ・プランは、アカウントに記録された購読（App Store / Google Play → billing.js）で判定する。
// ※要設定：Site settings → Environment variables → GEMINI_API_KEY
//          Blobs は Netlify の通常デプロイ（Git連携 / netlify deploy）で自動有効。

// ハイブリッド運用：ふだんの会話は軽量Lite、恋愛・重い相談・理屈など「品質が要る」質問だけ上位DEEPモデル。
// クライアントが x-pk-deep: '1' を付けた時だけ DEEP を使う。どちらも環境変数で差し替え可能。
//   LITE 候補: gemini-2.5-flash-lite（最安・casual）
//   DEEP 候補: gemini-3.6-flash（現行flash・推奨。速度と品質のバランス）/ gemini-3.1-pro-preview（最高品質・低速高コスト）
//   ※ Gemini 3.x は thinkingConfig.thinkingBudget:0 が非対応（下で自動除去）。旧2.5系に戻す場合のみ thinkingBudget:0 が有効。
const MODEL_LITE = process.env.GEMINI_MODEL      || 'gemini-2.5-flash-lite';
const MODEL_DEEP = process.env.GEMINI_MODEL_DEEP || 'gemini-3.6-flash';

// ---- 回数の上限（料金設計 2026-09-03 決定）----
// 無料（お試し）：1日の回数（全メッセージ）。端末ごと＋同じIPの合計（悪用抑止）
const FREE = { device: 5, ip: 40 };
// 有料プラン：数えるのは「本格鑑定」（上位モデル）だけ。1か月（日本時間の暦月）あたりの回数
const DEEP_QUOTA = { std: 50, pro: 100, vip: 175 };
// 有料プランの雑談（軽量モデル）は回数に含めない。ただしbot・悪用対策として1日の安全上限を置く（ふつうの利用では届かない値）
const LITE_SAFETY = { device: 300, ip: 1000 };
// 上位モデルだが本格鑑定には数えない呼び出し（「なぜ？」の説明・相づち・韓国語の雑談・作り直しなど）の1日の安全上限（アカウントごと）
const FREE_DEEP_DAILY = 100;
const MAX_BODY = 12000; // ユーザーの1発言あたりの最大文字数（トークン浪費・悪用防止。※システムプロンプトは対象外）

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: { code: 'METHOD', message: 'Method Not Allowed' } });

  // 簡易オリジンチェック
  const site = process.env.URL || '';
  const origin = event.headers.origin || event.headers.referer || '';
  if (site && origin && !origin.startsWith(site)) return json(403, { error: { code: 'ORIGIN', message: 'Forbidden' } });

  // 極端に長い「ユーザー入力」だけを弾く（システムプロンプトは正規に大きいので、本文全体ではなく“ユーザーの最後の発言”の長さで判定する）
  try {
    var _pb = JSON.parse(event.body || '{}');
    var _contents = (_pb && _pb.contents) || [];
    var _lastUser = '';
    for (var _i = _contents.length - 1; _i >= 0; _i--) {
      var _m = _contents[_i];
      if (_m && _m.role === 'user') { _lastUser = (_m.parts && _m.parts[0] && _m.parts[0].text) || ''; break; }
    }
    if (_lastUser.length > MAX_BODY) return json(413, { error: { code: 'TOO_LONG', message: '入力が長すぎます' } });
  } catch (e) {}
  // 全体サイズの安全上限（プロンプト＋長い会話履歴）。極端な肥大化だけを弾く（Netlify関数の6MB上限より十分小さく）。
  if ((event.body || '').length > 900000) return json(413, { error: { code: 'TOO_LONG', message: 'リクエストが大きすぎます' } });

  const key = process.env.GEMINI_API_KEY;
  if (!key) return json(500, { error: { code: 'NO_KEY', message: 'サーバー設定が未完了です（GEMINI_API_KEY 未設定）' } });

  // 識別子
  const h = lower(event.headers || {});
  const device = clean(h['x-pk-device']) || 'nodev';
  const ip = clean(h['x-nf-client-connection-ip'] || h['x-forwarded-for'] || '').split(',')[0].trim() || 'noip';
  // プランは「アカウントに記録された購読」で決める（billing.js がストアの通知で書き込む）。
  // x-pk-plan は端末の自己申告で誰でも書き換えられるので使わない（テスト時だけ PK_TRUST_PLAN_HEADER=1 で有効）。
  const acct = await accountInfo(event, String(h['x-pk-auth'] || '').replace(/[\r\n]/g, '').slice(0, 400));
  if (process.env.PK_TRUST_PLAN_HEADER === '1') { const hp = (clean(h['x-pk-plan']) || 'free').toLowerCase(); acct.plan = hp; if (!acct.uid) acct.uid = 'dev-' + device; }
  const day = jstDay(), ym = day.slice(0, 7);
  // 話題分類用の軽量呼び出し（x-pk-classify:1）は数えない（常に軽量モデルで安価）
  const isClassify = clean(h['x-pk-classify']) === '1';
  const wantDeep = clean(h['x-pk-deep']) === '1';
  // 上位モデルでも本格鑑定に数えない呼び出し：鑑定以外（「なぜ？」の説明・相づち・相談窓口が必要な時など。x-pk-nocount）と、品質のための作り直し（x-pk-retry）
  const freeDeep = wantDeep && (clean(h['x-pk-nocount']) === '1' || clean(h['x-pk-retry']) === '1');
  const paid = !!DEEP_QUOTA[acct.plan];

  // レート制限（Blobs が使えない環境ではフェイルオープン＝ヘッダで警告）
  const store = await getStore(event);
  let degraded = false, countKeys = [];
  if (store && !isClassify) {
    try {
      if (!paid) {
        const dKey = `d:${day}:${device}`, ipKey = `i:${day}:${ip}`;
        if (await readCount(store, dKey) >= FREE.device) return limitResp(FREE.device, 'device');
        if (await readCount(store, ipKey) >= FREE.ip) return limitResp(FREE.ip, 'ip');
        countKeys = [dKey, ipKey];
      } else if (wantDeep && !freeDeep) {
        const qKey = `q:${ym}:${acct.uid}`, quota = DEEP_QUOTA[acct.plan];
        if (await readCount(store, qKey) >= quota) return json(429, { error: { code: 'DEEP_QUOTA', limit: quota, plan: acct.plan, message: '今月の本格鑑定の回数を使い切りました。' } });
        countKeys = [qKey];
      } else if (freeDeep) {
        const fKey = `w:${day}:${acct.uid}`;
        if (await readCount(store, fKey) >= FREE_DEEP_DAILY) return limitResp(FREE_DEEP_DAILY, 'why');
        countKeys = [fKey];
      } else {
        const lKey = `l:${day}:${device}`, lipKey = `li:${day}:${ip}`;
        if (await readCount(store, lKey) >= LITE_SAFETY.device) return limitResp(LITE_SAFETY.device, 'fair');
        if (await readCount(store, lipKey) >= LITE_SAFETY.ip) return limitResp(LITE_SAFETY.ip, 'fair');
        countKeys = [lKey, lipKey];
      }
    } catch (e) { degraded = true; }
  } else if (!store) { degraded = true; }

  // Gemini 呼び出し（ハイブリッド：深い質問だけ上位モデル）
  const MODEL = (clean(h['x-pk-deep']) === '1') ? MODEL_DEEP : MODEL_LITE;
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(key)}`;
  // Gemini 3.x 互換：thinkingBudget:0 は 3.x で 400 になるため除去し、思考ぶんの出力トークンを確保する（クライアントが古い形で送ってきても安全に整える）
  let sendBody = event.body;
  if (/gemini-3/.test(MODEL)) {
    try {
      const pj = JSON.parse(event.body || '{}');
      pj.generationConfig = pj.generationConfig || {};
      if (pj.generationConfig.thinkingConfig) delete pj.generationConfig.thinkingConfig;
      const want = (clean(h['x-pk-deep']) === '1') ? 3200 : 2400;
      if (!pj.generationConfig.maxOutputTokens || pj.generationConfig.maxOutputTokens < want) pj.generationConfig.maxOutputTokens = want;
      sendBody = JSON.stringify(pj);
    } catch (e) {}
  }
  const usedDeep = (clean(h['x-pk-deep']) === '1');
  let resp;
  try {
    let r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: sendBody });
    let text = await r.text();
    // DEEP(上位/3.x)が失敗（課金枯渇429・一時的な5xx等）したら、LITEに一度だけフォールバックして必ず返答を返す（ユーザーにエラーを見せない）
    if (usedDeep && !r.ok && MODEL_DEEP !== MODEL_LITE) {
      try {
        const url2 = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL_LITE}:generateContent?key=${encodeURIComponent(key)}`;
        const r2 = await fetch(url2, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: event.body });
        const text2 = await r2.text();
        if (r2.ok) { r = r2; text = text2; }
      } catch (e2) {}
    }
    resp = { statusCode: r.status, headers: baseHeaders(degraded), body: text };
    // 正常応答のときだけカウント加算（失敗した回・分類用の軽量呼び出しは数えない）
    if (r.ok && store && !degraded && !isClassify) {
      try { for (const k of countKeys) await bump(store, k); } catch (e) {}
    }
    return resp;
  } catch (e) {
    return json(502, { error: { code: 'UPSTREAM', message: 'AIサービスへの接続に失敗しました' } });
  }
};

// ---- レート制限の純ロジック（テスト用に分離） ----
async function readCount(store, k) {
  const v = await store.get(k, { type: 'json' }).catch(() => null);
  return (v && typeof v.n === 'number') ? v.n : 0;
}
async function bump(store, k) {
  const cur = await readCount(store, k);
  await store.setJSON(k, { n: cur + 1, t: Date.now() });
  return cur + 1;
}
function limitResp(limit, scope) {
  return json(429, { error: { code: 'LIMIT', scope, limit, message: '本日の無料相談の上限に達しました。プランに登録すると、もっと相談できます。' } });
}

// ---- ユーティリティ ----
// ログイン中の利用者のトークン（x-pk-auth）を確かめ、アカウントの購読からプランを返す。未ログイン・不正・読めない時は free
async function accountInfo(event, tok) {
  const none = { plan: 'free', uid: '' };
  if (!tok) return none;
  try {
    const A = require('./auth.js')._t;
    const t = A.readToken(tok, process.env.AUTH_SECRET || '');
    if (!t) return none;
    const st = await A.getStore(event); if (!st) return none;
    const rec = await st.get(`u:${t.uid}`, { type: 'json' });
    if (!rec || rec.ver !== t.ver) return none;
    return { plan: A.planInfo(rec).plan, uid: t.uid };
  } catch (e) { return none; }
}
async function accountPlan(event, tok) { return (await accountInfo(event, tok)).plan; }
// Lambda互換（exports.handler）の関数では、Blobs を使う前に connectLambda(event) が必要（無いと本番で Blobs に繋がらずレート制限が効かない）
async function getStore(event) {
  try { const b = require('@netlify/blobs'); if (b.connectLambda && event && event.blobs) b.connectLambda(event); return b.getStore('pk-usage'); }
  catch (e) { return null; } // Blobs 未提供環境（手動zip等）ではフェイルオープン
}
function jstDay() { const d = new Date(Date.now() + 9 * 3600 * 1000); return d.toISOString().slice(0, 10); }
function lower(o) { const r = {}; for (const k in o) r[k.toLowerCase()] = o[k]; return r; }
function clean(s) { return (s == null ? '' : String(s)).replace(/[\r\n]/g, '').slice(0, 200); }
function baseHeaders(degraded) { const h = { 'Content-Type': 'application/json' }; if (degraded) h['x-pk-ratelimit'] = 'degraded'; return h; }
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(obj) }; }

// ---- テスト用エクスポート（本番動作には影響しない） ----
module.exports.__test = { readCount, bump, DEEP_QUOTA, FREE, jstDay };
exports._t = { accountPlan, accountInfo, DEEP_QUOTA, FREE, LITE_SAFETY, FREE_DEEP_DAILY };
