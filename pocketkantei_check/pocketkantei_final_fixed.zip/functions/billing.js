// Netlify Function：購読（App Store / Google Play）の通知を受け取り、アカウントのプランを書き込む。
// ・ストアの購入は、アプリ内の課金サービス（RevenueCat を想定）が確認し、ここへ Webhook で知らせる。
// ・アプリは RevenueCat の appUserID に「アカウントの uid」（ログイン用トークンの先頭の64桁）を使う。
//   → 通知の app_user_id（または aliases）から、どのアカウントの購読かが分かる。
// ・書き込み先：Netlify Blobs ストア pk-accounts の u:<uid> の rec.sub
//     { plan, product, expires(ms), willRenew, store, env, eventTs, updated }
//   チャットの回数上限（gemini.js）とアプリの表示（auth.js の plan）は、この rec.sub だけを見る。
// ※要設定（Netlify の環境変数）
//   REVENUECAT_WEBHOOK_AUTH … RevenueCat の Webhook 設定「Authorization header」に入れる合言葉（長いランダム文字列）
//   PK_PRODUCTS（任意）… ストアの商品ID → プランの対応（JSON）。例：{"pk_std_monthly":"std","pk_std_annual":"std","pk_pro_monthly":"pro","pk_pro_annual":"pro","pk_vip_monthly":"vip","pk_vip_annual":"vip"}
//                       未設定なら、商品IDに vip → vip、pro（単語として）→ pro、std / standard → std を含むかで判定（月額・年額とも同じプラン）
//   PK_IGNORE_SANDBOX（任意）… "1" ならテスト購入（SANDBOX）を反映しない。
//                       ※Apple の審査はテスト購入で行われるため、審査中は設定しないこと（既定＝反映する）

const PLANS = ['std', 'pro', 'vip'];   // Standard / Pro / VIP（料金設計 2026-09-03）
const GRANT = ['INITIAL_PURCHASE', 'RENEWAL', 'PRODUCT_CHANGE', 'UNCANCELLATION', 'NON_RENEWING_PURCHASE', 'SUBSCRIPTION_EXTENDED', 'TEMPORARY_ENTITLEMENT_GRANT'];

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false, code: 'METHOD' });
  const need = process.env.REVENUECAT_WEBHOOK_AUTH || '';
  if (need.length < 16) return json(500, { ok: false, code: 'NO_WEBHOOK_AUTH' });
  const h = lower(event.headers || {});
  const got = String(h['authorization'] || '');
  if (!safeEq(got, need) && !safeEq(got, 'Bearer ' + need)) return json(401, { ok: false, code: 'UNAUTHORIZED' });

  let b; try { b = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { ok: false, code: 'BAD_JSON' }); }
  const ev = b && b.event; if (!ev || !ev.type) return json(400, { ok: false, code: 'NO_EVENT' });
  if (ev.type === 'TEST') return json(200, { ok: true, test: true });
  if (process.env.PK_IGNORE_SANDBOX === '1' && String(ev.environment || '').toUpperCase() === 'SANDBOX') return json(200, { ok: true, ignored: 'sandbox' });

  const A = require('./auth.js')._t;
  const store = await A.getStore(event);
  if (!store) return json(503, { ok: false, code: 'NO_STORE' });

  try {
    // 引き継ぎ（別アカウントへ購読が移った）：移動元を解除し、移動先に付け直す
    if (ev.type === 'TRANSFER') {
      const from = uids(ev.transferred_from), to = uids(ev.transferred_to);
      let moved = null;
      for (const u of from) { const r = await store.get(`u:${u}`, { type: 'json' }); if (r && r.sub) { moved = moved || r.sub; delete r.sub; await store.setJSON(`u:${u}`, r); } }
      if (moved) for (const u of to) { const r = await store.get(`u:${u}`, { type: 'json' }); if (r) { r.sub = Object.assign({}, moved, { updated: Date.now() }); await store.setJSON(`u:${u}`, r); } }
      return json(200, { ok: true });
    }

    const ids = uids([ev.app_user_id, ev.original_app_user_id].concat(ev.aliases || []));
    if (!ids.length) return json(200, { ok: true, ignored: 'no_account' });   // 未ログインの購入（匿名ID）は対象外。アプリはログイン後にだけ購入させる
    const product = String((ev.type === 'PRODUCT_CHANGE' && ev.new_product_id) || ev.product_id || '');
    const plan = planOfProduct(product);
    const ts = +ev.event_timestamp_ms || Date.now();
    const exp = +ev.expiration_at_ms || 0;
    let done = 0;
    for (const uid of ids) {
      const key = `u:${uid}`;
      const rec = await store.get(key, { type: 'json' });
      if (!rec) continue;                                        // 退会済みなど
      const cur = rec.sub || {};
      if (cur.eventTs && ts < cur.eventTs) { done++; continue; }   // 古い通知が後から届いた時は無視
      if (GRANT.includes(ev.type)) {
        if (!plan) return json(200, { ok: true, ignored: 'unknown_product', product });
        // start＝今の支払い期間の開始（回数と原価の上限を、購読の期間に合わせて区切るのに使う）
        rec.sub = { plan, product, start: +ev.purchased_at_ms || Date.now(), expires: exp || (Date.now() + 35 * 864e5), willRenew: true, store: String(ev.store || ''), env: String(ev.environment || ''), eventTs: ts, updated: Date.now() };
      } else if (ev.type === 'CANCELLATION') {
        // 解約（または返金）：期限までは使える。返金（cancel_reason=CUSTOMER_SUPPORT 等で期限が過去）なら即時終了
        rec.sub = Object.assign({}, cur, { willRenew: false, eventTs: ts, updated: Date.now() });
        if (exp) rec.sub.expires = exp;
      } else if (ev.type === 'EXPIRATION') {
        rec.sub = Object.assign({}, cur, { expires: exp || Date.now(), willRenew: false, eventTs: ts, updated: Date.now() });
      } else if (ev.type === 'BILLING_ISSUE') {
        // 支払いの問題：ストアの猶予期間中は使える（期限はストアが延長して知らせる）
        rec.sub = Object.assign({}, cur, { billingIssue: true, eventTs: ts, updated: Date.now() });
      } else {
        continue;                                                // SUBSCRIPTION_PAUSED など：変更しない
      }
      await store.setJSON(key, rec); done++;
    }
    return json(200, { ok: true, updated: done });
  } catch (e) {
    return json(500, { ok: false, code: 'SERVER' });              // 500 を返すと RevenueCat が後で再送する
  }
};

// アカウントの uid（sha256 の64桁）だけを拾う
function uids(list) { const o = []; (list || []).forEach(x => { const v = String(x || '').toLowerCase(); if (/^[0-9a-f]{64}$/.test(v) && !o.includes(v)) o.push(v); }); return o; }
function planOfProduct(id) {
  const pid = String(id || '').split(':')[0];                   // Google の「商品ID:基本プランID」は商品IDだけで引く
  try { const m = JSON.parse(process.env.PK_PRODUCTS || '{}'); const v = m[id] || m[pid]; if (PLANS.includes(v)) return v; } catch (e) {}
  const s = pid.toLowerCase();
  if (/vip/.test(s)) return 'vip';
  if (/(^|[^a-z])pro([^a-z]|$)/.test(s)) return 'pro';
  if (/std|standard/.test(s)) return 'std';
  return '';
}
function safeEq(a, b) { const c = require('crypto'); const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && c.timingSafeEqual(x, y); }
function lower(o) { const r = {}; for (const k in o) r[k.toLowerCase()] = o[k]; return r; }
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(obj) }; }
exports._t = { planOfProduct, uids };
