// Netlify Function：アカウント（メールアドレス＋パスワード）とデータ同期。
// ・メール確認リンクは使わない。メールアドレス＋パスワードだけで登録／ログインする。
// ・パスワードは scrypt（ランダムsalt付き）でハッシュ化して保存。平文は保存しない。
// ・ログイン状態は署名付きトークン（HMAC-SHA256）。端末にはトークンだけを保存し、パスワードは保存しない。
// ・命式の入力・会話履歴などの端末データ（pk_*）をアカウントに保存し、機種変更しても同じメアド＋パスワードで復元できる。
// ※要設定：Site settings → Environment variables → AUTH_SECRET（32文字以上のランダムな文字列）
//          Blobs は Netlify の通常デプロイ（Git連携 / netlify deploy）で自動有効。
//
// POST /api/auth  { action, ... }
//   register { email, password, data }      → { ok, token, email }
//   login    { email, password }            → { ok, token, email, data }
//   save     { token, data }                → { ok, updated }
//   load     { token }                      → { ok, data, updated }
//   change   { token, password, newPassword } → { ok, token }
//   delete   { token, password }            → { ok }
//   forgot   { email, lang }                → { ok }   登録があれば再設定メールを送る（登録の有無は答えない）
//   reset    { code, newPassword }          → { ok, token, email, data }   メールのリンクのコードで新しいパスワードを設定
// ※パスワード再設定メールの送信に必要（Resend https://resend.com）：
//   RESEND_API_KEY（ResendのAPIキー）／ MAIL_FROM（送信元。例："Pocket Kantei <no-reply@72k.ai>"。Resendで認証済みのドメイン）
const crypto = require('crypto');

const MAX_DATA = 1500000;        // 保存データの上限（文字数）。会話履歴60件＋設定で十分な大きさ
const TOKEN_DAYS = 365;          // ログイン状態の有効期間
const LOCK_FAILS = 5;            // パスワードをこの回数続けて間違えると
const LOCK_MIN = 15;             // この分数ロック
const REG_PER_IP_DAY = 20;       // 同一IPからの新規登録の上限（1日）
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const RESET_MIN = 30;            // 再設定リンクの有効時間（分）
const RESET_PER_HOUR = 3;        // 同じアカウントへの再設定メールの上限（1時間）
const FORGOT_PER_IP_DAY = 30;    // 同一IPからの再設定依頼の上限（1日）

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false, code: 'METHOD' });
  const site = process.env.URL || '';
  const origin = event.headers.origin || event.headers.referer || '';
  if (site && origin && !origin.startsWith(site)) return json(403, { ok: false, code: 'ORIGIN' });
  if ((event.body || '').length > MAX_DATA + 20000) return json(413, { ok: false, code: 'TOO_LARGE' });

  const secret = process.env.AUTH_SECRET || '';
  if (secret.length < 16) return json(500, { ok: false, code: 'NO_SECRET' });
  const store = await getStore(event);
  if (!store) return json(503, { ok: false, code: 'NO_STORE' });

  let b; try { b = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { ok: false, code: 'BAD_JSON' }); }
  const action = String(b.action || '');
  const h = lower(event.headers || {});
  const ip = String(h['x-nf-client-connection-ip'] || h['x-forwarded-for'] || '').split(',')[0].trim() || 'noip';

  try {
    if (action === 'register') {
      const email = normEmail(b.email), pw = String(b.password || '');
      if (!EMAIL_RE.test(email)) return json(400, { ok: false, code: 'BAD_EMAIL' });
      if (pw.length < 8 || pw.length > 128) return json(400, { ok: false, code: 'BAD_PASSWORD' });
      const data = cleanData(b.data); if (data === null) return json(413, { ok: false, code: 'TOO_LARGE' });
      const rk = `r:${jstDay()}:${ip}`, rc = await readNum(store, rk);
      if (rc >= REG_PER_IP_DAY) return json(429, { ok: false, code: 'RATE' });
      const key = userKey(email);
      if (await store.get(key)) return json(409, { ok: false, code: 'EXISTS' });
      const salt = crypto.randomBytes(16).toString('hex');
      const now = Date.now();
      const rec = { email, salt, hash: hashPw(pw, salt), ver: 1, created: now, updated: now, fails: 0, lockUntil: 0, data };
      await store.setJSON(key, rec);
      await store.set(rk, String(rc + 1));
      return json(200, { ok: true, email, token: makeToken(email, rec.ver, secret), plan: planInfo(rec) });
    }

    if (action === 'login') {
      const email = normEmail(b.email), pw = String(b.password || '');
      const key = userKey(email);
      const rec = EMAIL_RE.test(email) ? await store.get(key, { type: 'json' }) : null;
      if (!rec) { hashPw(pw, 'x'); return json(401, { ok: false, code: 'BAD_LOGIN' }); } // 登録有無を応答時間で漏らしにくくする
      if (rec.lockUntil && rec.lockUntil > Date.now()) return json(429, { ok: false, code: 'LOCKED', retryMin: Math.ceil((rec.lockUntil - Date.now()) / 60000) });
      if (!safeEq(hashPw(pw, rec.salt), rec.hash)) {
        rec.fails = (rec.fails || 0) + 1;
        if (rec.fails >= LOCK_FAILS) { rec.lockUntil = Date.now() + LOCK_MIN * 60000; rec.fails = 0; }
        await store.setJSON(key, rec);
        return json(401, { ok: false, code: 'BAD_LOGIN' });
      }
      if (rec.fails || rec.lockUntil) { rec.fails = 0; rec.lockUntil = 0; await store.setJSON(key, rec); }
      return json(200, { ok: true, email: rec.email, token: makeToken(rec.email, rec.ver, secret), data: rec.data || {}, updated: rec.updated, plan: planInfo(rec) });
    }

    // パスワードを忘れた：登録があれば再設定メールを送る。登録の有無は応答で分からないようにする
    if (action === 'forgot') {
      const email = normEmail(b.email);
      if (!EMAIL_RE.test(email)) return json(400, { ok: false, code: 'BAD_EMAIL' });
      if (!process.env.RESEND_API_KEY || !process.env.MAIL_FROM) return json(500, { ok: false, code: 'NO_MAIL' });
      const fk = `f:${jstDay()}:${ip}`, fc = await readNum(store, fk);
      if (fc >= FORGOT_PER_IP_DAY) return json(429, { ok: false, code: 'RATE' });
      await store.set(fk, String(fc + 1));
      const key = userKey(email);
      const rec = await store.get(key, { type: 'json' });
      if (!rec) return json(200, { ok: true });
      const now = Date.now();
      const sent = (rec.resetSent || []).filter(t => t > now - 3600e3);
      if (sent.length >= RESET_PER_HOUR) return json(200, { ok: true });   // 送りすぎ防止（応答は同じ）
      const raw = crypto.randomBytes(24).toString('hex');
      rec.reset = { h: sha256(raw), exp: now + RESET_MIN * 60000 };
      rec.resetSent = sent.concat(now);
      await store.setJSON(key, rec);
      const lang = MAIL_TEXT[b.lang] ? b.lang : 'en';
      const link = `${siteUrl(event)}/index.html#reset=${userId(email)}.${raw}`;
      const ok = await sendResetMail(email, link, lang);
      if (!ok) return json(502, { ok: false, code: 'MAIL_FAIL' });
      return json(200, { ok: true });
    }
    // メールのリンクから新しいパスワードを設定 → そのままログイン
    if (action === 'reset') {
      const [uid, raw] = String(b.code || '').split('.');
      const np = String(b.newPassword || '');
      if (!/^[0-9a-f]{64}$/.test(uid || '') || !/^[0-9a-f]{48}$/.test(raw || '')) return json(400, { ok: false, code: 'BAD_RESET' });
      if (np.length < 8 || np.length > 128) return json(400, { ok: false, code: 'BAD_PASSWORD' });
      const key = `u:${uid}`;
      const rec = await store.get(key, { type: 'json' });
      if (!rec || !rec.reset || rec.reset.exp < Date.now() || !safeEq(sha256(raw), rec.reset.h)) return json(400, { ok: false, code: 'BAD_RESET' });
      rec.salt = crypto.randomBytes(16).toString('hex'); rec.hash = hashPw(np, rec.salt);
      rec.ver = (rec.ver || 1) + 1;            // 他の端末のログインは無効になる
      rec.reset = null; rec.fails = 0; rec.lockUntil = 0; rec.updated = Date.now();
      await store.setJSON(key, rec);
      return json(200, { ok: true, email: rec.email, token: makeToken(rec.email, rec.ver, secret), data: rec.data || {}, updated: rec.updated, plan: planInfo(rec) });
    }

    // ここから先はトークン必須
    const t = readToken(b.token, secret);
    if (!t) return json(401, { ok: false, code: 'BAD_TOKEN' });
    const key = `u:${t.uid}`;
    const rec = await store.get(key, { type: 'json' });
    if (!rec || rec.ver !== t.ver) return json(401, { ok: false, code: 'BAD_TOKEN' });

    if (action === 'save') {
      const data = cleanData(b.data); if (data === null) return json(413, { ok: false, code: 'TOO_LARGE' });
      rec.data = data; rec.updated = Date.now();
      await store.setJSON(key, rec);
      return json(200, { ok: true, updated: rec.updated });
    }
    if (action === 'load') return json(200, { ok: true, email: rec.email, data: rec.data || {}, updated: rec.updated, plan: planInfo(rec) });
    // 購入・復元の直後に、ストアからの通知（billing.js）が反映されたかを確かめる軽い問い合わせ
    if (action === 'status') return json(200, { ok: true, plan: planInfo(rec) });
    if (action === 'change') {
      if (!safeEq(hashPw(String(b.password || ''), rec.salt), rec.hash)) return json(401, { ok: false, code: 'BAD_LOGIN' });
      const np = String(b.newPassword || '');
      if (np.length < 8 || np.length > 128) return json(400, { ok: false, code: 'BAD_PASSWORD' });
      rec.salt = crypto.randomBytes(16).toString('hex'); rec.hash = hashPw(np, rec.salt);
      rec.ver = (rec.ver || 1) + 1; rec.updated = Date.now();   // 他の端末のログインは無効になる
      await store.setJSON(key, rec);
      return json(200, { ok: true, token: makeToken(rec.email, rec.ver, secret) });
    }
    if (action === 'delete') {
      if (!safeEq(hashPw(String(b.password || ''), rec.salt), rec.hash)) return json(401, { ok: false, code: 'BAD_LOGIN' });
      await store.delete(key);
      return json(200, { ok: true });
    }
    return json(400, { ok: false, code: 'BAD_ACTION' });
  } catch (e) {
    // Blobs 未接続（手動zipデプロイ等）は NO_STORE として返し、原因を見分けやすくする
    const blob = /blob/i.test(String((e && (e.name || '')) + ' ' + (e && e.message || '')));
    return json(blob ? 503 : 500, { ok: false, code: blob ? 'NO_STORE' : 'SERVER' });
  }
};

function sha256(s) { return crypto.createHash('sha256').update(String(s)).digest('hex'); }
function siteUrl(event) {
  const u = process.env.URL; if (u) return u.replace(/\/$/, '');
  const h = lower(event.headers || {}); return `https://${h.host || 'localhost'}`;
}
// 再設定メールの文面（アプリの表示言語で送る）
const MAIL_TEXT = {
  ja: ['パスワードの再設定', 'Pocket本格鑑定のパスワード再設定のご依頼を受け付けました。下のボタンから新しいパスワードを設定してください（30分間有効）。', '新しいパスワードを設定する', 'お心当たりがない場合は、このメールを破棄してください。パスワードは変更されません。'],
  en: ['Reset your password', 'We received a request to reset your Pocket Kantei password. Tap the button below to set a new password (valid for 30 minutes).', 'Set a new password', 'If you did not request this, you can ignore this email. Your password will not change.'],
  zh: ['重设密码', '我们收到了重设 Pocket 鉴定密码的请求。请点击下方按钮设置新密码（30分钟内有效）。', '设置新密码', '如非本人操作，请忽略此邮件，密码不会被更改。'],
  zt: ['重設密碼', '我們收到了重設 Pocket 鑑定密碼的請求。請點擊下方按鈕設定新密碼（30分鐘內有效）。', '設定新密碼', '如非本人操作，請忽略此郵件，密碼不會被變更。'],
  ko: ['비밀번호 재설정', 'Pocket 감정 비밀번호 재설정 요청을 받았습니다. 아래 버튼을 눌러 새 비밀번호를 설정하세요 (30분간 유효).', '새 비밀번호 설정', '요청하지 않으셨다면 이 메일을 무시하세요. 비밀번호는 바뀌지 않습니다.'],
  vi: ['Đặt lại mật khẩu', 'Chúng tôi đã nhận yêu cầu đặt lại mật khẩu Pocket Kantei. Nhấn nút bên dưới để đặt mật khẩu mới (hiệu lực 30 phút).', 'Đặt mật khẩu mới', 'Nếu bạn không yêu cầu, hãy bỏ qua email này. Mật khẩu sẽ không thay đổi.'],
  es: ['Restablecer contraseña', 'Recibimos una solicitud para restablecer tu contraseña de Pocket Kantei. Pulsa el botón para crear una nueva (válido 30 minutos).', 'Crear nueva contraseña', 'Si no lo solicitaste, ignora este correo. Tu contraseña no cambiará.'],
  pt: ['Redefinir senha', 'Recebemos um pedido para redefinir sua senha do Pocket Kantei. Toque no botão abaixo para criar uma nova (válido por 30 minutos).', 'Criar nova senha', 'Se não foi você, ignore este e-mail. Sua senha não será alterada.'],
  id: ['Atur ulang kata sandi', 'Kami menerima permintaan untuk mengatur ulang kata sandi Pocket Kantei Anda. Ketuk tombol di bawah untuk membuat kata sandi baru (berlaku 30 menit).', 'Buat kata sandi baru', 'Jika Anda tidak memintanya, abaikan email ini. Kata sandi tidak akan berubah.'],
  th: ['ตั้งรหัสผ่านใหม่', 'เราได้รับคำขอให้ตั้งรหัสผ่าน Pocket Kantei ใหม่ แตะปุ่มด้านล่างเพื่อตั้งรหัสผ่านใหม่ (ใช้ได้ 30 นาที)', 'ตั้งรหัสผ่านใหม่', 'หากคุณไม่ได้ขอ ให้เพิกเฉยต่ออีเมลนี้ รหัสผ่านจะไม่เปลี่ยน']
};
function escHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
async function sendResetMail(to, link, lang) {
  const t = MAIL_TEXT[lang] || MAIL_TEXT.en;
  const html = `<div style="font-family:sans-serif;max-width:480px;margin:auto;padding:24px;color:#2b2b2b">`
    + `<h2 style="font-size:18px">${escHtml(t[0])}</h2><p style="line-height:1.7">${escHtml(t[1])}</p>`
    + `<p style="margin:24px 0"><a href="${escHtml(link)}" style="background:#4E8060;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:bold">${escHtml(t[2])}</a></p>`
    + `<p style="font-size:12px;color:#777;line-height:1.7">${escHtml(t[3])}<br>${escHtml(link)}</p></div>`;
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.MAIL_FROM, to: [to], subject: `Pocket Kantei — ${t[0]}`, html, text: `${t[1]}\n\n${link}\n\n${t[3]}` })
    });
    return r.ok;
  } catch (e) { return false; }
}
function normEmail(s) { return String(s || '').trim().toLowerCase().slice(0, 254); }
// 購読の状態：billing.js（ストアからの通知）が rec.sub に書き込む。期限内なら有料プラン、切れていれば free
function planInfo(rec) {
  const s = rec && rec.sub;
  if (s && s.plan && +s.expires > Date.now()) return { plan: s.plan, expires: +s.expires, willRenew: s.willRenew !== false, store: s.store || '' };
  return { plan: 'free' };
}
function userId(email) { return crypto.createHash('sha256').update(email).digest('hex'); }
function userKey(email) { return `u:${userId(email)}`; }
function hashPw(pw, salt) { return crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex'); }
function safeEq(a, b) { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }
function makeToken(email, ver, secret) {
  const body = `${userId(email)}.${ver}.${Date.now() + TOKEN_DAYS * 864e5}`;
  return `${body}.${crypto.createHmac('sha256', secret).update(body).digest('hex')}`;
}
function readToken(tok, secret) {
  const p = String(tok || '').split('.'); if (p.length !== 4) return null;
  const body = `${p[0]}.${p[1]}.${p[2]}`;
  if (!safeEq(crypto.createHmac('sha256', secret).update(body).digest('hex'), p[3])) return null;
  if (+p[2] < Date.now()) return null;
  return { uid: p[0], ver: +p[1] };
}
// 端末データ：pk_ で始まるキーの文字列だけを受け付ける（APIキーやログイン情報は除外）
function cleanData(d) {
  const o = {}; let n = 0;
  if (d && typeof d === 'object') for (const k of Object.keys(d)) {
    if (!/^pk_[A-Za-z0-9_]{1,40}$/.test(k) || k === 'pk_key' || k === 'pk_auth') continue;
    const v = String(d[k]); n += k.length + v.length; o[k] = v;
  }
  return n > MAX_DATA ? null : o;
}
async function readNum(store, k) { const v = await store.get(k); return v ? (parseInt(v, 10) || 0) : 0; }
// Lambda互換（exports.handler）の関数では、Blobs を使う前に connectLambda(event) が必要
async function getStore(event) {
  try { const b = require('@netlify/blobs'); if (b.connectLambda && event && event.blobs) b.connectLambda(event); return b.getStore('pk-accounts'); }
  catch (e) { return null; }
}
function jstDay() { const d = new Date(Date.now() + 9 * 3600 * 1000); return d.toISOString().slice(0, 10); }
function lower(o) { const r = {}; for (const k in o) r[k.toLowerCase()] = o[k]; return r; }
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(obj) }; }

// ---- テスト用エクスポート（本番動作には影響しない） ----
exports._t = { hashPw, makeToken, readToken, cleanData, normEmail, planInfo, getStore, userId };
