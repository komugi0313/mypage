// Netlify Function：アカウント（メールアドレス＋パスワード）とデータ同期。
// ・メール確認リンクは使わない。メールアドレス＋パスワードだけで登録／ログインする。
// ・パスワードは scrypt（ランダムsalt付き）でハッシュ化して保存。平文は保存しない。
// ・ログイン状態は署名付きトークン（HMAC-SHA256）。端末にはトークンだけを保存し、パスワードは保存しない。
// ・命式の入力・会話履歴などの端末データ（pk_*）をアカウントに保存し、機種変更しても同じメアド＋パスワードで復元できる。
// ※要設定：Site settings → Environment variables → AUTH_SECRET（32文字以上のランダムな文字列）
//          Blobs は Netlify の通常デプロイ（Git連携 / netlify deploy）で自動有効。
//
// POST /api/auth  { action, ... }
//   register { email, password, data }      → { ok, token, email }
//   login    { email, password }            → { ok, token, email, data }
//   save     { token, data }                → { ok, updated }
//   load     { token }                      → { ok, data, updated }
//   change   { token, password, newPassword } → { ok, token }
//   delete   { token, password }            → { ok }
const crypto = require('crypto');

const MAX_DATA = 1500000;        // 保存データの上限（文字数）。会話履歴60件＋設定で十分な大きさ
const TOKEN_DAYS = 365;          // ログイン状態の有効期間
const LOCK_FAILS = 5;            // パスワードをこの回数続けて間違えると
const LOCK_MIN = 15;             // この分数ロック
const REG_PER_IP_DAY = 20;       // 同一IPからの新規登録の上限（1日）
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false, code: 'METHOD' });
  const site = process.env.URL || '';
  const origin = event.headers.origin || event.headers.referer || '';
  if (site && origin && !origin.startsWith(site)) return json(403, { ok: false, code: 'ORIGIN' });
  if ((event.body || '').length > MAX_DATA + 20000) return json(413, { ok: false, code: 'TOO_LARGE' });

  const secret = process.env.AUTH_SECRET || '';
  if (secret.length < 16) return json(500, { ok: false, code: 'NO_SECRET' });
  const store = await getStore(event);
  if (!store) return json(503, { ok: false, code: 'NO_STORE' });

  let b; try { b = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { ok: false, code: 'BAD_JSON' }); }
  const action = String(b.action || '');
  const h = lower(event.headers || {});
  const ip = String(h['x-nf-client-connection-ip'] || h['x-forwarded-for'] || '').split(',')[0].trim() || 'noip';

  try {
    if (action === 'register') {
      const email = normEmail(b.email), pw = String(b.password || '');
      if (!EMAIL_RE.test(email)) return json(400, { ok: false, code: 'BAD_EMAIL' });
      if (pw.length < 8 || pw.length > 128) return json(400, { ok: false, code: 'BAD_PASSWORD' });
      const data = cleanData(b.data); if (data === null) return json(413, { ok: false, code: 'TOO_LARGE' });
      const rk = `r:${jstDay()}:${ip}`, rc = await readNum(store, rk);
      if (rc >= REG_PER_IP_DAY) return json(429, { ok: false, code: 'RATE' });
      const key = userKey(email);
      if (await store.get(key)) return json(409, { ok: false, code: 'EXISTS' });
      const salt = crypto.randomBytes(16).toString('hex');
      const now = Date.now();
      const rec = { email, salt, hash: hashPw(pw, salt), ver: 1, created: now, updated: now, fails: 0, lockUntil: 0, data };
      await store.setJSON(key, rec);
      await store.set(rk, String(rc + 1));
      return json(200, { ok: true, email, token: makeToken(email, rec.ver, secret) });
    }

    if (action === 'login') {
      const email = normEmail(b.email), pw = String(b.password || '');
      const key = userKey(email);
      const rec = EMAIL_RE.test(email) ? await store.get(key, { type: 'json' }) : null;
      if (!rec) { hashPw(pw, 'x'); return json(401, { ok: false, code: 'BAD_LOGIN' }); } // 登録有無を応答時間で漏らしにくくする
      if (rec.lockUntil && rec.lockUntil > Date.now()) return json(429, { ok: false, code: 'LOCKED', retryMin: Math.ceil((rec.lockUntil - Date.now()) / 60000) });
      if (!safeEq(hashPw(pw, rec.salt), rec.hash)) {
        rec.fails = (rec.fails || 0) + 1;
        if (rec.fails >= LOCK_FAILS) { rec.lockUntil = Date.now() + LOCK_MIN * 60000; rec.fails = 0; }
        await store.setJSON(key, rec);
        return json(401, { ok: false, code: 'BAD_LOGIN' });
      }
      if (rec.fails || rec.lockUntil) { rec.fails = 0; rec.lockUntil = 0; await store.setJSON(key, rec); }
      return json(200, { ok: true, email: rec.email, token: makeToken(rec.email, rec.ver, secret), data: rec.data || {}, updated: rec.updated });
    }

    // ここから先はトークン必須
    const t = readToken(b.token, secret);
    if (!t) return json(401, { ok: false, code: 'BAD_TOKEN' });
    const key = `u:${t.uid}`;
    const rec = await store.get(key, { type: 'json' });
    if (!rec || rec.ver !== t.ver) return json(401, { ok: false, code: 'BAD_TOKEN' });

    if (action === 'save') {
      const data = cleanData(b.data); if (data === null) return json(413, { ok: false, code: 'TOO_LARGE' });
      rec.data = data; rec.updated = Date.now();
      await store.setJSON(key, rec);
      return json(200, { ok: true, updated: rec.updated });
    }
    if (action === 'load') return json(200, { ok: true, email: rec.email, data: rec.data || {}, updated: rec.updated });
    if (action === 'change') {
      if (!safeEq(hashPw(String(b.password || ''), rec.salt), rec.hash)) return json(401, { ok: false, code: 'BAD_LOGIN' });
      const np = String(b.newPassword || '');
      if (np.length < 8 || np.length > 128) return json(400, { ok: false, code: 'BAD_PASSWORD' });
      rec.salt = crypto.randomBytes(16).toString('hex'); rec.hash = hashPw(np, rec.salt);
      rec.ver = (rec.ver || 1) + 1; rec.updated = Date.now();   // 他の端末のログインは無効になる
      await store.setJSON(key, rec);
      return json(200, { ok: true, token: makeToken(rec.email, rec.ver, secret) });
    }
    if (action === 'delete') {
      if (!safeEq(hashPw(String(b.password || ''), rec.salt), rec.hash)) return json(401, { ok: false, code: 'BAD_LOGIN' });
      await store.delete(key);
      return json(200, { ok: true });
    }
    return json(400, { ok: false, code: 'BAD_ACTION' });
  } catch (e) {
    // Blobs 未接続（手動zipデプロイ等）は NO_STORE として返し、原因を見分けやすくする
    const blob = /blob/i.test(String((e && (e.name || '')) + ' ' + (e && e.message || '')));
    return json(blob ? 503 : 500, { ok: false, code: blob ? 'NO_STORE' : 'SERVER' });
  }
};

function normEmail(s) { return String(s || '').trim().toLowerCase().slice(0, 254); }
function userId(email) { return crypto.createHash('sha256').update(email).digest('hex'); }
function userKey(email) { return `u:${userId(email)}`; }
function hashPw(pw, salt) { return crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex'); }
function safeEq(a, b) { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }
function makeToken(email, ver, secret) {
  const body = `${userId(email)}.${ver}.${Date.now() + TOKEN_DAYS * 864e5}`;
  return `${body}.${crypto.createHmac('sha256', secret).update(body).digest('hex')}`;
}
function readToken(tok, secret) {
  const p = String(tok || '').split('.'); if (p.length !== 4) return null;
  const body = `${p[0]}.${p[1]}.${p[2]}`;
  if (!safeEq(crypto.createHmac('sha256', secret).update(body).digest('hex'), p[3])) return null;
  if (+p[2] < Date.now()) return null;
  return { uid: p[0], ver: +p[1] };
}
// 端末データ：pk_ で始まるキーの文字列だけを受け付ける（APIキーやログイン情報は除外）
function cleanData(d) {
  const o = {}; let n = 0;
  if (d && typeof d === 'object') for (const k of Object.keys(d)) {
    if (!/^pk_[A-Za-z0-9_]{1,40}$/.test(k) || k === 'pk_key' || k === 'pk_auth') continue;
    const v = String(d[k]); n += k.length + v.length; o[k] = v;
  }
  return n > MAX_DATA ? null : o;
}
async function readNum(store, k) { const v = await store.get(k); return v ? (parseInt(v, 10) || 0) : 0; }
// Lambda互換（exports.handler）の関数では、Blobs を使う前に connectLambda(event) が必要
async function getStore(event) {
  try { const b = require('@netlify/blobs'); if (b.connectLambda && event && event.blobs) b.connectLambda(event); return b.getStore('pk-accounts'); }
  catch (e) { return null; }
}
function jstDay() { const d = new Date(Date.now() + 9 * 3600 * 1000); return d.toISOString().slice(0, 10); }
function lower(o) { const r = {}; for (const k in o) r[k.toLowerCase()] = o[k]; return r; }
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(obj) }; }

// ---- テスト用エクスポート（本番動作には影響しない） ----
exports._t = { hashPw, makeToken, readToken, cleanData, normEmail };
