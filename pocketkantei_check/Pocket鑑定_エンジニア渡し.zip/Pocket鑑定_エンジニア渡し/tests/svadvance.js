// 登録のアンケート：選んだら次の質問へ自動で進む（スクロールしなくてよい）
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){ r.writeHead(404); return r.end('{}'); } let f=path.join(__dirname,'fx',decodeURIComponent(q.url.split('?')[0])); if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{ if(e){ r.writeHead(404); return r.end(); } r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
  const b=await chromium.launch(); const pg=await b.newPage({viewport:{width:390,height:740}}); const errs=[]; pg.on('pageerror',e=>errs.push(String(e))); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
  await pg.addInitScript(()=>{ localStorage.setItem('pk_lang','ja'); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_profile',JSON.stringify({name:'T',y:1990,m:4,d:8,tu:false,hh:12,mi:0,sex:'female',place:'tokyo'})); });
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1200);
  await pg.evaluate(()=>{ showSurvey(); document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active')); document.getElementById('scSurvey').classList.add('active'); window.scrollTo(0,0); });
  await pg.waitForTimeout(500);
  const top=async id=>pg.evaluate(id=>{ const e=document.getElementById(id); return Math.round(e.getBoundingClientRect().top); },id);
  const before=await top('svIvL');
  await pg.click('#svTopics button'); await pg.waitForTimeout(500);
  chk('いくつでも選べる質問は、選んですぐには動かない（続けて選べる）',Math.abs((await top('svIvL'))-before)<5);
  await pg.waitForTimeout(1500);
  const a=await top('svIvL'); chk('少し待つと、次の質問が画面の上に来る',a>=-5&&a<200,a);
  await pg.click('#svInterests button'); await pg.waitForTimeout(2000);
  const c=await top('svSrcL'); chk('次の質問へ（2つ目）',c>=-5&&c<200,c);
  await pg.click('#svSrcs button'); await pg.waitForTimeout(1200);
  const d=await top('svFreqL'); chk('1つだけ選ぶ質問は、選ぶとすぐ次へ',d>=-5&&d<200,d);
  await pg.click('#svFreqs button'); await pg.waitForTimeout(1200); await pg.click('#svJobs button'); await pg.waitForTimeout(1200);
  const e=await top('svBtn'); chk('最後の質問のあとは「はじめる」ボタンが見える',e>0&&e<740,e);
  chk('画面のエラーなし',errs.length===0,errs);
  await b.close(); srv.close(); console.log(ok+' OK / '+ng+' NG'); });
