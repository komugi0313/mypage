/* 相性：相手の性別が書いていない時は、Nico が先に聞く（運営決定 2026-10-24）。答えたら、その性別で計算し直す
   node sexask.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ const o={};
  function setup(usx){ state.profile={y:2000,m:4,d:4,sex:usx,place:'tokyo'}; state.chart=computeChart({name:'',y:2000,m:4,d:4,tu:true,hh:12,mi:0,sex:usx,place:'tokyo'}); state.chartB=null; state.mode='chat'; state.msgs=[{role:'ai',text:'お相手の生年月日を教えてください'}]; }
  setup('male'); chatPartnerScan('相手は2000年5月3日14時生まれです'); o.ask1=!!state.chartB._sexAsk; o.k1=state.chartB._bkey;
  o.ans=chatPartnerScan('男性です'); o.just=window._sexJustGiven; o.k2=state.chartB._bkey; o.ask2=!!state.chartB._sexAsk; o.dec=state.chartB.pro.decadeFortunes.slice(0,3).map(d=>d.ganzhi).join(','); o.hour=state.chartB.pro.pillars[3]&&state.chartB.pro.pillars[3].ganzhi;
  setup('male'); chatPartnerScan('相手は2000年5月3日14時生まれの男性です'); o.ask3=!!state.chartB._sexAsk;
  setup('female'); chatPartnerScan('彼は1990年2月3日生まれ'); o.ask4=!!state.chartB._sexAsk;
  setup('female'); chatPartnerScan('相手は1992年7月1日生まれ'); o.ask5=!!state.chartB._sexAsk; o.ans5=chatPartnerScan('女です'); o.k5=state.chartB._bkey;
  setup('male'); chatPartnerScan('Partner was born on 1999-08-09'); o.ask6=!!state.chartB._sexAsk; o.ans6=chatPartnerScan("She's a woman"); o.k6=state.chartB._bkey;
  setup('male'); chatPartnerScan('상대는 1990년 2월 3일생이에요'); o.ask7=!!state.chartB._sexAsk; chatPartnerScan('남자예요'); o.k7=state.chartB._bkey;
  /* 性別を聞いたあと、関係ない話には反応しない */
  setup('male'); chatPartnerScan('相手は1992年7月1日生まれ'); const k8=state.chartB._bkey; o.ans8=chatPartnerScan('今日は雨ですね'); o.k8same=(state.chartB._bkey===k8);
  return o; });
console.log(JSON.stringify(R));
chk('性別が書いていない → 聞く',R.ask1&&R.ask5&&R.ask6&&R.ask7);
chk('「男性です」で計算し直す（男性・14時のまま）',R.ans===true&&R.just===true&&R.k2==='2000-5-3-14:0-male'&&R.dec==='辛巳,壬午,癸未'&&R.hour==='乙未'&&!R.ask2,R);
chk('「男性」と書いてあれば聞かない',!R.ask3);
chk('「彼」と書いてあれば聞かない',!R.ask4);
chk('「女です」「She\'s a woman」「남자예요」で計算し直す',R.k5==='1992-7-1-female'&&R.k6==='1999-8-9-female'&&R.k7==='1990-2-3-male',[R.k5,R.k6,R.k7]);
chk('関係ない話では計算し直さない',R.k8same&&!R.ans8);
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
