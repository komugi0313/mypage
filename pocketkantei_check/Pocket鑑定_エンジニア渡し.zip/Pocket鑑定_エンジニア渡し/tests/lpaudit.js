const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
/* 紹介ページを4言語で調べる（ほかの言語の文字・中黒・空の文・はみ出し・消したはずの表現）：node lpaudit.js */
const ROOT=path.join(__dirname,'..','site'), OUT=path.join(__dirname,'shots_lpaudit'); fs.mkdirSync(OUT,{recursive:true});
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.endsWith('/')) u+='index.html'; fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':u.endsWith('.png')?'image/png':'application/javascript'}); r.end(b); }); });
const KANA=/[぀-ヺー-ヿ]/, DOT=/・/, HAN=/[一-鿿]/, HANGUL=/[가-힯]/;
const BANNED=[/(?<!\d)(50|100|175)\s*(回|readings?|회|次)/i,/対面の鑑定1回より安く|鑑定の質は同じ/,/真太陽時|진태양시|陰陽五行|true solar/i,/ほかにありません|elsewhere|어디에도 없|別處沒有/,/こんなにも当たる|uncannily|이렇게까지 맞|如此之準/,/クレカ|credit card|신용카드|信用卡|카드 불필요/i];
srv.listen(0,async()=>{ const b=await chromium.launch(); const issues=[], errs=[];
 for(const [L,p] of [['ja','/lp.html'],['en','/en/'],['ko','/ko/'],['zt','/zt/']]){
  const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,locale:'ja-JP'}); const pg=await ctx.newPage(); pg.on('pageerror',e=>errs.push(L+': '+e));
  await ctx.addInitScript(l=>{ localStorage.setItem('pk_lang',l); },L);
  await pg.goto('http://127.0.0.1:'+srv.address().port+p); await pg.waitForTimeout(1500);
  await pg.evaluate(()=>{ document.querySelectorAll('details').forEach(d=>d.open=true); document.querySelectorAll('[data-r]').forEach(e=>e.classList.add('on')); const s=document.getElementById('stickyCta'); if(s) s.style.display='none'; });
  await pg.waitForTimeout(800);
  const info=await pg.evaluate(()=>({text:document.body.innerText, empties:[...document.querySelectorAll('[data-t],[data-t-html]')].filter(e=>!e.closest('[hidden]')&&getComputedStyle(e).display!=='none'&&!e.textContent.trim()).map(e=>e.getAttribute('data-t')||e.getAttribute('data-t-html')), sw:document.documentElement.scrollWidth, title:document.title, lang:document.documentElement.lang,
    wide:[...document.querySelectorAll('body *')].filter(e=>{ const r=e.getBoundingClientRect(); return r.width>0&&r.right>392&&getComputedStyle(e).position!=='fixed'; }).slice(0,5).map(e=>e.tagName+'.'+e.className+' '+Math.round(e.getBoundingClientRect().right))}));
  if(info.sw>390) issues.push(`${L}: 横にはみ出し（幅 ${info.sw}）`+info.wide.join(' / '));
  if(info.empties.length) issues.push(`${L}: 空の文 ${info.empties.join(',')}`);
  const lines=info.text.split('\n').map(x=>x.trim()).filter(Boolean);
  for(const ln of lines){ let bad='';
    if(L!=='ja'&&KANA.test(ln)) bad='かな';
    if(L!=='ja'&&DOT.test(ln)) bad=bad||'中黒';
    if(L==='en'&&(HAN.test(ln)||HANGUL.test(ln))) bad=bad||'漢字/ハングル';
    if(L==='ko'&&HAN.test(ln)) bad=bad||'漢字';
    if((L==='zt'||L==='ja')&&HANGUL.test(ln)) bad=bad||'ハングル';
    for(const r of BANNED) if(r.test(ln)) bad=bad||('消したはずの表現 '+r.source.slice(0,20));
    if(bad&&!/^(日本語|English|한국어|繁體中文)$/.test(ln)) issues.push(`${L}: [${bad}] ${ln.slice(0,100)}`); }
  console.log(L,'title:',info.title,'| lang:',info.lang,'| 行数',lines.length);
  await pg.screenshot({path:`${OUT}/${L}_full.png`,fullPage:true});
  fs.writeFileSync(`${OUT}/${L}_text.txt`,info.text);
  await ctx.close(); }
 console.log(issues.length?issues.join('\n'):'問題なし'); console.log('errs',errs); await b.close(); srv.close(); });
