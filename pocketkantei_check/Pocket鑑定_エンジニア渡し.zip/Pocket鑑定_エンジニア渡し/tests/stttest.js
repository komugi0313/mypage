// 声を文字にする呼び出し（x-pk-stt）：上位モデルで、考える時間なし・出力の長さに上限（AI は偽物）
//   PK_STORE=memory NODE_PATH=mock/node_modules node stttest.js（無料はログインが必要なので、仮のアカウントで呼ぶ）
process.env.GEMINI_API_KEY='dummy'; process.env.PK_NOCARD_TRIAL='1'; process.env.AUTH_SECRET=process.env.AUTH_SECRET||'test-secret-0123456789abcdef'; let sent=[];
global.fetch=async(url,o)=>{ sent.push({model:url.match(/models\/([^:]+)/)[1],body:JSON.parse(o.body)}); return {ok:true,status:200,text:async()=>JSON.stringify({candidates:[{content:{parts:[{text:'こんにちは'}]}}]})}; };
const gem=require('./fx/functions/gemini.js').handler, auth=require('./fx/functions/auth.js').handler; let ok=0,ng=0;
const eq=(n,a,x)=>{const g=JSON.stringify(a)===JSON.stringify(x); g?ok++:ng++; console.log((g?'OK  ':'NG  ')+n+(g?'':' → '+JSON.stringify(a)+' ≠ '+JSON.stringify(x)));};
(async()=>{
  const tok=JSON.parse((await auth({httpMethod:'POST',headers:{},body:JSON.stringify({action:'register',email:'stt@x.com',password:'sakura2026',data:{}})})).body).token;
  const body=JSON.stringify({contents:[{role:'user',parts:[{inlineData:{mimeType:'audio/webm',data:'AAAA'}},{text:'Transcribe.'}]}],generationConfig:{maxOutputTokens:5000}});
  const r=await gem({httpMethod:'POST',headers:{'x-pk-auth':tok,'x-pk-device':'d1','x-pk-stt':'1','x-pk-deep':'1','x-pk-nocount':'1'},body});
  eq('声の文字起こしは成功する',r.statusCode,200);
  eq('上位モデルで文字にする（聞き取りの正確さ優先）',sent[0].model.includes('lite'),false);
  eq('考える時間なし（速く・安く）',sent[0].body.generationConfig.thinkingConfig,{thinkingLevel:'minimal'});
  eq('出力の長さは1000トークンまで',sent[0].body.generationConfig.maxOutputTokens,1000);
  eq('音声はそのまま Gemini に渡す',sent[0].body.contents[0].parts[0].inlineData.mimeType,'audio/webm');
  const r2=await gem({httpMethod:'POST',headers:{'x-pk-auth':tok,'x-pk-device':'d1','x-pk-deep':'1'},body:JSON.stringify({contents:[{role:'user',parts:[{text:'hi'}]}]})});
  const r3=await gem({httpMethod:'POST',headers:{'x-pk-device':'d9','x-pk-stt':'1'},body});
  eq('ログインしていない声の文字起こしは断る',r3.statusCode,401);
  eq('ふつうの上位モデルの呼び出しは今まで通り',sent[1].model.includes('lite'),false);
  console.log(`\n${ok} OK / ${ng} NG`); process.exit(ng?1:0);
})();
