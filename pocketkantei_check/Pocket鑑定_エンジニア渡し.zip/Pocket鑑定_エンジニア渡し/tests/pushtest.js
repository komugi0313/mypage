// Nicoからのメッセージ（push-lib.js）の動作テスト：AI・Firebase は偽物に差し替え（鍵は不要）
const crypto=require('crypto');
process.env.AUTH_SECRET='test-secret-0123456789abcdef'; process.env.GEMINI_API_KEY='dummy';
const {privateKey}=crypto.generateKeyPairSync('rsa',{modulusLength:2048});
process.env.FCM_PROJECT_ID='pk-test'; process.env.FCM_CLIENT_EMAIL='svc@pk-test.iam.gserviceaccount.com';
process.env.FCM_PRIVATE_KEY=privateKey.export({type:'pkcs8',format:'pem'}).replace(/\n/g,'\\n');
const L=require('./fx/functions/push-lib.js'), auth=require('./fx/functions/auth.js').handler;
const store=require('pk-test-store').getStore('pk-accounts');
const post=b=>auth({httpMethod:'POST',headers:{},body:JSON.stringify(b)}).then(o=>JSON.parse(o.body));
let ok=0,ng=0; const eq=(n,a,b)=>{ const r=JSON.stringify(a)===JSON.stringify(b); r?ok++:ng++; console.log(r?'OK ':'NG ',n,r?'':`→ ${JSON.stringify(a)} ≠ ${JSON.stringify(b)}`); };
// 偽の AI と Firebase
let aiQueue=[], sent=[], fcmStatus=200, lastSys='';
const fakeFetch=async(url,opt)=>{
  if(/generativelanguage/.test(url)){ const b=JSON.parse(opt.body); lastSys=b.systemInstruction.parts[0].text+'\n'+b.contents[0].parts[0].text; const t=aiQueue.length?aiQueue.shift():'おはよう☀️ 今日もいってらっしゃい';
    return {ok:true,json:async()=>({candidates:[{content:{parts:[{text:t}]}}],usageMetadata:{promptTokenCount:1500,candidatesTokenCount:40}})}; }
  if(/oauth2/.test(url)) return {ok:true,json:async()=>({access_token:'at-1',expires_in:3600})};
  if(/fcm.googleapis/.test(url)){ const b=JSON.parse(opt.body); sent.push(b.message); if(fcmStatus!==200) return {ok:false,status:fcmStatus,text:async()=>'{"error":{"status":"NOT_FOUND","details":[{"errorCode":"UNREGISTERED"}]}}'}; return {ok:true,status:200}; }
  throw new Error('unexpected '+url);
};
const D={fetch:fakeFetch};
const at=(iso)=>Date.parse(iso);
// テストの中の時計を、テストの日付（2026-10-01）に合わせる。今日の日付で結果が変わらないように（受け取り箱は7日以内だけを返すため）
const _realNow=Date.now; Date.now=()=>at('2026-10-01T23:30:00Z')+(_realNow()-_t0); const _t0=_realNow();
(async()=>{
  const r=await post({action:'register',email:'nico@example.com',password:'sakura2026',data:{pk_lang:'ja',pk_tmsg:'75',pk_profile:JSON.stringify({name:'りえ',sex:'female'}),pk_mem:'- 来週、転職の面接がある（相手：田中さん）',pk_msgs:JSON.stringify([{role:'me',text:'面接が不安'},{role:'ai',text:'大丈夫だよ'}])}});
  const tok=r.token, uid=tok.split('.')[0];
  // 設定：東京の朝9時 → UTC 0時の区切り（送る枠は朝8時半〜夜8時）
  const s1=await post({action:'push_set',token:tok,pushToken:'fcm-tok-1',on:true,mode:'fixed',hour:9,tz:'Asia/Tokyo',lang:'ja',platform:'ios'});
  eq('設定できる',s1.push,{on:true,mode:'fixed',hour:9,tz:'Asia/Tokyo'});
  eq('UTC0時の目印',!!(await store.get(`pb:0:${uid}`)),true);
  eq('認証トークンなしは拒否',(await post({action:'push_set',pushToken:'x',on:true})).code,'BAD_TOKEN');
  // 東京 9:00 に送る
  const t1=at('2026-10-02T00:00:05Z');
  let res=await L.runHour(store,store,0,t1,D);
  eq('送った',res.out,{sent:1});
  eq('Firebaseへ（宛先・題名・本文）',[sent[0].token,sent[0].notification.title,sent[0].notification.body],['fcm-tok-1','Nico 🦉','おはよう☀️ 今日もいってらっしゃい']);
  eq('指示：日本語・親しい段階・朝・ロック画面の配慮',[/Write ONLY in Japanese/.test(lastSys),/CLOSE COMPANION/.test(lastSys),/morning/.test(lastSys),/lock screen/.test(lastSys),/転職の面接/.test(lastSys),/面接が不安/.test(lastSys)],[true,true,true,true,true,true]);
  eq('運勢の案内はしない指示',/Do NOT: tell fortunes/.test(lastSys),true);
  // 受け取り箱
  const ib=await post({action:'push_inbox',token:tok});
  eq('受け取り箱に1件',[ib.items.length,ib.items[0].text,ib.push.on],[1,'おはよう☀️ 今日もいってらっしゃい',true]);
  // 同じ日にもう一度 → 送らない
  res=await L.runHour(store,store,0,t1+600e3,D); eq('同じ日は1回だけ',res.out,{done:1});
  // 翌日：前と同じ文面が来たら作り直す
  aiQueue=['おはよう☀️ 今日もいってらっしゃい','おはよう、りえ。ご飯はちゃんと食べてね🍙'];
  res=await L.runHour(store,store,0,at('2026-10-03T00:00:05Z'),D);
  eq('似た文面は作り直して送る',[res.out,sent[sent.length-1].notification.body],[{sent:1},'おはよう、りえ。ご飯はちゃんと食べてね🍙']);
  eq('前に送った文面を指示に入れる',/RECENT MESSAGES YOU SENT\]\n- おはよう☀️/.test(lastSys),true);
  // 言語違い2回 → 送らない
  aiQueue=['Good morning!','Have a nice day!'];
  res=await L.runHour(store,store,0,at('2026-10-04T00:00:05Z'),D); eq('言語が違えば送らない',res.out,{nogen:1});
  // 長すぎる → 送らない
  aiQueue=['あ'.repeat(200),'い'.repeat(200)];
  res=await L.runHour(store,store,0,at('2026-10-05T00:00:05Z'),D); eq('長すぎれば送らない',res.out,{nogen:1});
  // アプリを消した端末（Firebase 404）→ 以後送らない
  fcmStatus=404; aiQueue=['おつかれさま、ゆっくり休んでね'];
  res=await L.runHour(store,store,0,at('2026-10-06T00:00:05Z'),D); eq('消えた端末は止める',res.out,{unregistered:1});
  eq('目印も消える',[await store.get(`pb:0:${uid}`),(await store.get(`ps:${uid}`,{type:'json'})).on],[null,false]);
  fcmStatus=200;
  // 再設定 → オフ
  await post({action:'push_set',token:tok,pushToken:'fcm-tok-2',on:true,mode:'fixed',hour:9,tz:'Asia/Tokyo'});
  await post({action:'push_set',token:tok,on:false});
  eq('オフにすると目印が消える',[await store.get(`pb:0:${uid}`),(await store.get(`ps:${uid}`,{type:'json'})).on],[null,false]);
  // 長く開いていない無料の人には送らない
  await post({action:'push_set',token:tok,pushToken:'fcm-tok-3',on:true,mode:'fixed',hour:9,tz:'Asia/Tokyo'});
  const ps=await store.get(`ps:${uid}`,{type:'json'}); ps.seen=at('2026-10-01T00:00:00Z'); await store.setJSON(`ps:${uid}`,ps);
  res=await L.runHour(store,store,0,at('2026-10-21T00:00:05Z'),D); eq('14日以上開いていない無料の人は送らない',res.out,{inactive:1});
  // 夏時間：ニューヨーク朝9時（夏はUTC13時）→ 冬になると UTC14時へ付け直す
  const r2=await post({action:'register',email:'ny@example.com',password:'sakura2026',data:{pk_lang:'en',pk_tmsg:'3'}});
  const tok2=r2.token, uid2=tok2.split('.')[0];
  const L0=L._t; const b0=L0.utcHourFor('America/New_York',9,at('2026-10-15T00:00:00Z'));
  eq('夏時間のUTC',b0,13);
  const ps2={on:true,token:'fcm-ny',mode:'fixed',hour:9,tz:'America/New_York',lang:'en',bucket:13,seen:at('2026-11-05T00:00:00Z')}; await store.setJSON(`ps:${uid2}`,ps2); await store.set(`pb:13:${uid2}`,'1');
  res=await L.runHour(store,store,13,at('2026-11-05T13:00:05Z'),D); eq('冬時間になったら付け直す',[res.out,!!(await store.get(`pb:14:${uid2}`)),await store.get(`pb:13:${uid2}`)],[{moved:1},true,null]);
  aiQueue=['Good morning! Did you sleep okay? ☕'];
  res=await L.runHour(store,store,14,at('2026-11-05T14:00:05Z'),D); eq('付け直した時刻に送る',res.out,{sent:1});
  eq('英語・出会ったばかりの段階',[/Write ONLY in English/.test(lastSys),/NEW — you two have just met/.test(lastSys)],[true,true]);
  // 有料の人は原価を1か月の上限に含める
  const rec=await store.get(`u:${uid2}`,{type:'json'}); rec.sub={plan:'std',start:at('2026-11-01T00:00:00Z'),expires:Date.now()+20*864e5,willRenew:true,store:'APP_STORE'}; await store.setJSON(`u:${uid2}`,rec);
  aiQueue=['Hope your day is going well 🌿'];
  const before=[...store._m.keys()].filter(k=>/^c:/.test(k)).length;
  res=await L.runHour(store,store,14,at('2026-11-06T14:00:05Z'),D);
  eq('有料の人の原価を記録',[res.out,[...store._m.keys()].filter(k=>/^c:/.test(k)).length>before],[{sent:1},true]);
  // 退会すると全部消える
  await post({action:'delete',token:tok2,password:'sakura2026',force:true});
  eq('退会で消える',[await store.get(`ps:${uid2}`),await store.get(`pi:${uid2}`),await store.get(`pb:14:${uid2}`)],[null,null,null]);
  // ---- おまかせ（毎日ちがう時間帯）----
  const r3=await post({action:'register',email:'auto@example.com',password:'sakura2026',data:{pk_lang:'ja',pk_tmsg:'30'}});
  const tok3=r3.token, uid3=tok3.split('.')[0];
  const s3=await post({action:'push_set',token:tok3,pushToken:'fcm-auto',on:true,hour:9,tz:'Asia/Tokyo'});
  eq('既定はおまかせ',s3.push.mode,'auto');
  for(const k of [...store._m.keys()]) if(/^pb:/.test(k)&&!k.endsWith(uid3)) store._m.delete(k);   // ほかの人は外して、この人だけで確かめる
  const hours=[]; let day=Date.parse('2026-10-10T00:00:00Z');
  for(let d=0;d<12;d++){
    // その日の8〜21時（東京）を1時間ずつ回す＝本番の毎時実行と同じ
    { const q=await store.get(`ps:${uid3}`,{type:'json'}); q.seen=day+d*864e5; await store.setJSON(`ps:${uid3}`,q); }
    const uniq=['さくら','うみ','そら','ほし','かぜ','もり','やま','かわ','はな','つき','ゆき','にじ'][d];
    for(let h=8;h<=21;h++){ const t=day+d*864e5+(h-9)*3600e3+5e3; const uh=new Date(t).getUTCHours();
      aiQueue=[uniq+uniq+uniq+'！'+['おはよう','お昼食べた？','午後もね','おつかれさま','休んでね'][L0.slotOf(h)]];
      const rr=await L.runHour(store,store,uh,t,D); if(process.env.DBG&&rr.total) console.log(d,h,JSON.stringify(rr.out)); }
  }
  const got=sent.filter(m=>m.token==='fcm-auto').map(m=>m.notification.body);
  const psA=await store.get(`ps:${uid3}`,{type:'json'});
  eq('おまかせ：12日で12通（1日1回）',got.length,12);
  const slots=psA.hist.map(x=>x.replace(/^.*！/,''));
  eq('おまかせ：時間帯がばらける（3種類以上）',new Set(slots).size>=3,true);
  let rep2=0; for(let i=1;i<slots.length;i++) if(slots[i]===slots[i-1]) rep2++;
  eq('おまかせ：前の日と同じ時間帯が続かない',rep2,0);
  // 送る枠：その人の地域の朝8時半〜夜8時（運営決定 2026-10-26）。時差が30分・45分ずれる地域でも枠の中
  { const now0=at('2026-11-02T00:00:00Z'), bad=[];
    for(const tz of ['Asia/Tokyo','Asia/Kolkata','Asia/Kathmandu','Australia/Adelaide','America/St_Johns','America/New_York','Asia/Seoul','Asia/Taipei']){ const off=L0.offMin(tz,now0);
      for(let i=0;i<500;i++){ const h=L0.pickAutoHour(i%24,Math.random,off), m=h*60+off; if(m<510||m>1200) bad.push(tz+' auto '+h+':'+off); }
      for(let h=0;h<24;h++){ const f=L0.fitHour(h,off), m=f*60+off; if(m<510||m>1200) bad.push(tz+' fixed '+h+'→'+f+':'+off); } }
    eq('送るのは、どの地域でも朝8時半〜夜8時だけ（おまかせ・時刻指定とも）',bad,[]); }
  eq('インド：おまかせのいちばん遅い時刻は19:30',Math.max(...Array.from({length:300},(_, i)=>L0.pickAutoHour(i%24,Math.random,30))),19);
  eq('話し方の段階はチャットと同じ（打ち解けたら日本語はタメ語だけ）',/soft タメ語 in EVERY sentence \(no です・ます/.test(L0.stageOf?L0.stageOf(30):''),true);
  // 旅行：アプリを開いた地域がニューヨークに変わった → 目印を付け直す
  const ib3=await post({action:'push_inbox',token:tok3,tz:'America/New_York'});
  const psB=await store.get(`ps:${uid3}`,{type:'json'});
  eq('旅行先の地域に合わせ直す',[psB.tz,psB.bucket===L0.utcHourFor('America/New_York',psB.target,Date.now()),!!(await store.get(`pb:${psB.bucket}:${uid3}`))],['America/New_York',true,true]);
  // 時間帯に合わない言葉は作り直す（夜の「おはよう」）
  const tOk=L0.timeOk;
  eq('時間帯チェック',[tOk('おはよう！','ja',20),tOk('今日もおつかれさま','ja',20),tOk('Good morning, Rie!','en',19),tOk('早安！','zh',8),tOk('저녁은 먹었어?','ko',9),tOk('¿Ya cenaste?','es',20),tOk('Bom dia!','pt',21),tOk('Selamat malam!','id',7),tOk('ฝันดีนะ','th',21)],[false,true,false,true,false,true,false,false,true]);
  const r4=await post({action:'register',email:'night@example.com',password:'sakura2026',data:{pk_lang:'ja'}});
  const tok4=r4.token, uid4=tok4.split('.')[0];
  await post({action:'push_set',token:tok4,pushToken:'fcm-night',on:true,mode:'fixed',hour:20,tz:'Asia/Tokyo'});
  aiQueue=['おはよう！今日もがんばろう','今日もおつかれさま、ゆっくりしてね'];
  await L.runHour(store,store,11,Date.parse('2026-10-01T11:00:05Z'),D);
  eq('夜に「おはよう」は送らず作り直す',sent.filter(m=>m.token==='fcm-night').map(m=>m.notification.body),['今日もおつかれさま、ゆっくりしてね']);
  // 曜日の取り違え（木曜に「週の始まり」、火曜に「週末」、金曜に「水曜」など）は作り直す
  const dOk=L0.dayOk;
  eq('曜日チェック',[dOk('Espero que tengas un hermoso comienzo de semana','es','Thursday'),dOk('¡Feliz jueves!','es','Thursday'),dOk('週末楽しんで','ja','Tuesday'),dOk('もう週末だね','ja','Friday'),dOk('Happy Friday!','en','Thursday'),dOk('周三加油','zh','Friday'),dOk('불금이다!','ko','Friday'),dOk('Boa sexta!','pt','Wednesday'),dOk('Chúc cuối tuần vui','vi','Tuesday'),dOk('วันศุกร์แล้ว','th','Friday'),dOk('Semangat hari Senin!','id','Monday')],[false,true,false,true,false,false,true,false,false,true,true]);
  const r5=await post({action:'register',email:'day@example.com',password:'sakura2026',data:{pk_lang:'es'}});
  const tok5=r5.token;
  await post({action:'push_set',token:tok5,pushToken:'fcm-day',on:true,mode:'fixed',hour:9,tz:'Asia/Tokyo',lang:'zt'});
  aiQueue=['早安！新的一週開始囉 🌞','早安！昨晚睡得好嗎？☀️'];
  await L.runHour(store,store,0,Date.parse('2026-10-08T00:00:05Z'),D);   // 10/8 木曜 9時（東京）
  eq('木曜に「週の始まり」は送らず作り直す',sent.filter(m=>m.token==='fcm-day').map(m=>m.notification.body),['早安！昨晚睡得好嗎？☀️']);
  // 公開していない言語（例：スペイン語）で登録された時は英語で書く
  eq('非公開の言語は英語に置き換える',L._t.buildPrompt({pk_lang:'es'},{tz:'Asia/Tokyo'},Date.parse('2026-10-08T00:00:05Z')).lang,'en');
  // 言語チェック
  const lk=L0.langOk;
  eq('言語チェック',[lk('おはよう','ja'),lk('早安，吃饭了吗？','zh'),lk('早安，ご飯','zh'),lk('좋은 아침','ko'),lk('อรุณสวัสดิ์','th'),lk('Chào buổi sáng','vi'),lk('Buenos días','es'),lk('Good morning','vi')],[true,true,false,true,true,true,true,false]);
  console.log(`\n${ok} OK / ${ng} NG`);
})().catch(e=>{console.error(e);process.exit(1)});
