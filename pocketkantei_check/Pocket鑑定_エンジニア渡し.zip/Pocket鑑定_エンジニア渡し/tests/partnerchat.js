// チャットに打ったお相手の生年月日（運営指摘 2026-10-31）：Nico が聞いた後に相性のカードなどが挟まっても・全角の数字でも・「男性です」と一緒でも、お相手として相性に入る。入社日など・本人の誕生日は拾わない
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{ let f=path.join(__dirname,'fx',q.url.split('?')[0]); fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
 const b=await chromium.launch(); const pg=await b.newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
 await pg.addInitScript(()=>{localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1995,m:1,d:1,hh:12,tu:false,mi:0,sex:'female',place:'tokyo'}));localStorage.setItem('pk_msgs','[{"role":"ai","text":"hi"}]');});
 await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(1500);
 let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
 const run=(msgs,q)=>pg.evaluate(([msgs,q])=>{ state.mode='self'; state.chartB=null; state.msgs=msgs.concat([{role:'me',text:q}]); const ok=chatPartnerScan(q); return {ok:!!ok,mode:state.mode,b:state.chartB&&state.chartB._bkey,sex:state.chartB&&state.chartB._sex}; },[msgs,q]);
 const asked=[{role:'me',text:'彼が浮気してた'},{role:'ai',text:'お相手の生年月日（西暦・月・日）が分かれば、二人の相性も詳しく見られますので、教えてくださいね。'},{role:'ai',text:'相性をみてみたよ。\n\n相性スコア 66/100 ・ 価値観が似た二人'}];
 let r=await run(asked,'１９９０年１２月５日男性です'); chk('聞いた後に相性のカードが挟まっても・全角の数字でも、お相手として入る（男性）',r.ok&&r.mode==='aisho'&&/^1990-12-5/.test(r.b)&&r.sex==='male',r);
 r=await run([{role:'ai',text:'それはつらかったですね。'}],'1990年12月5日男性です'); chk('聞かれていなくても「男性です」と一緒なら、お相手として入る',r.ok&&r.mode==='aisho'&&r.sex==='male',r);
 r=await run([{role:'ai',text:'それはつらかったですね。'}],'2020年4月1日に入社しました'); chk('入社日などは拾わない',!r.ok&&r.mode==='self',r);
 r=await run(asked,'私は1995年1月1日生まれです'); chk('本人の誕生日は、お相手にしない',!r.ok&&r.mode==='self',r);
 r=await run([{role:'ai',text:'お相手の生年月日を教えてね。'}],'1988年3月3日'); chk('直前に聞かれていれば、日付だけでも入る',r.ok&&/^1988-3-3/.test(r.b),r);
 // 相性のボタン：お相手がまだの時は、AI を使わずに、お相手の生年月日を入れる画面を開く
 let ai=0; await pg.route('https://generativelanguage.googleapis.com/**',r=>{ ai++; r.abort(); }); await pg.route('**/api/gemini',r=>{ ai++; r.abort(); });
 await pg.evaluate(()=>{ state.mode='self'; state.chartB=null; state.msgs=[{role:'ai',text:'hi'},{role:'me',text:'ひどく振られた'},{role:'ai',text:'それはつらかったですね。'}]; renderChat(); _seqRunning=false; maybeTopicChips('ひどく振られた'); });
 const first=await pg.$eval('#topicChips button',x=>x.textContent).catch(()=>''); chk('失恋の話の最初のボタンが「相手との相性を命式で見て」',first==='相手との相性を命式で見て',first);
 await pg.click('#topicChips button'); await pg.waitForTimeout(2500);
 const s=await pg.evaluate(()=>({on:document.getElementById('shAisho').classList.contains('on'),last:state.msgs.slice(-2).map(m=>m.role+':'+m.text)}));
 chk('押すと、お相手の生年月日を入れる画面が開き、案内の一言が出る（AI は使わない）',s.on&&/生年月日と性別を選んで/.test(s.last[1]||'')&&ai===0,{s,ai});
 chk('画面のエラーなし',errs.length===0,errs);
 console.log(ok+' OK / '+ng+' NG'); await b.close(); srv.close(); });
