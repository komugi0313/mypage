#!/bin/sh
# テストの準備：site/ と server/ を、テストが読む場所（fx/）にまとめる。site/・server/ を直したら、もう一度実行する
cd "$(dirname "$0")"
rm -rf fx && cp -r ../site fx && mkdir -p fx/functions && cp ../server/*.js fx/functions/
echo "fx/ を作りました"
