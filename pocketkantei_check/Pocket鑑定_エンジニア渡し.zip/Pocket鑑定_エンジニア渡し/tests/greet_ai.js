const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path'),{execFile}=require('child_process');
// 本物のAIで「今日のひとこと」を試す（朝・夜・失恋の翌日）。GEMINI_KEY=... node greet_ai.js 出力先.txt
const KEY=(process.env.GEMINI_KEY||'').trim();
function curlPost(url,body){ return new Promise((res,rej)=>{ const p=execFile('curl',['-s','-m','90','-X','POST','-H','Content-Type: application/json','--data-binary','@-',url],{maxBuffer:2e7},(e,o)=>e?rej(e):res(o)); p.stdin.end(body); }); }
const srv=http.createServer((q,r)=>{ let f=path.join(__dirname,'fx',q.url.split('?')[0]); fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
 const b=await chromium.launch(); const base='http://127.0.0.1:'+srv.address().port;
 const HB=[{role:'me',text:'ひどく振られた'},{role:'ai',text:'それは本当におつらかったですね。'},{role:'me',text:'3年付き合ってたのに、他に好きな人ができたって'},{role:'ai',text:'3年という時間を大切にしてきた分、本当に胸が痛みますね。'},{role:'me',text:'眠れない'},{role:'ai',text:'眠れない夜もありますよね。よかったら、ここに気持ちを吐き出してくださいね。'}];
 const NORM=[{role:'me',text:'今年の仕事運は？'},{role:'ai',text:'今年は新しい役割が回ってきやすい年です。'}];
 const out=[];
 for(const [nm,time,msgs] of [['失恋の翌朝','2026-11-03T08:10:00+09:00',HB],['失恋の翌日の夜','2026-11-03T20:05:00+09:00',HB],['ふつうの人の夜','2026-11-03T20:05:00+09:00',NORM]]){
  for(let k=0;k<3;k++){
   const ctx=await b.newContext({timezoneId:'Asia/Tokyo'}); const pg=await ctx.newPage(); await pg.clock.install({time:new Date(time)});
   await pg.route('**/*',async r=>{ const u=r.request().url(); if(u.startsWith(base)) return r.continue(); if(u.startsWith('https://generativelanguage.googleapis.com/')){ try{ const t=await curlPost(u,r.request().postData()||''); return r.fulfill({status:200,contentType:'application/json',body:t}); }catch(e){ return r.abort(); } } return r.abort(); });
   await pg.addInitScript(([K,m])=>{ localStorage.setItem('pk_lang','ja'); localStorage.setItem('pk_key',K); localStorage.setItem('pk_dev','1'); localStorage.setItem('pk_svd','1'); localStorage.setItem('pk_mictip','1'); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1996,m:1,d:1,hh:12,tu:false,mi:0,sex:'female',place:'tokyo'})); localStorage.setItem('pk_msgs',JSON.stringify(m)); },[KEY,msgs]);
   await pg.goto(base+'/index.html'); await pg.waitForTimeout(1500);
   const t=await pg.evaluate(()=>{ window._seqRunning=false; return _dailyGreetAI(); });
   out.push(nm+' '+(k+1)+'： '+t); console.log(nm,k+1,'：',t); await ctx.close(); } }
 fs.writeFileSync(process.argv[2],out.join('\n')); await b.close(); srv.close(); });
