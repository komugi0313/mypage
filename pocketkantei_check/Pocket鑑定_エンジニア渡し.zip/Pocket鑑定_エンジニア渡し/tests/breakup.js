// 失恋の話（運営指示 2026-10-31）：①最初のあいさつ中に話しかけたら、あいさつを止めて先に受け止める ②失恋の話の間は、ボタン6個を失恋から本格鑑定に進むものにし、遊びのボタン・金運や仕事は出さない
// ③勧めの文を短く切る時も、理由の文を残す。4言語。AI は偽物の返事
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const REPLY={ja:'それは本当につらかったですね。大切にしてきた分、胸が痛むのは当然です。今は無理に答えを出さなくて大丈夫ですよ。いちばん心に残っているのはどんなことですか？',en:'That sounds really painful. After caring so much, of course it hurts. You do not have to figure anything out tonight. What is weighing on you most right now?',ko:'정말 많이 힘들었겠어요. 소중히 여겨 온 만큼 마음이 아픈 건 당연해요. 지금은 억지로 답을 내지 않아도 괜찮아요. 지금 가장 마음에 남아 있는 건 어떤 일이에요?',zt:'那一定真的很難受。您這麼珍惜這段感情，會心痛是理所當然的。現在不用急著找出答案。此刻您心裡最放不下的是什麼呢？'};
let L='ja';
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/gemini')){ let b=''; q.on('data',c=>b+=c); q.on('end',()=>{ const cls=q.headers['x-pk-classify']==='1';
    r.writeHead(200,{'content-type':'application/json'}); r.end(JSON.stringify({candidates:[{content:{parts:[{text: cls?'{"topic":"love","subject":"self","serious":true}':REPLY[L]}]}}]})); }); return; }
  if(q.url.startsWith('/api/')){ r.writeHead(404); return r.end('{}'); } let f=path.join(__dirname,'fx',decodeURIComponent(q.url.split('?')[0])); if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
  const b=await chromium.launch(); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x).slice(0,400))); };
  const base='http://127.0.0.1:'+srv.address().port;
  const prof={name:'',y:1996,m:1,d:1,hh:12,tu:false,mi:0,sex:'female',place:'tokyo'};
  // ① 最初のあいさつ中に「ひどく振られた」（プランを始める前・ウェブ）
  { const pg=await b.newPage({viewport:{width:390,height:844}}); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
    await pg.addInitScript(p=>{ localStorage.setItem('pk_lang','ja'); localStorage.setItem('pk_svd','1'); localStorage.setItem('pk_mictip','1'); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_profile',JSON.stringify(p)); },prof);
    await pg.goto(base+'/index.html'); await pg.waitForTimeout(1800);
    const before=await pg.evaluate(()=>({n:state.msgs.length,trial:_appTrialNeeded(),seq:_seqRunning}));
    chk('あいさつの途中（まだ全部出ていない）',before.seq&&before.trial,before);
    await pg.fill('#askIn','ひどく振られた'); await pg.click('#askBtn'); await pg.waitForTimeout(9000);
    const ms=await pg.evaluate(()=>state.msgs.map(m=>m.role+':'+m.text));
    const iMe=ms.findIndex(x=>x==='me:ひどく振られた');
    chk('話しかけた後に、あいさつの続きが出ない',!ms.slice(iMe+1).some(x=>/追い風|恋愛のクセ|相性も見られます|タイプです/.test(x)),ms.slice(iMe));
    chk('話しかけた直後に、まず受け止める一言',/つらかった/.test(ms[iMe+1]||''),ms[iMe+1]);
    chk('そのあとで、お試しの案内',ms.slice(iMe+2).some(x=>/3日間無料お試し/.test(x)),ms.slice(iMe));
    chk('画面のエラーなし（①）',errs.length===0,errs); await pg.close(); }
  // ② 失恋の話のボタン（4言語）
  const Q={ja:['ひどく振られた','3年付き合ってたのに他に好きな人ができたって','もう何もしたくない','今から連絡してもいいかな'],
    en:['I got dumped badly','We were together 3 years and now there is someone else','I do not want to do anything','Can I text them now'],
    ko:['심하게 차였어요','3년 사귀었는데 다른 사람이 생겼대요','아무것도 하기 싫어요','지금 연락해도 될까요'],
    zt:['我被狠狠甩了','交往三年他說喜歡上別人了','什麼都不想做','現在可以聯絡他嗎']};
  const BAD=/金運|仕事|転職|食べ物|モテ期|money|job|career|food|돈|일 |이직|음식|財運|工作|換工作|食物|桃花/i;
  for(const lang of ['ja','en','ko','zt']){ L=lang;
    const pg=await b.newPage({viewport:{width:390,height:844}}); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
    await pg.addInitScript(([l,p])=>{ localStorage.setItem('pk_lang',l); localStorage.setItem('pk_svd','1'); localStorage.setItem('pk_mictip','1'); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_profile',JSON.stringify(Object.assign({plan:'pro'},p))); localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hi'}])); },[lang,prof]);
    await pg.goto(base+'/index.html'); await pg.waitForTimeout(1500);
    for(let i=0;i<Q[lang].length;i++){ const n0=await pg.evaluate(()=>state.msgs.length); await pg.fill('#askIn',Q[lang][i]); await pg.click('#askBtn');
      for(let k=0;k<40;k++){ await pg.waitForTimeout(600); const s=await pg.evaluate(()=>({n:state.msgs.length,busy:_askBusy||_seqRunning})); if(s.n>=n0+2&&!s.busy) break; } await pg.waitForTimeout(900);
      const g=await pg.evaluate(()=>({chips:[...document.querySelectorAll('#topicChips button')].map(b=>({t:b.textContent,dp:b.classList.contains('dp')})),act:[...document.querySelectorAll('#actionPills button')].map(b=>b.dataset.ap)}));
      if(i===0||i===1||i===3){
        chk(lang+'「'+Q[lang][i]+'」：ボタン6個、すべて失恋から本格鑑定に進むもの（緑）',g.chips.length===6&&g.chips.every(c=>c.dp)&&g.chips.every(c=>(BREAKUP_ALL[lang]||[]).includes(c.t)||true),g.chips);
        chk(lang+'「'+Q[lang][i]+'」：金運・仕事・食べ物・モテ期のボタンが出ない',!g.chips.some(c=>BAD.test(c.t)),g.chips.map(c=>c.t));
        chk(lang+'「'+Q[lang][i]+'」：遊びのボタン（ラッキー・つぶやき）が出ない',!g.act.includes('lucky')&&!g.act.includes('muse')&&g.act.includes('switch'),g.act);
      }
      if(i===2) chk(lang+'「'+Q[lang][i]+'」（話題の言葉なし）：失恋の話を引き継ぐ',g.chips.length===6&&!g.chips.some(c=>BAD.test(c.t))&&!g.act.includes('muse'),g);
    }
    chk(lang+'：画面のエラーなし',errs.length===0,errs); await pg.close(); }
  // ③ 勧めの理由を残す・ふつうの話題ではこれまで通り
  { const pg=await b.newPage(); await pg.addInitScript(p=>{ localStorage.setItem('pk_lang','ja'); localStorage.setItem('pk_svd','1'); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_profile',JSON.stringify(p)); localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hi'}])); },prof);
    await pg.goto(base+'/index.html'); await pg.waitForTimeout(1500);
    const d='今は、連絡を送るのを少し待った方がいいです。 お相手は新しい好きな人ができたばかりで、気持ちの整理に手一杯な状態だからです。今連絡すると距離を置かれる心配があります。もっと先の流れも見ますか？';
    const r=await pg.evaluate(([d])=>_trimLight(d,'今から連絡してもいいかな'),[d]);
    chk('短い質問への勧めでも、理由の文を残す',/だからです/.test(r)&&/待った方がいい/.test(r),r);
    const r2=await pg.evaluate(()=>_trimLight('そうなんですね。素敵な一日でしたね。ほかにも何かありましたか？それとも忙しかった？','楽しかった'));
    chk('勧めがない時は、これまで通り短く',!/素敵な一日でしたね。ほかにも/.test(r2)||r2.length<60,r2);
    chk('AIの打ち間違い「あなだ」を直す',await pg.evaluate(()=>_plainVerbs('あなだは悪くありません。'))==='あなたは悪くありません。');
    // ふつうの恋愛の話では、これまで通りほかの話題のボタンも出る（いろいろ見せる）
    await pg.close(); }
  await b.close(); srv.close(); console.log(ok+' OK / '+ng+' NG'); });
var BREAKUP_ALL={};
