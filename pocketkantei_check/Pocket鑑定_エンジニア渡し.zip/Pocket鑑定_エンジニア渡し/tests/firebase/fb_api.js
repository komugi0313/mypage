// Firebase のエミュレーター（Hosting → 関数 → Firestore）で、API を全部たたいて確かめる。
// 先に、リポジトリの一番上で `firebase emulators:start --project demo-pk` を動かしておく（README.md）。
const B=process.env.FB_BASE||'http://127.0.0.1:5002', O={'Content-Type':'application/json',Origin:B};
const log=(...a)=>console.log(...a);
(async()=>{
 let r=await fetch(B+'/'); log('GET / ',r.status,(await r.text()).includes('Pocket'));
 const email='t'+Date.now()+'@example.com';
 const big='あ'.repeat(600000)+'😀'.repeat(100);   // 1MB を超える保存データ（日本語60万字 ≒ 1.8MB）
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'register',email,password:'password123',data:{pk_profile:'{"y":1990}',pk_msgs:big}})});
 let j=await r.json(); log('register',r.status,j.ok,j.plan&&j.plan.plan);
 const tok=j.token;
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'login',email,password:'password123'})}); j=await r.json();
 log('login',r.status,j.ok,'bigdata一致',j.data&&j.data.pk_msgs===big);
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'save',token:tok,data:{pk_profile:'{"y":1991}',pk_msgs:'short'}})}); j=await r.json(); log('save small',j.ok);
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'load',token:tok})}); j=await r.json(); log('load',j.ok,j.data&&j.data.pk_msgs,j.data&&j.data.pk_profile);
 r=await fetch(B+'/api/auth',{method:'POST',headers:{...O,Origin:'https://evil.example'},body:JSON.stringify({action:'login',email,password:'x'})}); log('他サイトから',r.status);
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'push_set',token:tok,pushToken:'fcm-test-token',on:true,mode:'fixed',hour:9,tz:'Asia/Tokyo',lang:'ja',platform:'ios'})}); j=await r.json(); log('push_set',r.status,j.ok);
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'push_inbox',token:tok,tz:'Asia/Tokyo'})}); j=await r.json(); log('push_inbox',r.status,j.ok,JSON.stringify(j.push||{}));
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'checkout',token:tok,plan:'std',period:'m',lang:'ja'})}); j=await r.json(); log('checkout(未設定)',r.status,j.code);
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'forgot',email,lang:'ja'})}); j=await r.json(); log('forgot(Resend未設定)',r.status,j.ok,j.code||'');
 const sv='uid=dev123&name=%E3%81%AF%E3%81%AA&email='+encodeURIComponent(email)+'&topics=love&interests=x&source=sns&freq=first&job=office&sex=female&age=30s&country=JP&lang=ja';
 r=await fetch(B+'/api/survey',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',Origin:B},body:sv}); j=await r.json(); log('survey',r.status,j.ok);
 const FS=process.env.FS_BASE||'http://127.0.0.1:8080'; r=await fetch(FS+'/v1/projects/demo-pk/databases/(default)/documents/pk-survey/dev123',{headers:{Authorization:'Bearer owner'}});   /* エミュレーターの管理者として読む（決まりでアプリからは読めないため） */ j=await r.json(); log('Firestore の pk-survey に保存',r.status,j.fields&&j.fields.email&&j.fields.email.stringValue===email,j.fields&&j.fields.country&&j.fields.country.stringValue);
 r=await fetch(B+'/api/billing',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'none'},body:'{}'}); j=await r.json(); log('billing(未設定)',r.status,j.code);
 const g={contents:[{role:'user',parts:[{text:'こんにちは'}]}]};
 r=await fetch(B+'/api/gemini',{method:'POST',headers:{...O,'x-pk-device':'dev123'},body:JSON.stringify(g)}); log('gemini(仮のキー)',r.status,(await r.text()).slice(0,120).replace(/\s+/g,' '));
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'delete',token:tok,password:'password123'})}); j=await r.json(); log('delete',r.status,j.ok);
 r=await fetch(B+'/api/auth',{method:'POST',headers:O,body:JSON.stringify({action:'login',email,password:'password123'})}); j=await r.json(); log('削除後ログイン',r.status,j.code);
})().catch(e=>console.log('ERR',e));
