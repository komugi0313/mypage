# Firebase のエミュレーターでのテスト

本物と同じ Firebase（Hosting → 関数 → Firestore）を手元で動かして、サイトとサーバーを通しで確かめます。Google のサーバーには何も送りません（Gemini だけは、仮のキーで「届いた」ことを確かめます）。

## 準備（リポジトリの一番上で）
1. Node.js 22、Java（JDK 11 以上）、Firebase CLI（`npm i -g firebase-tools`）を入れる
2. `cd server && npm install && cd ..`
3. `server/.env.local` を作る（テスト用。エミュレーターだけが読む。本番用の `server/.env` には書かない）
   ```
   SITE_URL=http://127.0.0.1:5002
   MAIL_FROM='Pocket Kantei <no-reply@example.com>'
   ```
4. `server/.secret.local` を作る（テスト用の仮の値。本物のキーは入れない）
   ```
   GEMINI_API_KEY=dummy-key
   AUTH_SECRET=0123456789abcdef0123456789abcdef0123456789
   RESEND_API_KEY=none
   REVENUECAT_WEBHOOK_AUTH=none
   TELECOM_CHECKOUT_URLS=none
   ```
5. `firebase emulators:start --project demo-pk`（動かしたままにする）

## 実行（このフォルダで。`npm i playwright` 済みのこと）
```
node fb_api.js
node fb_ui.js
```

## 正しい結果
- `fb_api.js`：register 200 / login 200・bigdata一致 true（1MB を超える会話履歴が戻る）/ 他サイトから 403 / push_set 200 / survey 200 / Firestore の pk-survey に保存 200 true / checkout(未設定) 400 NOT_READY / forgot(Resend未設定) 502 MAIL_FAIL / billing(未設定) 500 NO_WEBHOOK_AUTH / gemini(仮のキー) 400 API key not valid（＝Gemini まで届いている）/ delete 200 / 削除後ログイン 401
- `fb_ui.js`：登録後 scSurvey → アンケート送信 200 → scChat・送り直し待ち null → チャットの呼び出し 400（仮のキー）→ 別端末ログインで名前と会話が戻る → 画面のエラーなし

※`server/.env.local` と `server/.secret.local` はテスト用で、本番の `firebase deploy` には使われません。本番の値は、仕様書 2.2 のとおりシークレットと `server/.env` に入れます。
