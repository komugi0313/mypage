// 実物と同じ Firebase（Hosting → Functions → Firestore）のエミュレーターで、アプリの画面を通して確かめる
const {chromium}=require('playwright');
const base=process.env.FB_BASE||'http://127.0.0.1:5002', email='ui'+Date.now()+'@example.com';
(async()=>{
 const b=await chromium.launch();
 const mk=async(skipSv)=>{const ctx=await b.newContext({viewport:{width:420,height:900}});const pg=await ctx.newPage();pg.errs=[];pg.on('pageerror',e=>pg.errs.push(String(e).slice(0,160)));pg.on('dialog',d=>d.accept());
   await pg.route('**/*',r=>{const u=r.request().url();if(u.startsWith(base))return r.continue();return r.abort();});
   await pg.addInitScript((s)=>{try{if(!localStorage.getItem('pk_lang'))localStorage.setItem('pk_lang','ja');if(s)localStorage.setItem('pk_svd','1');}catch(e){}},skipSv);return pg;};
 const on=pg=>pg.evaluate(()=>[...document.querySelectorAll('.screen.on')].map(s=>s.id).join(','));
 const A=await mk(false); await A.goto(base+'/index.html?start=1'); await A.waitForTimeout(1000);
 await A.fill('#iname','はなこ'); await A.fill('#acEmail',email); await A.fill('#acPw','sakura2026'); await A.fill('#acPw2','sakura2026');
 await A.click('#regBtn'); await A.waitForTimeout(2500); console.log('登録後の画面',await on(A));
 // アンケート
 if((await on(A)).includes('scSurvey')){
   await A.fill('#svEmail',email);
   for(const c of ['#svTopics','#svInterests','#svSrcs','#svFreqs','#svJobs']){ await A.click(c+' button'); }
   const posted=A.waitForResponse(r=>r.url().includes('/api/survey'),{timeout:15000}).catch(()=>null);
   await A.click('#svBtn'); const pr=await posted; console.log('アンケート送信',pr&&pr.status());
   await A.waitForTimeout(1500); console.log('アンケート後の画面',await on(A),'| 送り直し待ち',await A.evaluate(()=>localStorage.getItem('pk_svq')));
 }
 await A.evaluate(()=>{state.msgs.push({role:'me',text:'テスト相談'});saveMsgs();}); await A.evaluate(()=>cloudSaveNow()); await A.waitForTimeout(1500);
 // チャット（仮のキーなので、AIからはエラーが返る＝サーバーまで届いている）
 const gr=A.waitForResponse(r=>r.url().includes('/api/gemini'),{timeout:20000}).catch(()=>null);
 await A.evaluate(()=>{ try{ $('scChat')&&showScreen&&showScreen('scChat'); }catch(e){} });
 await A.evaluate(()=>answer('こんにちは').catch(()=>{}));
 const g=await gr; console.log('チャットの呼び出し',g&&g.status());
 // 別の端末でログイン
 const B=await mk(true); await B.goto(base+'/index.html#login'); await B.waitForTimeout(1000);
 await B.fill('#lgEmail',email); await B.fill('#lgPw','sakura2026'); await B.click('#lgBtn'); await B.waitForTimeout(2500);
 console.log('別端末ログイン',await on(B),'| 名前:',await B.evaluate(()=>state.profile&&state.profile.name),'| 会話:',await B.evaluate(()=>(state.msgs||[]).filter(m=>m.text==='テスト相談').length));
 console.log('画面のエラー A',A.errs,'B',B.errs);
 await b.close();
})().catch(e=>{console.log('ERR',e.message);process.exit(1);});
