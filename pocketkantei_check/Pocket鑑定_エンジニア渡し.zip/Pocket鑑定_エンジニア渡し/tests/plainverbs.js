// 飾った言い回し（宿っています・秘めています・刻まれています など）を、ふつうの言葉に置きかえる（2026-10-27 運営指示）
const fs=require('fs'),path=require('path');const h=fs.readFileSync(path.join(__dirname,'fx','index.html'),'utf8');
const M=eval('['+h.match(/var PLAIN_VERBS=\[([\s\S]*?)\];\n/)[1]+']');const f=t=>{M.forEach(r=>t=t.replace(r[0],r[1]));return t};
let ok=0,ng=0;const chk=(a,b)=>{const r=f(a);if(r===b)ok++;else{ng++;console.log('NG',a,'→',r,'（期待：'+b+'）');}};
chk('温かい強みが宿っています。','温かい強みがあります。');
chk('人を惹きつける魅力を秘めています。','人を惹きつける魅力を持っています。');
chk('探求心が刻まれています。','探求心があります。');
chk('強い意志を宿している人です。','強い意志を持っている人です。');
chk('不思議な力が宿る場所','不思議な力がある場所');
chk('您的未來蘊含著一種支持。','您的未來有一種支持。');
chk('ふつうの文はそのまま。','ふつうの文はそのまま。');
chk('大運（たいいん）が切り替わる','大運（たいうん）が切り替わる');
chk('十二運（じゅうにん）の病','十二運（じゅうにうん）の病');
console.log(/_plainVerbs\(_dedupeYears/.test(h)?'OK 返事の最後の仕上げ（_finalFix）で使う':'NG _finalFix で使っていない'); if(!/_plainVerbs\(_dedupeYears/.test(h)) ng++; else ok++;
console.log(ok+' OK / '+ng+' NG');
