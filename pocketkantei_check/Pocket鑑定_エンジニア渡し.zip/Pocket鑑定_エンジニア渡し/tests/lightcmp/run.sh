#!/bin/bash
# 軽量モデルの比較：3モデル × 10言語 × 2人。同時に6本まで
cd "$(dirname "$0")/.."
OUT=../../lightout; mkdir -p $OUT
jobs_list=()
for m in gemini-2.5-flash-lite gemini-3.1-flash-lite gemini-3.5-flash-lite; do for f in lightcmp/*.json; do b=$(basename $f .json); jobs_list+=("$m $f $OUT/${m}__$b.json"); done; done
run(){ set -- $1; [ -s "$3" ] && return; PK_LITE_MODEL=$1 GEMINI_KEY=$(cat ../../.gemkey) timeout 900 node convo.js $2 $3 > $3.log 2>&1; }
export -f run
printf '%s\n' "${jobs_list[@]}" | xargs -P 6 -I{} bash -c 'run "{}"'
echo ALLDONE
