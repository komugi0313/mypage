// お試しが終わる前のメールに、金額を書く（運営指示 2026-11-02）：ウェブ版は月額・年額の金額、アプリ版は「ストアに表示された金額」。4言語
// 準備：./setup.sh。実行：PK_STORE=memory NODE_PATH=mock/node_modules node remindprice.js
const R=require('./fx/functions/remind.js'); const acc=require('./fx/functions/store.js').getStore('pk-accounts');
let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
(async()=>{ const now=Date.now(), exp=now+24*3600e3;
  const recs=[['web-pro-y','ja',{plan:'pro',period:'y',store:'TELECOM'}],['web-std-m','ja',{plan:'std',period:'m',store:'TELECOM'}],['app-vip','ja',{plan:'vip',store:'APP_STORE'}],
    ['web-vip-y-en','en',{plan:'vip',period:'y',store:'TELECOM'}],['web-std-m-ko','ko',{plan:'std',period:'m',store:'TELECOM'}],['app-pro-zt','zt',{plan:'pro',store:'PLAY_STORE'}]];
  for(const [id,lang,s] of recs) await acc.setJSON('u:'+id,{email:id+'@x.com',lang,sub:Object.assign({trial:true,expires:exp,willRenew:true},s)});
  const sent={}; await R.runRemind(acc,now,{send:async(to,subj,body)=>{ sent[to.split('@')[0]]=body; return true; }});
  const b=k=>sent[k]||'';
  chk('ウェブ・Pro年額：「年額64,900円（税込）」「一度に」',/年額64,900円（税込）/.test(b('web-pro-y'))&&/一度に/.test(b('web-pro-y')),b('web-pro-y'));
  chk('ウェブ・Standard月額：「月額3,300円（税込）」',/月額3,300円（税込）/.test(b('web-std-m')),b('web-std-m'));
  chk('アプリ・VIP：「ストアに表示された金額」（金額は書かない）',/ストアに表示された金額/.test(b('app-vip'))&&!/\d,\d{3}円/.test(b('app-vip')),b('app-vip'));
  chk('英語・VIP年額：¥107,800 per year',/¥107,800 per year/.test(b('web-vip-y-en')),b('web-vip-y-en'));
  chk('韓国語・Standard月額：월 3,300엔',/월 3,300엔/.test(b('web-std-m-ko')),b('web-std-m-ko'));
  chk('繁体字・アプリ：商店顯示的金額',/商店顯示的金額/.test(b('app-pro-zt')),b('app-pro-zt'));
  chk('文面に {x} などの置き換え忘れがない',!Object.values(sent).some(x=>/\{[a-z]\}/.test(x)),Object.values(sent));
  chk('6人全員に届く',Object.keys(sent).length===6,Object.keys(sent));
  console.log('--- 見本（ウェブ・Pro年額）\n'+b('web-pro-y'));
  console.log(ok+' OK / '+ng+' NG'); })();
