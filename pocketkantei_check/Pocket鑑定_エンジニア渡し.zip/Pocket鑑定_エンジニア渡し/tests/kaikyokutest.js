/* 相性：三合・方合の開局（2人の命式＋年運・大運でそろう）を必ず拾う（運営指示 2026-10-25）
   node kaikyokutest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x).slice(0,300));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ const P=a=>({pillars:a.map(b=>({branch:b}))});
  const o={};
  o.both=ctOpen('申',P(['子','丑']),P(['辰','巳']),'','');          /* 子(本人)＋辰(相手)＋申(運) */
  o.oneSide=ctOpen('申',P(['子','辰']),P(['午','巳']),'','');       /* 子・辰とも本人だけ → 2人の時期ではない */
  o.natal=ctOpen('申',P(['子','申']),P(['辰','巳']),'','');         /* 2人の命式だけで既にそろう → 除く */
  o.viaDec=ctOpen('子',P(['辰','丑']),P(['午','巳']),'','申');      /* 本人の辰＋相手の大運の申＋年の子 */
  o.hougo=ctOpen('卯',P(['寅','丑']),P(['辰','巳']),'','');
  const U=computeChart({name:'',y:2000,m:4,d:4,tu:true,hh:12,mi:0,sex:'male',place:'tokyo'}), B=computeChart({name:'',y:2000,m:5,d:3,tu:false,hh:14,mi:0,sex:'male',place:'tokyo'});
  state.chart=U; state.profile={y:2000,m:4,d:4,sex:'male'}; B._sex='male'; state.chartB=B; state.mode='aisho'; state.msgs=[{role:'me',text:'相性を見て'}]; state.compatDeep=compatDeep(U.pro,B.pro,U.fav,B.fav); window._newPartnerTurn=true;
  const ct=coupleTiming(); o.years=ct.goodYears.map(y=>y.year+':'+y.why.join('・')); o.block=coupleTimingBlock(); o.must=pkBuildMust('相性を詳しく見て',{}).filter(m=>/good years/.test(m.label)).map(m=>m.nums.join(','));
  return o; });
chk('2人の支＋年運で三合開局',R.both.length===1&&R.both[0].kind==='三合',R.both);
chk('1人の命式だけでそろう時は2人の時期に数えない',R.oneSide.length===0,R.oneSide);
chk('2人の命式だけで既にそろう時は除く',R.natal.length===0,R.natal);
chk('大運が加わって開局（本人の辰＋相手の大運の申＋年の子）',R.viaDec.length===1&&R.viaDec[0].viaLuck,R.viaDec);
chk('方合開局',R.hougo.length===1&&R.hougo[0].kind==='方合',R.hougo);
chk('2000年4月4日×5月3日：2031・2032（大運が加わる）・2034・2042を良い年に拾う',['2031','2032','2034','2042'].every(y=>R.years.some(x=>x.indexOf(y)===0))&&R.years.some(x=>/^2032.*大運/.test(x)),R.years);
chk('Nico への材料に「開局の年と月を必ず言う」',/OPENING OF A BOND/.test(R.block));
chk('毎回のチェックに開局の年が入る',R.must.length&&['2031','2032','2034','2042'].every(y=>R.must[0].includes(y)),R.must);
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
