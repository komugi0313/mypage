const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
/* 4言語で、メニューの各画面を開き、ほかの言語の文字（かな・ハングル・漢字）が混ざっていないかを調べる：node langaudit.js [画像の出力先] */
const ROOT=path.join(__dirname,'..','site'), OUT=process.argv[2]||path.join(__dirname,'shots_lang'); fs.mkdirSync(OUT,{recursive:true});
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){ r.writeHead(404); return r.end(); } fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':u.endsWith('.png')?'image/png':'application/javascript'}); r.end(b); }); });
const KANA=/[぀-ヺー-ヿ]/, NAKAGURO=/・/, HAN=/[一-鿿]/, HANGUL=/[가-힯]/;
srv.listen(0,async()=>{ const b=await chromium.launch(); const issues=[]; const errs=[];
 for(const L of ['ja','en','ko','zt']) for(const PLAN of ['free','std']){
  const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:1}); const pg=await ctx.newPage(); pg.on('pageerror',e=>errs.push(L+': '+e));
  pg.on('dialog',d=>d.dismiss());
  await ctx.addInitScript(l=>{ localStorage.setItem('pk_lang',l); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_svd','1'); localStorage.setItem('pk_auth',JSON.stringify({email:'a@x.com',token:'a'.repeat(64)+'.1.9999999999999.sig',verified:true})); },L);
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(500);
  await pg.fill('#iname','T'); await pg.selectOption('#iy','1995'); await pg.check('#agreeChk'); await pg.click('#sexSeg button[data-sex="female"]').catch(()=>{}); await pg.click('#regBtn'); await pg.waitForTimeout(1200);
  if(PLAN!=='free') await pg.evaluate(()=>{ state.profile.plan='std'; saveProfile(state.profile); applyServerPlan({plan:'std',expires:Date.now()+20*864e5,willRenew:true,store:'TELECOM'}); });
  const acts=['menu','mypage','plan','meishiki','aisho','about','contact','notify','edit'];
  for(const a of acts){
    await pg.evaluate(()=>closeSheets()); await pg.waitForTimeout(200);
    await pg.click('#btnMenu'); await pg.waitForTimeout(300);
    if(a!=='menu'){ const el=await pg.$(`#shMenu [data-act="${a}"]`); if(!el){ issues.push(`${L}/${PLAN} menu item missing: ${a}`); continue; } await el.click(); await pg.waitForTimeout(700); }
    const info=await pg.evaluate(()=>{ const ov=document.getElementById('pkNotifyOv'); if(ov&&ov.offsetParent!==null||ov){ const t=ov.innerText; ov.remove(); return {id:'pkNotifyOv',text:t,empties:[]}; } const s=[...document.querySelectorAll('.sheet.on')].pop(); if(!s) return null; return {id:s.id,text:s.innerText,empties:[...s.querySelectorAll('[data-i18n],[data-i18n-html]')].filter(e=>e.offsetParent&&!e.textContent.trim()).map(e=>e.getAttribute('data-i18n')||e.getAttribute('data-i18n-html'))}; });
    if(!info){ issues.push(`${L}/${PLAN} ${a}: no sheet opened`); continue; }
    const lines=info.text.split('\n').map(x=>x.trim()).filter(Boolean);
    for(const ln of lines){
      let bad='';
      if(L!=='ja'&&KANA.test(ln)) bad='かな';
      if((L==='ko'||L==='zt'||L==='en')&&NAKAGURO.test(ln)) bad=bad||'中黒（・）';
      if(L==='en'&&(HANGUL.test(ln)||(HAN.test(ln)&&info.id!=='shMeishiki'))) bad=bad||'漢字/ハングル';
      if(L==='ko'&&HAN.test(ln)&&info.id!=='shMeishiki') bad=bad||'漢字';
      if(L==='zt'&&HANGUL.test(ln)) bad=bad||'ハングル';
      if(L==='ja'&&HANGUL.test(ln)) bad='ハングル';
      if(bad&&!/日本語|English|한국어|繁體中文|Pocket本格鑑定|本格鑑定$/.test(ln)) issues.push(`${L}/${PLAN} ${info.id}: [${bad}] ${ln.slice(0,90)}`);
    }
    if(info.empties.length) issues.push(`${L}/${PLAN} ${info.id}: 空の文言 ${info.empties.join(',')}`);
    if(info.id!=='pkNotifyOv'&&(PLAN==='free'||['mypage','plan'].includes(a))) await pg.screenshot({path:`${OUT}/${L}_${PLAN}_${a}.png`,fullPage:false});
  }
  await ctx.close(); }
 console.log(issues.length?issues.join('\n'):'問題なし'); console.log('errs',errs); await b.close(); srv.close(); });
