// 28回目のテストで見つけた不具合の確認（AI は偽物。お金はかからない）
//   node fixtest.js
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
let editReply='';
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/gemini')){ let b='';q.on('data',c=>b+=c);q.on('end',()=>{ r.writeHead(200,{'content-type':'application/json'}); r.end(JSON.stringify({candidates:[{content:{parts:[{text:editReply}]}}]})); }); return; }
  let f=path.join('fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});
}).listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch(); let ok=0,ng=0;
  const eq=(n,a,x)=>{const g=JSON.stringify(a)===JSON.stringify(x); g?ok++:ng++; console.log((g?'OK  ':'NG  ')+n+(g?'':' → '+JSON.stringify(a)+' ≠ '+JSON.stringify(x)));};
  const pg=await (await b.newContext()).newPage();
  await pg.addInitScript(()=>{ localStorage.setItem('pk_lang','en');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');
    localStorage.setItem('pk_profile',JSON.stringify({name:'T',y:1990,m:6,d:8,tu:false,hh:12,mi:0,sex:'female',place:'tokyo',plan:'pro'}));
    localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hello'}])); });
  await pg.goto(base+'/index.html'); await pg.waitForTimeout(1200);
  eq('切りそろえ：答えの最初の文（好きな色）は外さない', await pg.evaluate(()=>{ state.msgs=[{role:'ai',text:'Most days I do readings, and I love making things by hand.'}]; return _trimLight('I love lavender! It just feels so soothing to me.','Do you have a favourite colour?'); }), 'I love lavender! It just feels so soothing to me.');
  eq('Nico への感想（日本語）は雑談', await pg.evaluate(()=>isPlainSmalltalk('へえ、占い師っぽいですね')), true);
  eq('Nico への感想（英語）は雑談', await pg.evaluate(()=>isPlainSmalltalk('Huh, very fortune-teller of you')), true);
  eq('占いの相談はそのまま相談', await pg.evaluate(()=>isPlainSmalltalk('占いって当たるの？')), false);
  const ed=async(draft,reply)=>{ editReply=reply; return pg.evaluate(d=>_editReply(d,'I am so tired today','gemini-3.6-flash',true,true),draft); };
  eq('仕上げ：最後の問いかけを消した直しは使わない', await ed('Oh no, that sounds rough. What happened today?','Oh no, that sounds rough. Take it easy tonight.'), 'Oh no, that sounds rough. What happened today?');
  eq('仕上げ：下書きにない「休んで」を足した直しは使わない', await ed('Oh no, that sounds rough. This month asks a lot of you.','Oh no, that sounds rough. Please get some rest tonight.'), 'Oh no, that sounds rough. This month asks a lot of you.');
  eq('仕上げ：大きく削った直しは使わない', await ed('That is a fantastic impulse! Your chart shows this month is ideal to express yourself and share ideas.','Your ideas carry weight.'), 'That is a fantastic impulse! Your chart shows this month is ideal to express yourself and share ideas.');
  eq('仕上げ：ふつうの小さな直しは使う', await ed('That is a fantastic impulse! Your chart shows this month is ideal to express yourself and share ideas.','That is a great impulse! Your chart shows this month is ideal to express yourself and share ideas.'), 'That is a great impulse! Your chart shows this month is ideal to express yourself and share ideas.');
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
