// 最初のあいさつのあとのピルボタン（4言語・実際の画面の流れ。AIは呼ばない）
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){ r.writeHead(500); return r.end('{}'); }
  let f=path.join('fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});
}).listen(0,async()=>{ const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch(); let ok=0,ng=0;
  for(const L of ['ja','en','ko','zt']){
    const pg=await (await b.newContext({viewport:{width:420,height:900}})).newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
    await pg.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());
    await pg.addInitScript((L)=>{localStorage.setItem('pk_lang',L);localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_profile',JSON.stringify({name:'T',y:1990,m:6,d:8,tu:false,hh:12,mi:0,sex:'female',place:'tokyo',plan:'pro'}));},L);
    await pg.goto(base+'/index.html'); let last=-1,st=0; for(let i=0;i<90;i++){ await pg.waitForTimeout(1000); const n=await pg.evaluate(()=>state.msgs.length+(_askBusy?100:0)+(document.querySelector(".typing")?100:0)); if(n===last){ if(++st>=6) break; } else { st=0; last=n; } }
    const r=await pg.evaluate(()=>({n:state.msgs.length,sugg:[...document.querySelectorAll('#sugg button')].map(x=>x.textContent),topic:[...document.querySelectorAll('#topicChips button')].map(x=>x.textContent),vis:(function(){var s=document.getElementById('sugg');return s?getComputedStyle(s).display+'/'+s.offsetHeight:'none';})()}));
    const good=(r.sugg.length+r.topic.length)>=4; good?ok++:ng++; console.log((good?'OK ':'NG ')+L,JSON.stringify(r),errs.slice(0,2));
    await pg.close();
  }
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close();
});
