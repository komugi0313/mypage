/* 無料お試し（アカウントごと）とログイン必須の確認。準備：./setup.sh、PK_STORE=memory NODE_PATH=mock/node_modules node trialtest.js */
process.env.PK_TELECOM_CANCEL_READY='1';   // 購入の流れを確かめるため（本番は解約の実装が終わるまで 0）
process.env.AUTH_SECRET='test-secret-0123456789abcdef'; process.env.REVENUECAT_WEBHOOK_AUTH='whsec-0123456789abcdefXYZ'; process.env.GEMINI_API_KEY='dummy';
process.env.PK_NOCARD_TRIAL='1';   // ここから下の前半は「カード登録なしの無料お試し」に戻した時の確認。最後に、ふだん（プランが必要）の確認をする
global.fetch=async()=>({ok:true,status:200,text:async()=>JSON.stringify({candidates:[{content:{parts:[{text:'ok'}]}}]})});
const auth=require('./fx/functions/auth.js').handler, bill=require('./fx/functions/billing.js').handler, gem=require('./fx/functions/gemini.js').handler;
const store=()=>require('./fx/functions/store.js').getStore('pk-usage');
const post=(fn,body,headers={})=>fn({httpMethod:'POST',headers,body:JSON.stringify(body)}).then(o=>({s:o.statusCode,b:o.body,h:o.headers||{}}));
const ask=(tok,h={})=>gem({httpMethod:'POST',headers:Object.assign({'x-pk-device':'dev1','x-pk-auth':tok||'','x-forwarded-for':'1.2.3.4'},h),body:JSON.stringify({contents:[{role:'user',parts:[{text:'hi'}]}]})}).then(o=>({code:o.statusCode+(o.statusCode!==200?(' '+JSON.parse(o.body).error.code):''),h:o.headers||{}}));
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
const jst=()=>new Date(Date.now()+9*3600e3).toISOString().slice(0,10);
const shift=(d,n)=>{ const t=new Date(Date.UTC(+d.slice(0,4),+d.slice(5,7)-1,+d.slice(8,10))+n*864e5); return t.toISOString().slice(0,10); };
(async()=>{ const now=Date.now();
  const reg=async(e,plan)=>{ const r=JSON.parse((await post(auth,{action:'register',email:e,password:'sakura2026',data:{}},{'x-forwarded-for':'9.9.9.'+Math.floor(Math.random()*200)})).b); const uid=r.token.split('.')[0];
    if(plan) await post(bill,{event:{type:'INITIAL_PURCHASE',app_user_id:uid,product_id:'pk_'+plan+'_monthly',expiration_at_ms:now+30*864e5,event_timestamp_ms:now}},{authorization:'whsec-0123456789abcdefXYZ'}); return {tok:r.token,uid}; };
  chk('ログインなしは使えない（401 LOGIN）',(await ask('',{'x-pk-main':'1'})).code==='401 LOGIN');
  chk('ログインなしは、ほかの呼び出しも使えない',(await ask('',{})).code==='401 LOGIN' && (await ask('',{'x-pk-classify':'1'})).code==='401 LOGIN');
  const a=await reg('a@x.com');
  const r1=[]; for(let i=0;i<5;i++) r1.push((await ask(a.tok,{'x-pk-main':'1'})).code);
  chk('1日目：本体の返事5通は通る',r1.every(x=>x==='200'),r1);
  const r6=await ask(a.tok,{'x-pk-main':'1','x-pk-device':'devNew'});
  chk('6通目は、端末を変えても止まる（アカウントの1日5通）',r6.code==='429 LIMIT',r6.code);
  const aux=[]; for(let i=0;i<10;i++) aux.push((await ask(a.tok,{'x-pk-device':'devNew'})).code);
  chk('文の整え・作り直しなど（本体以外）はお試しの数に入らない',aux.every(x=>x==='200'),aux);
  const tr=await store().get('t:'+a.uid,{type:'json'});
  chk('アカウントに「最初の日・5通」を記録',tr&&tr.s===jst()&&tr.n===5,tr);
  // 2日目・3日目：合計15通で終わり（日付を進めたことにする）
  await store().setJSON('t:'+a.uid,{s:shift(jst(),-2),n:10});
  const r2=await ask(a.tok,{'x-pk-main':'1','x-pk-device':'devC'});
  chk('ほかの日に使った分も数える（1日の上限は残るので、今日は止まる）',r2.code==='429 LIMIT',r2.code);
  const b=await reg('b@x.com');
  await store().setJSON('t:'+b.uid,{s:jst(),n:15});
  const rb=await ask(b.tok,{'x-pk-main':'1','x-pk-device':'devB'});
  chk('合計15通を使い切ると終わり（TRIAL_OVER）',rb.code==='429 TRIAL_OVER',rb.code);
  chk('お試し終了の時は、本体以外の呼び出しも使えない',(await ask(b.tok,{'x-pk-device':'devB'})).code==='429 TRIAL_OVER');
  const c=await reg('c@x.com');
  await store().setJSON('t:'+c.uid,{s:shift(jst(),-3),n:2});
  chk('3日間を過ぎると終わり（通数が残っていても）',(await ask(c.tok,{'x-pk-main':'1','x-pk-device':'devD'})).code==='429 TRIAL_OVER');
  const d=await reg('d@x.com');
  const rd=await ask(d.tok,{'x-pk-main':'1','x-pk-device':'devE'});
  chk('アプリへ「最初の日|使った通数」を返す（x-pk-trial）',rd.h['x-pk-trial']===jst()+'|1',rd.h);
  const rd2=await ask(d.tok,{'x-pk-main':'1','x-pk-device':'devE-cleared'});
  chk('端末のデータを消しても（別の端末IDでも）続きから数える',rd2.h['x-pk-trial']===jst()+'|2',rd2.h);
  const s=await reg('s@x.com','std');
  const rs=[]; for(let i=0;i<8;i++) rs.push((await ask(s.tok,{'x-pk-main':'1','x-pk-device':'devS'})).code);
  chk('有料プランは、お試しの上限を受けない',rs.every(x=>x==='200'),rs);
  // ストアの無料トライアル（アプリ版）：お試し中はお試しの上限、本プランが始まれば通常の回数
  const ev=(uid,type,period,extra={})=>post(bill,{event:Object.assign({type,app_user_id:uid,product_id:'pk_std_monthly',period_type:period,purchased_at_ms:now,expiration_at_ms:now+3*864e5,event_timestamp_ms:Date.now()},extra)},{authorization:'whsec-0123456789abcdefXYZ'});
  const t=await reg('t@x.com');
  await store().setJSON('t:'+t.uid,{s:jst(),n:15});   // ウェブ版の無料お試しは使い切っていても
  await ev(t.uid,'INITIAL_PURCHASE','TRIAL');
  const rt=[]; for(let i=0;i<6;i++) rt.push((await ask(t.tok,{'x-pk-main':'1','x-pk-device':'devT'})).code);
  chk('ストアのお試し中：ウェブのお試しとは別に数え、1日5通まで',rt.slice(0,5).every(x=>x==='200')&&rt[5]==='429 LIMIT',rt);
  const ttKey=(await store().list({prefix:'tt:'+t.uid})).blobs.map(b=>b.key)[0];
  await store().setJSON(ttKey,{s:jst(),n:15});
  chk('ストアのお試し中に15通を使い切ると TRIAL_CAP（本プランが始まれば使える）',(await ask(t.tok,{'x-pk-main':'1','x-pk-device':'devT2','x-forwarded-for':'5.5.5.5'})).code==='429 TRIAL_CAP');
  await ev(t.uid,'RENEWAL','NORMAL',{purchased_at_ms:now+3*864e5,expiration_at_ms:now+33*864e5});
  const rn=[]; for(let i=0;i<7;i++) rn.push((await ask(t.tok,{'x-pk-main':'1','x-pk-device':'devT3','x-forwarded-for':'6.6.6.6'})).code);
  chk('本プランが始まると、お試しの上限はなくなる',rn.every(x=>x==='200'),rn);
  // ふだん（運営決定 2026-10-22）：プランを始めていない人は使えない。お試し中・有料の人は使える
  delete process.env.PK_NOCARD_TRIAL;
  const f=await reg('f@x.com');
  chk('プランを始めていない人は、AIを使えない（402 NEED_PLAN）',(await ask(f.tok,{'x-pk-main':'1','x-pk-device':'devF'})).code==='402 NEED_PLAN');
  chk('お試し中（ストア）の人は使える',(await ask(t.tok,{'x-pk-main':'1','x-pk-device':'devT9','x-forwarded-for':'7.7.7.7'})).code==='200');
  // ウェブ版の申し込み：テレコムクレジットのURLに、お試しの印と初回の課金日を入れる
  process.env.TELECOM_CHECKOUT_URLS=JSON.stringify({std_m:'https://pay.example/?u={uid}&trial={trial}&first={first}&days={trialDays}'});
  const co=JSON.parse((await post(auth,{action:'checkout',token:f.tok,plan:'std',period:'m',lang:'ja'})).b);
  const want=new Date(Date.now()+9*3600e3+3*864e5).toISOString().slice(0,10).replace(/-/g,'');
  chk('はじめての人：お試しあり・初回の課金日は3日後',co.ok&&/trial=1/.test(co.url)&&co.url.includes('first='+want)&&/days=3/.test(co.url),co.url);
  const co1=JSON.parse((await post(auth,{action:'checkout',token:t.tok,plan:'std',period:'m',lang:'ja'})).b);
  chk('お試し中・有料プランの人は、もう一度買えない（二重の支払いを防ぐ）',co1.code==='HAS_PLAN',co1.code);
  { const A=require('./fx/functions/store.js').getStore('pk-accounts'); const rt=await A.get('u:'+t.uid,{type:'json'}); rt.sub=Object.assign({},rt.sub,{expires:Date.now()-864e5,willRenew:false}); await A.setJSON('u:'+t.uid,rt); }
  const co2=JSON.parse((await post(auth,{action:'checkout',token:t.tok,plan:'std',period:'m',lang:'ja'})).b);
  chk('お試しを使ったことがある人：お試しなし・今日から課金',co2.ok&&/trial=0/.test(co2.url),co2.url);
  // お試しが終わる前のお知らせメール
  const R=require('./fx/functions/remind.js'); const acc=require('./fx/functions/store.js').getStore('pk-accounts'); const sent=[];
  const g=await reg('g@x.com'); const rg=await acc.get('u:'+g.uid,{type:'json'}); rg.sub={plan:'pro',trial:true,willRenew:true,expires:Date.now()+24*3600e3}; rg.lang='en'; await acc.setJSON('u:'+g.uid,rg);
  const h2=await reg('h@x.com'); const rh=await acc.get('u:'+h2.uid,{type:'json'}); rh.sub={plan:'std',trial:true,willRenew:false,expires:Date.now()+24*3600e3}; await acc.setJSON('u:'+h2.uid,rh);
  const m1=await R.runRemind(acc,Date.now(),{send:async(to,subj,body)=>{ sent.push({to,subj,body}); return true; }});
  chk('お試しが約1日後に終わる人へ、1通だけ送る（解約済みの人には送らない）',m1.sent===1&&sent[0].to==='g@x.com'&&/Pro plan/.test(sent[0].body)&&/Japan time/.test(sent[0].body),{m1,sent});
  const m2=await R.runRemind(acc,Date.now(),{send:async()=>true});
  chk('同じ人に二度送らない',m2.sent===0,m2);
  console.log(`\n${ok} OK / ${ng} NG`); process.exit(ng?1:0);
})();
