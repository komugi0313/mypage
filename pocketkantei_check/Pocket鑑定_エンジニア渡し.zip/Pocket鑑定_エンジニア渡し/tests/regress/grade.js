// 定期テストの採点。run.js が作った会話の結果（<ID>.json）を読んで、機械で確かめる。
//   node regress/grade.js <結果フォルダ> [--judge] [--prev 前回の結果フォルダ]
// 分け方（運営と決めたこと 2026-11-07）：
//   事実の間違い … プログラムで計算した答えと違うこと（空亡の年・年齢、相性の強さ、過ぎた月を先のこととして言う、言ってはいけないこと）。目標 0。
//   場面の確かめ … scenarios.json の expect（今まで見つけた間違いが戻っていないか）。目標 0。
//   会話の問題   … くり返しの質問・同じ文・答えていない・吹き出しが多すぎる・説明のない専門用語（--judge なら AI の採点も）。目標 返事の5%以下。
//   動作のエラー … 画面のエラー・AI の呼び出しの失敗。目標 0。
const fs = require('fs'), path = require('path'), { execFile } = require('child_process');
const args = process.argv.slice(2), DIR = args[0];
const opt = (k) => { const i = args.indexOf(k); return i >= 0 ? (args[i + 1] || '') : null; };
const SET = JSON.parse(fs.readFileSync(path.join(__dirname, 'scenarios.json'), 'utf8'));
const PRICES = { lite: { in: 0.25, out: 1.50, cached: 0.025 }, deep: { in: 1.50, out: 7.50, cached: 0.15 } }, FX = 155;   // server/gemini.js と同じ
const cut = (s, n = 90) => { s = String(s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n) + '…' : s; };
const sents = (t) => (String(t || '').match(/[^。！？!?\n]+?(?:[。！？!?]+|\.(?=\s|$)|$)[」』）)"]*/g) || []).map(s => s.trim()).filter(Boolean);
const isQ = (s) => /[？?][」』）)]*$/.test(s);
const big = (s) => { s = s.replace(/[\s、。，,.！？!?「」『』（）()]/g, ''); const g = new Set(); for (let i = 0; i < s.length - 1; i++) g.add(s.slice(i, i + 2)); return g; };
const sim = (a, b) => { const A = big(a), B = big(b); if (!A.size || !B.size) return 0; let n = 0; A.forEach(x => { if (B.has(x)) n++; }); return 2 * n / (A.size + B.size); };
const PAST = /(した|でした|ました|だった|これまで|以前|去年|昨年|過ぎ|終わ|振り返|\b(was|were|did|last|ago|had)\b|었|았|했|지난|過去|去年|曾|了)/;
const FUTURE_Y = /(これから|迎え|訪れ|やってく|追い風が吹|予定|になります|でしょう|\bwill\b|올|될|將|會)/;
const MON_EN = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
const JARGON = /(劫財|偏官|正官|食神|傷官|印綬|偏印|比肩|偏財|正財|日主|蔵干|十二運|身強|身弱|喜神|忌神|七殺)(?![（(])/;

function turnsOf(msgs) {   // 発言ごとに、そのあとの AI の吹き出しをまとめる（最初のあいさつは除く）
  const T = []; let cur = null;
  for (const m of msgs) { if (m.role === 'me') { cur = { q: m.text, ai: [] }; T.push(cur); } else if (cur && m.role === 'ai') cur.ai.push(m.text || ''); }
  return T;
}
function cost(calls) { let y = 0; for (const c of calls || []) { const pr = /lite/.test(c.model || '') ? PRICES.lite : PRICES.deep; y += ((c.in - c.cached) * pr.in + c.cached * pr.cached + (c.out + c.think) * pr.out) / 1e6 * FX; } return y; }

function gradeOne(sc, d) {
  const F = [], E = [], Q = [], S = [];   // 事実・場面・会話・動作
  const T = turnsOf(d.msgs || []), fx = d.facts || {}, today = fx.today || new Date().toISOString().slice(0, 10);
  const nowY = +today.slice(0, 4), nowM = +today.slice(5, 7);
  const okY = new Set([...(fx.voidYears || []), ...(fx.compatVoidYears || [])]);
  const verdict = fx.verdict || '';
  const vc = /注意点が良い点を上回る/.test(verdict) ? 'bad' : (/良い点が注意点を上回る/.test(verdict) ? 'good' : (/同じくらい/.test(verdict) ? 'even' : (verdict ? 'plain' : '')));
  if ((d.errs || []).length) S.push({ t: 0, k: '画面のエラー', q: d.errs.join(' / ') });
  (d.calls || []).filter(c => c.status !== 200).forEach(c => S.push({ t: c.turn, k: 'AI の呼び出しの失敗', q: `${c.model} ${c.status}` }));
  if (T.length < sc.qs.length) S.push({ t: T.length + 1, k: '発言が送れていない', q: sc.qs[T.length] || '' });
  const prevSents = [];   // それより前の返事の文
  T.forEach((tn, i) => {
    const t = i + 1, all = tn.ai.join('\n'), ss = sents(all);
    // ---- 事実 ----
    let prev = '';
    ss.forEach(s => {
      if (/空亡|공망|\bvoid\b|kūbō/i.test(s)) {
        let ys = (s.match(/20\d\d/g) || []).map(Number);
        if (!ys.length && /^(これは|これらは|この(年|時期)は|それは|いずれも)/.test(s)) ys = (prev.match(/20\d\d/g) || []).map(Number);
        if (ys.length && !ys.some(y => okY.has(y))) F.push({ t, k: '空亡ではない年を空亡と言った', q: s, x: `空亡の年：${[...okY].join('・') || 'なし'}` });
        const ag = !ys.length && (s.match(/(\d{1,2})\s*(?:歳|살|歲|岁)/) || [])[1];
        if (ag && !(fx.voidAges || []).some(r => +ag >= r[0] - 1 && +ag <= r[1])) F.push({ t, k: '空亡ではない年齢を空亡と言った', q: s, x: `空亡の10年：${(fx.voidAges || []).map(r => r[0] + '〜' + r[1] + '歳').join('・') || 'なし'}` });
      }
      // 過ぎた月・年を、これからのこととして言う
      const pm = [];
      s.replace(/(20\d\d)\s*[年년]\s*(\d{1,2})\s*[月월]/g, (_, y, m) => pm.push([+y, +m]));
      s.replace(/\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(20\d\d)\b/gi, (_, m, y) => pm.push([+y, MON_EN[m.toLowerCase()]]));
      if (pm.some(([y, m]) => y < nowY || (y === nowY && m < nowM)) && !PAST.test(s)) F.push({ t, k: '過ぎた月を、これからのこととして言った', q: s, x: `今日：${today}` });
      else if ((s.replace(/20\d\d\s*[年년]?\s*(?:到|至|〜|～|~|–|-|から|부터)\s*20\d\d/g, '').match(/20\d\d/g) || []).map(Number).some(y => y < nowY) && FUTURE_Y.test(s) && !PAST.test(s))   // 「2018年到2028年」のような今を含む期間は数えない F.push({ t, k: '過ぎた年を、これからのこととして言った', q: s, x: `今日：${today}` });
      // 相性の強さ（日本語だけ）
      if (vc && sc.lang === 'ja' && /相性|組み合わせ|二人|2人|ふたり|全体|注意点|気をつけ|良い点|よい点/.test(s)) {
        const even = /同じくらい|打ち消し合|五分五分|半々/.test(s), up = /(良い|よい|いい)(点|面|ところ)が.{0,14}上回/.test(s), down = /注意(点|すべき点|するべき点)が.{0,12}上回|相性が(悪|よくない|良くない)/.test(s);
        const over = /最高の相性|抜群の相性|運命の(相手|人)|完璧な相性/.test(s);
        if ((vc === 'good' && (even || down)) || (vc === 'even' && (up || down)) || (vc === 'bad' && up) || (vc === 'plain' && (up || down)) || (vc !== 'good' && over) || (vc === 'good' && over))
          F.push({ t, k: '相性の強さが計算と違う（言い過ぎ・弱すぎ）', q: s, x: `計算：${verdict}` });
      }
      if (/6月10日|June 10|6월 10일|6月10號/.test(s) && /誕生日|birthday|생일|生日/.test(s)) F.push({ t, k: '運営の誕生日を言った', q: s });
      if (/編集結果|以下の通りです|Here is the (edited|revised)|CHIPS[:：]|```|\[(CHECKLIST|CLARITY|WRAP|READ)|undefined|NaN|\{"|<\/?(b|div|span|br|p)>/i.test(s)) F.push({ t, k: '指示や記号が文に出た', q: s });
      if (sc.lang !== 'ja' && /[぀-ヿ]/.test(s)) F.push({ t, k: '日本語のかなが混ざった', q: s });
      if (sc.lang !== 'ko' && /[가-힯]/.test(s)) F.push({ t, k: '韓国語が混ざった', q: s });
      prev = s;
    });
    // ---- 会話 ----
    if (!tn.ai.length) Q.push({ t, k: '返事がない', q: tn.q });
    else if (ss.length && ss.every(isQ)) Q.push({ t, k: '質問だけで答えていない', q: all });
    if (tn.ai.length > 8) Q.push({ t, k: `吹き出しが多すぎる（${tn.ai.length}個）`, q: tn.ai[0] });
    ss.filter(isQ).forEach(s => { const hit = prevSents.find(p => isQ(p) && sim(s, p) >= 0.6); if (hit) Q.push({ t, k: '前に聞いた質問をくり返した', q: s, x: `前：${cut(hit, 60)}` }); });
    ss.filter(s => !isQ(s) && s.length >= 15).forEach(s => { const hit = prevSents.find(p => sim(s, p) >= 0.8); if (hit) Q.push({ t, k: '前と同じ文をくり返した', q: s }); });
    if (sc.lang === 'ja') { const j = ss.find(s => JARGON.test(s)); if (j) Q.push({ t, k: '説明のない専門用語', q: j }); }
    prevSents.push(...ss);
    // ---- 場面の確かめ ----
    (sc.expect || []).filter(e => e.t === t).forEach(e => {
      (e.must || []).forEach(r => { if (!new RegExp(r).test(all)) E.push({ t, k: `入っているべき言葉がない（${r}）`, q: all, x: e.note }); });
      (e.not || []).forEach(r => { const m = all.match(new RegExp(r)); if (m) E.push({ t, k: `言ってはいけない言葉（${m[0]}）`, q: ss.find(s => new RegExp(r).test(s)) || all, x: e.note }); });
      if (e.sheet && !((d.sheets || [])[i] || []).includes(e.sheet)) E.push({ t, k: `入力画面（${e.sheet}）が開かなかった`, q: all, x: e.note });
      if (e.wrap) { const last = sents(tn.ai[tn.ai.length - 1] || '').pop() || ''; if (isQ(last)) E.push({ t, k: '話を締めたのに、質問で終えた', q: last }); }
    });
  });
  // 同じ間違いが同じ返事で何度も出たら、1つにまとめる
  const uniq = (a) => { const s = new Set(); return a.filter(x => { const k = x.t + x.k + x.q; if (s.has(k)) return false; s.add(k); return true; }); };
  return { id: sc.id, today, title: sc.title, lang: sc.lang, turns: T.length, fact: uniq(F), expect: uniq(E), talk: uniq(Q), sys: uniq(S), yen: cost(d.calls), T };
}

function post(body) {
  const KEY = (process.env.GEMINI_KEY || '').trim();
  return new Promise((res) => { const p = execFile('curl', ['-s', '-m', '150', '-X', 'POST', '-H', 'Content-Type: application/json', '--data-binary', '@-', `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${KEY}`], { maxBuffer: 20e6 }, (e, out) => res(out || '')); p.stdin.end(body); });
}
const JUDGE = `You review a conversation between a user and "Nico", the AI reader in a Japanese Four Pillars fortune-telling chat app. Report ONLY clear problems a real user would notice. Do not report style preferences. Problem types:
- context: Nico misread the situation (treats something that already happened as planned, mixes up who did what, asks again what the user already said, assumes facts the user did not give).
- unanswered: the user's question was not actually answered.
- unclear: a sentence a normal reader would not understand ("what does that mean?"), incl. unexplained jargon.
- generic: advice that could be sent to anyone, with no reason from the user's situation or chart.
- scary: a warning or bad sign given without explaining why or what to do.
- overstate: promises or certainty beyond what fortune-telling can say (e.g. guaranteed money, the partner's true feelings stated as fact).
- onesided: Nico talks at length without engaging with what the user said.
Note: encouraging contact with an ex-partner is fine; do not report it.
Return JSON only: {"issues":[{"turn":<user turn number, from 1>,"type":"<type>","quote":"<short exact quote from Nico>","why":"<one short sentence in Japanese>"}]}. Return {"issues":[]} if there is no clear problem.`;
async function judgeOne(r) {
  const conv = `TODAY: ${r.today} (the conversation happened on this date; judge every date and year against it).\n\n` + r.T.map((tn, i) => `【${i + 1}】USER: ${tn.q}\nNICO: ${tn.ai.join(' / ')}`).join('\n\n');
  const body = JSON.stringify({ systemInstruction: { parts: [{ text: JUDGE }] }, contents: [{ role: 'user', parts: [{ text: conv }] }], generationConfig: { temperature: 0, responseMimeType: 'application/json' } });
  const out = await post(body);
  try { const j = JSON.parse(out); const um = j.usageMetadata || {}; r.yenJudge = ((um.promptTokenCount || 0) * 1.5 + ((um.candidatesTokenCount || 0) + (um.thoughtsTokenCount || 0)) * 7.5) / 1e6 * FX;
    const txt = (j.candidates[0].content.parts || []).map(p => p.text || '').join(''); const o = JSON.parse(txt.replace(/^```json|```$/g, ''));
    const TY = { context: '文脈の読み違い', unanswered: '質問に答えていない', unclear: '意味が分かりにくい文', generic: 'ありきたりの助言', scary: '説明のない怖い注意', overstate: '言い過ぎ', onesided: '一方的' };
    (o.issues || []).forEach(x => r.talk.push({ t: +x.turn || 0, k: `AI 採点：${TY[x.type] || x.type}`, q: x.quote || '', x: x.why || '' }));
  } catch (e) { r.sys.push({ t: 0, k: 'AI 採点の失敗', q: cut(out, 120) }); }
}

(async () => {
  const R = [];
  for (const sc of SET.scenarios) { const f = path.join(DIR, sc.id + '.json'); if (!fs.existsSync(f)) continue; R.push(gradeOne(sc, JSON.parse(fs.readFileSync(f, 'utf8')))); }
  if (!R.length) { console.error('結果がありません：' + DIR); process.exit(1); }
  if (args.includes('--judge')) { for (const r of R) await judgeOne(r); }
  const sum = (k) => R.reduce((a, r) => a + r[k].length, 0), turns = R.reduce((a, r) => a + r.turns, 0), nExp = R.reduce((a, r) => a + ((SET.scenarios.find(s => s.id === r.id).expect || []).length), 0);
  const talkTurns = new Set(); R.forEach(r => r.talk.forEach(x => talkTurns.add(r.id + ':' + x.t)));
  const yen = R.reduce((a, r) => a + r.yen + (r.yenJudge || 0), 0);
  let ver = ''; try { ver = (fs.readFileSync(path.join(__dirname, '..', 'fx', 'sw.js'), 'utf8').match(/pocket-kantei-v\d+/) || [''])[0]; } catch (e) {}
  const G = { date: new Date().toISOString().slice(0, 10), ver, n: R.length, turns, fact: sum('fact'), expect: sum('expect'), nExp, talk: sum('talk'), talkTurns: talkTurns.size, sys: sum('sys'), yen: Math.round(yen), judge: args.includes('--judge'), byId: Object.fromEntries(R.map(r => [r.id, { fact: r.fact.length, expect: r.expect.length, talk: r.talk.length, sys: r.sys.length }])) };
  fs.writeFileSync(path.join(DIR, 'grade.json'), JSON.stringify({ G, R: R.map(r => Object.assign({}, r, { T: undefined })) }, null, 1));
  const pct = turns ? Math.round(talkTurns.size * 1000 / turns) / 10 : 0, mark = (ok) => ok ? '◯' : '✕';
  const L = [`# 定期テストの結果（${G.date}${ver ? '・' + ver : ''}）`, '', `本物の AI で ${R.length}本の会話（返事 ${turns}回）を流して、機械で採点しました${G.judge ? '（AI の採点つき）' : ''}。費用 約${G.yen}円。`, '',
    '| | 結果 | 目標 | |', '|---|---|---|---|',
    `| 事実の間違い | ${G.fact}件 | 0件 | ${mark(G.fact === 0)} |`,
    `| 前に見つけた間違いの再発 | ${G.expect}件（${nExp}か所を確認） | 0件 | ${mark(G.expect === 0)} |`,
    `| 会話の問題がある返事 | ${talkTurns.size}回／${turns}回（${pct}%） | 5%以下 | ${mark(pct <= 5)} |`,
    `| 動作のエラー | ${G.sys}件 | 0件 | ${mark(G.sys === 0)} |`, ''];
  const PREV = opt('--prev'); if (PREV) { try { const P = JSON.parse(fs.readFileSync(path.join(PREV, 'grade.json'), 'utf8')).G; const dlt = (a, b) => a === b ? '同じ' : (a < b ? `${b - a}件へった` : `${a - b}件ふえた`);
    L.push(`**前回（${P.date}${P.ver ? '・' + P.ver : ''}）との比べ**：事実の間違い ${dlt(G.fact, P.fact)}／再発 ${dlt(G.expect, P.expect)}／会話の問題 ${dlt(G.talkTurns, P.talkTurns)}／動作 ${dlt(G.sys, P.sys)}`, '');
    const worse = R.filter(r => { const p = P.byId && P.byId[r.id]; return p && (r.fact.length > p.fact || r.expect.length > p.expect); }).map(r => r.id + ' ' + r.title); if (worse.length) L.push(`前回より悪くなった会話：${worse.join('、')}`, ''); } catch (e) { L.push('（前回の結果が読めませんでした）', ''); } }
  L.push('## 見つかったこと', '');
  const sec = (name, k) => { const rows = []; R.forEach(r => r[k].forEach(x => rows.push(`- **${r.id} ${r.title}**（${x.t ? x.t + '回目の返事' : '全体'}）${x.k}：「${cut(x.q)}」${x.x ? ' — ' + x.x : ''}`))); L.push(`### ${name}（${rows.length}件）`, '', ...(rows.length ? rows : ['なし']), ''); };
  sec('事実の間違い', 'fact'); sec('前に見つけた間違いの再発', 'expect'); sec('会話の問題', 'talk'); sec('動作のエラー', 'sys');
  L.push('## 会話ごと', '', '| 会話 | 言語 | 事実 | 再発 | 会話 | 動作 | 費用 |', '|---|---|---|---|---|---|---|', ...R.map(r => `| ${r.id} ${r.title} | ${r.lang} | ${r.fact.length} | ${r.expect.length} | ${r.talk.length} | ${r.sys.length} | ${Math.round(r.yen)}円 |`), '',
    '※ 機械の採点なので、まちがって数えることもあります。数が増えた時は「会話の全文.md」で中身を見てから直します。');
  fs.writeFileSync(path.join(DIR, '報告.md'), L.join('\n') + '\n');
  const A = [`# 定期テストの会話の全文（${G.date}${ver ? '・' + ver : ''}）`, ''];
  R.forEach(r => { A.push(`## ${r.id} ${r.title}（${r.lang}）`, ''); r.T.forEach(tn => { A.push(`**あなた**：${tn.q}`, ''); tn.ai.forEach(a => A.push(`ニコ：${String(a).replace(/\n+/g, ' ')}`, '')); }); });
  fs.writeFileSync(path.join(DIR, '会話の全文.md'), A.join('\n') + '\n');
  console.log(`事実 ${G.fact}／再発 ${G.expect}／会話の問題 ${talkTurns.size}回/${turns}回（${pct}%）／動作 ${G.sys}／約${G.yen}円 → ${path.join(DIR, '報告.md')}`);
})();
