// 定期テスト：決まった会話（scenarios.json）を本物の AI で流して、採点する。
// 使い方（tests のフォルダで、./setup.sh のあと）：
//   GEMINI_KEY=… node regress/run.js <結果フォルダ> [--only ja01,ja04] [--par 3] [--judge] [--prev 前回の結果フォルダ]
//   ・--judge … 機械で見られないこと（文脈の読み違い・質問に答えていない・意味が分からない文）を、別の AI で採点する（1会話 1円ほど足される）
//   ・--prev  … 前回の結果と比べる
// 結果フォルダに、会話ごとの JSON・採点（grade.json）・報告（報告.md）・会話の全文（会話の全文.md）ができる。
// 費用のめやす：31会話で 400〜500円（--judge で +30円ほど）。
const fs = require('fs'), path = require('path'), { spawn } = require('child_process');
const KEY = (process.env.GEMINI_KEY || '').trim(); if (!KEY) { console.error('GEMINI_KEY に鍵を入れてください'); process.exit(1); }
const args = process.argv.slice(2); const OUT = args[0]; if (!OUT || OUT.startsWith('--')) { console.error('結果フォルダを指定してください'); process.exit(1); }
const opt = (k) => { const i = args.indexOf(k); return i >= 0 ? (args[i + 1] || '') : null; };
const ONLY = opt('--only') ? opt('--only').split(',') : null, PAR = +(opt('--par') || 3);
const SET = JSON.parse(fs.readFileSync(path.join(__dirname, 'scenarios.json'), 'utf8'));
fs.mkdirSync(OUT, { recursive: true });
const list = SET.scenarios.filter(s => !ONLY || ONLY.includes(s.id));
function runOne(s) {
  return new Promise((res) => {
    const inF = path.join(OUT, s.id + '.in.json'), outF = path.join(OUT, s.id + '.json');
    fs.writeFileSync(inF, JSON.stringify({ lang: s.lang, stage: 0, profile: SET.profiles[s.p], qs: s.qs }));
    const t0 = Date.now();
    const p = spawn(process.execPath, [path.join(__dirname, '..', 'convo.js'), inF, outF], { cwd: path.join(__dirname, '..'), env: process.env, stdio: ['ignore', 'ignore', 'pipe'] });
    let err = ''; p.stderr.on('data', d => err += d);
    const kill = setTimeout(() => p.kill('SIGKILL'), 15 * 60e3);
    p.on('close', (code) => { clearTimeout(kill); fs.unlinkSync(inF); console.log(`${s.id} ${s.title} … ${code === 0 && fs.existsSync(outF) ? 'おわり' : '失敗 ' + err.slice(-200)}（${Math.round((Date.now() - t0) / 1000)}秒）`); res(); });
  });
}
(async () => {
  const q = list.slice(); const workers = Array.from({ length: Math.min(PAR, q.length) }, async () => { while (q.length) await runOne(q.shift()); });
  await Promise.all(workers);
  const ga = [path.join(__dirname, 'grade.js'), OUT]; if (args.includes('--judge')) ga.push('--judge'); if (opt('--prev')) ga.push('--prev', opt('--prev'));
  await new Promise(r => spawn(process.execPath, ga, { stdio: 'inherit', env: process.env }).on('close', r));
})();
