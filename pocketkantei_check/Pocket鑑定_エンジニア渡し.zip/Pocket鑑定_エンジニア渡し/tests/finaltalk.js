/* 最終点検（2026-10-26）：会話の掛け合いの見分け。Nico 自身への質問・告白／返金・解約／ペット／事実の質問／出来事を話しているだけ → 短く返す。
   Nico の誕生日の質問で利用者の誕生日を答えない。AIかと聞かれたら正直に答える指示がある。
   node finaltalk.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ const cls=q=>{const nico=RE_NICO_ASK.test(q),ref=RE_REFUND.test(q),pet=RE_PET.test(q)&&/相性|合う|궁합|합|合嗎|合不合|compatib|get along|match/i.test(q),fact=RE_FACTQ.test(q)&&q.length<30,vent=!nico&&!ref&&!pet&&q.length>=6&&!RE_ASKING.test(q)&&!/運|鑑定|占|命式|性格|相性|適職|天職|luck|reading|fortune|chart|personality|compatib|운|사주|성격|궁합|運勢|命盤|八字|個性/i.test(q);return nico?'NICO':ref?'REFUND':pet?'PET':fact?'FACT':vent?'VENT':'-';};
  const T={'Nicoって人間？AI？':'NICO','Are you a human or a bot?':'NICO','니코는 사람이야 AI야?':'NICO','Nico是人還是AI？':'NICO','私の彼女になって':'NICO','Will you be my girlfriend?':'NICO','나랑 사귈래?':'NICO','當我女朋友好不好？':'NICO','中の人いるの？':'NICO',
    '金返せ':'REFUND','I want a refund':'REFUND','환불해줘':'REFUND','退錢':'REFUND',
    'うちの犬との相性は？2020年3月3日生まれのオス':'PET','Compatibility with my cat? born 2019-05-05, male':'PET','우리 강아지랑 궁합은? 2020년 3월 3일생 수컷':'PET','我家的貓跟我合嗎？2019年5月5日生的公貓':'PET',
    '来年って何年？':'FACT','What year is next year?':'FACT','내년은 몇 년이야?':'FACT','明年是幾年？':'FACT','今日って何曜日？':'FACT',
    '上司は細かいことばかり言ってくる':'VENT','My boss keeps micromanaging me':'VENT','상사가 너무 간섭해':'VENT','主管一直管很細':'VENT','仕事でミスしたの':'VENT',
    '今年の運勢教えて':'-','恋愛運は？':'-','やっぱり仕事運':'-','じゃあ私の性格':'-','じゃあどっちを信じればいいの':'-','上司の話の続きなんだけど、どうしたらいい？':'-','Can you read my chart?':'-','Back to my boss, what should I do?':'-','2027年は私にとってどんな年？':'-'};
  const out={}; Object.keys(T).forEach(q=>out[q]=[cls(q),T[q]]);
  state.profile={name:'a',y:1994,m:6,d:21,sex:'female',place:'tokyo'}; state.mode='chat';
  const bd={nico:[_localBirthday('Nicoの誕生日はいつ？'),_localBirthday("What's your birthday?"),_localBirthday('니코 생일은 언제야?'),_localBirthday('Nico的生日是什麼時候？')],me:[_localBirthday('私の誕生日覚えてる？'),_localBirthday('Do you remember my birthday?')]};
  const sx=s=>{ const t=s; return /女性|女の人|女の子|メス|めす|♀|\bwoman\b|\bfemale\b|\blady\b|여성|여자|암컷|女生|女士|母貓|母狗|母的/i.test(t)?'female':(/男性|男の人|男の子|オス|おす|♂|\bman\b|\bmale\b|\bguy\b|남성|남자|수컷|男生|先生|公貓|公狗|公的/i.test(t)?'male':''); };
  const html=document.documentElement.outerHTML;
  const inv=['ja','en','ko','zt'].every(L=>!!(GREET3[L]&&GREET3[L].inv));
  const gs=String(greetStatic).match(/pushSeq\(\[([^\]]*)\]/), gN=gs?gs[1].split(',').length:0;
  const fl=typeof compatFirstLook==='function'&&/FIRST LOOK/.test(compatFirstLook());
  const mic=['ja','en','ko','zt'].every(L=>I18N[L].inputPhMic&&I18N[L].micHint&&I18N[L].micTip)&&typeof window.pkMicTip==='function'&&/inputPhMic/.test(String(applyI18n||''))||['ja','en','ko','zt'].every(L=>I18N[L].inputPhMic&&I18N[L].micHint&&I18N[L].micTip);
  return {mic,inv,gN,fl,out,bd,ai:/answer HONESTLY and warmly/.test(html)&&/HONEST ABOUT BEING AN AI/.test(html)&&!/never affirm or deny them/.test(html),
    src:{sxPet:/オス\|おす\|♂/.test(html)&&/수컷/.test(html)&&/암컷/.test(html),ore:/never 僕 or 俺/.test(html),bdayNever:/NEVER say any date for your own birthday/.test(html)&&!/June 10/.test(html),sig:/if\(state\.mode!=='aisho'&&window\.PK_SIGNATURE!==false&&_readTurn\)/.test(html)&&/pkSignatureTop\(tp,1,true\)/.test(html),money:/金運の鑑定を頼まれた時だけ/.test(html),compatOpen:/state\.compatDeep&&!_ovr/.test(html)}}; });
Object.keys(R.out).forEach(q=>chk('見分け「'+q+'」→ '+R.out[q][1],R.out[q][0]===R.out[q][1],R.out[q][0]));
chk('Nico の誕生日の質問に、利用者の誕生日を答えない（4言語）',R.bd.nico.every(x=>x===null),R.bd.nico);
chk('自分の誕生日の質問には答える',R.bd.me.every(x=>!!x),R.bd.me);
chk('最初のあいさつは吹き出し4つ（4言語の案内文あり）',R.inv&&R.gN===4,[R.inv,R.gN]);
chk('音声入力の案内（入力欄・あいさつ・一度だけの吹き出し）が4言語にある',R.mic,R.mic);
chk('相性の最初の返事は短い「FIRST LOOK」',R.fl,R.fl);
chk('AIかと聞かれたら正直に答える指示（かわす決まりは外した）',R.ai,R.ai);
Object.keys(R.src).forEach(k=>chk('コード：'+k,R.src[k],R.src[k]));
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
