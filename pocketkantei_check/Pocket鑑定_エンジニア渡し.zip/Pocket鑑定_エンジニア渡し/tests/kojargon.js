/* 韓国語の言い換えが、ふつうの言葉を壊さないか（「편인지」「상관없어요」「일주일」「세운」）・同性カップルの「異性」の言い換え（2026-10-25）
   node kojargon.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ state.lang='ko'; const keep=['컨디션이 올라가는 편인지 아니면 지치는 편인지 보여줘요.','그건 상관없어요. 상관이 없어요. 상관하지 마세요.','일주일 동안 쉬어요.','비견될 만큼 좋아요.','계획을 세운 사람이에요.'].map(t=>[t,_softenJargon(t)]);
  const conv=['당신은 편인이 강해요.','상관이 두 개 있어요.','세운의 흐름이에요.'].map(t=>[t,_softenJargon(t)]);
  state.mode='aisho'; state.profile={sex:'male'}; state.chartB={_sex:'male'}; const ss=_sameSexWord('유님이 상대분에게 이성적인 매력을 느껴요. 이성으로서 끌려요.'); state.lang='ja'; const ssj=_sameSexWord('お相手に異性として惹かれやすい'); state.chartB={_sex:'female'}; const diff=_sameSexWord('お相手に異性として惹かれやすい');
  return {keep,conv,ss,ssj,diff}; });
R.keep.forEach(([a,b])=>chk('ふつうの言葉はそのまま：'+a,a===b,b));
R.conv.forEach(([a,b])=>chk('専門用語は言い換える：'+a,a!==b,b));
chk('同性カップル：韓国語の「이성」を言い換える',!/이성/.test(R.ss),R.ss);
chk('同性カップル：日本語の「異性として」を言い換える',/恋愛の相手として/.test(R.ssj),R.ssj);
chk('男女のカップルはそのまま',R.diff==='お相手に異性として惹かれやすい',R.diff);
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
