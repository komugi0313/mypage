/* アプリ版（ストアの3日間無料トライアル）の画面の確認：node apptrial.js
   Capacitor と RevenueCat を偽物にして、iPhone アプリとして開く */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){ r.writeHead(404); return r.end(); } fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':u.endsWith('.png')?'image/png':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), errs=[];
  for(const L of ['ja','en']){
  const ctx=await b.newContext({viewport:{width:390,height:844}}); const pg=await ctx.newPage(); pg.on('pageerror',e=>errs.push(String(e)));
  await ctx.addInitScript(l=>{ localStorage.setItem('pk_lang',l); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_svd','1');
    const pkg=(id,price)=>({identifier:id,packageType:'MONTHLY',product:{identifier:id,priceString:price,introPrice:{price:0,periodNumberOfUnits:3,periodUnit:'DAY'}}});
    window.PK_RC_KEYS={ios:'appl_test'};
    window.Capacitor={getPlatform:()=>'ios',isNativePlatform:()=>true,Plugins:{Purchases:{isConfigured:async()=>({isConfigured:false}),configure:async()=>{},logIn:async()=>{},
      getOfferings:async()=>({current:{availablePackages:[pkg('pk_std_monthly','¥3,300'),pkg('pk_pro_monthly','¥5,900'),pkg('pk_vip_monthly','¥9,800')]}}),purchasePackage:async()=>({})}}};
    localStorage.setItem('pk_auth',JSON.stringify({email:'a@x.com',token:'a'.repeat(64)+'.1.9999999999999.sig',verified:true}));
  },L);
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(600);
  await pg.fill('#iname','T'); await pg.selectOption('#iy','1995'); await pg.check('#agreeChk'); await pg.click('#regBtn'); await pg.waitForTimeout(1500);
  const inChat=await pg.evaluate(()=>document.getElementById('scChat').classList.contains('on'));
  if(!inChat){ await pg.evaluate(()=>{ try{ enterChat(); }catch(e){} }); await pg.waitForTimeout(800); }
  chk(L+' アプリ版：無料お試しの表示（あと何通）は出さない',await pg.evaluate(()=>{ const e=document.getElementById('trialPill'); return !e||getComputedStyle(e).display==='none'; }));
  await pg.evaluate(q=>{ const i=document.getElementById('askIn'); i.value=q; i.dispatchEvent(new Event('input',{bubbles:true})); },L==='ja'?'今年の仕事運は？':'How is my work luck this year?');
  await pg.evaluate(()=>{ document.getElementById('askBtn').click(); });
  for(let i=0;i<150;i++){ await pg.waitForTimeout(500); if(await pg.evaluate(()=>document.getElementById('shPlan').classList.contains('on'))) break; }
  await pg.waitForTimeout(800);
  const txt=await pg.evaluate(()=>document.getElementById('scChat').innerText);
  chk(L+' 相談するとNicoが3日間無料お試しを案内（カードにはふれない）',(L==='ja'?/3日間無料お試し/.test(txt):/3-day free trial/.test(txt))&&!/カード|card/i.test(txt.split(/\n/).slice(-6).join(' ')), txt.slice(-300));
  const sheet=await pg.evaluate(()=>{ const s=document.getElementById('shPlan'); return {open:s.classList.contains('on'), btn:[...s.querySelectorAll('.plan-buy')].map(b=>b.textContent), terms:[...s.querySelectorAll('.plan-trial')].map(p=>p.textContent)}; });
  chk(L+' プランの画面が開き、ボタンは「3日間無料で始める」',sheet.open&&sheet.btn.length===3&&sheet.btn.every(t=>L==='ja'?t==='3日間無料で始める':t==='Start 3-day free trial'),sheet);
  chk(L+' ボタンの下に、お試しのあとの料金と解約の条件',sheet.terms.length===3&&(L==='ja'?/¥3,300.*自動更新.*24時間前/.test(sheet.terms[0]):/¥3,300.*24 hours/.test(sheet.terms[0])),sheet.terms[0]);
  await pg.screenshot({path:path.join(__dirname,'..','..','shots_apptrial_'+L+'.png')});
  await ctx.close(); }
  chk('JSのエラーなし',errs.length===0,errs);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0); });
