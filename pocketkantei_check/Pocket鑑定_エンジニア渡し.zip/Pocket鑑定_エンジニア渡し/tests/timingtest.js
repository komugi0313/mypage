/* 相性の大運・月運（12か月・刑害・三合の完成）と、出会いの場所（命式から計算）の確認
   node timingtest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const R=await pg.evaluate(()=>{ const A=computeChart({name:'花子',y:2008,m:3,d:28,tu:false,hh:14,mi:0,sex:'female',place:''}); const out={};
    state.chart=A; state.profile={sex:'female'}; state.mode='chat'; state.chartB=null;
    out.mp=meetPlaces(); out.single=nearTimelineBlock();
    for(const [k,y,m,d] of [['c1',2007,1,17],['c2',2006,8,19],['c3',2006,6,7]]){ const B=computeChart({name:'太郎',y,m,d,tu:true,hh:12,mi:0,sex:'male',place:''});
      state.chartB=B; state.mode='aisho'; state.compat=compatData(A.pro,B.pro); state.compatDeep=compatDeep(A.pro,B.pro,A.fav,B.fav); const ct=coupleTiming();
      out[k]={decades:ct.decades,good:ct.goodMonths,caut:ct.cautMonths,soft:ct.softMonths,minor:ct.minorMonths,block:coupleTimingBlock(),near:nearTimelineBlock(),deep:compatDeepGrounding(state.compatDeep)}; }
    /* 男性の場合：パートナーの星は財星 */
    const M=computeChart({name:'太郎',y:2007,m:1,d:17,tu:true,hh:12,mi:0,sex:'male',place:''}); state.chart=M; state.profile={sex:'male'}; state.mode='chat'; state.chartB=null; out.male=meetPlaces();
    return out; });
  console.log(JSON.stringify({mp:R.mp,male:R.male,c1:{good:R.c1.good,caut:R.c1.caut,minor:R.c1.minor},c2:{good:R.c2.good,caut:R.c2.caut,decades:R.c2.decades},c3:{decades:R.c3.decades,good:R.c3.good,soft:R.c3.soft,caut:R.c3.caut,minor:R.c3.minor}},null,1));
  console.log((R.single.match(/\[WHERE THEY MAY MEET[^\n]*/)||[''])[0]);
  /* 花子さん（日干 丁＝火）：パートナーの星＝水。命式の水＝年柱 子 */
  chk('女性のパートナーの星は水（丁の官星）',R.mp.spouseEl==='水',R.mp.spouseEl);
  chk('場面：年柱（子）にパートナーの星＝家族・地元',R.mp.areas.length===1&&/年柱/.test(R.mp.areas[0]),R.mp.areas);
  chk('男性（日干 辛＝金）のパートナーの星は木（財星）',R.male.spouseEl==='木',R.male.spouseEl);
  chk('ひとりの時：出会いの場所の行がある',/\[WHERE THEY MAY MEET/.test(R.single));
  chk('出会いの月に方角が付く',/ENCOUNTER MONTHS with their direction: \d{4}\/\d+ → direction /.test(R.single));
  chk('専門用語を出さない指示',/never output the words 官星\/財星\/喜神\/驛馬\/桃花/.test(R.single));
  for(const c of ['c1','c2','c3']){
    chk(c+'：相性中は出会いの場所の行を出さない',!/WHERE THEY MAY MEET/.test(R[c].near));
    chk(c+'：大運が2人分ある',R[c].decades.length===2&&/^あなた→/.test(R[c].decades[0])&&/^相手→/.test(R[c].decades[1]),R[c].decades);
    chk(c+'：月運が12か月ぶん分類されている（よい・穏やか・注意で合計12以内、7か月以上）',(R[c].good.length+R[c].soft.length+R[c].caut.length+R[c].minor.length)>=7&&(R[c].good.length+R[c].soft.length+R[c].caut.length+R[c].minor.length)<=12,[R[c].good.length,R[c].soft.length,R[c].caut.length,R[c].minor.length]);
    chk(c+'：「くわしく」で大運と月も話す指示',/\(5\) the 10-year flow from DECADES/.test(R[c].deep)&&/\(6\) one sentence on the coming months/.test(R[c].deep));
  }
  const all=[].concat(R.c1.minor,R.c2.minor,R.c3.minor).join(' ');
  chk('刑・害の月は「小さな行き違いの月」に入る',/刑|害/.test(all)&&/MINOR-FRICTION MONTHS/.test(R.c1.block),all);
  chk('注意の月（冲）には刑・害を入れない',!/刑|害/.test([].concat(R.c1.caut,R.c2.caut,R.c3.caut).join(' ')));
  chk('よい月に三合・方合の完成が入る',/開局/.test([].concat(R.c1.good,R.c2.good,R.c3.good).join(' ')));
  const dc=[].concat(R.c1.decades,R.c2.decades,R.c3.decades).join(' ');
  chk('大運で配偶宮の刑・害も見る（どれかに出る、または落ち着いた10年）',/刑|害|落ち着いた10年|開局|成立|調和|冲/.test(dc),dc);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
