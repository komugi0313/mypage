// 相手の誕生日の見分け（chatPartnerScan）：誕生日の言葉がなくても、Nico が聞いた直後・相手を指す言葉があれば受け付け、記念日や入社日は受け付けない（4言語）
//   node partnerscan.js fx
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const root=process.argv[2];
const srv=http.createServer((q,r)=>{ let f=path.join(root,decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
 fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});}).listen(0,async()=>{
 const b=await chromium.launch(); const base='http://127.0.0.1:'+srv.address().port; let ok=0,ng=0;
 const cases=[['','1991年8月4日です。付き合って2年の彼です',true],['彼の生年月日を教えてね','1991年8月4日です',true],['','彼と2020年4月1日に付き合い始めた',false],['','2020年4月1日に入社しました',false],['','彼の誕生日は1991年8月4日',true],['','My boyfriend: Aug 4, 1991',true],['','남친 생년월일은 1991년 8월 4일이야',true],['','他是1991年8月4日出生的',true],['','我們2019年5月20日在一起的',false],['','明日1995年5月5日のイベントに行く',false]];
 for(const [ai,q,exp] of cases){ const pg=await (await b.newContext()).newPage(); await pg.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());
  await pg.addInitScript(()=>{localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1993,m:3,d:21,tu:false,hh:9,mi:15,sex:'female',place:'tokyo'}));});
  await pg.goto(base+'/index.html'); await pg.waitForTimeout(700);
  const got=await pg.evaluate(([ai,q])=>{ state.msgs=ai?[{role:'ai',text:ai}]:[]; state.mode='self'; state.chartB=null; return chatPartnerScan(q); },[ai,q]);
  const g=(!!got)===exp; g?ok++:ng++; console.log((g?'OK  ':'NG  ')+q+' → '+got); await pg.close(); }
 console.log(ok+' OK / '+ng+' NG'); await b.close(); srv.close(); });
