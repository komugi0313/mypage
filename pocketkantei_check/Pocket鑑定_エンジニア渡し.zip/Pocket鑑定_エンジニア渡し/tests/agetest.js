/* 18歳以上・同意のチェックの確認：node tests/agetest.js （サーバーなしで動きます） */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u==='/') u='/index.html'; if(u.startsWith('/api/')){ r.writeHead(404); return r.end(); }
  fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':u.endsWith('.png')?'image/png':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch(), errs=[];
  for(const [L,word] of [['ja','外部のAIサービス'],['en','external AI service'],['ko','외부 AI 서비스'],['zt','外部AI服務']]){
    const ctx=await b.newContext({viewport:{width:390,height:844}}); await ctx.addInitScript(l=>{ localStorage.setItem('pk_lang',l); localStorage.setItem('pk_seen_lp','1'); },L);
    const pg=await ctx.newPage(); pg.on('pageerror',e=>errs.push(String(e))); const alerts=[]; pg.on('dialog',d=>{ alerts.push(d.message()); d.accept(); });
    await pg.goto(base+'/index.html?start=1'); await pg.waitForTimeout(700);
    chk(L+' 同意の文が出る（18歳・AI）',(await pg.textContent('#agreeBox')).includes(word) && (await pg.textContent('#agreeBox')).includes('18'));
    await pg.fill('#iname','T');
    const y=new Date().getFullYear();
    await pg.selectOption('#iy',String(y-16)); await pg.click('#sexSeg button[data-sex="female"]').catch(()=>{}); await pg.click('#regBtn'); await pg.waitForTimeout(300);
    chk(L+' 16歳は登録できない',alerts.length===1 && /18/.test(alerts[0]), alerts);
    await pg.selectOption('#iy','1995'); await pg.click('#sexSeg button[data-sex="female"]').catch(()=>{}); await pg.click('#regBtn'); await pg.waitForTimeout(300);
    chk(L+' チェックなしは進めない',alerts.length===2 && await pg.$eval('#scOnboard',e=>e.classList.contains('on')||getComputedStyle(e).display!=='none'), alerts);
    await pg.check('#agreeChk'); await pg.click('#sexSeg button[data-sex="female"]').catch(()=>{}); await pg.click('#regBtn'); await pg.waitForTimeout(1500);
    const prof=await pg.evaluate(()=>{ try{ return JSON.parse(localStorage.getItem('pk_profile')||'null'); }catch(e){ return null; } });
    chk(L+' チェックすると登録へ進み、同意を記録',!!(prof&&prof.aiConsent&&prof.agreedAt), prof);
    await ctx.close();
  }
  chk('JSのエラーなし',errs.length===0,errs);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
