/* 言語ごとの紹介ページの確認：node tests/lppages.js （先に node tools/build-lp.js） */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0].split('#')[0]); if(u.endsWith('/')) u+='index.html';
  const f=path.join(ROOT,u); fs.readFile(f,(e,b)=>{ if(e){r.writeHead(404);return r.end('404');}
  const ct=f.endsWith('.html')?'text/html; charset=utf-8':f.endsWith('.png')?'image/png':f.endsWith('.xml')?'application/xml':'application/javascript'; r.writeHead(200,{'content-type':ct}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch(), errs=[];
  async function open(p,{locale='ja-JP',saved=null,js=true}={}){
    const ctx=await b.newContext({locale,javaScriptEnabled:js,viewport:{width:390,height:844}});
    if(saved) await ctx.addInitScript(l=>{ try{localStorage.setItem('pk_lang',l);}catch(e){} },saved);
    const pg=await ctx.newPage(); pg.on('pageerror',e=>errs.push(p+': '+e)); await pg.goto(base+p); await pg.waitForTimeout(500); return {ctx,pg};
  }
  const want={'/en/':['en','How is this different'],'/ko/':['ko','다른 점과'],'/zt/':['zh-Hant','和其他占卜']};
  for(const [p,[hl,word]] of Object.entries(want)){
    let {ctx,pg}=await open(p,{js:false});   // JSなし（検索エンジン・シェアのカードが見る形）
    chk(p+' JSなしでも本文がその言語',(await pg.content()).includes(word));
    chk(p+' html lang',await pg.getAttribute('html','lang')===hl);
    await ctx.close();
    ({ctx,pg}=await open(p,{saved:'ja'}));   // 前に日本語を選んだ人でも、このページの言語
    chk(p+' 日本語を選んだことがある人にも、このページの言語で表示',(await pg.textContent('[data-t="onT"]')).includes(word));
    chk(p+' アドレスはそのまま',new URL(pg.url()).pathname===p, pg.url());
    await ctx.close();
  }
  // lp.html：英語のブラウザ → 英語に切りかわり、アドレスも /en/
  let {ctx,pg}=await open('/lp.html',{locale:'en-US'});
  chk('lp.html 英語のブラウザで英語表示',(await pg.textContent('[data-t="onT"]')).includes('How is this'));
  chk('lp.html 英語のブラウザで /en/ に',new URL(pg.url()).pathname==='/en/', pg.url());
  await ctx.close();
  ({ctx,pg}=await open('/lp.html',{locale:'ja-JP'}));
  chk('lp.html 日本語のブラウザはそのまま',new URL(pg.url()).pathname==='/lp.html' && (await pg.textContent('[data-t="onT"]')).includes('ほかの占い'), pg.url());
  await ctx.close();
  // 言語の切りかえ → アドレスも変わる、ボタンはアプリへ
  ({ctx,pg}=await open('/ko/'));
  await pg.selectOption('#langSel','en'); await pg.waitForTimeout(200);
  chk('/ko/ で英語に切りかえ → /en/',new URL(pg.url()).pathname==='/en/', pg.url());
  const href=await pg.$eval('.hero a.cta, a.cta',a=>a.href);
  chk('申し込みボタンはアプリへ',new URL(href).pathname==='/index.html', href);
  chk('Nicoの絵が出る',await pg.$eval('.brand img',i=>i.naturalWidth>0));
  await pg.selectOption('#langSel','ja'); await pg.waitForTimeout(200);
  chk('日本語に切りかえ → /lp.html',new URL(pg.url()).pathname==='/lp.html', pg.url());
  await ctx.close();
  // ストアのボタン（URLを入れた時だけ。日本語ページはウェブ版のまま）
  const STORE={ios:'https://apps.apple.com/app/id000',android:'https://play.google.com/store/apps/details?id=x',langs:['en','ko','zt']};
  const IPH='Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1';
  const AND='Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36';
  async function storeOpen(p,ua,store){ const ctx=await b.newContext({locale:'ja-JP',userAgent:ua,viewport:{width:390,height:844}});
    if(store) await ctx.addInitScript(S=>{ window.PK_STORE=S; },store);
    const pg=await ctx.newPage(); pg.on('pageerror',e=>errs.push(p+': '+e)); await pg.goto(base+p); await pg.waitForTimeout(400); return {ctx,pg}; }
  const cta=pg=>pg.$eval('.cta-top a.cta',a=>a.getAttribute('href'));
  ({ctx,pg}=await storeOpen('/en/',IPH,null));
  chk('ストアURLが空 → 英語ページもウェブ版のまま',(await cta(pg))==='/index.html?start=1' && await pg.$eval('#storeRow',e=>e.hidden));
  await ctx.close();
  ({ctx,pg}=await storeOpen('/en/',IPH,STORE));
  chk('iPhone → App Store',(await cta(pg))===STORE.ios, await cta(pg));
  chk('iPhone ではストアのボタンは App Store だけ',(await pg.$$eval('#storeRow .store-b',x=>x.map(e=>e.dataset.store)).then(v=>v.join(',')))==='ios');
  chk('ログインの案内は隠す',await pg.$eval('.lp-login',e=>getComputedStyle(e).display==='none'));
  chk('下の固定ボタンもストアへ',(await pg.$eval('#stickyCta a',a=>a.getAttribute('href')))===STORE.ios);
  await pg.selectOption('#langSel','ja'); await pg.waitForTimeout(200);
  chk('日本語に切りかえるとウェブ版に戻る',(await cta(pg))==='/index.html?start=1');
  await ctx.close();
  ({ctx,pg}=await storeOpen('/ko/',AND,STORE));
  chk('Android → Google Play',(await cta(pg))===STORE.android, await cta(pg));
  await ctx.close();
  ({ctx,pg}=await storeOpen('/zt/',undefined,STORE));
  chk('パソコンは両方のボタン',(await pg.$$eval('#storeRow .store-b',x=>x.length))===2);
  await ctx.close();
  ({ctx,pg}=await storeOpen('/lp.html',IPH,STORE));
  chk('日本語ページはウェブ版のまま',(await cta(pg))==='/index.html?start=1' && await pg.$eval('#storeRow',e=>e.hidden));
  await ctx.close();
  // メタ情報
  for(const p of ['/lp.html','/en/','/ko/','/zt/']){
    const h=fs.readFileSync(path.join(ROOT,p.endsWith('/')?p+'index.html':p),'utf8');
    chk(p+' canonical / hreflang 4つ / og:url', h.includes('rel="canonical"') && (h.match(/hreflang="(ja|en|ko|zh-Hant)"/g)||[]).length===4 && h.includes('og:url'));
  }
  chk('sitemap.xml',fs.readFileSync(path.join(ROOT,'sitemap.xml'),'utf8').split('<loc>').length===5);
  chk('JSのエラーなし',errs.length===0,errs);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
