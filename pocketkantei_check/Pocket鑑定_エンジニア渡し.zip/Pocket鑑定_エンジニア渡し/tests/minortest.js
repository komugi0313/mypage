/* 大人と18歳未満の恋愛：恋愛の相性・告白・時期の助言をしない／ボタンを出さない（運営決定 2026-10-24）
   node minortest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ const o={};
  function run(u,usx,msg){ state.profile={y:u[0],m:u[1],d:u[2],sex:usx,place:'tokyo'}; state.chart=computeChart({name:'',y:u[0],m:u[1],d:u[2],tu:true,hh:12,mi:0,sex:usx,place:'tokyo'}); state.chartB=null; state.mode='chat'; state.msgs=[{role:'me',text:msg}]; chatPartnerScan(msg); return minorLoveInfo(msg); }
  o.a=run([1980,3,8],'male','好きな子がいます。相手の生年月日が2009年4月5日、女性です。告白していいか？');
  o.b=run([2009,4,5],'female','好きな人がいます。1980年3月8日生まれの男性です。付き合えますか？');
  o.c=run([2009,4,5],'female','好きな人は2010年1月1日生まれの男子です。告白していい？');
  o.d=run([1980,3,8],'male','娘は2009年4月5日生まれです。親子の相性は？');
  o.e=run([1980,3,8],'male','I have a crush. She was born on 2009-04-05.');
  o.f=run([1980,3,8],'male','好きな人がいます。相手は1990年4月5日生まれの女性です');
  o.g=run([1980,3,8],'male','좋아하는 사람이 있어요. 2010년 5월 5일생 여자예요');
  return o; });
console.log(JSON.stringify(R));
chk('46歳×17歳の告白 → 止める',R.a&&R.a.partnerAge===17&&!R.a.userMinor,R.a);
chk('17歳×46歳（本人が未成年） → 止める（本人を守る言い方）',R.b&&R.b.userMinor,R.b);
chk('17歳どうし（どちらも未成年） → ふつうの恋愛相談',!R.c,R.c);
chk('親子の相性 → ふつうの相性',!R.d,R.d);
chk('英語・韓国語でも止める',R.e&&R.g,[R.e,R.g]);
chk('大人どうし → ふつう',!R.f,R.f);
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
