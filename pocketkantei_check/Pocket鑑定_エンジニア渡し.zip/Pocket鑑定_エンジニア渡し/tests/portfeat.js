// 古い版から移したボタン：🍀今日のラッキー・🎯ピンポイント占い・🕰過去を占う・🔮未来を占う・🦉Nicoのつぶやき・🔄話題を変えたい（AIは偽物）
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');const SHOT=process.argv[2]||'';
const bodies=[];
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/gemini')){ let b=''; q.on('data',c=>b+=c); q.on('end',()=>{ bodies.push(b); const cls=q.headers['x-pk-classify']==='1';
    r.writeHead(200,{'content-type':'application/json'}); r.end(JSON.stringify({candidates:[{content:{parts:[{text: cls?'{"topic":"other","subject":"self","serious":false}':'今年は追い風の年です。春から人とのつながりが増えます。\nCHIPS:["運気の流れをくわしく","10年の流れも見る","向いている仕事は？"]'}]}}]})); }); return; }
  if(q.url.startsWith('/api/')){ r.writeHead(404); return r.end('{}'); } let f=path.join(__dirname,'fx',decodeURIComponent(q.url.split('?')[0])); if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':(f.endsWith('.png')?'image/png':'application/javascript')}); r.end(d); }); }).listen(0,async()=>{
  const b=await chromium.launch(); const pg=await b.newPage({viewport:{width:390,height:844},deviceScaleFactor:2}); const errs=[]; pg.on('pageerror',e=>errs.push(String(e))); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x).slice(0,300))); };
  await pg.addInitScript(()=>{ localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_mictip','1');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');
    localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1995,m:1,d:1,hh:12,tu:false,mi:0,sex:'female',place:'tokyo',plan:'pro'})); localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'こんにちは'}])); });
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(1500);
  const waitAi=async n=>{ for(let i=0;i<40;i++){ await pg.waitForTimeout(700); const s=await pg.evaluate(()=>({n:state.msgs.length,last:state.msgs[state.msgs.length-1].role,busy:_askBusy||_seqRunning})); if(s.n>=n&&s.last==='ai'&&!s.busy) return; } };
  const send=async q=>{ const n=await pg.evaluate(()=>state.msgs.length); await pg.fill('#askIn',q); await pg.click('#askBtn'); await waitAi(n+2); await pg.waitForTimeout(800); };
  await send('今年の運勢はどう？');
  const ap=await pg.evaluate(()=>[...document.querySelectorAll('#actionPills button')].map(b=>b.textContent));
  chk('返事のあと、押すだけで占えるボタンの行が出る（ラッキー・ピンポイント・過去・未来・つぶやき・話題を変えたい）',ap.length===6&&/ラッキー/.test(ap[0])&&/ピンポイント/.test(ap[1])&&/過去/.test(ap[2])&&/未来/.test(ap[3])&&/つぶやき/.test(ap[4])&&/話題を変えたい/.test(ap[5]),ap);
  chk('話題のボタン（6個）も今までどおり出る',(await pg.evaluate(()=>document.querySelectorAll('#topicChips button').length))===6);
  if(SHOT){ await pg.evaluate(()=>{ const x=document.getElementById('scroll'); x.scrollTop=x.scrollHeight; }); await pg.waitForTimeout(300); await pg.screenshot({path:SHOT+'_row.png'}); }
  // 🍀 今日のラッキー
  await pg.click('#actionPills [data-ap="lucky"]'); await pg.waitForTimeout(800);
  const lk=await pg.evaluate(()=>{ const c=document.querySelector('.lk-card'); return c?c.innerText:''; });
  chk('🍀 今日のラッキーのカードが出る（ラッキーカラー・ごはん・開運アクション・気をつけること）',/ラッキーカラー/.test(lk)&&/ラッキーごはん/.test(lk)&&/開運アクション/.test(lk),lk.slice(0,200));
  if(SHOT){ await pg.evaluate(()=>{ const x=document.getElementById('scroll'); x.scrollTop=x.scrollHeight; }); await pg.waitForTimeout(300); await pg.screenshot({path:SHOT+'_lucky.png'}); }
  // 🎯 ピンポイント占い
  await pg.evaluate(()=>openDaySheet()); await pg.waitForTimeout(500);
  chk('🎯 ピンポイント占いの画面が開く（日付・何のための日か）',await pg.evaluate(()=>document.getElementById('shDay').classList.contains('on')&&document.getElementById('dyPur').options.length>=10));
  if(SHOT) await pg.screenshot({path:SHOT+'_day.png'});
  bodies.length=0; let n=await pg.evaluate(()=>state.msgs.length); await pg.selectOption('#dyPur','wedding'); await pg.click('#dayRun'); await waitAi(n+2);
  chk('「この日を占う」で、計算した根拠（その日の吉凶・目的）を AI に渡して占う',bodies.some(x=>/PINPOINT DAY READING NOW/.test(x)&&/wedding/.test(x)),bodies.map(x=>x.slice(0,80)));
  // 🕰 過去を占う
  await pg.evaluate(()=>openPastSheet()); await pg.waitForTimeout(500); bodies.length=0; n=await pg.evaluate(()=>state.msgs.length); await pg.click('#pastRun'); await waitAi(n+2);
  chk('🕰 過去を占う：選んだ時期の根拠（大運・年運など）を AI に渡す',bodies.some(x=>/A LOOK BACK AT A PAST TIME/.test(x)));
  // 🔮 未来を占う
  await pg.evaluate(()=>openFutureSheet()); await pg.waitForTimeout(500); bodies.length=0; n=await pg.evaluate(()=>state.msgs.length); await pg.click('#futureRun'); await waitAi(n+2);
  chk('🔮 未来を占う：選んだ時期の根拠を AI に渡す',bodies.some(x=>/A LOOK AHEAD TO A FUTURE TIME/.test(x)));
  // 🦉 つぶやき
  bodies.length=0; n=await pg.evaluate(()=>state.msgs.length); await pg.evaluate(()=>nicoMuse()); await waitAi(n+2);
  const lastMe=await pg.evaluate(()=>state.msgs.filter(m=>m.role==='me').pop().text);
  chk('🦉 Nicoのつぶやき：テーマの種を渡して、Nico が語る（鑑定ではない）',bodies.some(x=>/NICO.S MUSING/.test(x))&&/つぶやき|一言|ひとこと/.test(lastMe),lastMe);
  const m1=await pg.evaluate(()=>window.localStorage.getItem('pk_muse')); await pg.evaluate(()=>nicoMuse()); await waitAi(0); const m2=await pg.evaluate(()=>window.localStorage.getItem('pk_muse'));
  chk('押すたびに次のテーマへ（156個を順番に）',m1!==m2&&await pg.evaluate(()=>MUSE_SEEDS.length)>=150,[m1,m2]);
  // 🔄 話題を変えたい
  await pg.evaluate(()=>_openTopicSwitch()); await pg.waitForTimeout(300);
  const sw=await pg.evaluate(()=>[...document.querySelectorAll('#topicSwitchMenu button')].map(b=>b.textContent));
  chk('🔄 話題を変えたい：恋愛・仕事・家族・お金・自分・これから・聞いてほしい のメニュー',sw.length>=7,sw);
  // 文で頼んだ時
  n=await pg.evaluate(()=>state.msgs.length); bodies.length=0; await pg.fill('#askIn','過去を占って'); await pg.click('#askBtn'); await pg.waitForTimeout(7000);
  chk('「過去を占って」と打つと、日付を選ぶボタンを出す（AI は呼ばない）',!!(await pg.$('#pastPillBtn'))&&!bodies.some(x=>!/x-pk-classify/.test(x)&&/過去を占って/.test(x)),{pill:!!(await pg.$('#pastPillBtn'))});
  chk('画面のエラーなし',errs.length===0,errs);
  await b.close(); srv.close(); console.log(ok+' OK / '+ng+' NG'); });
