// 実際の人に試してもらう版：招待リンクだけで使える・キーはブラウザに出ない・上限・記録（AIは偽物）
// 実行：node tester_relay.mjs（tests フォルダで。fx は setup.sh で作る）
import http from 'http'; import fs from 'fs'; import path from 'path'; import { fileURLToPath } from 'url'; import { createRequire } from 'module';
const require = createRequire(import.meta.url); const { chromium } = require('/opt/node22/lib/node_modules/playwright');
const D = path.dirname(fileURLToPath(import.meta.url));
const mem = new Map(); globalThis.__pkStore = { get: async (k) => mem.has(k) ? JSON.parse(mem.get(k)) : null, setJSON: async (k, v) => { mem.set(k, JSON.stringify(v)); } };
let calls = []; const realFetch = globalThis.fetch;
globalThis.fetch = async (u, o) => { if (String(u).startsWith('https://generativelanguage.googleapis.com/')) { calls.push({ u: String(u), body: o.body }); return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'テストの返事です。あなたは丁寧に物事を進める人です。' }] } }] }), { status: 200 }); } return realFetch(u, o); };
process.env.GEMINI_API_KEY = 'SERVER-SIDE-KEY-123'; process.env.PK_INVITES = 'abcd1234,zzzz9999'; process.env.PK_ADMIN = 'admin-secret-0123456789'; process.env.PK_LOG = '1'; process.env.PK_PER_DAY = '1000';
const relay = (await import(path.join(D, '..', 'tester', 'netlify', 'functions', 'relay.mjs'))).default;
let ok = 0, ng = 0; const chk = (n, c, x) => { c ? ok++ : ng++; console.log((c ? 'OK  ' : 'NG  ') + n + (c || x === undefined ? '' : ' → ' + JSON.stringify(x).slice(0, 300))); };
// 1) 中継だけ
const R = (h, q = 'm=gemini-3.1-flash-lite', body = '{"contents":[{"role":"user","parts":[{"text":"hi"}]}]}') => relay(new Request('http://x/api/relay?' + q, { method: 'POST', headers: h, body }));
chk('招待コードが無いと使えない', (await R({})).status === 401);
chk('違う招待コードは使えない', (await R({ 'x-pk-invite': 'nope0000' })).status === 401);
chk('知らないモデルは通さない', (await R({ 'x-pk-invite': 'abcd1234' }, 'm=gemini-ultra')).status === 400);
const r1 = await R({ 'x-pk-invite': 'abcd1234' }); chk('正しい招待コードなら AI の返事が返る', r1.status === 200 && /テストの返事/.test(await r1.text()));
chk('AI へはサーバーのキーで送る', calls.length && /key=SERVER-SIDE-KEY-123/.test(calls[calls.length - 1].u));
process.env.PK_PER_DAY = '2'; const rA = await R({ 'x-pk-invite': 'abcd1234' }), rB = await R({ 'x-pk-invite': 'abcd1234' }); chk('1人1日の上限を超えると 429（ほかの人は使える）', rA.status === 200 && rB.status === 429 && (await R({ 'x-pk-invite': 'zzzz9999' })).status === 200, [rA.status, rB.status]); process.env.PK_PER_DAY = '1000';
chk('記録の書き出しは合言葉が無いと見られない', (await relay(new Request('http://x/api/relay?admin=wrong', { method: 'GET' }))).status === 403);
// 2) ブラウザで：招待リンクを開くだけで会話できる
const srv = http.createServer(async (q, r) => {
  if (q.url.startsWith('/api/relay')) { let b = ''; q.on('data', c => b += c); q.on('end', async () => { const res = await relay(new Request('http://x' + q.url, { method: 'POST', headers: q.headers, body: b })); r.writeHead(res.status, { 'content-type': 'application/json' }); r.end(await res.text()); }); return; }
  if (q.url.startsWith('/api/')) { r.writeHead(404); return r.end('{}'); }
  let f = path.join(D, 'fx', decodeURIComponent(q.url.split('?')[0])); if (f.endsWith('/')) f += 'index.html';
  fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.html') ? 'text/html; charset=utf-8' : 'application/javascript' }); r.end(d); });
}).listen(0, async () => {
  const base = 'http://127.0.0.1:' + srv.address().port; const b = await chromium.launch(); const pg = await b.newPage(); const errs = []; pg.on('pageerror', e => errs.push(String(e)));
  const direct = []; await pg.route('**/*', rt => { const u = rt.request().url(); if (u.startsWith('https://generativelanguage.googleapis.com/')) { direct.push(u); return rt.abort(); } if (u.startsWith(base)) return rt.continue(); return rt.abort(); });
  await pg.addInitScript(() => { localStorage.setItem('pk_lang', 'ja'); localStorage.setItem('pk_svd', '1'); localStorage.setItem('pk_seen_lp', '1'); localStorage.setItem('pk_profile', JSON.stringify({ name: 'T', y: 1990, m: 4, d: 8, tu: false, hh: 12, mi: 0, sex: 'female', place: 'tokyo' })); localStorage.setItem('pk_msgs', JSON.stringify([{ role: 'ai', text: 'こんにちは' }])); });
  await pg.goto(base + '/index.html?invite=abcd1234'); await pg.waitForTimeout(1500);
  chk('リンクの招待コードを覚え、アドレスからは消す', (await pg.evaluate(() => localStorage.getItem('pk_invite'))) === 'abcd1234' && !/invite/.test(pg.url()), pg.url());
  chk('キーを貼る欄は出ない', !(await pg.$('#keyBar')));
  calls = []; const n0 = await pg.evaluate(() => state.msgs.length);
  await pg.fill('#askIn', '私の性格は？'); await pg.click('#askBtn');
  for (let i = 0; i < 60; i++) { await pg.waitForTimeout(1000); const s = await pg.evaluate(() => state.msgs.map(m => m.role)); if (s.length > n0 + 1 && s[s.length - 1] === 'ai') break; }
  await pg.waitForTimeout(6000);
  const last = await pg.evaluate(() => state.msgs.filter(m => m.role === 'ai').map(m => m.text).join(' '));
  chk('招待リンクだけで、Nico の返事が出る', /テストの返事/.test(last), last.slice(-120));
  chk('AI への呼び出しは全部、中継を通る（ブラウザから直接 Google に行かない）', direct.length === 0 && calls.length > 0, { direct: direct.length, relayed: calls.length });
  chk('ブラウザにサーバーのキーが出ない', !(await pg.content()).includes('SERVER-SIDE-KEY-123') && !(await pg.evaluate(() => JSON.stringify(localStorage))).includes('SERVER-SIDE-KEY-123'));
  chk('お試しの回数の表示は出ない（試す人は回数を気にせず使える）', !(await pg.evaluate(() => { const e = document.querySelector('#trialPill'); return !!(e && e.offsetParent); })));
  const ex = await relay(new Request('http://x/api/relay?admin=admin-secret-0123456789', { method: 'GET' })); const exj = await ex.json();
  chk('運営は合言葉で、その日の会話の記録を書き出せる', ex.status === 200 && exj.testers.abcd1234 && exj.testers.abcd1234.calls > 0, exj);
  chk('画面のエラーなし', errs.length === 0, errs);
  await b.close(); srv.close(); console.log(ok + ' OK / ' + ng + ' NG');
});
