// 軽い発言（あいさつ・雑談）への返事を、AI（上位モデル）で採点する。convo.js の結果ファイルが入ったフォルダを読む
//   node judge_light.js <結果フォルダ> <出力.json>     （GEMINI_KEY が必要）
// 見るもの：
//   chart     … 返事の中に、その人の命式（今日の流れ・今月の流れ・性質・運気の時期など）にもとづく理由が入っているか
//   invented  … ニコに天気・場所・時刻・五感があるかのような言い方（「こちらもいい天気」など）をしていないか
//   lang      … 指定の言語だけで書かれているか
//   invite    … （3回目の返事だけ）最近気になっていること・本題へやさしく誘う問いかけで終わっているか
const fs = require('fs'), path = require('path');
const { execFile } = require('child_process');
const KEY = (process.env.GEMINI_KEY || '').trim(); if (!KEY) { console.error('GEMINI_KEY'); process.exit(1); }
const DIR = process.argv[2], OUT = process.argv[3];
const LN = { ja: 'Japanese', en: 'English', zh: 'Simplified Chinese', zt: 'Traditional Chinese', ko: 'Korean', vi: 'Vietnamese', es: 'Spanish', pt: 'Portuguese', id: 'Indonesian', th: 'Thai' };
function post(body) { return new Promise((res) => { const p = execFile('curl', ['-s', '-m', '120', '-X', 'POST', '-H', 'Content-Type: application/json', '--data-binary', '@-', `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${KEY}`], { maxBuffer: 20e6 }, (e, out) => res(out || '')); p.stdin.end(body); }); }
async function judge(lang, q, a, turn) {
  const prompt = `You grade one reply from "Nico", a Four Pillars (BaZi) fortune-teller chat app. The user sent a light, casual message. Nico must still speak as a fortune teller: the reply should give at least one reason grounded in THE USER'S OWN CHART (e.g. today's or this month's energy flow for them, their inborn nature, their current luck period, elements) tied to what they said. Generic friendly chat with no chart-based reason does NOT count. Nico also has no body, weather, location or clock of her own, so phrases like "it's sunny here too" or "it's evening here" are invented.\n\nExpected language: ${LN[lang]}\nUser: ${q}\nNico: ${a}\n\nReturn JSON only: {"chart":true|false,"invented":true|false,"lang":true|false,"invite":true|false,"note":"<10 words>"} where invite = the reply ends with a gentle question inviting what has been on their mind lately (love, work, a decision, etc.).`;
  const body = JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0, responseMimeType: 'application/json', maxOutputTokens: 2000 } });
  for (let i = 0; i < 3; i++) { try { const d = JSON.parse(await post(body)); const t = d.candidates[0].content.parts.map(p => p.text || '').join(''); return JSON.parse(t); } catch (e) { } }
  return null;
}
(async () => {
  const files = fs.readdirSync(DIR).filter(f => f.endsWith('.json'));
  const rows = [];
  for (const f of files) {
    const d = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
    const model = f.split('__')[0], lang = d.C.lang;
    // 発言ごとに、そのあとのニコの返事（複数の吹き出し）をまとめる
    const turns = []; let cur = null;
    for (const m of d.msgs) { if (m.role === 'me') { cur = { q: m.text, a: [] }; turns.push(cur); } else if (cur) cur.a.push(m.text); }
    const jobs = turns.map((t, i) => judge(lang, t.q, t.a.join('\n'), i + 1).then(r => rows.push({ model, lang, file: f, turn: i + 1, q: t.q, a: t.a.join(' / '), r })));
    await Promise.all(jobs);
    // 使用量（トークン数）
    rows.push({ model, lang, file: f, usage: d.calls || [] });
    process.stdout.write('.');
  }
  fs.writeFileSync(OUT, JSON.stringify(rows, null, 1));
  console.log('\nsaved', OUT);
})();
