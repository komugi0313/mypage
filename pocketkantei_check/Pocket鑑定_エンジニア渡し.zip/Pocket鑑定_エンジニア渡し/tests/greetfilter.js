// 今日のひとこと（運営指摘 2026-11-02）：ありきたりな助言（紙に書き出す・お茶・ゆっくり過ごして）や、まだ話していないのに「話してくれてありがとう」が来たら、一度作り直し、だめなら出さない
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{ let f=path.join(__dirname,'fx',q.url.split('?')[0]); fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
 const b=await chromium.launch(); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
 const base='http://127.0.0.1:'+srv.address().port;
 const run=async(replies)=>{ const pg=await b.newPage(); let n=0; await pg.route('https://generativelanguage.googleapis.com/**',r=>{ const t=replies[Math.min(n,replies.length-1)]; n++; r.fulfill({status:200,contentType:'application/json',body:JSON.stringify({candidates:[{content:{parts:[{text:t}]}}]})}); });
   await pg.addInitScript(()=>{ localStorage.setItem('pk_lang','ja'); localStorage.setItem('pk_key','test-dummy-key'); localStorage.setItem('pk_dev','1'); localStorage.setItem('pk_svd','1'); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1996,m:1,d:1,hh:12,tu:false,mi:0,sex:'female',place:'tokyo'})); localStorage.setItem('pk_msgs','[{"role":"ai","text":"hi"}]'); });
   await pg.goto(base+'/index.html'); await pg.waitForTimeout(1200); n=0; const t=await pg.evaluate(()=>_dailyGreetAI()); await pg.close(); return {t,n}; };
 let r=await run(['こんばんは。昨夜は眠れましたか？']); chk('ふつうの一言はそのまま使う（呼び出し1回）',r.t==='こんばんは。昨夜は眠れましたか？'&&r.n===1,r);
 r=await run(['おはようございます。今の気持ちを紙に書き出してみませんか。','おはようございます。あれから少しは眠れましたか？']); chk('「紙に書き出す」が来たら作り直して、良い方を使う',r.t==='おはようございます。あれから少しは眠れましたか？'&&r.n===2,r);
 r=await run(['お話してくださってありがとうございます。','こんばんは。温かい飲み物でも飲んでゆっくり過ごしてくださいね。']); chk('2回ともだめなら出さない',r.t===''&&r.n===2,r);
 console.log(ok+' OK / '+ng+' NG'); await b.close(); srv.close(); });
