// ウェブ版（テレコムクレジット）の申し込み〜更新〜解約の流れ（テスト用の通知の形。本物の形は telecom-connect.js に書く）
// 準備：./setup.sh。実行：PK_STORE=memory NODE_PATH=mock/node_modules node telecomtest.js
process.env.AUTH_SECRET = 'test-secret-0123456789abcdef';
process.env.PK_TELECOM_TEST = '1'; process.env.PK_TELECOM_CANCEL_READY = '1';
process.env.TELECOM_WEBHOOK_SECRET = 'tc-secret-0123456789abcdef';
process.env.TELECOM_CHECKOUT_URLS = JSON.stringify({ std_m: 'https://pay.example/?u={uid}&trial={trial}', pro_y: 'https://pay.example/?u={uid}&trial={trial}' });
const auth = require('./fx/functions/auth.js').handler, tc = require('./fx/functions/telecom.js'), G = require('./fx/functions/gemini.js')._t;
const post = (body) => auth({ httpMethod: 'POST', headers: {}, body: JSON.stringify(body) }).then(o => ({ s: o.statusCode, j: JSON.parse(o.body) }));
const notify = (evs, k = process.env.TELECOM_WEBHOOK_SECRET) => tc.handler({ httpMethod: 'POST', headers: {}, query: { k }, body: JSON.stringify({ events: evs }) });
let ng = 0; const ok = (c, m, x) => { console.log((c ? 'OK ' : 'NG ') + m + (c || x === undefined ? '' : ' → ' + JSON.stringify(x))); if (!c) ng++; };
const acc = () => require('./fx/functions/store.js').getStore('pk-accounts');
(async () => {
  const r = await post({ action: 'register', email: 'w@example.com', password: 'sakura2026', data: {}, lang: 'ja' }); const tok = r.j.token, uid = tok.split('.')[0];
  const co = await post({ action: 'checkout', token: tok, plan: 'std', period: 'm', lang: 'ja' });
  ok(co.j.ok && /trial=1/.test(co.j.url), 'はじめての人：お試しつきの決済画面へ', co.j);

  ok((await notify([{ kind: 'start', uid, planKey: 'std_m', telecomId: 'T1', eventId: 'e1' }], 'wrong-key-0000000000')).statusCode === 401, '合言葉が違う通知は受け付けない');
  const n1 = await notify([{ kind: 'start', uid, planKey: 'std_m', telecomId: 'T1', eventId: 'e1' }]);
  ok(n1.statusCode === 200 && n1.body === 'OK', '申し込みの通知を受け付ける');
  let rec = await acc().get('u:' + uid, { type: 'json' });
  ok(rec.sub && rec.sub.plan === 'std' && rec.sub.trial === true && rec.sub.store === 'TELECOM' && rec.hadTrial === true, 'お試し中の Standard になる', rec.sub);
  ok(Math.round((rec.sub.expires - Date.now()) / 864e5) === 3, 'お試しは3日間');
  ok(await G.accountPlan({}, tok) === 'std', 'チャットでも Standard として数える');

  await notify([{ kind: 'start', uid, planKey: 'std_m', telecomId: 'T1', eventId: 'e1' }]);
  const rec1b = await acc().get('u:' + uid, { type: 'json' });
  ok(rec1b.sub.start === rec.sub.start, '同じ通知が2回来ても、1回分だけ');

  const dup = await post({ action: 'checkout', token: tok, plan: 'pro', period: 'y', lang: 'ja' });
  ok(dup.j.code === 'HAS_PLAN', 'お試し中・有料の人は、もう一度買えない（二重の支払いを防ぐ）', dup.j);

  // お試し中に解約 → 継続課金を止め、期限まで使える・メールが出る
  global.__tcStops = [];
  const cx = await post({ action: 'cancel', token: tok, lang: 'ja' });
  ok(cx.j.ok && cx.j.plan.willRenew === false && cx.j.plan.plan === 'std', 'お試し中の解約：期限まで使える・自動更新なし', cx.j);
  ok(global.__tcStops.includes('T1'), '決済会社の継続課金を止める（telecomId で）', global.__tcStops);

  // 解約したのに請求の通知が来た → もう一度止め、運営への印を残す
  global.__tcStops = [];
  rec = await acc().get('u:' + uid, { type: 'json' });
  await notify([{ kind: 'renew', uid, telecomId: 'T1', eventId: 'e2', at: rec.sub.expires }]);
  rec = await acc().get('u:' + uid, { type: 'json' });
  ok(rec.billAlert && rec.billAlert.kind === 'charged_after_cancel' && global.__tcStops.includes('T1'), '解約後の請求：もう一度止めて、運営への印を残す', rec.billAlert);
  ok(rec.sub.trial === false && rec.sub.willRenew === false && rec.sub.expires > Date.now() + 25 * 864e5, '払った分の期間は使える（自動更新はなし）', rec.sub);

  // 別の人：お試しを使ったことがある → お試しなし・更新で期間がのびる・返金で止まる
  const r2 = await post({ action: 'register', email: 'w2@example.com', password: 'sakura2026', data: {} }); const tok2 = r2.j.token, uid2 = tok2.split('.')[0];
  const A = acc(); const x = await A.get('u:' + uid2, { type: 'json' }); x.hadTrial = true; await A.setJSON('u:' + uid2, x);
  const co2 = await post({ action: 'checkout', token: tok2, plan: 'std', period: 'm' });
  ok(/trial=0/.test(co2.j.url), 'お試しを使ったことがある人：お試しなし', co2.j);
  await notify([{ kind: 'start', uid: uid2, planKey: 'std_m', telecomId: 'T2', eventId: 'f1' }]);
  let r2s = (await A.get('u:' + uid2, { type: 'json' })).sub;
  ok(r2s.trial === false && Math.round((r2s.expires - Date.now()) / 864e5) >= 28, 'お試しなしで、すぐ1か月', r2s);
  const e0 = r2s.expires;
  await notify([{ kind: 'renew', uid: uid2, telecomId: 'T2', eventId: 'f2', at: e0 }]);
  r2s = (await A.get('u:' + uid2, { type: 'json' })).sub;
  ok(r2s.start === e0 && r2s.expires > e0 + 27 * 864e5, '継続課金の成功：前の期間の終わりから、次の1か月', r2s);
  await notify([{ kind: 'fail', uid: uid2, telecomId: 'T2', eventId: 'f3' }]);
  ok((await A.get('u:' + uid2, { type: 'json' })).sub.expires === r2s.expires, '継続課金の失敗：何も変えない（期限で無料に戻る）');
  // 古い継続課金が残ったまま新しい申し込みが届いた → 古い方を止める
  global.__tcStops = [];
  await notify([{ kind: 'start', uid: uid2, planKey: 'pro_y', telecomId: 'T3', eventId: 'f4' }]);
  r2s = (await A.get('u:' + uid2, { type: 'json' })).sub;
  ok(r2s.plan === 'pro' && r2s.period === 'y' && global.__tcStops.includes('T2'), '新しい継続課金が来たら、古い方を必ず止める（二重請求を防ぐ）', { sub: r2s, stops: global.__tcStops });
  await notify([{ kind: 'refund', uid: uid2, telecomId: 'T3', eventId: 'f5' }]);
  ok(await G.accountPlan({}, tok2) === 'free', '返金・取り消し：その場で無料に戻る');

  // 解約が決済会社で失敗 → 解約したことにしない
  const r3 = await post({ action: 'register', email: 'w3@example.com', password: 'sakura2026', data: {} }); const tok3 = r3.j.token, uid3 = tok3.split('.')[0];
  await notify([{ kind: 'start', uid: uid3, planKey: 'std_m', telecomId: 'T9', eventId: 'g1' }]);
  global.__tcStopFail = true;
  const cf = await post({ action: 'cancel', token: tok3 });
  global.__tcStopFail = false;
  ok(!cf.j.ok && (await A.get('u:' + uid3, { type: 'json' })).sub.willRenew === true, '決済会社で止められなかった時は、解約したことにしない（画面に失敗を出す）', cf.j);

  // 退会した人の請求の通知 → 継続課金を止める
  global.__tcStops = [];
  await notify([{ kind: 'renew', uid: 'f'.repeat(64), telecomId: 'T404', eventId: 'h1' }]);
  ok(global.__tcStops.includes('T404'), 'アカウントが無い人（退会済み）への請求は止める');

  // ウェブの購読中に削除（確かめた上で）→ 継続課金を止めてから消す
  global.__tcStops = [];
  const dl = await post({ action: 'delete', token: tok3, password: 'sakura2026', force: true });
  ok(dl.j.ok && global.__tcStops.includes('T9'), 'ウェブの購読中に削除：先に継続課金を止める', { dl: dl.j, stops: global.__tcStops });
  console.log(ng ? ('NG ' + ng) : 'ALL OK');
})();
