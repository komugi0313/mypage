/* 墓庫開冲の年の確認（無料・計算だけ）
   ・命式の辰戌丑未が、年運・大運の冲（辰戌・丑未）で開く年を、別の計算と照らし合わせる
   ・庫が開くのは、その年に土（辰戌丑未）が巡ってきた時だけ。大運だけでは10年ずっと開いたことにしない
   ・大運との冲（その年の地支×大運の地支）でも、両方の庫が開く／命式の庫とその年が冲なら、その年の庫も開く
   ・刑（丑戌未）では開かない
   node kotest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const R=await pg.evaluate(()=>{ const out={cases:[],bad:[],stats:{charts:0,openYears:0,keiOnly:0,natal:0,danger:0,lucky:0}};
    const CL={辰:'戌',戌:'辰',丑:'未',未:'丑'}, EL={辰:'水',戌:'火',丑:'金',未:'木'}, KEI={丑:['戌','未'],戌:['丑','未'],未:['丑','戌']};
    for(let y=1950;y<=2010;y+=1){ for(const [m,d,hh] of [[1,15,3],[4,8,9],[7,22,15],[10,3,21]]){
      const A=computeChart({name:'x',y,m,d,tu:false,hh,mi:0,sex:(y%2?'female':'male'),place:''}); state.chart=A; state.profile={sex:'female'};
      const M=luckMap(); if(!M){ out.bad.push(['null',y,m,d]); continue; } out.stats.charts++;
      const P=A.pro.pillars, brs=P.map(p=>p.branch);
      if(M.natalOpen.length) out.stats.natal++;
      M.years.forEach(Y=>{ const br=Y.gz.charAt(1);
        const dd=(A.pro.decadeFortunes||[]).find(d=>d&&d.ganzhi&&Y.year>=d.startYear&&Y.year<d.startYear+10), dB=dd?dd.ganzhi.charAt(1):'';
        const nat=brs.filter(x=>CL[x]===br||(dB&&CL[x]===dB&&EL[br])), natEl=nat.map(x=>EL[x]);   /* 命式の庫：その年と冲、または大運と冲で、その年に土が来た時 */
        const extra=[]; if(brs.some(x=>CL[x]===br)&&!natEl.includes(EL[br])) extra.push(br);   /* 命式の庫と冲なら、その年の庫も開く */
        const decOpen=extra.slice(); if(dB&&CL[dB]===br) [dB,br].forEach(x=>{ if(!natEl.includes(EL[x])&&!decOpen.some(y=>EL[y]===EL[x])) decOpen.push(x); });   /* 大運との冲：大運と年の両方の庫が開く */
        if(Y.tags.some(t=>/storage/.test(t))&&!EL[br]) out.bad.push(['opened-without-earth',y,Y.year,Y.gz]);
        if(decOpen.length) out.stats.decOpen=(out.stats.decOpen||0)+1;
        const exp=nat.length+decOpen.length;           /* 開くはずの庫の数 */
        const got=Y.tags.filter(t=>/storage/.test(t)).length;
        if(exp!==got) out.bad.push(['count',y,m,d,Y.year,Y.gz,brs.join(''),exp,got]);
        /* 開いた庫の五行が正しい */
        Y.tags.filter(t=>/storage/.test(t)).forEach(t=>{ const e=(t.match(/opens the (.) storage/)||[])[1]; if(!nat.some(x=>EL[x]===e)&&!decOpen.some(x=>EL[x]===e)) out.bad.push(['el',y,Y.year,t]); });
        /* 刑だけ（冲なし）の年は開かない */
        const kei=(brs.concat(dB?[dB]:[])).some(x=>KEI[x]&&KEI[x].includes(br)) && !exp; if(kei){ out.stats.keiOnly++; if(got) out.bad.push(['kei-opened',y,Y.year,Y.gz,brs.join('')]); }
        if(exp) out.stats.openYears++; if(Y.v==='DANGER') out.stats.danger++; if(Y.v==='LUCKY') out.stats.lucky++;
        /* LUCKY は「よい開き」があるときだけ。BUILD は庫が理由ではない */
        if(Y.v==='LUCKY'&&!Y.tags.some(t=>/GOOD opening/.test(t))) out.bad.push(['lucky-no-good',y,Y.year]);
      });
      if(out.cases.length<400) out.cases.push({b:[y,m,d,hh],pill:P.map(p=>p.stem+p.branch).join(' '),kos:M.kos,natal:M.natalOpen,yrs:M.years.filter(Y=>Y.tags.length).map(Y=>Y.year+Y.gz+'='+Y.v+' '+Y.tags.map(t=>t.slice(0,60)).join(' / '))});
    } }
    /* 1981年6月10日22時：日支 未（木の庫＝官殺）。2033 癸丑で開く */
    const H=computeChart({name:'花子',y:1981,m:6,d:10,tu:false,hh:22,mi:0,sex:'female',place:''}); state.chart=H; out.hana=luckMap(); out.hanaBlock=luckMapBlock(); out.hanaMoney=moneyNote(); state.chart=computeChart({name:'健',y:1976,m:1,d:15,tu:false,hh:3,mi:0,sex:'male',place:''}); out.kenMoney=moneyNote(); out.kenDec=luckMap().decades;
    return out; });
  fs.writeFileSync('kotest.out.json',JSON.stringify(R,null,1));
  console.log(JSON.stringify(R.stats), 'bad:',R.bad.length, JSON.stringify(R.bad.slice(0,8)));
  chk('調べた命式が200以上',R.stats.charts>=200,R.stats.charts);
  chk('開く庫の数・五行が全部合う（冲だけで開く）',R.bad.filter(x=>x[0]==='count'||x[0]==='el').length===0);
  chk('刑だけの年は開かない',R.stats.keiOnly>0&&!R.bad.some(x=>x[0]==='kei-opened'),R.stats.keiOnly);
  chk('大運との冲で開く年も出てくる',R.stats.decOpen>0,R.stats.decOpen);
  chk('金運：お金の年の一覧を渡す',/MONEY YEARS in the next 10 years/.test(R.hanaMoney),R.hanaMoney);
  chk('金運：大運との冲でお金の庫が開く年（1976年1月15日 2033年）も、お金の年に入る',/2033: the money storage opens/.test(R.kenMoney),R.kenMoney);
  chk('大運だけでは10年ずっと開いたことにしない（MONEY DECADE なし・大運は LUCKY にならない）',!/MONEY DECADE/.test(R.kenMoney)&&R.kenDec.every(d=>d.v!=='LUCKY'),R.kenDec);
  chk('庫が開くのは、その年に土（辰戌丑未）が来た時だけ',!R.bad.some(x=>x[0]==='opened-without-earth'));
  chk('LUCKY はよい開きのある年だけ',!R.bad.some(x=>x[0]==='lucky-no-good'));
  chk('LUCKY・DANGER の年がどちらも出てくる',R.stats.lucky>0&&R.stats.danger>0,R.stats);
  const h2033=R.hana.years.find(Y=>Y.year===2033); chk('花子さん：2033年 癸丑で日柱の未（木の庫）が開く',h2033&&/opens the 木 storage in the 日柱/.test(h2033.tags.join(' ')),h2033);
  const h2027=R.hana.years.find(Y=>Y.year===2027); chk('花子さん：2027年 丁未は刑・同じ支で、開かない',h2027&&!h2027.tags.some(t=>/storage/.test(t)),h2027);
  chk('指示に専門用語を出さない一文',/never output 墓庫\/開冲/.test(R.hanaBlock));
  console.log(R.hanaBlock); console.log(R.hanaMoney);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
