/* 墓庫開冲の確認（無料・計算だけ）。教室資料の決まりと照らし合わせる
   ・墓と冠帯の冲で開く。命式・大運・年運のどの組み合わせでも巡ってくる（命式に墓がなくても、運で墓が来て冠帯と冲すれば開く）
     丑⇔未グループの日干＝甲丁己庚癸（墓：甲癸＝未、丁己庚＝丑）／戌⇔辰グループ＝乙丙戊辛壬（墓：乙丙戊＝戌、辛壬＝辰）
   ・冲された支の通変星（司令の蔵干だけで見る）が財星なら、お金（臨時収入）
   ・大運で開く＝その10年は機運が上昇中。大きく出てくるのは年に土が巡った年。刑では開かない
   node kotest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const R=await pg.evaluate(()=>{ const out={bad:[],stats:{charts:0,withBo:0,yearOpen:0,decRising:0,earthOpen:0,keiOnly:0,money:0}};
    const BO={甲:'未',癸:'未',丁:'丑',己:'丑',庚:'丑',乙:'戌',丙:'戌',戊:'戌',辛:'辰',壬:'辰'}, CL={辰:'戌',戌:'辰',丑:'未',未:'丑'}, EARTH='辰戌丑未', KEI={丑:['戌','未'],戌:['丑','未'],未:['丑','戌']};
    for(let y=1950;y<=2010;y++){ for(const [m,d,hh] of [[1,15,3],[4,8,9],[7,22,15],[10,3,21]]){
      const A=computeChart({name:'x',y,m,d,tu:false,hh,mi:0,sex:(y%2?'female':'male'),place:''}); state.chart=A; state.profile={sex:'female'};
      const M=luckMap(); if(!M){ out.bad.push(['null',y]); continue; } out.stats.charts++;
      const P=A.pro.pillars, dm=P[2].stem, bo=BO[dm], kan=CL[bo];
      /* 蔵干は司令だけ：各柱の蔵干は1つ（司令）、割合なし。大運・年運にも司令がある */
      P.forEach(p=>{ if(!p.hiddenStems||p.hiddenStems.length!==1||!p.hiddenStems[0].ling||p.hiddenStems[0].pct!=null) out.bad.push(['sirei',y,m,d,p.branch,JSON.stringify(p.hiddenStems)]); });
      (A.pro.annualFortunes||[]).slice(0,3).concat(A.pro.decadeFortunes||[]).forEach(x=>{ if(x&&x.branch&&(!x.sirei||x.sirei!==window.sireiStem(x.branch,A.pro.birth.setsuMin))) out.bad.push(['luck-sirei',y,x.ganzhi,x.sirei]); });
      /* 十二運の墓・冠帯が資料の表と一致（命式・大運・年運） */
      P.forEach(p=>{ if((p.terrain==='墓')!==(p.branch===bo)||(p.terrain==='冠帯')!==(p.branch===kan)) out.bad.push(['terrain',y,m,d,dm,p.branch,p.terrain]); });
      const nb=P.filter(p=>p.branch===bo).length, nk=P.filter(p=>p.branch===kan).length; if(nb) out.stats.withBo++;
      M.decades.forEach(D=>{ const b2=D.gz.charAt(1), rising=D.tags.filter(t=>/^RISING/.test(t)).length, exp=(b2===kan?nb:0)+(b2===bo?nk:0); if(rising!==exp) out.bad.push(['dec',y,m,d,D.gz,rising,exp]); if(rising){ out.stats.decRising++; if(!['LUCKY','CAUTION','DANGER'].includes(D.v)) out.bad.push(['dec-label',y,D.gz,D.v]); } });
      M.years.forEach(Y=>{ const br=Y.gz.charAt(1), Dd=(A.pro.decadeFortunes||[]).find(x=>x&&x.ganzhi&&Y.year>=x.startYear&&Y.year<x.startYear+10), dB=Dd?Dd.ganzhi.charAt(1):'';
        const got=Y.tags.filter(t=>/opens the storage/.test(t)).length;
        const pair=(br===kan?nb+(dB===bo?1:0):0)+(br===bo?nk+(dB===kan?1:0):0);          /* その年が冠帯→命式・大運の墓、その年が墓→命式・大運の冠帯 */
        const risingN=(dB===kan?nb:0)+(dB===bo?nk:0), exp=pair||((EARTH.includes(br))?risingN:0);
        if(got!==exp) out.bad.push(['year',y,m,d,dm,Y.year,Y.gz,dB,exp,got]);
        if(pair) out.stats.yearOpen++; if(!pair&&exp) out.stats.earthOpen++; if(pair&&!nb) out.stats.noNatalBo=(out.stats.noNatalBo||0)+1;
        if(got&&!EARTH.includes(br)) out.bad.push(['no-earth',y,Y.year]);
        if(!exp&&KEI[br]&&P.concat([{branch:dB}]).some(p=>KEI[br].includes(p.branch))){ out.stats.keiOnly++; if(got) out.bad.push(['kei',y,Y.year]); }
        if(Y.tags.some(t=>/opens the storage/.test(t)&&/[(; ]財:/.test(t))) out.stats.money++;
      });
    } }
    /* 1981年6月10日22時：日干 己 → 墓は丑、冠帯は未（日柱）。2033 癸丑で開く */
    state.chart=computeChart({name:'花子',y:1981,m:6,d:10,tu:false,hh:22,mi:0,sex:'female',place:''}); out.hana=luckMap(); out.hanaBlock=luckMapBlock(); out.hanaMoney=moneyNote();
    return out; });
  fs.writeFileSync('kotest.out.json',JSON.stringify(R,null,1));
  console.log(JSON.stringify(R.stats),'bad:',R.bad.length,JSON.stringify(R.bad.slice(0,8)));
  chk('蔵干は司令だけ（各柱1つ・割合なし・大運と年運にも司令）',!R.bad.some(x=>x[0]==='sirei'||x[0]==='luck-sirei'),R.bad.filter(x=>/sirei/.test(x[0])).slice(0,3));
  chk('調べた命式が200以上',R.stats.charts>=200,R.stats.charts);
  chk('十二運の「墓」が資料の表（丑未・戌辰グループ）と一致',!R.bad.some(x=>x[0]==='terrain'));
  chk('大運で冠帯が冲 → その10年は機運が上昇中（LUCKY）',R.stats.decRising>0&&!R.bad.some(x=>x[0]==='dec'||x[0]==='dec-label'));
  chk('年運で冠帯が冲 → その年に開く',R.stats.yearOpen>0&&!R.bad.some(x=>x[0]==='year'));
  chk('上昇中の大運では、年に土が巡った年に大きく開く',R.stats.earthOpen>0);
  chk('土の年以外で開かない',!R.bad.some(x=>x[0]==='no-earth'));
  chk('刑だけでは開かない',R.stats.keiOnly>0&&!R.bad.some(x=>x[0]==='kei'),R.stats.keiOnly);
  chk('財星のときはお金（臨時収入）として出る',R.stats.money>0);
  chk('命式に墓がなくても、運で墓と冠帯がそろえば開く',R.stats.noNatalBo>0,R.stats);
  const h33=R.hana.years.find(Y=>Y.year===2033); chk('花子さん（己・墓＝丑）：2033年 癸丑（墓）が日柱の未（冠帯）と冲で開く・丑の司令（出生の節入りから4日18時間 → 癸）＝偏財でお金も出る',h33&&h33.tags.some(t=>/opens the storage/.test(t)&&/財:/.test(t)),h33);
  const h27=R.hana.years.find(Y=>Y.year===2027); chk('花子さん：2027年 丁未は冠帯どうしで開かない',h27&&!h27.tags.some(t=>/opens the storage/.test(t)),h27);
  chk('指示に専門用語を出さない一文',/never output 墓庫\/開冲/.test(R.hanaBlock));
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
