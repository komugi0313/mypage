/* 墓庫開冲の確認（無料・計算だけ）。教室資料の決まりと照らし合わせる
   ・命式の十二運に【墓】があり、大運・年運で【冠帯】が冲で巡ってくると開く
     丑⇔未グループの日干＝甲丁己庚癸（墓：甲癸＝未、丁己庚＝丑）／戌⇔辰グループ＝乙丙戊辛壬（墓：乙丙戊＝戌、辛壬＝辰）
   ・冲された支の通変星が財星なら、お金（臨時収入）
   ・大運で開く＝その10年は機運が上昇中。大きく出てくるのは年に土が巡った年。刑では開かない
   node kotest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const R=await pg.evaluate(()=>{ const out={bad:[],stats:{charts:0,withBo:0,yearOpen:0,decRising:0,earthOpen:0,keiOnly:0,money:0}};
    const BO={甲:'未',癸:'未',丁:'丑',己:'丑',庚:'丑',乙:'戌',丙:'戌',戊:'戌',辛:'辰',壬:'辰'}, CL={辰:'戌',戌:'辰',丑:'未',未:'丑'}, EARTH='辰戌丑未', KEI={丑:['戌','未'],戌:['丑','未'],未:['丑','戌']};
    for(let y=1950;y<=2010;y++){ for(const [m,d,hh] of [[1,15,3],[4,8,9],[7,22,15],[10,3,21]]){
      const A=computeChart({name:'x',y,m,d,tu:false,hh,mi:0,sex:(y%2?'female':'male'),place:''}); state.chart=A; state.profile={sex:'female'};
      const M=luckMap(); if(!M){ out.bad.push(['null',y]); continue; } out.stats.charts++;
      const P=A.pro.pillars, dm=P[2].stem, bo=BO[dm], kan=CL[bo], nBo=P.filter(p=>p.branch===bo).length;
      /* 十二運の墓が資料の表と一致 */
      P.forEach(p=>{ if((p.terrain==='墓')!==(p.branch===bo)) out.bad.push(['terrain',y,m,d,dm,p.branch,p.terrain]); });
      if(nBo) out.stats.withBo++;
      M.decades.forEach(D=>{ const rising=D.tags.some(t=>/^RISING/.test(t)), exp=nBo>0&&D.gz.charAt(1)===kan; if(rising!==exp) out.bad.push(['dec',y,m,d,D.gz,rising,exp]); if(rising){ out.stats.decRising++; if(D.v!=='LUCKY'&&D.v!=='CAUTION'&&D.v!=='DANGER') out.bad.push(['dec-label',y,D.gz,D.v]); } });
      M.years.forEach(Y=>{ const br=Y.gz.charAt(1), Dd=(A.pro.decadeFortunes||[]).find(x=>x&&x.ganzhi&&Y.year>=x.startYear&&Y.year<x.startYear+10), dB=Dd?Dd.ganzhi.charAt(1):'';
        const got=Y.tags.filter(t=>/opens the storage/.test(t)).length;
        const byYear=(nBo&&br===kan)?nBo:0, byDec=(nBo&&dB===kan&&EARTH.includes(br)&&br!==kan)?nBo:0, exp=byYear+byDec;
        if(got!==exp) out.bad.push(['year',y,m,d,dm,Y.year,Y.gz,dB,exp,got]);
        if(byYear) out.stats.yearOpen++; if(byDec) out.stats.earthOpen++;
        if(got&&!EARTH.includes(br)) out.bad.push(['no-earth',y,Y.year]);
        if(!exp&&nBo&&KEI[bo]&&KEI[bo].includes(br)&&dB!==kan){ out.stats.keiOnly++; if(got) out.bad.push(['kei',y,Y.year]); }
        if(Y.tags.some(t=>/opens the storage/.test(t)&&/[(; ]財:/.test(t))) out.stats.money++;
      });
    } }
    /* 1981年6月10日22時：日干 己 → 墓は丑。命式に丑なし → 墓庫開冲なし */
    state.chart=computeChart({name:'花子',y:1981,m:6,d:10,tu:false,hh:22,mi:0,sex:'female',place:''}); out.hana=luckMap(); out.hanaBlock=luckMapBlock(); out.hanaMoney=moneyNote();
    return out; });
  fs.writeFileSync('kotest.out.json',JSON.stringify(R,null,1));
  console.log(JSON.stringify(R.stats),'bad:',R.bad.length,JSON.stringify(R.bad.slice(0,8)));
  chk('調べた命式が200以上',R.stats.charts>=200,R.stats.charts);
  chk('十二運の「墓」が資料の表（丑未・戌辰グループ）と一致',!R.bad.some(x=>x[0]==='terrain'));
  chk('大運で冠帯が冲 → その10年は機運が上昇中（LUCKY）',R.stats.decRising>0&&!R.bad.some(x=>x[0]==='dec'||x[0]==='dec-label'));
  chk('年運で冠帯が冲 → その年に開く',R.stats.yearOpen>0&&!R.bad.some(x=>x[0]==='year'));
  chk('上昇中の大運では、年に土が巡った年に大きく開く',R.stats.earthOpen>0);
  chk('土の年以外で開かない',!R.bad.some(x=>x[0]==='no-earth'));
  chk('刑だけでは開かない',R.stats.keiOnly>0&&!R.bad.some(x=>x[0]==='kei'),R.stats.keiOnly);
  chk('財星のときはお金（臨時収入）として出る',R.stats.money>0);
  chk('花子さん（己・命式に丑なし）は墓庫開冲なし',/none — 墓庫開冲 does not apply/.test(R.hanaBlock)&&!R.hana.years.some(Y=>Y.tags.some(t=>/opens the storage/.test(t))));
  chk('指示に専門用語を出さない一文',/never output 墓庫\/開冲/.test(R.hanaBlock));
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
