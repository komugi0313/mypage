// 英語・韓国語・繁体字を本物の AI で試して見つけた3つ（運営指摘 2026-11-03）：繁体字の「なぜ」・「流年」の置き換え・片思いの恋愛ボタン
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{ let f=path.join(__dirname,'fx',q.url.split('?')[0]); fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
 const b=await chromium.launch(); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
 const page=async(lang)=>{ const pg=await b.newPage(); await pg.addInitScript(l=>{localStorage.setItem('pk_lang',l);localStorage.setItem('pk_svd','1');localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1994,m:9,d:8,hh:21,tu:false,mi:0,sex:'female',place:'tokyo'}));localStorage.setItem('pk_msgs','[{"role":"ai","text":"hi"}]');},lang); await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(1300); return pg; };
 let pg=await page('zt');
 let r=await pg.evaluate(()=>['為什麼這樣說？','為什麼？','根據是什麼？','為什麼這麼說'].map(q=>[q,RE_THEORY.test(q)]));
 chk('繁体字の「なぜ？」を見分ける',r.every(x=>x[1]),r);
 r=await pg.evaluate(()=>['我們會順利嗎？','什麼時候可能在一起？','為什麼不能在一起'].map(q=>[q,RE_THEORY.test(q)]));
 chk('ふつうの質問は「なぜ」にしない',r.every(x=>!x[1]),r);
 r=await pg.evaluate(()=>_softenJargon('這兩年流年的氣場，流年的氣氛剛好，今年年運很好'));
 chk('繁体字：「流年」「年運」は置き換えない（文がこわれない）',r==='這兩年流年的氣場，流年的氣氛剛好，今年年運很好',r);
 r=await pg.evaluate(()=>['我在公司暗戀一個人','我喜歡上同事了'].map(q=>[q,_chipTopicOf(q)]));
 chk('繁体字：「暗戀」「喜歡上」は恋愛の話題',r.every(x=>x[1]==='love'),r);
 r=await pg.evaluate(()=>_softenJargon('2027年起進入下一個大運。'));
 chk('繁体字：「下一個大運」が「下一個目前…」にならない',!/目前/.test(r)&&/下一個/.test(r),r);
 await pg.close(); pg=await page('ko');
 r=await pg.evaluate(()=>['직장에 짝사랑하는 사람이 있어요','썸 타는 사람이 있어요'].map(q=>[q,_chipTopicOf(q)]));
 chk('韓国語：「짝사랑」（職場でも）は恋愛の話題',r.every(x=>x[1]==='love'),r);
 r=await pg.evaluate(()=>_chipTopicOf('직장 상사가 힘들어요'));
 chk('韓国語：職場の悩みは今まで通り仕事の話題',r==='work',r);
 r=await pg.evaluate(()=>_softenJargon('2027년부터 다음 대운으로 바뀌어요.'));
 chk('韓国語：「다음 대운」が「다음 지금의…」にならない',!/지금의/.test(r)&&/다음/.test(r),r);
 await pg.close(); pg=await page('ja');
 r=await pg.evaluate(()=>_softenJargon('2028年の流年は追い風です。'));
 chk('日本語：「2028年の流年」が「2028年の今年の運」にならない',!/今年/.test(r)&&/2028年/.test(r),r);
 await pg.close();
 console.log(ok+' OK / '+ng+' NG'); await b.close(); srv.close(); });
