// 雑談が続いた時：何回続いても AI が答える（定型文で打ち切らない）。本題への誘いは4回目（短い一言なら話の手がかりがある回まで待つ）と、そのあと約5往復ごと（おやすみ等の締めには誘わない）。AI は偽物（呼ばれた回数と、指示文に誘いの指示が入ったかを数える）
//   node steertest.js
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
let calls=0; const kinds=[]; const inv=[];
const srv=http.createServer((q,r)=>{
  if(q.url.startsWith('/api/gemini')){ let b='';q.on('data',c=>b+=c);q.on('end',()=>{ const j=JSON.parse(b||'{}'); const cls=q.headers['x-pk-classify']==='1'; const sys=JSON.stringify((j.systemInstruction||{}).parts||'').slice(0,4000); const isReply=!cls&&/REPLY LANGUAGE/.test(sys)&&q.headers['x-pk-retry']!=='1'; /* 偽の返事は日本語なので、ほかの言語では作り直しが1回走る（数えない） */ if(isReply){ calls++; inv.push(/END with ONE gentle question that offers a real reading/.test(JSON.stringify(j.systemInstruction||''))); } const _inv=!cls&&/output exactly CHIPS/.test(JSON.stringify(j.systemInstruction||'')); if(isReply||_inv){} else kinds.push((cls?'classify ':'other ')+sys.slice(0,70));
    r.writeHead(200,{'content-type':'application/json'}); r.end(JSON.stringify({candidates:[{content:{parts:[{text: cls?'{"topic":"other","subject":"self","serious":false}':({English:'I see. Today is a calm-flow day for you, so that sounds good.',Korean:'그렇군요. 오늘은 당신에게 흐름이 순한 날이라 좋아요.','Traditional Chinese':'原來如此。從你的命盤來看，今天是流動平穩的一天，很不錯喔。'}[((JSON.stringify(j.systemInstruction||'').match(/REPLY LANGUAGE: ([A-Za-z ()]+?)\]/)||[])[1]||'').replace(/ \(.*\)/,'')]||'そうなんですね。今日はあなたにとって流れがおだやかな日なので、いいと思います。')+(_inv?'\nCHIPS:["来月からの流れを詳しく","始めるのにいい日は？"]':'')}]}}]})); }); return; }
  if(q.url.startsWith('/api/')){ r.writeHead(500); return r.end('{}'); }
  let f=path.join('fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});
}).listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch();
  let ok=0,ng=0; const eq=(n,a,x)=>{const g=JSON.stringify(a)===JSON.stringify(x); g?ok++:ng++; console.log((g?'OK  ':'NG  ')+n+(g?'':' → '+JSON.stringify(a)+' ≠ '+JSON.stringify(x)));};
  for(const [L,lights,real] of [
    ['ja',['おはよう','ただいま〜','コンビニの新作スイーツ買っちゃった','駅前の新しいパン屋さんに行ってきたよ','雨すごいね','暇〜','ゲームしてた','おやすみ〜'],'向いてる仕事は？'],
    ['en',['Morning!','I\'m home~','Bought a new dessert','Went to the new bakery near the station today','Rainy today','lol ok','Played games','Good night~'],'What work suits me?'],
    ['ko',['좋은 아침!','다녀왔어~','편의점 신상 디저트 샀어','역 앞에 새로 생긴 빵집에 다녀왔어요','비 엄청 오네','ㅋㅋ 그렇구나','게임했어','잘 자~'],'저에게 맞는 일은?'],
    ['zt',['早安！','我回來囉～','買了新出的甜點','今天去了車站前新開的麵包店','雨好大','哈哈好喔','在打電動','晚安～'],'適合我的工作？']]){
    const pg=await (await b.newContext({viewport:{width:420,height:900}})).newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e).slice(0,200)));
    await pg.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());
    await pg.addInitScript(l=>{localStorage.setItem('pk_lang',l);localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_tmsg','30');
      localStorage.setItem('pk_profile',JSON.stringify({name:'T',y:1990,m:6,d:8,tu:false,hh:12,mi:0,sex:'female',place:'tokyo',plan:'pro'}));
      localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hello'}]));},L);
    await pg.goto(base+'/index.html'); await pg.waitForTimeout(1200);
    await pg.evaluate(()=>{ window.pkSend=async q=>{ ask(q); for(let i=0;i<120&&_askBusy;i++) await new Promise(r=>setTimeout(r,250)); }; });
    const per=[], i0=inv.length; let chipSeen=0;
    for(const [i,q] of lights.slice(0,7).entries()){ const c0=calls; await pg.evaluate(q=>pkSend(q),q); per.push(calls-c0); if(await pg.evaluate(()=>!!(document.getElementById('topicChips')||document.getElementById('sugg')))) chipSeen++;
      if(i===3){ eq(L+'：誘いの回は、深い鑑定に入るボタン（AI の提案）を先頭に必ず出す（そのあとにほかのテーマ。毎回6個・2026-10-28）',await pg.evaluate(()=>{ const d=document.getElementById('topicChips'); return d?[...d.querySelectorAll('button')].slice(0,2).map(x=>x.textContent).concat([d.querySelectorAll('button').length>=6]):null; }),['来月からの流れを詳しく','始めるのにいい日は？',true]);
        eq(L+'：ボタン用の行は本文に出さない',await pg.evaluate(()=>state.msgs.some(m=>/CHIPS/.test(m.text||''))),false); }
      if(i===3) eq(L+'：アプリが定型文を足さない（返事は AI の言葉だけ）',await pg.evaluate(()=>{ const ai=state.msgs.filter(m=>m.role==='ai').slice(-1)[0].text; return /ところで、最近いちばん|By the way, what has been on your mind|요즘 가장 마음에 걸리는|最近有沒有最放在心上/.test(ai); }),false); }
    eq(L+'：雑談は何回続いても AI が答える（定型文で打ち切らない）',per,[1,1,1,1,1,1,1]);
    eq(L+'：誘いの指示は4回目だけ（ほかは誘わない）',inv.slice(i0),[false,false,false,true,false,false,false]);
    eq(L+'：雑談のあいだも、相談の選択肢（ボタン）がときどき出る',chipSeen>=2,true);
    { const i1=inv.length; await pg.evaluate(q=>pkSend(q),lights[7]); eq(L+'：8回目でも「おやすみ」には誘わない',inv.slice(i1),[false]); }
    const c1=calls; await pg.evaluate(q=>pkSend(q),real); eq(L+'：選択肢の質問はさえぎらずに AI で鑑定する',calls-c1,1);
    const c2=calls; await pg.evaluate(q=>pkSend(q),lights[0]); eq(L+'：本題のあとの雑談は、また AI で答える',calls-c2,1);
    eq(L+'：画面のエラーなし',errs,[]);
  }
  console.log('ほかの呼び出し:',[...new Set(kinds)].slice(0,8)); console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
