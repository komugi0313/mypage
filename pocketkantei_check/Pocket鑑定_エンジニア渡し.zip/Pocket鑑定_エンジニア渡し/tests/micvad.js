// マイク：黙ったら5秒で自動で止まる・何も話さなければ15秒で止まる・「Transcribe」が入らない（本物のブラウザの録音。音声は作りもの。AIは偽物）
//   node micvad.js audio/speak.wav audio/silent.wav（2秒話して黙る音声／25秒の無音。ffmpeg で作ったもの）
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
let stt=0, reply='今日、上司にちょっと言われて落ち込んでるの。';
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/gemini')){ let b=''; q.on('data',c=>b+=c); q.on('end',()=>{ if(q.headers['x-pk-stt']==='1'){ stt++; r.writeHead(200,{'content-type':'application/json'}); return r.end(JSON.stringify({candidates:[{content:{parts:[{text:reply}]}}]})); } r.writeHead(500); r.end('{}'); }); return; }
  if(q.url.startsWith('/api/')){ r.writeHead(500); return r.end('{}'); }
  let f=path.join(__dirname,'fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});
}).listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port; let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
  async function run(wav,label,fn){ const b=await chromium.launch({args:['--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream','--use-file-for-fake-audio-capture='+wav+'%noloop','--autoplay-policy=no-user-gesture-required']});
    const ctx=await b.newContext({permissions:['microphone']}); const pg=await ctx.newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
    await pg.addInitScript(()=>{ localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');
      localStorage.setItem('pk_profile',JSON.stringify({name:'T',y:1990,m:6,d:8,tu:false,hh:12,mi:0,sex:'female',place:'tokyo',plan:'pro'})); localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hello'}])); });
    await pg.goto(base+'/index.html'); await pg.waitForTimeout(1500);
    await fn(pg); chk(label+'：画面のエラーなし',errs.length===0,errs); await b.close(); }
  // 1) 2秒話して黙る → 約5秒で自動で止まり、文字になる
  await run(process.argv[2],'話して黙る',async pg=>{ stt=0; const t0=Date.now(); await pg.click('#micBtn'); await pg.waitForTimeout(400);
    const ph=await pg.$eval('#askIn',e=>e.placeholder); chk('録音中の案内：「話し終わったら、もう一度🎤を押してね」',/もう一度🎤/.test(ph),ph);
    let stopped=0; for(let i=0;i<150;i++){ await pg.waitForTimeout(100); const on=await pg.$eval('#micBtn',e=>e.classList.contains('on')); if(!on){ stopped=Date.now()-t0; break; } }
    chk('話し終わって約5秒で自動で止まる（話し始め1秒＋話す2秒＋5秒＝約8秒）',stopped>=7000&&stopped<=10500,stopped);
    await pg.waitForTimeout(1500); chk('止まったら文字になって入力欄に入る（自動では送らない）',(await pg.$eval('#askIn',e=>e.value))===reply&&stt===1,{v:await pg.$eval('#askIn',e=>e.value),stt}); });
  // 2) 何も話さない → 15秒で止まり、文字にしない
  await run(process.argv[3],'何も話さない',async pg=>{ stt=0; const t0=Date.now(); await pg.click('#micBtn');
    let stopped=0; for(let i=0;i<220;i++){ await pg.waitForTimeout(100); const on=await pg.$eval('#micBtn',e=>e.classList.contains('on')); if(!on){ stopped=Date.now()-t0; break; } }
    chk('声が無ければ約15秒で止まる',stopped>=14000&&stopped<=17500,stopped);
    const ph=await pg.$eval('#askIn',e=>e.placeholder); chk('「うまく聞き取れませんでした」と出し、文字にしに行かない',/聞き取れません/.test(ph)&&stt===0,{ph,stt}); });
  // 3) 自分で止めた時に AI が「Transcribe」と返しても、入力欄に入れない
  reply='Transcribe.';
  await run(process.argv[2],'Transcribeが返る',async pg=>{ stt=0; await pg.click('#micBtn'); await pg.waitForTimeout(2500); await pg.click('#micBtn'); await pg.waitForTimeout(2000);
    chk('「Transcribe」は入力欄に入れず、「聞き取れませんでした」',(await pg.$eval('#askIn',e=>e.value))===''&&/聞き取れません/.test(await pg.$eval('#askIn',e=>e.placeholder)),{v:await pg.$eval('#askIn',e=>e.value)}); });
  console.log(ok+' OK / '+ng+' NG'); srv.close(); });
