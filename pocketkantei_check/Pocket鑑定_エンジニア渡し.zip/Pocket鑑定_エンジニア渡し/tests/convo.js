// 本物のAIで、1人の利用者として続けて会話する（アプリの画面をそのまま使う）。鍵は環境変数 GEMINI_KEY
const {chromium}=require('/opt/node22/lib/node_modules/playwright');const http=require('http'),fs=require('fs'),path=require('path');
const KEY=(process.env.GEMINI_KEY||'').trim(); if(!KEY){ console.error('GEMINI_KEY'); process.exit(1); }
const {execFile}=require('child_process');
function curlPost(url,body){ return new Promise((res,rej)=>{ const p=execFile('curl',['-s','-m','120','-w','\\n%{http_code}','-X','POST','-H','Content-Type: application/json','--data-binary','@-',url],{maxBuffer:50e6},(err,out)=>{ if(err) return rej(err); const i=out.lastIndexOf('\n'); res({status:+out.slice(i+1)||500,body:out.slice(0,i)}); }); p.stdin.end(body); }); }
const C=JSON.parse(fs.readFileSync(process.argv[2],'utf8')); const OUT=process.argv[3];
// 使うモデルを変えて試す時：PK_LITE_MODEL（軽量）・PK_DEEP_MODEL（上位）。呼び出しごとのモデルと使用量（トークン数）も記録する
const LITE=process.env.PK_LITE_MODEL||'', DEEPM=process.env.PK_DEEP_MODEL||''; const calls=[]; let turn=0;
const srv=http.createServer((q,r)=>{let f=path.join(process.env.PK_FX||'fx',decodeURIComponent(q.url.split('?')[0]));fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});}).listen(0,async()=>{
 const base='http://127.0.0.1:'+srv.address().port;const b=await chromium.launch();
 const pg=await b.newPage({viewport:{width:420,height:900},timezoneId:({ja:'Asia/Tokyo',ko:'Asia/Seoul',zt:'Asia/Taipei',en:'America/Los_Angeles'})[C.lang]||'Asia/Tokyo'});   /* 実際の利用者と同じ時間帯で動かす（日本・韓国の人に日本時間を言う、などのテストだけのずれを防ぐ） */ const errs=[];pg.on('pageerror',e=>errs.push(String(e).slice(0,200)));
 await pg.route('**/*',async r=>{const u=r.request().url(); if(u.startsWith(base)) return r.continue();
   if(u.startsWith('https://generativelanguage.googleapis.com/')){ try{ const res=await curlPost(u,r.request().postData()||''); try{ const mm=(u.match(/models\/([^:]+):/)||[])[1]; const um=(JSON.parse(res.body).usageMetadata)||{}; calls.push({turn,model:mm,status:res.status,in:um.promptTokenCount||0,cached:um.cachedContentTokenCount||0,out:um.candidatesTokenCount||0,think:um.thoughtsTokenCount||0}); }catch(e){} return r.fulfill({status:res.status,contentType:'application/json',body:res.body}); }catch(e){ return r.fulfill({status:599,body:'{}'}); } }
   return r.abort();});
 await pg.addInitScript((a)=>{localStorage.setItem('pk_lang',a.L);localStorage.setItem('pk_key',a.K);localStorage.setItem('pk_dev','1');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_profile',JSON.stringify(a.p));if(a.st) localStorage.setItem('pk_tmsg',String(a.st)); if(a.lite) window.PK_DIRECT_MODEL=a.lite; if(a.koDeep) window.PK_KO_DEEP=true; if(a.deep) window.PK_DIRECT_MODEL_DEEP=a.deep;},{L:C.lang,K:KEY,p:C.profile,st:C.stage||0,lite:LITE,deep:DEEPM,koDeep:process.env.PK_KO_DEEP==='1'});
 await pg.goto(base+'/index.html');
 // 比べる時だけ：PK_FORCE_FULL=1 で、雑談も全部入りの指示文で答えさせる（軽い指示文との質の比較用）
 if(process.env.PK_FORCE_FULL==='1') await pg.evaluate(()=>{ window.isPlainSmalltalk=function(){ return false; }; });
 const waitAi=async(n)=>{let last=-1,stable=0;for(let i=0;i<180;i++){await pg.waitForTimeout(1000);const s=await pg.evaluate(()=>state.msgs.map(m=>m.role));
   if(s.length>=n&&s[s.length-1]==='ai'){ if(s.length===last) stable++; else {stable=0; last=s.length;} if(stable>=7) return true; } else {stable=0; last=s.length;} }return false;};
 await waitAi(1);
 const sheets=[];
 for(const q of C.qs){ turn++; const n=await pg.evaluate(()=>state.msgs.length); await pg.evaluate(()=>{ try{ closeSheets(); }catch(e){} }); await pg.fill('#askIn',q); await pg.click('#askBtn'); await waitAi(n+2); await pg.waitForTimeout(600); await pg.evaluate(()=>{ try{ var d=document.getElementById('topicChips'); if(!d) return; var c=[...d.querySelectorAll('button')].map(x=>x.textContent); for(var i=state.msgs.length-1;i>=0;i--){ if(state.msgs[i].role==='ai'){ state.msgs[i]._chips=c; break; } } }catch(e){} }); sheets.push(await pg.evaluate(()=>[...document.querySelectorAll('.sheet.on')].map(s=>s.id))); console.log('sent',q.slice(0,20)); }
 const msgs=await pg.evaluate(()=>state.msgs.map(m=>({role:m.role,text:m.text,dbg:m.dbg,chips:m._chips})));
 // 採点用に、プログラムで計算した事実も残す（空亡の年・10年ごとの運の空亡の年齢・相性の結果・今日の日付）
 const facts=await pg.evaluate(()=>{ try{ var y0=new Date().getFullYear(), vd=function(pro){ var v=(window.kuboX?kuboX(pro):[])||[]; return (pro&&pro.decadeFortunes||[]).filter(function(d){ return d&&d.ganzhi&&v.indexOf(d.ganzhi.charAt(1))>=0; }).map(function(d){ return [d.startAge,d.endAge]; }); };
   return {today:new Date().toISOString().slice(0,10), voidYears:(window.pkVoidYears?pkVoidYears(y0-1,y0+30):[]), compatVoidYears:window._compatVoidYears||[], voidAges:vd(state.chart&&state.chart.pro).concat(state.chartB&&state.chartB.pro?vd(state.chartB.pro):[]), partner:!!state.chartB, verdict:state.compatDeep&&state.compatDeep.verdict||'' }; }catch(e){ return {err:String(e)}; } });
 fs.writeFileSync(OUT,JSON.stringify({C,msgs,errs,calls,sheets,facts,lite:LITE,deep:DEEPM},null,1)); await b.close(); srv.close();
});
