// ピルボタン（相談の選択肢）の出方：最初のあいさつ・雑談の後・話題の質問の後・重い相談の後（出さない）・雑談5回目。AI は偽物
//   node chipstest.js
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{
  if(q.url.startsWith('/api/gemini')){ let b='';q.on('data',c=>b+=c);q.on('end',()=>{ const cls=q.headers['x-pk-classify']==='1';
    r.writeHead(200,{'content-type':'application/json'}); r.end(JSON.stringify({candidates:[{content:{parts:[{text: cls?'{"topic":"other","subject":"self","serious":false}':'そうなんですね。今日はあなたにとって流れがおだやかな日なので、いいと思います。'}]}}]})); }); return; }
  if(q.url.startsWith('/api/')){ r.writeHead(500); return r.end('{}'); }
  let f=path.join('fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});
}).listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch();
  let ok=0,ng=0; const eq=(n,a,x)=>{const g=JSON.stringify(a)===JSON.stringify(x); g?ok++:ng++; console.log((g?'OK  ':'NG  ')+n+(g?'':' → '+JSON.stringify(a)+' ≠ '+JSON.stringify(x)));};
  const pg=await (await b.newContext({viewport:{width:420,height:900}})).newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
  await pg.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());
  await pg.addInitScript(()=>{localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_profile',JSON.stringify({name:'T',y:1990,m:6,d:8,tu:false,hh:12,mi:0,sex:'female',place:'tokyo',plan:'pro'}));});
  await pg.goto(base+'/index.html');
  /* 最初のあいさつが最後まで出るのを待つ（実際の画面の流れのまま。前は表示の関数を差し替えていたため、ボタンが出ない形になっていた） */
  { let last=-1,st=0; for(let i=0;i<90;i++){ await pg.waitForTimeout(1000); const n=await pg.evaluate(()=>state.msgs.length+(document.querySelector('.typing')?100:0)); if(n===last){ if(++st>=5) break; } else { st=0; last=n; } } }
  const chips=()=>pg.evaluate(()=>{ const a=[...document.querySelectorAll('#sugg button, #topicChips button')].map(x=>x.textContent); return a; });
  eq('最初のあいさつの後に6つ',(await chips()).length,6);
  eq('先頭は「相性を見てほしい」',(await chips())[0],'相性を見てほしい');
  const send=async q=>{ await pg.evaluate(q=>{ ask(q); },q); for(let i=0;i<80;i++){ if(!(await pg.evaluate(()=>_askBusy))) break; await pg.waitForTimeout(200); } await pg.waitForTimeout(300); return chips(); };
  let c=await send('おはよう'); eq('1回目の雑談の後：入り口のボタンが出る',c.length>=2,true); console.log('   ',c);
  c=await send('パスタおいしかった'); eq('2回目：連発しない（2往復に1回）',c.length,0);
  c=await send('ちょっと眠い'); eq('3回目：また出る（前と違うボタン）',c.length>=2,true); console.log('   ',c);
  c=await send('彼氏とうまくいってない'); eq('恋の話：直後は出ない（2往復に1回）',c.length,0);
  c=await send('私のモテ期はいつ？'); eq('恋の質問の後：恋のボタン',c.length>=2,true); console.log('   ',c);
  c=await send('もう全部つらい、眠れない'); eq('重い相談の後：出さない',c.length,0);
  eq('画面のエラーなし',errs,[]);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
