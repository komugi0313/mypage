/* 人生の重い相談の見分け（DV・妊娠・ギャンブル・借金・介護・重い病気・いじめ）と、取り違えないこと（2026-10-25）
   node senstest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const Y=[['dv','夫に殴られることがあります。'],['dv','My husband hits me sometimes.'],['dv','남편이 때려요'],['dv','老公會打我'],['pregnancy','妊娠しているのがわかりました。産むか迷っています'],['pregnancy','I just found out I am pregnant'],['gambling','パチンコがやめられません'],['gambling','도박을 끊을 수가 없어요'],['debt','借金が500万円あって返せません'],['debt','I have credit card debt I can\'t pay back'],['debt','빚이 너무 많아요'],['care','認知症の母の介護に疲れました'],['care','長照我媽媽好累'],['illness','乳がんと診断されました'],['illness','I was diagnosed with cancer'],['bully','学校でいじめられています'],['bully','학교에서 왕따를 당해요']];
const N=['メールを返せないまま寝てしまった','ネットで叩かれて落ち込んでいます','彼に無視されてつらい','がんばりたいです','今日は手術の話じゃなくて恋愛の話','I can\'t pay attention at work','友達にお金を貸した'];
const R=await pg.evaluate(([Y,N])=>({y:Y.map(([k,q])=>[k,q,sensTopic(q)]),n:N.map(q=>[q,sensTopic(q)])}),[Y,N]);
R.y.forEach(([k,q,got])=>chk('見分ける：'+q,got===k,got));
R.n.forEach(([q,got])=>chk('取り違えない：'+q,!got||(q.indexOf('手術')>=0),got));
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
