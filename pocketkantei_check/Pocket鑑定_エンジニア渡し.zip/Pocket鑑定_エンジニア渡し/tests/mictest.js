// マイク入力：使える時だけボタンが出る／話した言葉が入力欄に入る／自動では送らない／送ったあと入力欄に戻ってこない（AI は呼ばない）
//   node mictest.js
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
let calls=0;
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){ calls++; r.writeHead(500); return r.end('{}'); }
  let f=path.join('fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});
}).listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch(); let ok=0,ng=0;
  const eq=(n,a,x)=>{const g=JSON.stringify(a)===JSON.stringify(x); g?ok++:ng++; console.log((g?'OK  ':'NG  ')+n+(g?'':' → '+JSON.stringify(a)+' ≠ '+JSON.stringify(x)));};
  for(const [L,withSR] of [['ja',true],['ko',true],['en',false]]){
    const pg=await (await b.newContext()).newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
    await pg.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());
    await pg.addInitScript(a=>{ localStorage.setItem('pk_lang',a.L);localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');
      localStorage.setItem('pk_profile',JSON.stringify({name:'T',y:1990,m:6,d:8,tu:false,hh:12,mi:0,sex:'female',place:'tokyo',plan:'pro'}));
      localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hello'}]));
      delete window.SpeechRecognition; delete window.webkitSpeechRecognition;
      if(a.withSR){ window.webkitSpeechRecognition=function(){ var me=this; window._lastSR=me; me.start=function(){ window._srLang=me.lang; setTimeout(function(){ var r1=[{transcript:'今日ほんと疲れた'}]; r1.isFinal=true; me.onresult({results:[r1]}); },50); }; me.stop=function(){ setTimeout(function(){ me.onend&&me.onend(); },10); }; }; } },{L,withSR});
    await pg.goto(base+'/index.html'); await pg.waitForTimeout(1200);
    const shown=await pg.evaluate(()=>{ const x=document.getElementById('micBtn'); return !!x&&!x.hidden; });
    eq(L+'：音声入力が使える時だけマイクボタンを出す',shown,withSR);
    if(withSR){
      const n0=await pg.evaluate(()=>state.msgs.length);
      await pg.click('#micBtn'); await pg.waitForTimeout(300);
      eq(L+'：言語に合わせて聞き取る',await pg.evaluate(()=>window._srLang),L==='ja'?'ja-JP':'ko-KR');
      eq(L+'：話した言葉が入力欄に入る',await pg.evaluate(()=>document.getElementById('askIn').value),'今日ほんと疲れた');
      eq(L+'：話しただけでは送らない',await pg.evaluate(()=>state.msgs.length),n0);
      await pg.click('#micBtn'); await pg.waitForTimeout(100);
      eq(L+'：もう一度押すと止まる',await pg.evaluate(()=>document.getElementById('micBtn').classList.contains('on')),false);
      await pg.click('#askBtn'); await pg.waitForTimeout(300);
      await pg.evaluate(()=>{ var r1=[{transcript:'遅れて届いた'}]; r1.isFinal=true; try{ window._lastSR.onresult&&window._lastSR.onresult({results:[r1]}); }catch(e){} });
      eq(L+'：送ったあと、遅れて届いた音声が入力欄に戻らない',await pg.evaluate(()=>document.getElementById('askIn').value),'');
      eq(L+'：送信ボタンで送られる',await pg.evaluate(()=>state.msgs.some(m=>m.role==='me'&&m.text==='今日ほんと疲れた')),true);
    }
    eq(L+'：画面のエラーなし',errs,[]);
  }
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
