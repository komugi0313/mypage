// マイク入力（AI は偽物。お金はかからない）
//  ・録音できる機種：録音 → Gemini で文字に（x-pk-stt を付け、会話の回数に数えない）→ 入力欄に入る。自動では送らない
//  ・録音できない機種：端末の音声入力で入力欄に入る
//  ・どちらも無い機種：マイクのボタンを出さない
//   node mictest.js
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
let stt=[];
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/gemini')){ let b=''; q.on('data',c=>b+=c); q.on('end',()=>{ const j=JSON.parse(b||'{}');
    if(q.headers['x-pk-stt']==='1'){ const p=j.contents[0].parts[0]; stt.push({deep:q.headers['x-pk-deep'],nocount:q.headers['x-pk-nocount'],mime:p.inlineData&&p.inlineData.mimeType,hasData:!!(p.inlineData&&p.inlineData.data)});
      r.writeHead(200,{'content-type':'application/json'}); return r.end(JSON.stringify({candidates:[{content:{parts:[{text:'今日、上司にちょっと言われて落ち込んでるの。'}]}}]})); }
    r.writeHead(500); r.end('{}'); }); return; }
  if(q.url.startsWith('/api/')){ r.writeHead(500); return r.end('{}'); }
  let f=path.join('fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});
}).listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch(); let ok=0,ng=0;
  const eq=(n,a,x)=>{const g=JSON.stringify(a)===JSON.stringify(x); g?ok++:ng++; console.log((g?'OK  ':'NG  ')+n+(g?'':' → '+JSON.stringify(a)+' ≠ '+JSON.stringify(x)));};
  for(const [L,mode] of [['ja','rec'],['ko','rec'],['ja','sr'],['en','none']]){
    const pg=await (await b.newContext()).newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
    await pg.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());
    await pg.addInitScript(a=>{ localStorage.setItem('pk_lang',a.L);localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');
      localStorage.setItem('pk_profile',JSON.stringify({name:'T',y:1990,m:6,d:8,tu:false,hh:12,mi:0,sex:'female',place:'tokyo',plan:'pro'}));
      localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hello'}]));
      delete window.SpeechRecognition; delete window.webkitSpeechRecognition;
      if(a.mode!=='rec'){ delete window.MediaRecorder; try{ Object.defineProperty(navigator,'mediaDevices',{value:undefined}); }catch(e){} }
      else { navigator.mediaDevices.getUserMedia=()=>Promise.resolve({getTracks:()=>[{stop(){}}]});
        window.MediaRecorder=function(st,o){ const me=this; me.mimeType=(o&&o.mimeType)||'audio/webm'; me.state='inactive'; me.start=()=>{ me.state='recording'; }; me.stop=()=>{ me.state='inactive'; me.ondataavailable({data:new Blob(['xx'],{type:me.mimeType})}); setTimeout(()=>me.onstop(),10); }; };
        window.MediaRecorder.isTypeSupported=t=>t==='audio/mp4'; }
      if(a.mode==='sr'){ window.webkitSpeechRecognition=function(){ var me=this; window._lastSR=me; me.start=function(){ window._srLang=me.lang; setTimeout(function(){ var r1=[{transcript:'今日ほんと疲れた'}]; r1.isFinal=true; me.onresult({results:[r1]}); },50); }; me.stop=function(){ setTimeout(function(){ me.onend&&me.onend(); },10); }; }; } },{L,mode});
    await pg.goto(base+'/index.html'); await pg.waitForTimeout(1200);
    const shown=await pg.evaluate(()=>{ const x=document.getElementById('micBtn'); return !!x&&!x.hidden; });
    eq(`${L}/${mode}：録音か音声入力ができる時だけマイクボタンを出す`,shown,mode!=='none');
    if(mode==='rec'){
      const n0=await pg.evaluate(()=>state.msgs.length), s0=stt.length;
      await pg.click('#micBtn'); await pg.waitForTimeout(900);
      eq(`${L}/rec：録音中はボタンが赤くなる`,await pg.evaluate(()=>document.getElementById('micBtn').classList.contains('on')),true);
      await pg.click('#micBtn'); await pg.waitForTimeout(600);
      eq(`${L}/rec：止めると Gemini に声を送る（上位モデル・本格鑑定に数えない印）`,stt.slice(s0),[{deep:'1',nocount:'1',mime:'audio/mp4',hasData:true}]);
      eq(`${L}/rec：文字にした言葉が入力欄に入る`,await pg.evaluate(()=>document.getElementById('askIn').value),'今日、上司にちょっと言われて落ち込んでるの。');
      eq(`${L}/rec：話しただけでは送らない`,await pg.evaluate(()=>state.msgs.length),n0);
      await pg.click('#askBtn'); await pg.waitForTimeout(300);
      eq(`${L}/rec：送信ボタンで送られる`,await pg.evaluate(()=>state.msgs.some(m=>m.role==='me'&&/上司に/.test(m.text))),true);
      const s1=stt.length; await pg.click('#micBtn'); await pg.waitForTimeout(200); await pg.click('#micBtn'); await pg.waitForTimeout(400);
      eq(`${L}/rec：0.7秒未満の押し間違いは送らない`,stt.length-s1,0);
    }
    if(mode==='sr'){
      const n0=await pg.evaluate(()=>state.msgs.length);
      await pg.click('#micBtn'); await pg.waitForTimeout(300);
      eq('ja/sr：言語に合わせて聞き取る',await pg.evaluate(()=>window._srLang),'ja-JP');
      eq('ja/sr：話した言葉が入力欄に入る',await pg.evaluate(()=>document.getElementById('askIn').value),'今日ほんと疲れた');
      eq('ja/sr：話しただけでは送らない',await pg.evaluate(()=>state.msgs.length),n0);
      await pg.click('#askBtn'); await pg.waitForTimeout(300);
      await pg.evaluate(()=>{ var r1=[{transcript:'遅れて届いた'}]; r1.isFinal=true; try{ window._lastSR.onresult&&window._lastSR.onresult({results:[r1]}); }catch(e){} });
      eq('ja/sr：送ったあと、遅れて届いた音声が入力欄に戻らない',await pg.evaluate(()=>document.getElementById('askIn').value),'');
    }
    eq(`${L}/${mode}：画面のエラーなし`,errs,[]);
  }
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
