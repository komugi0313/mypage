// 命式の画面が横にはみ出さない（幅320・375・390・393、4言語、3人）。node sheetwidth.js fx shot.png
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');const ROOT=process.argv[2];
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){ r.writeHead(404); return r.end(); } let f=path.join(ROOT,decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html'; fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':(f.endsWith('.png')?'image/png':'application/javascript')});r.end(d);}); }).listen(0,async()=>{
 const b=await chromium.launch(); let bad=0;
 for(const w of [320,375,390,393]) for(const L of ['ja','en','ko','zt']) for(const prof of [{y:1994,m:12,d:28,hh:12},{y:1988,m:12,d:8,hh:12},{y:1965,m:3,d:3,hh:23}]){
  const ctx=await b.newContext({viewport:{width:w,height:844},isMobile:true,hasTouch:true}); const pg=await ctx.newPage();
  await pg.addInitScript(a=>{ localStorage.setItem('pk_lang',a.L);localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_mictip','1');
    localStorage.setItem('pk_profile',JSON.stringify(Object.assign({name:'T',tu:false,mi:0,sex:'female',place:'tokyo'},a.p))); localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hello'}])); },{L,p:prof});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(900); await pg.click('#btnMeishiki'); await pg.waitForTimeout(700);
  const r=await pg.evaluate(()=>{ const sh=[...document.querySelectorAll('.sheet')].filter(s=>getComputedStyle(s).transform==='none'||s.classList.contains('on'))[0]||document.querySelector('.sheet.on'); const pl=document.querySelector('.pillars'); const W=sh?sh.clientWidth:0; return {sheetScroll:sh?sh.scrollWidth-sh.clientWidth:-1, pillarsOver:pl?Math.round(pl.scrollWidth-pl.clientWidth):-1, plRight:pl?Math.round(pl.getBoundingClientRect().right):0, vw:document.documentElement.clientWidth}; });
  if(r.sheetScroll>0||r.pillarsOver>0||r.plRight>r.vw){ bad++; console.log('NG',w,L,JSON.stringify(prof),JSON.stringify(r)); }
  if(w===393&&L==='ja'&&prof.y===1994) await pg.screenshot({path:process.argv[3]}); await ctx.close(); }
 console.log(bad?('NG '+bad):'ALL OK（横にはみ出さない）'); await b.close(); srv.close(); });
