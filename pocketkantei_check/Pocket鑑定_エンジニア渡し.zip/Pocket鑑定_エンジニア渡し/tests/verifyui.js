// 画面のテスト：登録 → 確認コードの画面 → アドレスの打ち間違いを直す → コードで確認 → マイページ（確認済み・ログアウト）→ 別の端末で新しいアドレスでログイン
//   PK_STORE=memory NODE_PATH=mock/node_modules node verifyui.js     （Resend は偽物）
process.env.AUTH_SECRET='test-secret-0123456789abcdef'; process.env.RESEND_API_KEY='re_test'; process.env.MAIL_FROM='Pocket Kantei <no-reply@example.com>';
const mails=[]; const realFetch=global.fetch; global.fetch=async(u,o)=>{ if(String(u).includes('api.resend.com')){ mails.push(JSON.parse(o.body)); return {ok:true}; } return realFetch(u,o); };
const {chromium}=require('playwright'); const http=require('http'),fs=require('fs'),path=require('path');
const auth=require('./fx/functions/auth.js').handler;
const srv=http.createServer((q,r)=>{
  if(q.url.startsWith('/api/auth')){let b='';q.on('data',c=>b+=c);q.on('end',async()=>{const o=await auth({httpMethod:q.method,headers:q.headers,body:b});r.writeHead(o.statusCode,o.headers);r.end(o.body);});return;}
  if(q.url.startsWith('/api/')){r.writeHead(500);return r.end('{}');}
  let f=path.join('fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':f.endsWith('.js')?'application/javascript':'application/octet-stream'});r.end(d);});
}).listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port; const b=await chromium.launch();
  let ok=0,ng=0; const eq=(n,a,x)=>{const g=JSON.stringify(a)===JSON.stringify(x); g?ok++:ng++; console.log((g?'OK  ':'NG  ')+n+(g?'':' → '+JSON.stringify(a)+' ≠ '+JSON.stringify(x)));};
  const code=to=>{const m=[...mails].reverse().find(x=>x.to[0]===to); return m?(m.text.match(/\b(\d{6})\b/)||[])[1]:null;};
  const mk=async(lang)=>{const ctx=await b.newContext({viewport:{width:420,height:900}});const pg=await ctx.newPage();pg.errs=[];pg.on('pageerror',e=>pg.errs.push(String(e).slice(0,200)));pg.on('dialog',d=>{pg.lastDialog=d.message();d.accept();});
    await pg.route('**/*',r=>r.request().url().startsWith(base)?r.continue():r.abort());
    await pg.addInitScript(l=>{try{localStorage.setItem('pk_lang',l);localStorage.setItem('pk_svd','1');}catch(e){}},lang);return pg;};
  const scr=pg=>pg.evaluate(()=>[...document.querySelectorAll('.screen.on')].map(s=>s.id).join(','));
  // 1) 登録（アドレスを打ち間違える）
  const A=await mk('ja'); await A.goto(base+'/index.html?start=1'); await A.waitForTimeout(800);
  await A.fill('#iname','はな'); await A.fill('#acEmail','hana@gmial.com'); await A.fill('#acPw','sakura2026'); await A.fill('#acPw2','sakura2026'); await A.check('#agreeChk').catch(()=>{}); await A.click('#sexSeg button[data-sex="female"]').catch(()=>{}); await A.click('#regBtn'); await A.waitForTimeout(1500);
  eq('登録の直後に、確認コードの画面が出る',await scr(A),'scVerify');
  eq('画面に送り先のアドレスが出る',/hana@gmial\.com/.test(await A.textContent('#vfLead')),true);
  eq('日本語の確認コードのメールが届く',[mails.length,/確認コード/.test(mails[0].subject)],[1,true]);
  // 2) 違うコード
  await A.fill('#vfCode','000000'===code('hana@gmial.com')?'111111':'000000'); await A.click('#vfBtn'); await A.waitForTimeout(700);
  eq('違うコードはエラー',/コードが違います/.test(await A.textContent('#vfErr')),true);
  // 3) 打ち間違いに気づいて直す
  await A.click('#vfChgS'); await A.fill('#vfNew','hana@gmail.com'); await A.fill('#vfPw','sakura2026'); await A.click('#vfChgBtn'); await A.waitForTimeout(900);
  eq('新しいアドレスに切り替えの画面',[await scr(A),/hana@gmail\.com/.test(await A.textContent('#vfLead'))],['scVerify',true]);
  await A.fill('#vfCode',code('hana@gmail.com')); await A.click('#vfBtn'); await A.waitForTimeout(1500);
  eq('コードを入れると完了のお知らせ',/hana@gmail\.com/.test(A.lastDialog||''),true);
  eq('そのままチャットへ',await scr(A),'scChat');
  eq('端末のログイン情報も新しいアドレス・確認済み',await A.evaluate(()=>{const a=JSON.parse(localStorage.getItem('pk_auth'));return [a.email,a.v];}),['hana@gmail.com',true]);
  // 4) マイページ：いちばん上にアカウント、確認済み、ログアウト
  await A.evaluate(()=>{renderMyPage();openSheet('shMyPage');}); await A.waitForTimeout(400);
  const mp=(await A.textContent('#mpBody')).replace(/\s+/g,' ');
  eq('マイページの先頭にアカウント欄',mp.indexOf('アカウント')<mp.indexOf('生年月日')||mp.indexOf('アカウント')<20,true);
  eq('確認済みと表示',/✓ 確認済み/.test(mp),true);
  eq('メールアドレスの変更・パスワードの変更・ログアウト・削除がある',['メールアドレスを変更','パスワードを変更','ログアウト','アカウントを削除'].every(w=>mp.includes(w)),true);
  await A.evaluate(()=>closeSheets()); await A.evaluate(()=>openSheet('shMenu')); await A.waitForTimeout(300);
  eq('メニューにもログアウトがある（ログイン中）',await A.evaluate(()=>{const m=document.getElementById('miOut');return m.style.display!=='none'&&m.textContent.includes('ログアウト');}),true);
  await A.click('#miOut'); await A.waitForTimeout(1500);
  eq('メニューからログアウト → ログイン画面・端末のデータは消える',[await scr(A),await A.evaluate(()=>localStorage.getItem('pk_auth'))],['scLogin',null]);
  // 5) 別の端末：新しいアドレスでログインできる、前のアドレスではできない
  const B=await mk('ja'); await B.goto(base+'/index.html#login'); await B.waitForTimeout(700);
  await B.fill('#lgEmail','hana@gmial.com'); await B.fill('#lgPw','sakura2026'); await B.click('#lgBtn'); await B.waitForTimeout(800);
  eq('前の（打ち間違いの）アドレスではログインできない',/違います/.test(await B.textContent('#lgErr')),true);
  await B.fill('#lgEmail','hana@gmail.com'); await B.click('#lgBtn'); await B.waitForTimeout(1800);
  eq('新しいアドレスでログインでき、名前も戻る',[await scr(B),await B.evaluate(()=>state.profile&&state.profile.name)],['scChat','はな']);
  // 6) あとで確認する → マイページから確認できる（韓国語・繁体字の文言も）
  for(const [L,em,word] of [['ko','min@example.com','인증 코드'],['zt','yi@example.com','驗證碼']]){
    const C=await mk(L); await C.goto(base+'/index.html?start=1'); await C.waitForTimeout(800);
    await C.fill('#iname','T'); await C.fill('#acEmail',em); await C.fill('#acPw','sakura2026'); await C.fill('#acPw2','sakura2026'); await C.check('#agreeChk').catch(()=>{}); await C.click('#sexSeg button[data-sex="female"]').catch(()=>{}); await C.click('#regBtn'); await C.waitForTimeout(1500);
    eq(L+'：確認の画面の言葉',(await C.textContent('#vfCodeL')).includes(word.split(' ')[0])||(await C.textContent('#vfCodeL')).includes(word),true);
    await C.click('#vfLater'); await C.waitForTimeout(1000);
    eq(L+'：「あとで」でチャット（またはアンケート）へ進める',['scChat','scSurvey'].includes(await scr(C)),true);
    await C.evaluate(()=>{show('scChat');renderMyPage();openSheet('shMyPage');}); await C.waitForTimeout(300);
    eq(L+'：マイページに「未確認」と確認ボタン',await C.evaluate(()=>!!document.getElementById('acVerify')),true);
    await C.click('#acVerify'); await C.waitForTimeout(1000);
    await C.fill('#vfCode',code(em)); await C.click('#vfBtn'); await C.waitForTimeout(1500);
    eq(L+'：マイページから確認できる',await C.evaluate(()=>JSON.parse(localStorage.getItem('pk_auth')).v),true);
    eq(L+'：エラーなし',C.errs,[]);
  }
  eq('画面のエラーなし',[A.errs,B.errs],[[],[]]);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
