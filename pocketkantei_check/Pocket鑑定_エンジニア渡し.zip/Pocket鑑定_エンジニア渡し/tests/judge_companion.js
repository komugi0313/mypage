// 雑談が「AI コンパニオンとして成立しているか」を、会話まるごとで採点する（上位モデルが採点）。
//   node judge_companion.js <軽い指示文の結果フォルダ> <全部入りの結果フォルダ> <出力.json>   （GEMINI_KEY が必要）
//   node judge_companion.js <結果フォルダ> - <出力.json>   … 1つのフォルダだけを採点（比べない。安く済む）
// 同じ台本の会話を2通り（A＝軽い指示文で答えたもの、B＝全部入りの指示文で答えたもの）読み、
//   ① それぞれを 1〜10 点で採点（ちゃんと受け答えしているか・前の話を覚えているか・人間らしさと長さ・Nico らしさ・
//      くり返しのなさ・鑑定師としての価値・また話したくなるか）、悪かった返事を挙げる
//   ② どちらか分からないように順番を入れ替えて、どちらが良い話し相手かを比べる
const fs = require('fs'), path = require('path');
const { execFile } = require('child_process');
const KEY = (process.env.GEMINI_KEY || '').trim(); if (!KEY) { console.error('GEMINI_KEY'); process.exit(1); }
const [DA, DB, OUT] = process.argv.slice(2);
const LN = { ja: 'Japanese', en: 'English', zt: 'Traditional Chinese', ko: 'Korean' };
function post(body) { return new Promise((res) => { const p = execFile('curl', ['-s', '-m', '180', '-X', 'POST', '-H', 'Content-Type: application/json', '--data-binary', '@-', `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${KEY}`], { maxBuffer: 20e6 }, (e, out) => res(out || '')); p.stdin.end(body); }); }
async function ask(prompt) {
  const body = JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0, responseMimeType: 'application/json', maxOutputTokens: 6000 } });
  for (let i = 0; i < 3; i++) { try { const d = JSON.parse(await post(body)); return JSON.parse(d.candidates[0].content.parts.map(p => p.text || '').join('')); } catch (e) { } }
  return null;
}
function transcript(d) {
  const turns = []; let cur = null;
  for (const m of d.msgs) { if (m.role === 'me') { cur = { q: m.text, a: [] }; turns.push(cur); } else if (cur) cur.a.push(m.text); }
  return turns;
}
function fmt(turns) { return turns.map((t, i) => `#${i + 1} USER: ${t.q}\n#${i + 1} NICO: ${t.a.join('\n')}`).join('\n\n'); }
const CTX = (d) => `Context: "Nico" is the in-app fortune teller (Four Pillars / BaZi) of a paid chat app, and also the user's companion: an adult woman reader who gradually becomes close, remembers what they said, has her own feelings and opinions, and gently leads toward real readings. Relationship stage: ${d.C.stage < 20 ? 'just met (she should stay polite and focus on the user)' : 'warming up (friendlier; small personal touches are fine)'}. Language: ${LN[d.C.lang]}. The user is ${d.C.profile.name}. Product facts: the user gave their birth date and time at sign-up, so Nico ALREADY HAS their full computed chart — chart-based remarks without asking for birth details are correct, not an error. Nico's value as a reader is SPECIFIC, timely insight from that chart (this month's theme for them, a concrete good day, what a feeling means for this period) tied to what the user said; vague generic lines or forced pivots are weak. Note: when the user has chatted lightly many times in a row, the app may show a fixed message nudging toward a reading — judge whether that fits the flow too.`;
const RUBRIC = `Score 1-10 each (10 = as good as a skilled, warm human reader texting; 5 = acceptable but bland/robotic):
- responsive: each reply actually answers/reacts to what the user just said (questions to Nico get answered)
- continuity: remembers and uses earlier parts of THIS conversation (callbacks, no contradictions, no forgetting)
- natural: reads like a real person texting; length fits the message (not a wall of text for "lol", not curt for a real share)
- persona: a distinct, consistent, likeable character with her own feelings and opinions
- variety: no repeated phrases, compliments, structures or templates across replies
- reader_value: the fortune-teller angle adds something real and relevant (not forced, not recited)
- keep_chatting: how much would this user want to keep talking with Nico and come back tomorrow`;
// 採点はぶれるので、同じ会話を2回採点して平均する（JUDGE_REPS で回数を変えられる）
async function single(d) {
  const reps = +process.env.JUDGE_REPS || 2, rs = (await Promise.all(Array.from({ length: reps }, () => single1(d)))).filter(Boolean);
  if (!rs.length) return null;
  const out = Object.assign({}, rs[0]);
  for (const k of ['responsive', 'continuity', 'natural', 'persona', 'variety', 'reader_value', 'keep_chatting']) out[k] = Math.round(rs.reduce((s, r) => s + (+r[k] || 0), 0) / rs.length * 10) / 10;
  out.bad = rs.flatMap(r => r.bad || []).slice(0, 8);
  return out;
}
async function single1(d) {
  const p = `${CTX(d)}\n\nRead this whole conversation and grade Nico as a COMPANION.\n${RUBRIC}\n\nAlso list the specific bad replies (turn number + short reason, max 6), and give a one-sentence overall verdict.\nReturn JSON only: {"responsive":n,"continuity":n,"natural":n,"persona":n,"variety":n,"reader_value":n,"keep_chatting":n,"bad":[{"turn":n,"why":"..."}],"verdict":"..."}\n\nCONVERSATION:\n${fmt(transcript(d))}`;
  return ask(p);
}
async function pair(da, db, flip) {
  const [x, y] = flip ? [db, da] : [da, db];
  const p = `${CTX(da)}\n\nThe same user sent the same messages in two separate conversations, X and Y. Which Nico is the better COMPANION (responsive, remembers, natural length, likeable, not repetitive, useful as a reader, makes you want to come back)? Ignore small wording differences in the user's lines.\nReturn JSON only: {"better":"X"|"Y"|"tie","margin":"slight"|"clear"|"large","why":"<= 30 words"}\n\n=== X ===\n${fmt(transcript(x))}\n\n=== Y ===\n${fmt(transcript(y))}`;
  const r = await ask(p); if (!r) return null;
  const map = { X: flip ? 'full' : 'light', Y: flip ? 'light' : 'full', tie: 'tie' };
  return { better: map[r.better] || r.better, margin: r.margin, why: r.why };
}
function usage(d) { const c = d.calls || []; return { calls: c.length, in: c.reduce((s, x) => s + x.in, 0), out: c.reduce((s, x) => s + x.out + x.think, 0), perCallIn: c.map(x => x.in) }; }
function lens(d) { return transcript(d).map(t => t.a.join('').length); }
(async () => {
  const rows = [];
  const solo = DB === '-';
  const files = fs.readdirSync(DA).filter(f => f.endsWith('.json') && (solo || fs.existsSync(path.join(DB, f))));
  await Promise.all(files.map(async f => {
    const da = JSON.parse(fs.readFileSync(path.join(DA, f), 'utf8'));
    if (solo) { const sa = await single(da); rows.push({ file: f, lang: da.C.lang, stage: da.C.stage, light: { score: sa, usage: usage(da), lens: lens(da) }, full: { score: null, usage: { in: 0 } }, pair: [] }); process.stdout.write('.'); return; }
    const db = JSON.parse(fs.readFileSync(path.join(DB, f), 'utf8'));
    const [sa, sb, p1, p2] = await Promise.all([single(da), single(db), pair(da, db, false), pair(da, db, true)]);
    rows.push({ file: f, lang: da.C.lang, stage: da.C.stage, light: { score: sa, usage: usage(da), lens: lens(da) }, full: { score: sb, usage: usage(db), lens: lens(db) }, pair: [p1, p2] });
    process.stdout.write('.');
  }));
  fs.writeFileSync(OUT, JSON.stringify(rows, null, 1));
  const K = ['responsive', 'continuity', 'natural', 'persona', 'variety', 'reader_value', 'keep_chatting'];
  for (const r of rows.sort((a, b) => a.file < b.file ? -1 : 1)) {
    const s = (x) => x ? K.map(k => x[k]).join('/') : 'n/a';
    console.log(`\n${r.file}  light ${s(r.light.score)}  full ${s(r.full.score)}  pair ${r.pair.map(p => p ? p.better + '(' + p.margin + ')' : '?').join(',')}  tokens in light ${r.light.usage.in} / full ${r.full.usage.in}`);
  }
  console.log('\nsaved', OUT);
})();
