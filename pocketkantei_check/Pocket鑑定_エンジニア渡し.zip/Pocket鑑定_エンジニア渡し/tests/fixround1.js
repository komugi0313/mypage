// まとめて直した8つ（運営指摘 2026-11-03）：過ぎた月・相性を見てほしい・相性の結果・大事な質問の1文・くり返し・締め・言い換え。AI は呼ばない
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){r.writeHead(404);return r.end('{}');} let f=path.join(__dirname,'fx',q.url.split('?')[0]); fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
 const b=await chromium.launch(); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
 const pg=await b.newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e))); await pg.clock.install({time:new Date('2026-11-03T12:00:00+09:00')});
 let ai=0; await pg.route('https://generativelanguage.googleapis.com/**',r=>{ ai++; r.abort(); });
 await pg.addInitScript(()=>{localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_mictip','1');localStorage.setItem('pk_key','test-dummy-key');localStorage.setItem('pk_dev','1');localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1994,m:9,d:8,hh:21,tu:false,mi:0,sex:'female',place:'tokyo',plan:'pro'}));localStorage.setItem('pk_msgs','[{"role":"ai","text":"hi"}]');});
 await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(1500);
 // ① 過ぎた月
 chk('月は読み違えのない形で渡す（November 2026）',await pg.evaluate(()=>_ymW(2026,11))==='November 2026');
 let r=await pg.evaluate(()=>_dropPastFuture('恋の流れが動く時期です。特に直近では2026年1月に動きが出やすくなります。お相手の生年月日を教えてくださいね。'));
 chk('過ぎた月を「直近」と言う文を外す',!/2026年1月/.test(r)&&/生年月日/.test(r),r);
 r=await pg.evaluate(()=>_dropPastFuture('2026年1月は大きな転機でした。2027年1月に動きが出やすくなります。'));
 chk('過去の話・これからの月は残す',/2026年1月は大きな転機でした/.test(r)&&/2027年1月/.test(r),r);
 r=await pg.evaluate(()=>JSON.stringify(pkBuildMust('いつ恋が動く？',{}).map(m=>m.fact||'').join(' ')));
 chk('鑑定の材料の月に「2026/11」の形が残っていない',!/20\d\d\/\d{1,2}(?!\d)/.test(r),r);
 // ② 相性を見てほしい（お相手まだ）
 await pg.evaluate(()=>{ state.mode='self'; state.chartB=null; }); ai=0;
 await pg.fill('#askIn','相性を見てほしい'); await pg.click('#askBtn'); await pg.waitForTimeout(2500);
 let s=await pg.evaluate(()=>({on:document.getElementById('shAisho').classList.contains('on'),last:state.msgs.slice(-1)[0].text}));
 chk('「相性を見てほしい」→ お相手の生年月日を入れる画面を開く（AI は使わない）',s.on&&/生年月日と性別を選んで/.test(s.last)&&ai===0,{s,ai});
 await pg.evaluate(()=>closeSheets());
 chk('「私と相性がいいのはどんな人？」は画面を開かない（ふつうの質問）',!(await pg.evaluate(()=>RE_COMPAT_ASK.test('私と相性がいいのはどんな人？'))));
 // ③④ 大事な質問は雑談の2文に切らない
 const plain=await pg.evaluate(()=>['私たちうまくいく？','今の会社に残るとどうなる？','彼は私のことどう思ってるかな','こんにちは','そうなんだ'].map(q=>[q,isPlainSmalltalk(q)]));
 chk('「うまくいく？」「会社に残ると？」「どう思ってる？」は鑑定として答える',plain.slice(0,3).every(x=>!x[1]),plain);
 chk('「こんにちは」「そうなんだ」は今まで通り雑談',plain.slice(3).every(x=>x[1]),plain);
 chk('お相手の生年月日を入れた直後は、雑談として切らない',await pg.evaluate(()=>{ window._newPartnerTurn=true; const v=isPlainSmalltalk('1992年3月10日生まれの男性です'); window._newPartnerTurn=false; return v===false; }));
 // ⑤ くり返し
 const sig=await pg.evaluate(()=>{ window._sigRecent=[]; const out=[]; for(let i=0;i<3;i++){ const M=pkBuildMust('転職した方がいい？',{}); const x=M.find(m=>/distinctive/.test(m.label)); out.push(x?x.fact:'(なし)'); } return out; });
 chk('「その人の特徴」は3回続けて同じものを入れない',sig[0]!==sig[1]&&(sig[1]!==sig[2]||sig[2]==='(なし)'),sig);
 const mv=await pg.evaluate(()=>{ window._moneyVdAt=0; const has=()=>pkBuildMust('私って金運ないの？',{}).some(m=>/direct verdict on money/.test(m.label)); const a=has(); state.msgs.push({role:'me',text:'x'}); const b2=has(); return [a,b2]; });
 chk('金運の総評は、続けて入れない',mv[0]===true&&mv[1]===false,mv);
 // ⑥ 締め
 const wu=await pg.evaluate(()=>['ありがとう、少し考えてみる','ありがとう、ちょっと勇気出た','ありがとう、次は仕事運を見て','ありがとう、いつ頃動けばいい？'].map(q=>[q,_isWrapUp(q)]));
 chk('「ありがとう、考えてみる」「勇気出た」は締め',wu[0][1]&&wu[1][1],wu);
 chk('「ありがとう、次は〜を見て」「いつ頃？」は締めにしない',!wu[2][1]&&!wu[3][1],wu);
 r=await pg.evaluate(()=>{ window._wrapUp=true; const x=_wrapClose('少しでも心が軽くなったなら、私もうれしいです。まずは11月、どんな話から始めてみようか、アイデアは浮かんでいますか？'); window._wrapUp=false; return x; });
 chk('締めの返事では最後の問いかけを外し、「またいつでも〜」で終える',!/[?？]/.test(r)&&/またいつでも/.test(r),r);
 // ⑦ 言い換え
 r=await pg.evaluate(()=>_plainVerbs('社会に関わる部分には、内側に秘めた才能が表に出てくる特徴があります。'));
 chk('「内側に秘めた」→「内側に持つ」（「内側に内に」にならない）',/内側に持つ才能/.test(r)&&!/内に内に|内側に内に/.test(r),r);
 chk('画面のエラーなし',errs.length===0,errs);
 console.log(ok+' OK / '+ng+' NG'); await b.close(); srv.close(); });
