// まとめて直した8つ（運営指摘 2026-11-03）：過ぎた月・相性を見てほしい・相性の結果・大事な質問の1文・くり返し・締め・言い換え。AI は呼ばない
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){r.writeHead(404);return r.end('{}');} let f=path.join(__dirname,'fx',q.url.split('?')[0]); fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
 const b=await chromium.launch(); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
 const pg=await b.newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e))); await pg.clock.install({time:new Date('2026-11-03T12:00:00+09:00')});
 let ai=0; await pg.route('https://generativelanguage.googleapis.com/**',r=>{ ai++; r.abort(); });
 await pg.addInitScript(()=>{localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_mictip','1');localStorage.setItem('pk_key','test-dummy-key');localStorage.setItem('pk_dev','1');localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1994,m:9,d:8,hh:21,tu:false,mi:0,sex:'female',place:'tokyo',plan:'pro'}));localStorage.setItem('pk_msgs','[{"role":"ai","text":"hi"}]');});
 await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(1500);
 // ① 過ぎた月
 chk('月は読み違えのない形で渡す（November 2026）',await pg.evaluate(()=>_ymW(2026,11))==='November 2026');
 let r=await pg.evaluate(()=>_dropPastFuture('恋の流れが動く時期です。特に直近では2026年1月に動きが出やすくなります。お相手の生年月日を教えてくださいね。'));
 chk('過ぎた月を「直近」と言う文を外す',!/2026年1月/.test(r)&&/生年月日/.test(r),r);
 r=await pg.evaluate(()=>_dropPastFuture('2026年1月は大きな転機でした。2027年1月に動きが出やすくなります。'));
 chk('過去の話・これからの月は残す',/2026年1月は大きな転機でした/.test(r)&&/2027年1月/.test(r),r);
 r=await pg.evaluate(()=>JSON.stringify(pkBuildMust('いつ恋が動く？',{}).map(m=>m.fact||'').join(' ')));
 chk('鑑定の材料の月に「2026/11」の形が残っていない',!/20\d\d\/\d{1,2}(?!\d)/.test(r),r);
 // ② 相性を見てほしい（お相手まだ）
 await pg.evaluate(()=>{ state.mode='self'; state.chartB=null; }); ai=0;
 await pg.fill('#askIn','相性を見てほしい'); await pg.click('#askBtn'); await pg.waitForTimeout(2500);
 let s=await pg.evaluate(()=>({on:document.getElementById('shAisho').classList.contains('on'),last:state.msgs.slice(-1)[0].text}));
 chk('「相性を見てほしい」→ お相手の生年月日を入れる画面を開く（AI は使わない）',s.on&&/生年月日と性別を選んで/.test(s.last)&&ai===0,{s,ai});
 await pg.evaluate(()=>closeSheets());
 chk('「私と相性がいいのはどんな人？」は画面を開かない（ふつうの質問）',!(await pg.evaluate(()=>RE_COMPAT_ASK.test('私と相性がいいのはどんな人？'))));
 // ③④ 大事な質問は雑談の2文に切らない
 const plain=await pg.evaluate(()=>['私たちうまくいく？','今の会社に残るとどうなる？','彼は私のことどう思ってるかな','こんにちは','そうなんだ'].map(q=>[q,isPlainSmalltalk(q)]));
 chk('「うまくいく？」「会社に残ると？」「どう思ってる？」は鑑定として答える',plain.slice(0,3).every(x=>!x[1]),plain);
 chk('「こんにちは」「そうなんだ」は今まで通り雑談',plain.slice(3).every(x=>x[1]),plain);
 chk('お相手の生年月日を入れた直後は、雑談として切らない',await pg.evaluate(()=>{ window._newPartnerTurn=true; const v=isPlainSmalltalk('1992年3月10日生まれの男性です'); window._newPartnerTurn=false; return v===false; }));
 // ⑤ くり返し
 const sig=await pg.evaluate(()=>{ window._sigRecent=[]; const out=[]; for(let i=0;i<3;i++){ const M=pkBuildMust('転職した方がいい？',{}); const x=M.find(m=>/distinctive/.test(m.label)); out.push(x?x.fact:'(なし)'); } return out; });
 chk('「その人の特徴」は3回続けて同じものを入れない',sig[0]!==sig[1]&&(sig[1]!==sig[2]||sig[2]==='(なし)'),sig);
 const mv=await pg.evaluate(()=>{ window._moneyVdAt=0; const has=()=>pkBuildMust('私って金運ないの？',{}).some(m=>/direct verdict on money/.test(m.label)); const a=has(); state.msgs.push({role:'me',text:'x'}); const b2=has(); return [a,b2]; });
 chk('金運の総評は、続けて入れない',mv[0]===true&&mv[1]===false,mv);
 // ⑥ 締め
 const wu=await pg.evaluate(()=>['ありがとう、少し考えてみる','ありがとう、ちょっと勇気出た','ありがとう、次は仕事運を見て','ありがとう、いつ頃動けばいい？'].map(q=>[q,_isWrapUp(q)]));
 chk('「ありがとう、考えてみる」「勇気出た」は締め',wu[0][1]&&wu[1][1],wu);
 chk('「ありがとう、次は〜を見て」「いつ頃？」は締めにしない',!wu[2][1]&&!wu[3][1],wu);
 r=await pg.evaluate(()=>{ window._wrapUp=true; const x=_wrapClose('少しでも心が軽くなったなら、私もうれしいです。まずは11月、どんな話から始めてみようか、アイデアは浮かんでいますか？'); window._wrapUp=false; return x; });
 chk('締めの返事では最後の問いかけを外し、「またいつでも〜」で終える',!/[?？]/.test(r)&&/またいつでも/.test(r),r);
 // ⑦ 言い換え
 r=await pg.evaluate(()=>_plainVerbs('社会に関わる部分には、内側に秘めた才能が表に出てくる特徴があります。'));
 chk('「内側に秘めた」→「内側に持つ」（「内側に内に」にならない）',/内側に持つ才能/.test(r)&&!/内に内に|内側に内に/.test(r),r);
 r=await pg.evaluate(()=>_plainVerbs('生涯お金に困るような運気ではありません。職場では手厚い守りがあります。'));
 chk('言い切りすぎ「生涯お金に困るような運気ではありません」・「手厚い守り」をやわらげる',!/生涯|守り/.test(r)&&/大きく困りにくい/.test(r),r);
 r=await pg.evaluate(()=>{ state.msgs=[{role:'me',text:'転職した方がいい？'},{role:'ai',text:'準備して動くのが良いです。職場で困った時に同僚から助けが入りやすい傾向があります。2017年から2026年までの10年間は仕事の動きが多い時期です。'},{role:'me',text:'今の会社に残るとどうなる？'}]; window._lastQ='今の会社に残るとどうなる？';
   return _dropRepeatTopics('残っても居場所を失う心配はありません。ただ、自由に技術を活かしたい気持ちが抑えられ、物足りなさがたまりやすくなります。あなたには目上の人から引き立てを受ける強さがあります。2017年から2026年までの10年間はビジネスの動きが多い時期です。残るなら2028年に向けた準備期間と割り切るのがおすすめです。'); });
 chk('前の返事で話した「助けが入る」「この10年」を言い換えてまた話す文は外す',!/引き立て/.test(r)&&!/2017年から2026年/.test(r)&&/物足りなさ/.test(r)&&/2028年/.test(r),r);
 r=await pg.evaluate(()=>{ window._lastQ='誰が助けてくれるの？'; return _dropRepeatTopics('目上の人から引き立てを受けやすいです。特に職場の上司が力になってくれます。'); });
 chk('その話題を聞かれた時は外さない',/引き立て/.test(r),r);
 r=await pg.evaluate(()=>_trimLight('険悪になりたくなくて、自分の気持ちを後回しにして苦しくなる場面はありませんか？ 流されずに本音を守ることができますよ。 まずは今の心地よい距離感を保ちたいという本音を、優しく伝えてみるのはいかがでしょうか。何か不安なことはありますか？','険悪にはなりたくない'));
 chk('短い返事でも、問いかけだけにしない（提案の文を残す）',/伝えてみるのはいかが/.test(r)&&(r.match(/[?？]/g)||[]).length<=1,r);
 r=await pg.evaluate(()=>_fixJoints('そのお気持ち、すごくよく分かります。それとも、周囲の目が気になっていますか？'));
 chk('前に問いかけが無い「それとも、」を外す',r==='そのお気持ち、すごくよく分かります。周囲の目が気になっていますか？',r);
 r=await pg.evaluate(()=>_fixJoints('恋愛として見られますか？それとも、今の関係を守りたいですか？'));
 chk('前が問いかけの「それとも、」は残す',/それとも、/.test(r),r);
 r=await pg.evaluate(()=>_fixJoints('すぐに困ることはありません。ただ、残ったからといって安心とは言えません。ただ、自由に動けない時間が続きます。'));
 chk('「ただ、…。ただ、…」と続く時は2つ目の「ただ、」を外す',(r.match(/ただ、/g)||[]).length===1,r);
 chk('文脈を読む決まり（過去の出来事を予定と取り違えない）が、毎回の指示に入っている',/READ THE CONTEXT FIRST/.test(require('fs').readFileSync(__dirname+'/fx/index.html','utf8')));
 r=await pg.evaluate(()=>{ state.msgs=[{role:'me',text:'先輩から告白されちゃった'},{role:'ai',text:'驚かれたと思います。その場では何かお返事をされたのでしょうか？'},{role:'me',text:'先輩は2006年6月7日生まれの男性です'},{role:'ai',text:'とても縁の深い組み合わせです。'},{role:'me',text:'私から誘ってたのに、逆に申し訳ない'}];
   return _dropRepeatQuestion('ご自身を責める必要はありませんよ。誠実な姿勢です。先輩にはもう何かお返事をされましたか？'); });
 chk('答えてもらえなかった質問を、言い方を変えてまた聞かない',!/お返事/.test(r)&&/責める必要はありません/.test(r),r);
 r=await pg.evaluate(()=>_dropRepeatQuestion('ご自身を責める必要はありませんよ。先輩とはサークルで毎週会いますか？'));
 chk('別のことを聞く質問は残す',/毎週会いますか/.test(r),r);
 r=await pg.evaluate(()=>_trimLight('罪悪感でいっぱいになってしまうお気持ち、すごくよく分かります。でも、誘ったのは素直で自然なことですし、思わせぶりではありませんでしたよ。 これからの人間関係を表す場所に、物事に誠実に向き合う特徴が出ています。 まずは自分を許してあげてくださいね。そのうえで、先輩にはどんな言葉で伝えるのが一番すっきりしそうでしょうか？','私から誘ってたのに、逆に申し訳ない気持ちになってる'));
 chk('「申し訳ない」への短い返事で、安心させる文を質問のために切らない',/自然なこと/.test(r),r);
 chk('「もう嫌われたかな」は鑑定の質問として答える（雑談の2文に切らない）',await pg.evaluate(()=>isPlainSmalltalk('もう嫌われたかな')===false));
 r=await pg.evaluate(()=>_trimLight('返信が来ないと不安になりますよね。 結論からお伝えすると、嫌われたと決めつける必要はまったくありません。 彼女は慎重に言葉を選ぶタイプです。 少しだけ待ってみませんか？','そうかな'));
 chk('短い返事で「決めつける必要はありません」のような答えの文を、質問のために切らない',/決めつける必要/.test(r),r);
 chk('AIの打ち間違い「真重」を直す',await pg.evaluate(()=>_plainVerbs('真重に受け止めています。'))==='慎重に受け止めています。');
 r=await pg.evaluate(()=>_plainVerbs('でも、結論からお伝えすると、嫌われたわけではありませんので安心してくださいね。これを「律音（りっとん）」と呼びます。'));
 chk('相手の気持ちを言い切らない・「律音」の読みを直す',/嫌われたと決めつける必要はありません/.test(r)&&/律音（りついん）/.test(r)&&!/わけではありません/.test(r),r);
 chk('画面のエラーなし',errs.length===0,errs);
 console.log(ok+' OK / '+ng+' NG'); await b.close(); srv.close(); });
