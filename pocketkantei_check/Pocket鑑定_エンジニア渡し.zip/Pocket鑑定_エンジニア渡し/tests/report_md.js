// 会話テストの結果を、人が読める1つのファイル（Markdown）にする。お金はかからない（AI を呼ばない）
//   node report_md.js <結果フォルダ> <出力.md> [採点.json] [見出し]
const fs = require('fs'), path = require('path');
const [DIR, OUT, JUDGE, TITLE] = process.argv.slice(2);
const LN = { ja: '日本語', en: '英語', ko: '韓国語', zt: '繁体字中国語' };
const K = { responsive: '受け答え', continuity: '前の話を覚えている', natural: '自然さ・長さ', persona: 'Nicoらしさ', variety: 'くり返しのなさ', reader_value: '鑑定師としての価値', keep_chatting: 'また話したくなるか' };
let J = {}; try { for (const r of JSON.parse(fs.readFileSync(JUDGE, 'utf8'))) J[r.file] = r.light && r.light.score; } catch (e) { }
let md = `# ${TITLE || '会話テストの結果'}\n\n`;
for (const f of fs.readdirSync(DIR).filter(f => f.endsWith('.json')).sort()) {
  const d = JSON.parse(fs.readFileSync(path.join(DIR, f), 'utf8'));
  md += `## ${LN[d.C.lang] || d.C.lang}：${d.C.profile.name}（${d.C.stage < 20 ? '出会ったばかり' : '打ち解けてきた'}）\n\n`;
  const s = J[f];
  if (s) md += Object.keys(K).map(k => `${K[k]} **${s[k]}**`).join(' ・ ') + `\n\n> ${s.verdict}\n\n` + (s.bad && s.bad.length ? s.bad.map(b => `- ${b.turn}通目：${b.why}`).join('\n') + '\n\n' : '');
  let on = false, n = 0;
  for (const m of d.msgs) { if (m.role === 'me') { on = true; n++; md += `**${n}. 利用者：** ${m.text}\n\n`; } else if (on) md += `**Nico：** ${m.text.replace(/\n+/g, ' ')}\n\n`; }
  md += '---\n\n';
}
fs.writeFileSync(OUT, md); console.log('saved', OUT);
