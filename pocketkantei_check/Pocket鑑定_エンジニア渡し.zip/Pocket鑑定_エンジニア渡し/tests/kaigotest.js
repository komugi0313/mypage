/* 日柱の魁罡（庚辰・庚戌・壬辰・壬戌・戊戌）を必ず拾うか（無料・計算だけ）。node kaigotest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const R=await pg.evaluate(()=>{ const out={bad:[],n:0,k:0,soft:{}};
    const KG=['庚辰','庚戌','壬辰','壬戌','戊戌'];
    for(let y=1950;y<=2010;y++){ for(const [m,d,hh] of [[1,15,3],[4,8,9],[7,22,15],[10,3,21],[12,28,12]]){
      const A=computeChart({name:'x',y,m,d,tu:false,hh,mi:0,sex:(y%2?'female':'male'),place:''}); state.chart=A; out.n++;
      const want=KG.indexOf(A.pro.pillars[2].ganzhi)>=0; if(want) out.k++;
      if(hasKaigo()!==want) out.bad.push([y,m,d,A.pro.pillars[2].ganzhi]);
      const st=(A.pro.stars||A.stars||[]); } }
    /* 返事の言葉の整え（専門用語をやさしくする処理）で、魁罡の言葉が消えないか */
    for(const L of ['ja','zt','ko']){ state.lang=L; out.soft[L]=_softenJargon(L==='ja'?'あなたは魁罡（かいごう・四柱推命の中でも特別に強い星）の人です。':(L==='zt'?'您是「魁罡」（八字中特別強勢的星）的人。':'괴강(사주에서 특히 강한 별)을 타고나셨어요.')); }
    out.greet=Object.keys(KAIGO_GREET); return out; });
  console.log('命式',R.n,'人のうち魁罡',R.k,'人'); console.log('  言葉の整えのあと',JSON.stringify(R.soft));
  chk('魁罡の日柱を、5つとも正しく見つける（ほかは見つけない）',R.bad.length===0&&R.k>0,R.bad.slice(0,5));
  chk('言葉の整えで「魁罡」「괴강」が消えない',/魁罡/.test(R.soft.ja)&&/魁罡/.test(R.soft.zt)&&/괴강/.test(R.soft.ko),R.soft);
  chk('最初のあいさつの文が4言語ある',['ja','en','ko','zt'].every(l=>R.greet.includes(l)),R.greet);
  const src=fs.readFileSync(path.join(ROOT,'index.html'),'utf8');
  chk('性格・人生・仕事・恋愛の質問で、この返事で必ず触れる指示がある',/MUST IN THIS REPLY — 魁罡 day/.test(src));
  chk('あいさつの性格の吹き出しに足す',/var b2=il\.one\+\(hasKaigo\(\)/.test(src));
  console.log(ok+' OK / '+ng+' NG'); await b.close(); srv.close(); });
