// 性別は最初から選んでおかない（運営指示 2026-10-31）：自分の登録・相性のお相手のどちらも、選ぶまで進めない。選んだ性別がそのまま使われる。4言語
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){ r.writeHead(404); return r.end('{}'); } let f=path.join(__dirname,'fx',decodeURIComponent(q.url.split('?')[0])); if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(d); }); }).listen(0,async()=>{
  const b=await chromium.launch(); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x).slice(0,300))); };
  const base='http://127.0.0.1:'+srv.address().port;
  const W={ja:'性別を選んで',en:'choose your sex',ko:'성별을 선택',zt:'請選擇性別'}, WB={ja:'お相手の性別',en:'other person',ko:'상대의 성별',zt:'對方的性別'};
  for(const lang of ['ja','en','ko','zt']){
    const pg=await b.newPage({viewport:{width:390,height:844}}); const errs=[], dlg=[]; pg.on('pageerror',e=>errs.push(String(e))); pg.on('dialog',d=>{ dlg.push(d.message()); d.accept(); });
    await pg.addInitScript(l=>{ localStorage.setItem('pk_lang',l); localStorage.setItem('pk_svd','1'); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_dev','1'); },lang);
    await pg.goto(base+'/index.html?start=1'); await pg.waitForTimeout(1200);
    chk(lang+'：登録の画面で、性別がどちらも選ばれていない',await pg.evaluate(()=>document.querySelectorAll('#sexSeg button.on').length===0));
    await pg.selectOption('#iy','1990'); await pg.check('#agreeChk').catch(()=>{});
    await pg.click('#regBtn'); await pg.waitForTimeout(800);
    chk(lang+'：選ばずに進むと、性別を選ぶよう案内して止まる',dlg.some(m=>m.includes(W[lang]))&&await pg.evaluate(()=>!state.profile),dlg);
    dlg.length=0; await pg.click('#sexSeg button[data-sex="male"]'); await pg.click('#regBtn'); await pg.waitForTimeout(800);
    chk(lang+'：「男性」を選ぶと、性別の案内は出ず、男性として次へ進む',await pg.evaluate(()=>state.sex==='male')&&!dlg.some(m=>m.includes(W[lang])),dlg);
    await pg.close();
    // 相性のお相手（登録済みの人）
    const pg2=await b.newPage({viewport:{width:390,height:844}}); pg2.on('pageerror',e=>errs.push(String(e))); pg2.on('dialog',d=>{ dlg.push(d.message()); d.accept(); });
    await pg2.addInitScript(l=>{ localStorage.setItem('pk_lang',l); localStorage.setItem('pk_svd','1'); localStorage.setItem('pk_seen_lp','1'); localStorage.setItem('pk_mictip','1'); localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1990,m:1,d:1,hh:12,tu:false,mi:0,sex:'male',place:'tokyo'})); localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hi'}])); },lang);
    await pg2.goto(base+'/index.html'); await pg2.waitForTimeout(1500);
    { const pg=pg2;
    await pg.evaluate(()=>openSheet('shAisho')); await pg.waitForTimeout(400);
    chk(lang+'：相性のお相手の性別も、どちらも選ばれていない',await pg.evaluate(()=>document.querySelectorAll('#bsexSeg .segb.on').length===0));
    chk(lang+'：お相手の月・日が空になっていない',await pg.evaluate(()=>!!$('bm').value&&!!$('bd').value));
    dlg.length=0; await pg.evaluate(()=>{ $('by').value='1992'; }); await pg.click('#aishoRun'); await pg.waitForTimeout(600);
    chk(lang+'：お相手の性別を選ばずに進むと、案内して止まる',dlg.some(m=>m.includes(WB[lang]))&&await pg.evaluate(()=>state.mode!=='aisho'),dlg);
    await pg.click('#bsexSeg .segb[data-sex="female"]'); await pg.click('#aishoRun'); await pg.waitForTimeout(1200);
    chk(lang+'：「女性」を選ぶと、お相手は女性として計算される',await pg.evaluate(()=>state.chartB&&state.chartB._sex==='female'));
    } chk(lang+'：画面のエラーなし',errs.length===0,errs); await pg2.close(); }
  await b.close(); srv.close(); console.log(ok+' OK / '+ng+' NG'); });
