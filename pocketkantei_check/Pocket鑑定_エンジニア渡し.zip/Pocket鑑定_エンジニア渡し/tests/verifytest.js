// メールアドレスの確認と、メールアドレスの変更（打ち間違いの直しを含む）のサーバーのテスト。Resend は偽物
//   PK_STORE=memory NODE_PATH=mock/node_modules node verifytest.js
process.env.AUTH_SECRET='test-secret-0123456789abcdef'; process.env.RESEND_API_KEY='re_test'; process.env.MAIL_FROM='Pocket Kantei <no-reply@example.com>';
const mails=[]; global.fetch=async(u,o)=>{ if(String(u).includes('api.resend.com')){ mails.push(JSON.parse(o.body)); return {ok:true}; } throw new Error('no net'); };
const A=require('./fx/functions/auth.js'), h=A.handler;
let ipN=0; const call=async(o)=>{const r=await h({httpMethod:'POST',headers:{'x-forwarded-for':'10.0.0.'+(++ipN%200)},body:JSON.stringify(o)});return [r.statusCode,JSON.parse(r.body)];};
const codeOf=(to)=>{ const m=[...mails].reverse().find(x=>x.to[0]===to); return m?(m.text.match(/\b(\d{6})\b/)||[])[1]:null; };
let ok=0,ng=0; const eq=(name,a,b)=>{ const g=JSON.stringify(a)===JSON.stringify(b); g?ok++:ng++; console.log((g?'OK  ':'NG  ')+name+(g?'':' → '+JSON.stringify(a)+' ≠ '+JSON.stringify(b))); };
(async()=>{
  // 1) 登録 → 確認コードのメール
  let [s,j]=await call({action:'register',email:'hana@exmaple.com',password:'sakura2026',data:{pk_profile:'{"y":1990}'},lang:'ja'});
  eq('登録できる・未確認',[s,j.ok,j.verified,j.mailSent],[200,true,false,true]);
  const tok=j.token, c1=codeOf('hana@exmaple.com');
  eq('確認コードのメールが届く（日本語・6桁）',[!!c1,/確認コード/.test(mails[mails.length-1].subject)],[true,true]);
  [s,j]=await call({action:'login',email:'hana@exmaple.com',password:'sakura2026'}); eq('未確認でもログインできる',[s,j.verified],[200,false]);
  // 2) 違うコード
  [s,j]=await call({action:'verify',token:tok,code:c1==='000000'?'111111':'000000'}); eq('違うコードは BAD_CODE',[s,j.code],[400,'BAD_CODE']);
  // 3) 打ち間違いに気づいて、正しいアドレスに直す（パスワードが要る）
  [s,j]=await call({action:'email_change',token:tok,password:'wrongpass1',newEmail:'hana@example.com',lang:'ja'}); eq('パスワード違いは変えられない',[s,j.code],[401,'BAD_LOGIN']);
  [s,j]=await call({action:'email_change',token:tok,password:'sakura2026',newEmail:'hana@exmaple.com',lang:'ja'}); eq('同じアドレスは SAME_EMAIL',j.code,'SAME_EMAIL');
  await call({action:'register',email:'taken@example.com',password:'sakura2026'});
  [s,j]=await call({action:'email_change',token:tok,password:'sakura2026',newEmail:'taken@example.com',lang:'ja'}); eq('使われているアドレスは EXISTS',[s,j.code],[409,'EXISTS']);
  [s,j]=await call({action:'email_change',token:tok,password:'sakura2026',newEmail:'Hana@Example.com',lang:'ja'}); eq('新しいアドレスにコードを送る',[s,j.ok,j.newEmail],[200,true,'hana@example.com']);
  const c2=codeOf('hana@example.com');
  [s,j]=await call({action:'login',email:'hana@example.com',password:'sakura2026'}); eq('コードを入れるまでは、新しいアドレスでログインできない',s,401);
  [s,j]=await call({action:'email_confirm',token:tok,code:c2}); eq('コードが合えば切り替わる・確認済み',[s,j.email,j.verified],[200,'hana@example.com',true]);
  eq('前のアドレスにお知らせが届く',!!mails.find(m=>m.to[0]==='hana@exmaple.com'&&/変更/.test(m.subject)),true);
  [s,j]=await call({action:'load',token:tok}); eq('前のトークンのまま使える（uid が変わらない）',[s,j.email,j.verified],[200,'hana@example.com',true]);
  [s,j]=await call({action:'login',email:'hana@example.com',password:'sakura2026'}); eq('新しいアドレスでログインできる・データもある',[s,JSON.parse(j.data.pk_profile).y],[200,1990]);
  const uidA=A._t.readToken(tok,process.env.AUTH_SECRET).uid, uidB=A._t.readToken(j.token,process.env.AUTH_SECRET).uid;
  eq('ログインし直しても同じ uid（課金・回数・通知がそのまま）',uidA,uidB);
  [s,j]=await call({action:'login',email:'hana@exmaple.com',password:'sakura2026'}); eq('前のアドレスではログインできない',s,401);
  [s,j]=await call({action:'register',email:'hana@exmaple.com',password:'other12345'}); eq('前のアドレスは、別の人が新しく登録できる',[s,j.ok],[200,true]);
  const uidC=A._t.readToken(j.token,process.env.AUTH_SECRET).uid;
  eq('その人は別の uid になる（前の人の記録と混ざらない）',uidC!==uidA,true);
  [s,j]=await call({action:'login',email:'hana@example.com',password:'sakura2026'}); eq('元の人は、まだ新しいアドレスで入れる',s,200);
  // 4) 確認コード：送り直し・期限・回数
  [s,j]=await call({action:'register',email:'kei@example.com',password:'sakura2026',lang:'en'}); const tk=j.token;
  eq('英語で登録すると英語のメール',/verification code/i.test(mails[mails.length-1].subject),true);
  [s,j]=await call({action:'verify_send',token:tk,lang:'en'}); eq('送り直しできる',s,200);
  [s,j]=await call({action:'verify_send',token:tk,lang:'en'}); [s,j]=await call({action:'verify_send',token:tk,lang:'en'}); eq('1時間に3通まで',[s,j.code],[429,'CODE_RATE']);
  const ck=codeOf('kei@example.com');
  for(let i=0;i<4;i++) [s,j]=await call({action:'verify',token:tk,code:'999999'===ck?'888888':'999999'});
  [s,j]=await call({action:'verify',token:tk,code:'999999'===ck?'888888':'999999'}); eq('5回間違えると、そのコードは使えない',j.code,'CODE_EXPIRED');
  [s,j]=await call({action:'verify',token:tk,code:ck}); eq('使えなくなったコードは、合っていても通らない',j.code,'CODE_EXPIRED');
  // 5) 正しく確認できる
  [s,j]=await call({action:'register',email:'mio@example.com',password:'sakura2026',lang:'ko'}); const tm=j.token;
  eq('韓国語で登録すると韓国語のメール',/인증/.test(mails[mails.length-1].subject),true);
  [s,j]=await call({action:'verify',token:tm,code:codeOf('mio@example.com')}); eq('正しいコードで確認済み',[s,j.verified],[200,true]);
  [s,j]=await call({action:'login',email:'mio@example.com',password:'sakura2026'}); eq('ログインしても確認済み',j.verified,true);
  // 6) この仕組みより前のアカウント（uid・verified の欄がない）
  const st=await A._t.getStore(); const old='old@example.com', ouid=A._t.userId(old);
  await st.setJSON('u:'+ouid,{email:old,salt:'ab',hash:A._t.hashPw('sakura2026','ab'),ver:1,created:1,updated:1,fails:0,lockUntil:0,data:{}});
  [s,j]=await call({action:'login',email:old,password:'sakura2026'}); eq('前からのアカウントもログインでき、確認済み扱い',[s,j.verified],[200,true]);
  const tko=j.token;
  [s,j]=await call({action:'email_change',token:tko,password:'sakura2026',newEmail:'new@example.com'}); [s,j]=await call({action:'email_confirm',token:tko,code:codeOf('new@example.com')});
  [s,j]=await call({action:'login',email:'new@example.com',password:'sakura2026'}); eq('前からのアカウントもアドレスを変えられ、uid はそのまま',[s,A._t.readToken(j.token,process.env.AUTH_SECRET).uid],[200,ouid]);
  // 7) パスワード再設定のリンクは、変えた後のアドレスに届き、使える
  [s,j]=await call({action:'forgot',email:'new@example.com',lang:'ja'}); const link=(mails[mails.length-1].text.match(/#reset=([0-9a-f.]+)/)||[])[1];
  [s,j]=await call({action:'reset',code:link,newPassword:'newpass2026'}); eq('変えた後のアドレスでパスワードを再設定できる',[s,j.email],[200,'new@example.com']);
  // 8) 削除すると、そのアドレスで新しく登録し直せる
  [s,j]=await call({action:'login',email:'hana@example.com',password:'sakura2026'}); const td=j.token;
  [s,j]=await call({action:'delete',token:td,password:'sakura2026'}); eq('削除できる',s,200);
  [s,j]=await call({action:'register',email:'hana@example.com',password:'sakura2026'}); eq('削除したアドレスで、新しく登録できる',[s,j.ok],[200,true]);
  console.log(`\n${ok} OK / ${ng} NG`); process.exit(ng?1:0);
})();
