// 運営の「月のまとめ」（stats.js）：本格鑑定を使った・8割・使い切った人数、新しい申し込み、上のプランへの変更（使い切った直後か）を正しく数えるか。合言葉がないと見られないか
// 準備：./setup.sh。実行：PK_STORE=memory NODE_PATH=mock/node_modules node statstest.js
process.env.AUTH_SECRET='test-secret-0123456789abcdef'; process.env.REVENUECAT_WEBHOOK_AUTH='whsec-0123456789abcdefXYZ'; process.env.GEMINI_API_KEY='dummy';
process.env.PK_TELECOM_TEST='1'; process.env.TELECOM_WEBHOOK_SECRET='tc-secret-0123456789abcdef';
global.fetch=async()=>({ok:true,status:200,text:async()=>JSON.stringify({candidates:[{content:{parts:[{text:'ok'}]}}]})});
const auth=require('./fx/functions/auth.js').handler, bill=require('./fx/functions/billing.js').handler, gem=require('./fx/functions/gemini.js').handler, tc=require('./fx/functions/telecom.js'), stats=require('./fx/functions/stats.js');
const post=(fn,body,headers={})=>fn({httpMethod:'POST',headers,body:JSON.stringify(body)});
const ask=(tok,h={})=>gem({httpMethod:'POST',headers:Object.assign({'x-pk-device':'dev1','x-pk-auth':tok},h),body:JSON.stringify({contents:[{role:'user',parts:[{text:'hi'}]}]})}).then(o=>o.statusCode);
let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
const W='whsec-0123456789abcdefXYZ', now=Date.now();
const rc=(type,uid,product,extra={})=>post(bill,{event:Object.assign({type,app_user_id:uid,product_id:product,expiration_at_ms:now+30*864e5,event_timestamp_ms:Date.now(),purchased_at_ms:now},extra)},{authorization:W});
const view=async(key,q={})=>{ const o=await stats.handler({httpMethod:'GET',headers:key?{'x-pk-admin':key}:{},query:q}); return {s:o.statusCode,b:JSON.parse(o.body)}; };
(async()=>{
  const reg=async e=>{ const r=JSON.parse((await post(auth,{action:'register',email:e,password:'sakura2026',data:{}})).body); return r.token; };
  // Standard の人：50回使い切る → 51回目は断られる
  const s=await reg('stat-std@x.com'), su=s.split('.')[0];
  await rc('INITIAL_PURCHASE',su,'pk_std_monthly');
  for(let i=0;i<51;i++) await ask(s,{'x-pk-deep':'1','x-pk-device':'dS'});
  // Pro の人：85回（8割は越えるが、使い切らない）
  const p=await reg('stat-pro@x.com'), pu=p.split('.')[0];
  await rc('INITIAL_PURCHASE',pu,'pk_pro_monthly');
  for(let i=0;i<85;i++) await ask(p,{'x-pk-deep':'1','x-pk-device':'dP'});
  // VIP の人：雑談だけ（本格鑑定は使わない）
  const v=await reg('stat-vip@x.com'), vu=v.split('.')[0];
  await rc('INITIAL_PURCHASE',vu,'pk_vip_monthly');
  for(let i=0;i<5;i++) await ask(v,{'x-pk-device':'dV'});
  // Standard の人が使い切った後に Pro へ。Pro の人は使い切らずに VIP へ
  await rc('PRODUCT_CHANGE',su,'pk_std_monthly',{new_product_id:'pk_pro_monthly'});
  await rc('PRODUCT_CHANGE',pu,'pk_pro_monthly',{new_product_id:'pk_vip_monthly'});
  // 下のプランへの変更・更新（RENEWAL）・テスト購入は数えない
  await rc('RENEWAL',vu,'pk_vip_monthly');
  await rc('PRODUCT_CHANGE',vu,'pk_vip_monthly',{new_product_id:'pk_std_monthly'});
  const t=await reg('stat-sandbox@x.com'); await rc('INITIAL_PURCHASE',t.split('.')[0],'pk_vip_monthly',{environment:'SANDBOX'});
  // ウェブ版（テレコム）で新しく申し込む
  const w=await reg('stat-web@x.com'), wu=w.split('.')[0];
  await tc.handler({httpMethod:'POST',headers:{},query:{k:process.env.TELECOM_WEBHOOK_SECRET},body:JSON.stringify({events:[{kind:'start',uid:wu,planKey:'std_m',telecomId:'T1',eventId:'e1',at:Date.now()}]})});

  // 見る
  chk('合言葉をサーバーに入れていない時は使えない（404）',(await view('x')).s===404);
  process.env.PK_ADMIN_KEY='admin-key-0123456789abcdef';
  chk('合言葉なしは断る（401）',(await view('')).s===401);
  chk('違う合言葉は断る（401）',(await view('admin-key-0123456789abcdeX')).s===401);
  const r=await view(process.env.PK_ADMIN_KEY); chk('正しい合言葉なら見られる',r.s===200&&r.b.ok&&r.b.months.length===3,r);
  const m=r.b.months[0];
  chk('Standard：使った1・8割1・使い切り1（51回目は数えない）',JSON.stringify(m.plans.std)==='{"used":1,"p80":1,"full":1}',m.plans.std);
  chk('Pro：使った1・8割1・使い切り0',JSON.stringify(m.plans.pro)==='{"used":1,"p80":1,"full":0}',m.plans.pro);
  chk('VIP：雑談だけの人は「使った人」に入らない',JSON.stringify(m.plans.vip)==='{"used":0,"p80":0,"full":0}',m.plans.vip);
  chk('新しい申し込み：Standard 2（アプリ1・ウェブ1）・Pro 1・VIP 1（テスト購入は数えない）',JSON.stringify(m.new)==='{"std":2,"pro":1,"vip":1}',m.new);
  chk('Standard→Pro 1人、うち使い切った直後 1人',JSON.stringify(m.up['std>pro'])==='{"n":1,"afterFull":1}',m.up['std>pro']);
  chk('Pro→VIP 1人、うち使い切った直後 0人',JSON.stringify(m.up['pro>vip'])==='{"n":1,"afterFull":0}',m.up['pro>vip']);
  chk('下のプランへの変更・更新は数えない',m.up['std>vip'].n===0);
  const r2=await view(process.env.PK_ADMIN_KEY,{m:m.month}); chk('月を指定して見られる',r2.s===200&&r2.b.months.length===1&&r2.b.months[0].month===m.month);
  // 名前・メール・uid が月のまとめに入っていない
  const mem=require('pk-test-store').getStore()._m; const st=[...mem.entries()].filter(([k])=>k.startsWith('st:'));
  chk('まとめには人数だけ（メール・uid が入らない）',st.length>0&&!st.some(([k,val])=>/@|[0-9a-f]{64}/.test(k+val)),st.slice(0,3));
  console.log(ok+' OK / '+ng+' NG');
})();
