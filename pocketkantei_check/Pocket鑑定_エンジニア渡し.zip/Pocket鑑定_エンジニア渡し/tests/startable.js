/* 教室資料5（変通星・十二運・吉凶星・刑冲破害・合）と、アプリの表を全部照らし合わせる  node startable.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ const S='甲乙丙丁戊己庚辛壬癸'.split(''), B='子丑寅卯辰巳午未申酉戌亥'.split(''); const ng=[]; let ok=0;
 const eqSet=(a,b)=>JSON.stringify([...(a||[])].sort())===JSON.stringify([...(b||[])].sort());
 // ③ 日干から見る星
 const R3={天乙貴人:['丑未','子申','酉亥','酉亥','丑未','子申','丑未','寅午','卯巳','卯巳'],太極貴人:['子午','子午','卯酉','卯酉','丑辰未戌','丑辰未戌','寅亥','寅亥','巳申','巳申'],福星貴人:['子寅','丑亥','子戌','酉','申','未','午','巳','辰','卯'],文昌貴人:['巳','午','申','酉','申','酉','亥','子','寅','卯'],羊刃:['卯','辰','午','未','午','未','酉','戌','子','丑'],飛刃:['酉','戌','子','丑','子','丑','卯','辰','午','未'],暗禄:['亥','戌','申','未','申','未','巳','辰','寅','丑'],金与禄:['辰','巳','未','申','未','申','戌','亥','丑','寅'],紅艶:['午','申','寅','未','辰','辰','戌','酉','子','申']};
 // 星の判定を、命式をつくって確かめる（地支1つずつ）
 const fake=(ds,br,mb,yb)=>({dayMaster:{stem:ds},pillars:[{branch:yb||'子',stem:'甲',ganzhi:'甲'+(yb||'子')},{branch:mb||'丑',stem:'乙',ganzhi:'乙'+(mb||'丑')},{branch:br,stem:ds,ganzhi:ds+br},]});
 for(const name in R3) S.forEach((ds,i)=>{ const want=R3[name][i].split(''); const got=B.filter(br=>shinsatsuHits({dayMaster:{stem:ds},pillars:[{branch:'',stem:'',ganzhi:''},{branch:'',stem:'',ganzhi:''},{branch:br,stem:ds,ganzhi:ds+br}]}).indexOf(name+'('+br+')')>=0);
   eqSet(got,want)?ok++:ng.push('③'+name+' '+ds+' 資料='+want.join('')+' アプリ='+got.join('')); });
 // ⑥ 年支・日支から見る星
 const R6={咸池:'酉午卯子酉午卯子酉午卯子',驛馬:'寅亥申巳寅亥申巳寅亥申巳',劫殺:'巳寅亥申巳寅亥申巳寅亥申',亡神:'亥申巳寅亥申巳寅亥申巳寅',血刃:'戌酉申未午巳辰卯寅丑子亥',囚獄:'午卯子酉午卯子酉午卯子酉'};
 for(const name in R6) B.forEach((base,i)=>{ const want=R6[name][i]; const t=kichi4Targets(base)||{}; (t[name]===want)?ok++:ng.push('⑥'+name+' '+base+' 資料='+want+' アプリ='+t[name]); });
 // 年支からも見ているか（年支だけで出る例）
 { const c={dayMaster:{stem:'甲'},pillars:[{branch:'子',stem:'甲',ganzhi:'甲子'},{branch:'寅',stem:'丙',ganzhi:'丙寅'},{branch:'午',stem:'甲',ganzhi:'甲午'}]}; const h=shinsatsuHits(c); h.indexOf('驛馬(寅)')>=0?ok++:ng.push('⑥ 年支からの驛馬が出ない '+h); }
 // 隔角（年→日）
 const KK='卯卯午午午酉酉酉子子子卯'; B.forEach((yb,i)=>{ const c={dayMaster:{stem:'甲'},pillars:[{branch:yb,stem:'甲',ganzhi:'甲'+yb},{branch:'',stem:'',ganzhi:''},{branch:KK[i],stem:'甲',ganzhi:'甲'+KK[i]}]}; shinsatsuHits(c).indexOf('隔角')>=0?ok++:ng.push('⑥隔角 '+yb+'→'+KK[i]); });
 // ④ 日柱干支
 const dayStar=(gz)=>shinsatsuHits({dayMaster:{stem:gz[0]},pillars:[{branch:'',stem:'',ganzhi:''},{branch:'',stem:'',ganzhi:''},{branch:gz[1],stem:gz[0],ganzhi:gz}]});
 ['庚辰','庚戌','壬辰','壬戌','戊戌'].forEach(g=>dayStar(g).indexOf('魁罡')>=0?ok++:ng.push('④魁罡 '+g)); dayStar('戊辰').indexOf('魁罡')<0?ok++:ng.push('④魁罡 戊辰は資料にない');
 ['丙午','戊午','壬子'].forEach(g=>dayStar(g).indexOf('日刃')>=0?ok++:ng.push('④日刃 '+g));
 // ⑤ 月支から見る星
 const R5={天德貴人:'巳庚丁申壬辛亥甲癸寅丙乙',月德貴人:'壬庚丙甲壬庚丙甲壬庚丙甲',天德合:'申乙壬巳丁丙寅己戊亥辛庚',月德合:'丁乙辛己丁乙辛己丁乙辛己',華蓋:'辰丑戌未辰丑戌未辰丑戌未'};
 for(const name in R5) B.forEach((mb,i)=>{ const tg=R5[name][i], isBr=B.indexOf(tg)>=0;
   const c={dayMaster:{stem:'甲'},pillars:[{branch:isBr?tg:'',stem:isBr?'':tg,ganzhi:''},{branch:mb,stem:'',ganzhi:''},{branch:'',stem:'甲',ganzhi:''}]}; shinsatsuHits(c).indexOf(name+'('+tg+')')>=0?ok++:ng.push('⑤'+name+' 月支'+mb+' 資料='+tg); });
 // ⑦ 刑冲破害
 const R7={刑:['卯','未戌','巳申','子','辰','寅申','午','丑戌','寅巳','酉','丑未','亥'],冲:'午未申酉戌亥子丑寅卯辰巳',破:'酉辰亥午丑申卯戌巳子未寅',害:'未午巳辰卯寅丑子亥戌酉申'};
 B.forEach((a,i)=>{ const want=R7.刑[i].split(''); const got=B.filter(x=>cpKei(a,x)); eqSet(got,want)?ok++:ng.push('⑦刑 '+a+' 資料='+want.join('')+' アプリ='+got.join(''));
   cpChong(a,R7.冲[i])?ok++:ng.push('⑦冲 '+a); (CP_HA[a]===R7.破[i])?ok++:ng.push('⑦破 '+a); (CP_GAI[a]===R7.害[i])?ok++:ng.push('⑦害 '+a); });
 // ⑧ 合
 [['甲','己'],['乙','庚'],['丙','辛'],['丁','壬'],['戊','癸']].forEach(([a,c])=>(CP_KANGO[a]===c&&CP_KANGO[c]===a)?ok++:ng.push('⑧干合 '+a+c));
 [['子','丑'],['寅','亥'],['卯','戌'],['辰','酉'],['巳','申'],['午','未']].forEach(([a,c])=>(CP_RIKUGO[a]===c)?ok++:ng.push('⑧支合 '+a+c));
 return {ok,ng};});
R.ng.forEach(x=>console.log('NG ',x)); console.log(`\n${R.ok} OK / ${R.ng.length} NG`);await b.close();srv.close();process.exit(R.ng.length?1:0);});
