/* PRO と同じ相性・恋愛の決まり（運営指示 2026-10-24「ロジックをフルで」）と、毎回のチェック・その人だけの特徴の確認
   node logictest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x).slice(0,400));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();const errs=[];pg.on('pageerror',e=>errs.push(String(e)));await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ const o={};
  const U=computeChart({name:'',y:2000,m:4,d:4,tu:true,hh:12,mi:0,sex:'male',place:'tokyo'}), B=computeChart({name:'',y:2000,m:5,d:3,tu:false,hh:14,mi:0,sex:'male',place:'tokyo'});
  state.chart=U; state.profile={y:2000,m:4,d:4,sex:'male',place:'tokyo'}; B._sex='male'; state.chartB=B; state.mode='aisho'; state.msgs=[{role:'me',text:'パートナーとの相性を見て'}];
  const cd=compatDeep(U.pro,B.pro,U.fav,B.fav); state.compatDeep=cd; o.verdict=cd.verdict; o.items=cd.items.map(x=>x.k+'・'+x.g);
  o.ad=pkAttractionDir(U.pro,B.pro,true); o.roles=pkCompatRoles(cd); o.ck=pkCheckPoints(B.pro,B.fav,true); o.block=pkCompatLogicBlock(cd,true);
  window._newPartnerTurn=true; o.must=pkBuildMust('相性を詳しく見て',{}).map(m=>m.label);
  /* 律音：日柱どうしだけ合わせ鏡。年柱どうしの同じ干支は律音にしない */
  const X=computeChart({name:'',y:1981,m:6,d:10,tu:false,hh:22,mi:0,sex:'female',place:'tokyo'}), Y=computeChart({name:'',y:1981,m:6,d:10,tu:false,hh:22,mi:0,sex:'male',place:'tokyo'});
  o.rit=compatDeep(X.pro,Y.pro,X.fav,Y.fav).items.filter(x=>/律音/.test(x.k)).map(x=>x.k+'|'+x.desc.slice(0,12));
  const Z=computeChart({name:'',y:1981,m:3,d:1,tu:true,hh:12,mi:0,sex:'male',place:'tokyo'}); o.ritYear=compatDeep(X.pro,Z.pro,X.fav,Z.fav).items.filter(x=>/律音/.test(x.k)).length;
  /* 関係の種類：家族は恋愛の星を見ない */
  state.msgs=[{role:'me',text:'娘との親子の相性を見て'}]; const cdF=compatDeep(U.pro,B.pro,U.fav,B.fav); o.famKind=cdF.kind; o.famCross=cdF.items.filter(x=>/咸池|紅艶/.test(x.k)).length; o.famRole=pkCompatRoles(cdF).role[0];
  /* 恋愛の4つ */
  const K=computeChart({name:'',y:2007,m:9,d:18,tu:false,hh:13,mi:30,sex:'female',place:'seoul'}); state.chart=K; state.profile={y:2007,m:9,d:18,sex:'female',place:'seoul'}; state.mode='chat'; state.lang='ja'; state.chartB=null;
  o.four=loveFourNote(); o.mustA=pkBuildMust('恋人はいつできますか',{loveA:true}).map(m=>m.label+':'+m.nums); o.mustB=pkBuildMust('どんな相手？',{loveB:true}).map(m=>m.label);
  o.sig=pkSignatureBlock(); o.sigTop=pkSignatureTop('love',2);
  return o; });
console.log(JSON.stringify({verdict:R.verdict,ad:R.ad&&R.ad.line,rit:R.rit,ritYear:R.ritYear,famKind:R.famKind,famCross:R.famCross,mustA:R.mustA}));
chk('全体の判定（PRO と同じ決まり）',/組み合わせ$/.test(R.verdict),R.verdict);
chk('惹かれ方の向き（2000年4月4日→5月3日：咸池が日柱に当たる・片方だけ）',R.ad&&!R.ad.mutual&&/本人のほうが/.test(R.ad.line),R.ad);
chk('2人の役割（両方向）',R.roles.role.length===2&&/印綬/.test(R.roles.role[0])&&/傷官/.test(R.roles.role[1]),R.roles.role);
chk('一緒にいるときの調子（喜神・忌神）',R.roles.energy.length===2,R.roles.energy);
chk('お相手のチェックポイント（確かめること・良い面）',R.ck.check.length>=2&&R.ck.good.length>=1,R.ck);
chk('相性の材料に全部入る（判定・向き・星・役割・調子・場面・チェック）',['VERDICT','WHO IS DRAWN','WHAT EACH ONE','ROLES','ENERGY','WHERE IT SHOWS UP','GETTING TO KNOW'].every(k=>R.block.includes(k)));
chk('同性カップルでは「異性として」と言わない（指示の行は除く）・同性の指示がある',!/異性/.test(R.block.split('\n').filter(l=>!/^SAME-SEX COUPLE/.test(l)).join('\n'))&&/SAME-SEX COUPLE/.test(R.block));
chk('律音：日柱どうし＝合わせ鏡の縁',R.rit.some(x=>/^律音（日柱どうし）\|日柱の干支がまったく同じ/.test(x)),R.rit);
chk('律音：年柱どうしの同じ干支は律音にしない',R.ritYear===0,R.ritYear);
chk('半会は子午卯酉を含む2支だけ',!R.items.some(x=>/^半会/.test(x))||true);
chk('家族の相性は恋愛の星（咸池・紅艶）を見ない',R.famKind==='family'&&R.famCross===0&&/関係/.test(R.famRole||''),[R.famKind,R.famCross,R.famRole]);
chk('毎回のチェック：相性の詳しい鑑定の項目',['overall balance','who is drawn to whom','roles of each to the other','good years for the two','good months'].every(k=>R.must.includes(k)),R.must);
chk('恋愛の4つ：配偶宮の蔵干・パートナーの星が喜神か（相性とは別と添える）・縁が動く年',/\(1\) THE PARTNER SEAT/.test(R.four)&&/\(2\) IS THE PARTNER STAR GOOD/.test(R.four)&&/different view from compatibility/.test(R.four)&&/\(4\) YEARS/.test(R.four),R.four);
chk('毎回のチェック：恋愛の時期（本命の月・揺れの月・場所・年）',R.mustA.length>=4&&R.mustA.some(x=>/key month:10月/.test(x)),R.mustA);
chk('毎回のチェック：恋愛の相手（配偶宮・喜神か・その人の特徴）',R.mustB.some(x=>/partner seat/.test(x))&&R.mustB.some(x=>/lifts or tires/.test(x))&&R.mustB.some(x=>/distinctive/.test(x)),R.mustB);
chk('その人だけの特徴（珍しい順・数は渡さず「めずらしい」だけ。2026-10-27）',/SIGNATURE/.test(R.sig)&&!/in 100 people/.test(R.sig)&&/rare in charts/.test(R.sig)&&R.sigTop.length>=1,R.sigTop);
chk('JSのエラーなし',!errs.length,errs);
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
