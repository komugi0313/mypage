// 毎日のひとこと（実際のAI）：出会ったばかり（ていねい）と、いつもの相棒（くだけた話し方＋前回の話の続き）を4言語で出す
//   GEMINI_KEY=… node dailytest.js 出力.json
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path'),{execFile}=require('child_process');
// Gemini への呼び出しは curl で中継する（convo.js と同じ。テスト環境のブラウザが通信の証明書を受け付けないため）
function curlPost(url,body){ return new Promise((res,rej)=>{ const p=execFile('curl',['-s','-m','120','-w','\\n%{http_code}','-X','POST','-H','Content-Type: application/json','--data-binary','@-',url],{maxBuffer:50e6},(err,out)=>{ if(err) return rej(err); const i=out.lastIndexOf('\n'); res({status:+out.slice(i+1)||500,body:out.slice(0,i)}); }); p.stdin.end(body); }); }
const KEY=(process.env.GEMINI_KEY||'').trim(); if(!KEY){ console.error('GEMINI_KEY'); process.exit(1); }
const MEM={ja:'- 明日（今日）は転職の最終面接。かなり緊張していた。',en:'- Had the final job interview yesterday; was very nervous.',ko:'- 어제 이직 최종 면접이 있었음. 많이 긴장했음.',zt:'- 昨天有轉職的最終面試，非常緊張。'};
const LAST={ja:['明日いよいよ最終面接なんだ、緊張する…','大丈夫、あなたの準備してきた力はちゃんと伝わるよ。いってらっしゃい！'],en:['Final interview tomorrow, so nervous...','You will be fine. Your preparation will show. Go get it!'],ko:['내일 드디어 최종 면접이야, 긴장돼…','괜찮아, 준비한 만큼 잘 전해질 거야. 잘 다녀와!'],zt:['明天終於要最終面試了，好緊張…','沒問題的，你準備的實力一定會被看見。加油！']};
const srv=http.createServer((q,r)=>{ let f=path.join('fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(d);});}).listen(0,async()=>{
  const base='http://127.0.0.1:'+srv.address().port, b=await chromium.launch(), out=[];
  for(const L of ['ja','en','ko','zt']) for(const stage of [0,80]) for(let k=0;k<2;k++){
    const pg=await (await b.newContext({timezoneId:'Asia/Tokyo'})).newPage();
    await pg.route('**/*',async r=>{const u=r.request().url(); if(u.startsWith(base)) return r.continue();
      if(u.startsWith('https://generativelanguage.googleapis.com/')){ try{ const res=await curlPost(u,r.request().postData()||''); return r.fulfill({status:res.status,contentType:'application/json',body:res.body}); }catch(e){ return r.abort(); } }
      return r.abort();});
    await pg.addInitScript(a=>{localStorage.setItem('pk_lang',a.L);localStorage.setItem('pk_key',a.K);localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_tmsg',String(a.stage));
      localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1991,m:5,d:9,tu:false,hh:7,mi:0,sex:'female',place:a.L==='ko'?'seoul':(a.L==='zt'?'taipei':'tokyo')}));
      if(a.stage){ localStorage.setItem('pk_mem',a.mem); localStorage.setItem('pk_msgs',JSON.stringify([{role:'me',text:a.last[0]},{role:'ai',text:a.last[1]}])); }},{L,K:KEY,stage,mem:MEM[L],last:LAST[L]});
    await pg.goto(base+'/index.html'); await pg.waitForTimeout(1500);
    const t=await pg.evaluate(()=>_dailyGreetAI().then(x=>sanitizeOut(x||'')));
    out.push({L,stage,t}); console.log(L,stage===0?'出会ったばかり':'いつもの相棒(面接の記憶あり)','|',t); await pg.close();
  }
  fs.writeFileSync(process.argv[2]||'daily.json',JSON.stringify(out,null,1)); await b.close(); srv.close();
});
