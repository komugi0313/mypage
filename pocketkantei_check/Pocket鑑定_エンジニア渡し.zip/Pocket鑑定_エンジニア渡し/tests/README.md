# Pocket鑑定 テスト

どれも公開サイトには置きません。何を確かめるかは、仕様書（zip の一番上の `Pocket鑑定_実装仕様書.md`）の「10. テスト」を見てください。

## 準備
1. `./setup.sh` を実行します。`site/` と `server/` を、テストが読む場所（`fx/`）にまとめます。`site/`・`server/` を直したら、もう一度実行します。
2. `npm i playwright` と `npx playwright install chromium` を実行します。
3. `export PK_STORE=memory NODE_PATH=mock/node_modules` を実行します。Firestore の代わりに、メモリ上の仮の保存領域（`mock/`）を使うためです。
4. 実際のAIを使うテストは、`GEMINI_KEY=<テスト用のキー>` を付けて実行します。**キーをファイルに保存しないでください。**

## 変更したら必ず流すもの（実際のAIは使いません）
```
./setup.sh
export PK_STORE=memory NODE_PATH=mock/node_modules
node unitguard.js
node e2e.js
node quotatest.js
node budgettest.js
node ui10.js
node pushtest.js
node surveytest.js
node verifytest.js
node verifyui.js
node steertest.js
node prefix.js
```

## Firebase のエミュレーターでのテスト
本物と同じ Firebase（Hosting → 関数 → Firestore）を手元で動かすテストは、`firebase/README.md` を見てください。

## 一覧

### 命式
| ファイル | 内容 | 実行例 |
|---|---|---|
| `chk1.js` | 大運の一括チェック1万件（第一運＝月柱・期間・10年ごと） | `node chk1.js` |
| `cmp184.js` | 四柱推命PRO v184 との比較2万件。基準は同じフォルダの `v184_bazi.js`（PRO v184 の計算部分だけを取り出したもの。サイトでは使わない） | `node cmp184.js` |
| `tzref.py` → `tzapp.js` → `tzcmp.py` | 出生地ごとの時差を、独立した計算（`pip install ephem`）とアプリで出して照合 | `python3 tzref.py 1 40 && node tzapp.js && python3 tzcmp.py` |

### アカウント・課金・回数
| ファイル | 内容 | 実行例 |
|---|---|---|
| `surveytest.js` | 登録時のアンケートの受け口（保存・メールの形・他サイト・大きさ） | `node surveytest.js` |
| `authtest.js` | アカウントAPI（登録〜削除・ロック・偽造トークン・Origin） | `node authtest.js` |
| `verifytest.js` | メールアドレスの確認コードと、アドレスの変更（打ち間違いの直し・uid が変わらない・前のアドレスの再登録・古いアカウント）。Resend は偽物 | `node verifytest.js` |
| `verifyui.js` | 画面：登録 → 確認コード → アドレスを直す → マイページ（確認済み・ログアウト）→ メニューからログアウト → 別の端末でログイン。韓国語・繁体字も | `node verifyui.js` |
| `e2e.js` | 2台の端末：登録 → 別の端末でログイン → ログアウト → 削除 | `node e2e.js` |
| `e2e_reset.js` | パスワード再設定（Resend は偽物） | `node e2e_reset.js` |
| `lpflow.js` / `eye.js` | 未登録の時のLPへの移動／パスワード表示ボタン | `node lpflow.js` |
| `billtest.js` / `billtest2.js` | RevenueCat の通知とプランの変化／チャットの上限に使うプラン | `node billtest.js` |
| `billui.js` | 料金画面・購入・復元・マイページ（RevenueCat は模擬） | `node billui.js` |
| `webcard.js` / `webcancel.js` | ウェブ版の決済画面への移動／自分で解約 | `node webcard.js` |
| `quotatest.js` | サーバーの回数の上限（無料・本格鑑定・数えない呼び出し・プランの詐称） | `node quotatest.js` |
| `dailytest.js` | 毎日のひとこと：出会ったばかり（ていねい）と、いつもの相棒（くだけた話し方・前回の面接を気にかける）を4言語で出す | `GEMINI_KEY=… node dailytest.js 出力.json` |
| `partnerscan.js` | 相手の誕生日の見分け（「1991年8月4日です。付き合って2年の彼です」は相手として受け付け、記念日・入社日は受け付けない。4言語） | `node partnerscan.js fx` |
| `near_*.json` | 身近な時期の質問（今月のいい日・出会いの時期・結婚の時期・二人のデートの日）。`convo.js` で流す | `GEMINI_KEY=… node convo.js near_couple_ja.json 結果.json` |
| `steertest.js` | 雑談が5回続くと AI を呼ばずに本格鑑定へ案内し、選択肢の質問はさえぎらない（4言語。AI は偽物） | `node steertest.js` |
| `planui2.js` | 本格鑑定の数え方と、使い切った時の画面 | `node planui2.js` |
| `budgettest.js` / `budgetui.js` | 31日間使い続けた時のAI原価と利益率／雑談の割り当てを使い切った時の画面 | `node budgettest.js` |

### 画面・後処理・キャッシュ
| ファイル | 内容 | 実行例 |
|---|---|---|
| `ui10.js` | 公開中の4言語と、非公開の言語（vi）を選んでいた人（英語になる）のエラー表示と各画面 | `node ui10.js` |
| `unitguard.js` | AIの返事の後処理（言語違い・専門用語・決まり文句・相談先・〇〇・見分けの正規表現など） | `node unitguard.js` |
| `datep.js` / `bday.js` / `pb.js` | 相手の誕生日の読み取り／自分の誕生日の質問／AI用データの本人・相手の行 | `node datep.js` |
| `hl.js` | 端末の地域ごとの相談窓口 | `node hl.js` |
| `prefix.js` / `blocks.js` | 指示文の先頭の一致率／各部分が毎回変わるか | `node prefix.js` |

### ニコのメッセージ（プッシュ）
| ファイル | 内容 | 実行例 |
|---|---|---|
| `pushtest.js` | 送信の仕組み（時刻・1日1回・似た文面・言語違い・消えた端末・長く開いていない人・夏時間・旅行・夜の「おはよう」・曜日・退会）。AIと Firebase は偽物 | `node pushtest.js` |
| `pushui.js` | 画面（ウェブ版・未ログイン・オン／オフ・受け取り箱からチャットへ・10言語） | `node pushui.js` |
| `pushlive.js` / `pushlive2.js` / `pushlive3.js` | 実際のAIで10言語×距離×時間帯×曜日の文面を作る（送信はしない） | `GEMINI_KEY=… node pushlive3.js` |

### 会話の質（実際のAI）
| ファイル | 内容 | 実行例 |
|---|---|---|
| `convoall.js` | 利用者として、アプリの画面で数往復ずつ話す。国ごとの時刻で動かす。人物は `personas.json`（10言語32人）・`love_personas.json`（恋愛24人）・`crisis_personas.json`（危機） | `GEMINI_KEY=… node convoall.js love_personas.json 結果.json 8` |
| `convocheck.py` | 言語の混入・専門用語・繰り返し・誕生日の聞き直し・相談先を機械的に確かめる | `python3 convocheck.py 結果.json` |
| `fillercheck.py` | お茶・休息などの決まり文句の数 | `python3 fillercheck.py 結果.json` |
| `judge.js` | AIによる採点（具体性・行動・深さ・正直さ・解決・繰り返し・突き放し・決まり文句） | `GEMINI_KEY=… node judge.js 結果.json 採点.json` |
| `stance.js` + `stanceq.json` | ニコの姿勢（無謀な決断・「私悪くないよね？」・自分責めなど） | `GEMINI_KEY=… node stance.js 結果.json` |
| `convo.js` + `convo_*.json` | 1人の利用者として続けて会話する（目で確かめる用）。`convo_reader_ja.json`・`convo_reader_en.json` は、雑談でも命式で話すか・3回目で本題に誘うか・うれしい／悲しい報告への気持ち・「私悪くないよね？」への反対・結婚の相談の鑑定を確かめる | `GEMINI_KEY=… node convo.js convo_ja.json 結果.json` |
| `regress/`（定期テスト） | **出す前・モデルを変える前に必ず流す**決まった会話31本（日本語24・英韓繁7）。今まで見つけた間違いを場面ごとの確かめにしてある。機械で「事実の間違い（空亡の年・年齢、相性の強さ、過ぎた月、運営の誕生日、指示の漏れ、言語の混ざり）」「前に見つけた間違いの再発」「会話の問題（くり返し・答えていない・吹き出しの多すぎ・説明のない専門用語）」「動作のエラー」を数え、`報告.md` と `会話の全文.md` を作る。目標：事実0・再発0・会話の問題は返事の5%以下・動作0。費用 400〜600円（`--judge` で AI の採点 +30円ほど） | `GEMINI_KEY=… node regress/run.js 結果/2026-11-07 --judge --prev 結果/前回` |
| `lightcmp/*.json` → `judge_light.js` | 軽い発言（あいさつ・雑談）への返事に、その人の命式の根拠が入っているか・作り話（天気・場所）がないか・言語・Nico らしさ・3回目の問いかけを、上位モデルで採点する（4言語×2〜4人） | `GEMINI_KEY=… node convo.js lightcmp/zt0.json 出力/zt0.json` のあと `node judge_light.js 出力 採点.json` |
| `companion/*.json` → `judge_companion.js` | 雑談が AI の話し相手として成り立っているか。12往復の会話まるごとを、受け答え・前の話を覚えているか・自然さと長さ・Nico らしさ・くり返しのなさ・鑑定師としての価値・また話したくなるか、の7項目（1〜10点）で採点し、軽い指示文と全部入りの指示文を、どちらか分からないようにして比べる（4言語×2人）。`persona/*.json` は Nico への質問（好きな色・お酒・最近の楽しみ・性格・会いたい） | `GEMINI_KEY=… node convo.js companion/ja_a.json 軽/ja_a.json`、`PK_FORCE_FULL=1 GEMINI_KEY=… node convo.js companion/ja_a.json 全/ja_a.json` のあと `node judge_companion.js 軽 全 採点.json` |
| `bigtest.js` / `finaltest.js` / `finaltest_u.js` → `bigcheck.py` | 10言語の長い会話 | `GEMINI_KEY=… node bigtest.js && python3 bigcheck.py big_all.json` |
| `live.js` → `livecheck.py` | 10言語のランダムな会話 | `GEMINI_KEY=… node live.js && python3 livecheck.py` |

本番の Firebase（実際の Firestore・Resend・通知）での確認は、仕様書の「11. 公開前チェック」で行ってください。
