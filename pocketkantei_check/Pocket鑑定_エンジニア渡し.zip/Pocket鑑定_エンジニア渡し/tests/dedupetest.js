/* 言い換えで同じ言葉が重なった時の整え（内容は変えず、言葉だけ） node dedupetest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const eq=(n,a,b)=>{ if(a===b){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,'\n   got :',a,'\n   want:',b);} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const run=(L,x)=>pg.evaluate(([L,x])=>{ state.lang=L; return _softenJargon(x); },[L,x]);
  eq('今回の例（紅艶という、あなたの持つ華やかな魅力）',await run('ja','紅艶という、あなたの持つ華やかな魅力が強まる時期でもあるよ。'),'あなたの持つ華やかな魅力が強まる時期でもあるよ。');
  eq('咸池っていう、華やかな魅力',await run('ja','咸池っていう華やかな魅力があるね。'),'華やかな魅力があるね。');
  eq('2回目は別の言い方（意味は同じ）',await run('ja','あなたには紅艶がある。だから12月は紅艶が強く出るよ。'),'あなたには華やかな魅力がある。だから12月は人を惹きつける輝きが強く出るよ。');
  eq('1回だけならそのまま',await run('ja','あなたには紅艶があるよ。'),'あなたには華やかな魅力があるよ。');
  eq('三合が2回',await run('ja','二人には三合がある。三合は心強いよ。'),'二人には強い縁がある。深いつながりは心強いよ。');
  eq('ふつうの文は変えない',await run('ja','今日はゆっくり休んでね。明日もゆっくりでいいよ。'),'今日はゆっくり休んでね。明日もゆっくりでいいよ。');
  eq('韓国語：도화살이라는 매력운',await run('ko','도화살이라는 매력운이 강해요.'),'매력운이 강해요.');
  eq('台湾華語：桃花這個戀愛運',await run('zt','桃花這個戀愛運很旺。'),'戀愛運很旺。');
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
