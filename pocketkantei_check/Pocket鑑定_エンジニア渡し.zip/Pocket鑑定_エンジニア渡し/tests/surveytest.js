// 登録時のアンケートの受け口（server/survey.js）。保存は仮の保存領域（PK_STORE=memory）
process.env.PK_STORE = 'memory'; process.env.SITE_URL = 'https://pk.example.com';
const S = require('./fx/functions/survey.js'), M = require('pk-test-store');
const ev = (body, h) => ({ httpMethod: 'POST', headers: Object.assign({ origin: 'https://pk.example.com' }, h || {}), body });
const ok = [], ng = [];
const t = (name, c) => (c ? ok : ng).push(name);
(async () => {
  const b = 'form-name=pk-signup&uid=dev-1&name=%E3%81%AF%E3%81%AA&email=a%40example.com&topics=love,work&interests=x&source=sns&freq=first&job=office&sex=female&age=30s&country=JP&lang=ja';
  let r = await S.handler(ev(b)); t('保存できる 200', r.statusCode === 200);
  const rec = await M.getStore('pk-survey').get('s:dev-1', { type: 'json' });
  t('項目がそろう', rec && rec.email === 'a@example.com' && rec.name === 'はな' && rec.country === 'JP' && rec.lang === 'ja' && rec.topics === 'love,work' && !!rec.at);
  r = await S.handler(ev(b.replace('a%40example.com', 'bad'))); t('メールの形が違うと 400', r.statusCode === 400);
  r = await S.handler(ev(b, { origin: 'https://evil.example' })); t('他のサイトからは 403', r.statusCode === 403);
  r = await S.handler(ev('email=a%40example.com&name=' + 'x'.repeat(9000))); t('大きすぎると 413', r.statusCode === 413);
  r = await S.handler({ httpMethod: 'GET', headers: {}, body: '' }); t('GET は 405', r.statusCode === 405);
  r = await S.handler(ev('uid=../../x&email=b%40example.com')); const k = [...M.getStore('pk-survey')._m.keys()].filter(x => x.startsWith('s:')); t('端末IDの変な文字は消す', k.includes('s:x'));
  console.log(ok.map(x => 'OK ' + x).join('\n')); if (ng.length) console.log(ng.map(x => 'NG ' + x).join('\n'));
  console.log(`\n${ok.length} OK / ${ng.length} NG`);
})();
