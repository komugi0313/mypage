/* 最初は敬語（どの言語も）：あいさつ・指示文・台湾華語の「您」  node politetest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const R=await pg.evaluate(()=>{ const A=computeChart({name:'花子',y:2008,m:3,d:28,tu:false,hh:14,mi:0,sex:'female',place:''}); state.chart=A; state.profile={sex:'female'}; state.mode='chat'; state.chartB=null; const out={};
    for(const L of ['ja','en','ko','zt']){ state.lang=L; const g=GREET3[L], ng=NEAR_GREET[L]; out[L]={greet:[g.g1,g.pre,g.ten,g.love,g.g3,g.compat,g.why].join(' ')+' '+Object.values(ng.y).join(' ')+' '+Object.values(ng.m).join(' ')+' '+ng.love};
      localStorage.setItem('pk_tmsg','1'); out[L].tone0=toneBlock(); out[L].reg0=(typeof regBlock==='function')?'':'';
      out[L].soft0=_softenJargon(L==='zt'?'你的日主很有力量。可以傳給他：「你今天好嗎？」你們兩個很合。':'x');
      localStorage.setItem('pk_tmsg','25'); out[L].soft25=_softenJargon(L==='zt'?'妳的日主很有力量。':'x'); }
    localStorage.setItem('pk_tmsg','0');
    const src=document.documentElement.outerHTML; return out; });
  chk('日本語のあいさつは です・ます',/です|ます/.test(R.ja.greet)&&!/だよ|だね|してね/.test(R.ja.greet));
  chk('韓国語のあいさつに 당신 がない',!/당신/.test(R.ko.greet),R.ko.greet.match(/.{0,10}당신.{0,10}/g));
  chk('韓国語のあいさつは 해요체（-요）',/요\./.test(R.ko.greet)&&!/[가-힣](야|해|어)\./.test(R.ko.greet));
  chk('台湾華語のあいさつは 您（你・妳 を使わない）',/您/.test(R.zt.greet)&&!/[你妳](?![們们])/.test(R.zt.greet),R.zt.greet.match(/.{0,6}[你妳].{0,6}/g));
  chk('英語のあいさつにくだけた言葉がない',!/\b(gonna|wanna|girl|babe|hey)\b/i.test(R.en.greet));
  chk('指示：最初はどの言語も丁寧（台湾華語＝您、英語＝丁寧）',/Traditional Chinese \(Taiwan\) NEW = courteous: address them as 您/.test(R.ja.tone0)&&/English NEW = courteous/.test(R.ja.tone0)&&/never start casual/.test(R.ja.tone0));
  chk('台湾華語：最初の段階は返事の 你 を 您 に（「」と你們はそのまま）',R.zt.soft0.indexOf('您')>=0&&R.zt.soft0.indexOf('「你今天好嗎？」')>=0&&R.zt.soft0.indexOf('你們')>=0&&!/[你妳](?![們们])[^今]/.test(R.zt.soft0.replace(/「[^」]*」/g,'')),R.zt.soft0);
  chk('台湾華語：打ち解けたあと（25通）は 妳 のまま',/妳/.test(R.zt.soft25)&&!/您/.test(R.zt.soft25),R.zt.soft25);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
