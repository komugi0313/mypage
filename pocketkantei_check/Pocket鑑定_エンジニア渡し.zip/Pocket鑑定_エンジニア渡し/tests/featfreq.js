/* その人だけの特徴（pkFeatures）が、たくさんの命式の中でどれくらいの割合かを数えて、index.html の PK_FEAT_FREQ を作る。node featfreq.js ../site out.json */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');const ROOT=process.argv[2];
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const t0=Date.now();
const R=await pg.evaluate(()=>{ const cnt={}; let n=0; const d0=new Date(1950,0,1).getTime();
  for(let k=0;k<2000;k++){ const dt=new Date(d0+k*11*86400000+((k*7)%24)*3600000); const y=dt.getFullYear(), m=dt.getMonth()+1, d=dt.getDate();
    for(const hh of [3,11,19]) for(const sex of ['female','male']){ const ch=computeChart({name:'',y,m,d,tu:false,hh,mi:0,sex,place:'tokyo'}); if(!ch||!ch.ok) continue; n++;
      const ks=new Set(pkFeatures(ch,sex).map(f=>f.k)); ks.forEach(k2=>cnt[k2]=(cnt[k2]||0)+1); } }
  const o={}; Object.keys(cnt).sort().forEach(k=>o[k]=+(cnt[k]/n).toFixed(4)); return {n,o}; });
console.log('charts',R.n,'keys',Object.keys(R.o).length,'sec',(Date.now()-t0)/1000);
fs.writeFileSync(process.argv[3],JSON.stringify(R.o));
const arr=Object.entries(R.o).sort((a,b)=>a[1]-b[1]); console.log(arr.slice(0,15).map(x=>x.join(':')).join('  ')); console.log(arr.slice(-12).map(x=>x.join(':')).join('  '));
await b.close();srv.close();});
