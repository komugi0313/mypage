// 移したボタン（ラッキー・ピンポイント・過去・未来・つぶやき・話題を変えたい）が、英語・韓国語・繁体字でも正しい言葉で出るか（日本語が混ざらない・はみ出さない）
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');const SHOT=process.argv[2]||'';
const REPLY={ja:'今年は追い風の年です。',en:'This year has a tailwind for you.',ko:'올해는 순풍이 부는 해예요.',zt:'今年對您來說是順風的一年。'};
let L='ja'; const bodies=[];
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/gemini')){ let b=''; q.on('data',c=>b+=c); q.on('end',()=>{ bodies.push(b); const cls=q.headers['x-pk-classify']==='1';
    r.writeHead(200,{'content-type':'application/json'}); r.end(JSON.stringify({candidates:[{content:{parts:[{text: cls?'{"topic":"other","subject":"self","serious":false}':REPLY[L]}]}}]})); }); return; }
  if(q.url.startsWith('/api/')){ r.writeHead(404); return r.end('{}'); } let f=path.join(__dirname,'fx',decodeURIComponent(q.url.split('?')[0])); if(f.endsWith('/'))f+='index.html';
  fs.readFile(f,(e,d)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':(f.endsWith('.png')?'image/png':'application/javascript')}); r.end(d); }); }).listen(0,async()=>{
  const b=await chromium.launch(); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x).slice(0,400))); };
  const JA=/[぀-ヿ]/;   // ひらがな・カタカナ（日本語だけが使う字）
  for(const lang of ['en','ko','zt','ja']){ L=lang;
    const pg=await b.newPage({viewport:{width:390,height:844},deviceScaleFactor:2}); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
    await pg.addInitScript(l=>{ localStorage.setItem('pk_lang',l);localStorage.setItem('pk_mictip','1');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');
      localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1995,m:1,d:1,hh:12,tu:false,mi:0,sex:'female',place:'tokyo',plan:'pro'})); localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'hi'}])); },lang);
    await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(1500);
    const n0=await pg.evaluate(()=>state.msgs.length); await pg.fill('#askIn',{en:'How is this year?',ko:'올해 운세 어때요?',zt:'今年運勢如何？',ja:'今年の運勢はどう？'}[lang]); await pg.click('#askBtn');
    for(let i=0;i<30;i++){ await pg.waitForTimeout(700); const s=await pg.evaluate(()=>({n:state.msgs.length,busy:_askBusy||_seqRunning})); if(s.n>=n0+2&&!s.busy) break; } await pg.waitForTimeout(800);
    const row=await pg.evaluate(()=>[...document.querySelectorAll('#actionPills button')].map(b=>b.textContent));
    const fixed=await pg.evaluate(()=>[...document.querySelectorAll('#topicChips button:not(.dp)')].map(b=>b.textContent));
    if(lang!=='ja'){ chk(lang+'：ボタンの行に日本語が混ざらない',row.length===6&&!row.some(t=>JA.test(t)),row); chk(lang+'：話題の決まったボタン（白）に日本語が混ざらない',fixed.length&&!fixed.some(t=>JA.test(t)),fixed); }
    const over=await pg.evaluate(()=>[...document.querySelectorAll('#actionPills button,#topicChips button')].filter(b=>b.scrollWidth>b.clientWidth+2||b.getBoundingClientRect().right>window.innerWidth).map(b=>b.textContent));
    chk(lang+'：ボタンが画面からはみ出さない',over.length===0,over);
    const nested=await pg.evaluate(()=>[...document.querySelectorAll('.sheet')].filter(s=>s.parentElement.closest('.sheet')).map(s=>s.id));
    chk(lang+'：画面（シート）が別の画面の中に入り込んでいない',nested.length===0,nested);
    if(SHOT){ await pg.evaluate(()=>{ const x=document.getElementById('scroll'); x.scrollTop=x.scrollHeight; }); await pg.waitForTimeout(300); await pg.screenshot({path:SHOT+'_'+lang+'_1row.png'}); }
    // ラッキー
    await pg.evaluate(()=>showLuckyToday()); await pg.waitForTimeout(500);
    const lk=await pg.evaluate(()=>{ const c=[...document.querySelectorAll('.lk-card')].pop(); return c?c.innerText:''; });
    if(lang!=='ja') chk(lang+'：今日のラッキーのカードに日本語が混ざらない',lk.length>40&&!JA.test(lk),lk.slice(0,300));
    const lkOver=await pg.evaluate(()=>{ const c=[...document.querySelectorAll('.lk-card')].pop(); return c?c.getBoundingClientRect().right>window.innerWidth:true; }); chk(lang+'：今日のラッキーのカードがはみ出さない',!lkOver);
    if(SHOT){ await pg.evaluate(()=>{ const x=document.getElementById('scroll'); x.scrollTop=x.scrollHeight; }); await pg.waitForTimeout(300); await pg.screenshot({path:SHOT+'_'+lang+'_2lucky.png'}); }
    // シート3つ
    for(const [fn,id,nm] of [['openDaySheet','shDay','3day'],['openPastSheet','shPast','4past'],['openFutureSheet','shFuture','5future']]){
      await pg.evaluate(f=>window[f](),fn); await pg.waitForTimeout(400);
      const t=await pg.evaluate(id=>document.getElementById(id).innerText,id);
      if(lang!=='ja') chk(lang+'：'+nm.slice(1)+' の画面に日本語が混ざらない',t.length>20&&!JA.test(t),t.slice(0,300));
      if(lang==='ko') chk('ko：'+nm.slice(1)+' の画面のニコの言葉がていねい（반말なし）',!/(골라줘|줄게|너의|네 운|않아\.)/.test(t),t.slice(0,300));
      if(lang==='zt') chk('zt：'+nm.slice(1)+' の画面のニコの言葉が「您」（你を使わない）',!/你(?!們)/.test(t),t.slice(0,300));
      if(SHOT) await pg.screenshot({path:SHOT+'_'+lang+'_'+nm+'.png'});
      await pg.evaluate(()=>closeSheets()); await pg.waitForTimeout(200); }
    // つぶやき（送る言葉）・話題を変えたい
    bodies.length=0; const n1=await pg.evaluate(()=>state.msgs.length); await pg.evaluate(()=>nicoMuse());
    for(let i=0;i<30;i++){ await pg.waitForTimeout(700); const s=await pg.evaluate(()=>({n:state.msgs.length,busy:_askBusy||_seqRunning})); if(s.n>=n1+2&&!s.busy) break; }
    const me=await pg.evaluate(()=>state.msgs.filter(m=>m.role==='me').pop().text);
    if(lang!=='ja') chk(lang+'：つぶやきを押した時に送る言葉が、その言語',!JA.test(me),me);
    await pg.evaluate(()=>_openTopicSwitch()); await pg.waitForTimeout(300);
    const sw=await pg.evaluate(()=>document.getElementById('topicSwitchMenu').innerText);
    if(lang!=='ja') chk(lang+'：話題を変えたいのメニューに日本語が混ざらない',sw.length>10&&!JA.test(sw),sw);
    if(SHOT){ await pg.evaluate(()=>{ const x=document.getElementById('scroll'); x.scrollTop=x.scrollHeight; }); await pg.waitForTimeout(300); await pg.screenshot({path:SHOT+'_'+lang+'_6switch.png'}); }
    // 「過去を占って」を文字で
    const pw={en:'Look back at the past for me',ko:'과거를 봐 줘',zt:'回顧過去',ja:'過去を占って'}[lang]; const n2=await pg.evaluate(()=>state.msgs.length); await pg.fill('#askIn',pw); await pg.click('#askBtn'); await pg.waitForTimeout(6000);
    const pm=await pg.evaluate(()=>{ const a=state.msgs.filter(m=>m.role==='ai').pop(); return a?a.text:''; }); const pb=await pg.$eval('#pastPillBtn',e=>e.textContent).catch(()=>'');
    if(lang!=='ja') chk(lang+'：「過去を占って」の案内と、日付を選ぶボタンがその言語',pb&&!JA.test(pm)&&!JA.test(pb),{pm,pb});
    if(lang==='ko') chk('ko：「過去を占って」の案内がていねい',!/(골라줘|줄게|보자\.|좋아,)/.test(pm),pm);
    if(lang==='zt') chk('zt：「過去を占って」の案内が「您」',!/你(?!們)/.test(pm),pm);
    chk(lang+'：画面のエラーなし',errs.length===0,errs);
    await pg.close(); }
  await b.close(); srv.close(); console.log(ok+' OK / '+ng+' NG'); });
