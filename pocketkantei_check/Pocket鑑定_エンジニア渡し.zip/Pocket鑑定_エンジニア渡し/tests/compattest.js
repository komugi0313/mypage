/* 相性（すべての柱どうし）の確認：鑑定士向けツールの結果（花子さん 2008/3/28 14時・女性 と、お相手3人）と同じ関係を拾えるか
   node compattest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const R=await pg.evaluate(()=>{ const A=computeChart({name:'花子',y:2008,m:3,d:28,tu:false,hh:14,mi:0,sex:'female',place:''}); const out={A:A.pro.pillars.map(p=>p.ganzhi).join(' ')};
    for(const [k,y,m,d] of [['c1',2007,1,17],['c2',2006,8,19],['c3',2006,6,7]]){ const B=computeChart({name:'太郎',y,m,d,tu:true,hh:12,mi:0,sex:'male',place:''}); const cd=compatDeep(A.pro,B.pro,A.fav,B.fav);
      state.chart=A; state.chartB=B; state.mode='aisho'; state.compat=compatData(A.pro,B.pro); state.compatDeep=cd; const ct=coupleTiming();
      out[k]={B:B.pro.pillars.map(p=>p.ganzhi).join(' '),good:cd.good,caution:cd.caution,diff:cd.diff,items:cd.items.map(it=>it.k+'・'+it.g+(it.detail?'('+it.detail+')':'')),caut:(ct.cautYears||[]).filter(c=>c.why.some(w=>/あなたの配偶宮/.test(w))).map(c=>c.year+c.gz)}; }
    return out; });
  const has=(c,re,n)=>c.items.filter(x=>re.test(x)).length>=(n||1);
  chk('花子さんの命式（戊子 乙卯 丁卯 丁未）',R.A==='戊子 乙卯 丁卯 丁未',R.A);
  chk('お相手の日柱（辛亥・庚辰・丁卯）',R.c1.B.endsWith('辛亥')&&R.c2.B.endsWith('庚辰')&&R.c3.B.endsWith('丁卯'));
  // 1位
  chk('1位：三合（亥卯未）・強',has(R.c1,/^三合・強\(亥卯未/));
  chk('1位：方合（亥子丑）・中',has(R.c1,/^方合・中\(亥子丑/));
  chk('1位：日柱どうしの半会（卯×亥）・強',has(R.c1,/^半会・強\(卯亥/));
  chk('1位：半会は子午卯酉を含む2支だけ（月柱卯×日柱亥は数える、時柱未×日柱亥は数えない＝鑑定者の表）',has(R.c1,/^半会・中\(卯亥/)&&!has(R.c1,/^半会・中\(未亥/));
  chk('1位：支合が3か所',has(R.c1,/^支合・/,3));
  chk('1位：天戦地冲（時柱 丁未×月柱 辛丑）・弱',has(R.c1,/^天戦地冲・弱\(丁未×辛丑/));
  chk('1位：刑・破（時柱 未×年柱 戌）',has(R.c1,/^刑・弱\(三刑 未戌/)&&has(R.c1,/^破・弱\(未戌/));
  chk('1位：日干の相剋（丁×辛）',has(R.c1,/^日干の相剋/));
  chk('1位：未×丑は冲として1回だけ（刑に重ねない）',!has(R.c1,/未丑\)/));
  chk('1位：注意点は4（ツールと同じ）',R.c1.caution===4,R.c1.caution);
  // 2位
  chk('2位：三合（申子辰）・中',has(R.c2,/^三合・中\(申子辰/));
  chk('2位：干合（月柱 乙×日柱 庚）',has(R.c2,/^干合・中\(乙庚/));
  chk('2位：半会（子×辰、子×申）',has(R.c2,/^半会・.\(子辰/)&&has(R.c2,/^半会・.\(子申/));
  chk('2位：日柱どうしの害（卯×辰）・強',has(R.c2,/^害・強\(卯辰/));
  chk('2位：害（月柱 卯×日柱 辰）',has(R.c2,/^害・中\(卯辰/));
  chk('2位：刑・破（時柱 未×年柱 戌）と日干の相剋',has(R.c2,/^刑・弱\(三刑 未戌/)&&has(R.c2,/^破・弱\(未戌/)&&has(R.c2,/^日干の相剋/));
  // 3位
  chk('3位：律音（日柱どうし 丁卯）・強＝合わせ鏡の縁',has(R.c3,/^律音（日柱どうし）・強\(丁卯/));
  chk('3位：半会（時柱 未×日柱 卯）',has(R.c3,/^半会・中\(未卯/));
  chk('3位：支合が3か所',has(R.c3,/^支合・/,3));
  chk('3位：刑（年柱 子×日柱 卯）・中',has(R.c3,/^刑・中\(相刑 子卯/));
  chk('3位：破（日柱 卯×月柱 午）・中',has(R.c3,/^破・中\(卯午/));
  chk('3位：天戦地冲（年柱 戊子×月柱 甲午）・弱',has(R.c3,/^天戦地冲・弱\(戊子×甲午/));
  chk('3位：そのほか刑・破が3か所（弱）',R.c3.items.filter(x=>/^(刑|破)・弱/.test(x)).length===3);
  // 順位と時期
  chk('順位がツールと同じ（1位＞2位＞3位）',R.c1.diff>R.c2.diff&&R.c2.diff>R.c3.diff,[R.c1.diff,R.c2.diff,R.c3.diff]);
  for(const c of ['c1','c2','c3']) chk(c+'：花子さんの揺れやすい年 2029己酉・2032壬子・2036丙辰・2041辛酉',['2029己酉','2032壬子','2036丙辰','2041辛酉'].every(x=>R[c].caut.includes(x)),R[c].caut);
  console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);
});
