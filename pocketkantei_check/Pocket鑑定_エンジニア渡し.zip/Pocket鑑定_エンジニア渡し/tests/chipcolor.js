// 返事のあとのボタン（案3）：毎回6個・いまの話を深める＝緑・ほかのテーマ＝白・理由＝うすい黄・ほかのテーマは毎回回る
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');const OUT=process.argv[2]||'';
const srv=http.createServer((q,r)=>{ if(q.url.startsWith('/api/')){ r.writeHead(404); return r.end(); } let f=path.join(__dirname,'fx',decodeURIComponent(q.url.split('?')[0]));if(f.endsWith('/'))f+='index.html'; fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':(f.endsWith('.png')?'image/png':'application/javascript')});r.end(d);}); }).listen(0,async()=>{
 const b=await chromium.launch(); const pg=await b.newPage({viewport:{width:390,height:844},deviceScaleFactor:2}); const errs=[]; pg.on('pageerror',e=>errs.push(String(e))); let ok=0,ng=0; const chk=(n,c,x)=>{ c?ok++:ng++; console.log((c?'OK  ':'NG  ')+n+(c||x===undefined?'':' → '+JSON.stringify(x))); };
 await pg.addInitScript(()=>{ localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_mictip','1');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1990,m:4,d:8,hh:12,tu:false,mi:0,sex:'female',place:'tokyo'}));
   localStorage.setItem('pk_msgs',JSON.stringify([{role:'me',text:'今年の運勢はどう？'},{role:'ai',text:'今年は、追い風の年です。春から夏にかけて人とのつながりが増え、仕事の話も舞い込みやすくなります。'}])); });
 await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(1500);
 const once=async(q,ai)=>pg.evaluate(({q,ai})=>{ document.querySelectorAll('#sugg,#topicChips,#logicBtnRow').forEach(e=>e.remove()); window._pendingChips=ai; maybeTopicChips(q); appendLogicBtn(); const bs=[...document.querySelectorAll('#topicChips button')]; const lb=document.querySelector('#logicBtnRow button');
   return {chips:bs.map(b=>b.textContent),dp:bs.filter(b=>b.classList.contains('dp')).map(b=>b.textContent),bg:bs.map(b=>getComputedStyle(b).backgroundColor),lbg:lb?getComputedStyle(lb).backgroundColor:''}; },{q,ai});
 const r1=await once('今年の運勢はどう？',['運気の流れをくわしく','10年の流れも見る','向いている仕事は？']);
 chk('毎回6個',r1.chips.length===6,r1.chips);
 chk('AI が作った3個（いまの話を深める）は緑',r1.dp.length===3&&r1.dp.includes('運気の流れをくわしく')&&r1.bg[0]==='rgb(229, 239, 231)',r1);
 chk('ほかのテーマの3個は白',r1.bg.slice(3).every(x=>x==='rgb(255, 255, 255)'),r1.bg);
 chk('「なぜそう言えるの？」はうすい黄',r1.lbg==='rgb(251, 245, 227)',r1.lbg);
 if(OUT){ await pg.evaluate(()=>{ const box=document.getElementById('scroll'); box.scrollTop=box.scrollHeight; }); await pg.waitForTimeout(300); await pg.screenshot({path:OUT}); }
 const r2=await once('金運は？',['金運をくわしく','月ごとに見る','2027年の金運は？']), r3=await once('恋愛はどう？',['恋愛運をくわしく','出会いの時期は？','どんな人と縁がある？']);
 const oth=x=>x.chips.filter(c=>!x.dp.includes(c));
 chk('ほかのテーマのボタンは、毎回ちがう顔ぶれ（恋愛・お金・仕事・健康…を回す）',JSON.stringify(oth(r1))!==JSON.stringify(oth(r2))&&JSON.stringify(oth(r2))!==JSON.stringify(oth(r3)),[oth(r1),oth(r2),oth(r3)]);
 chk('ほぼ同じ意味のボタンを並べない（向いている仕事は？／私に向いてる仕事は？）',!(r1.chips.includes('向いている仕事は？')&&r1.chips.includes('私に向いてる仕事は？')),r1.chips);
 chk('画面のエラーなし',errs.length===0,errs);
 await b.close(); srv.close(); console.log(ok+' OK / '+ng+' NG'); });
