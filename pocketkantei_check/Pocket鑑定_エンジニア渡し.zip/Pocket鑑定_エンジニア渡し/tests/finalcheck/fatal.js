// 商品として決定的なミスがないか（お金のかからない機械の数え方）：最後の確認の120回の返事を見る
const fs=require('fs'),path=require('path');const D=process.argv[2]||__dirname;
const TERM={ja:/[年月日時]柱|偏印|印綬|正官|偏官|食神|傷官|比肩|劫財|正財|偏財|十二運|大運|五行|干支|咸池|華蓋|暗禄|魁罡|天乙|太極|紅艶|空亡|[木火土金水]が[0-9０-９]/g,
 en:/(Year|Month|Day|Hour) Pillar|Day Master|Indirect Resource|Direct Resource|Seven Killings|Direct Officer|Eating God|Hurting Officer|Rob Wealth|Friend|Wealth star|10-year luck|luck pillar|five elements|Wood|Fire|Earth|Metal|Water|Peach Blossom|Canopy|Nobleman|Kaigo|void/gi,
 ko:/[연월일시]주|편인|정인|편관|정관|식신|상관|비견|겁재|정재|편재|십이운|대운|오행|도화|화개|귀인|괴강|공망|목|화|토|금|수/g,
 zt:/[年月日時]柱|偏印|正印|偏官|正官|七殺|食神|傷官|比肩|劫財|正財|偏財|十二運|大運|五行|咸池|華蓋|暗祿|暗禄|魁罡|天乙|太極|紅艷|紅艶|空亡/g};
const BECAUSE={ja:/だから|ため|理由|根拠|から来て/,en:/that'?s why|because|which is why|this is why|explains/i,ko:/그래서|때문|이유|근거/,zt:/所以|因為|原因|依據|根據|這就是/};
const TOPIC={ja:[/金運|お金|収入|財/,/恋|出会|パートナー|結婚/,/転職|仕事|職/],en:[/money|income|wealth|financ/i,/love|romance|partner|relationship/i,/job|career|work/i],ko:[/금전|돈|재물|수입/,/연애|사랑|만남|인연/,/이직|직장|일|커리어/],zt:[/財|錢|收入|金錢/,/感情|戀|桃花|伴侶|緣/,/工作|職|轉職|換工作|事業/]};
const sents=(t)=>String(t).split(/(?<=[。！？!?\.])\s*|\n+/).map(s=>s.trim()).filter(s=>s.length>=12);
const grams=(s)=>{ s=s.replace(/[\s「」『』（）()、。，．,.!?！？・:：;；"'“”]/g,'').toLowerCase(); const g=new Set(); for(let i=0;i<s.length-3;i++) g.add(s.slice(i,i+4)); return g; };
const jac=(a,b)=>{ if(!a.size||!b.size) return 0; let n=0; a.forEach(x=>{ if(b.has(x)) n++; }); return n/Math.min(a.size,b.size); };
const files=fs.readdirSync(D).filter(f=>/^(ja|en|ko|zt)_\d+\.out\.json$/.test(f)).sort(); const P={logicSame:[],logicNoTerm:[],repIn:[],repAcross:[],noInvite:[],offTopic:[],long:[]}; let N=0,NL=0;
for(const f of files){ const l=f.split('_')[0], idx=+f.split('_')[1].split('.')[0], j=JSON.parse(fs.readFileSync(path.join(D,f),'utf8')); const T=[]; let cur=null;
  for(const m of j.msgs){ if(m.role==='me'){ cur={q:m.text,b:[]}; T.push(cur); } else if(cur) cur.b.push(m.text); }
  const prevS=[]; T.forEach((t,k)=>{ N++; const tx=t.b.join('\n'), S=sents(tx), G=S.map(grams), name=f.replace('.out.json','')+'#'+(k+1);
    // 同じ返事の中で、同じことを2回
    for(let a=0;a<G.length;a++) for(let b=a+1;b<G.length;b++) if(jac(G[a],G[b])>=0.6){ P.repIn.push([name,S[a],S[b]]); a=G.length; break; }
    // 前の返事と同じことをくり返す（理屈ボタンは前の答えに触れるので別に見る）
    if(k!==1){ let hit=null; G.forEach((g,i)=>{ if(hit) return; prevS.forEach(p=>{ if(!hit&&jac(g,p.g)>=0.7) hit=[S[i],p.s]; }); }); if(hit) P.repAcross.push([name,hit[0],hit[1]]); }
    // 理屈ボタン：命式の言葉で説明しているか・前の鑑定のくり返しになっていないか
    if(k===1){ NL++; const terms=new Set((tx.match(TERM[l])||[]).map(x=>x.toLowerCase())); if(terms.size<3||!BECAUSE[l].test(tx)) P.logicNoTerm.push([name,terms.size,[...terms].join(',')]);
      const prevG=grams(T[0].b.join('')), cg=grams(tx); const ov=jac(cg,prevG); if(ov>=0.55) P.logicSame.push([name,Math.round(ov*100)+'%']); }
    // 一方的：最後が問いかけで終わらない（会話が続かない）
    const last=(t.b[t.b.length-1]||'').trim(); if(!/[？?]\s*$|か。\s*$|ますか|でしょうか|みますか|right here|let me know|any time|嗎|呢|까요|나요|세요\?|また|いつでも|気軽に|anytime|feel free|whenever|언제든|편하게|隨時|歡迎|再聊/.test(last.slice(-40)))   /* 問いかけか、「また話してね」のような開いた終わり方なら良い（運営決定 2026-10-28） */ P.noInvite.push([name,last.slice(-40)]);
    if(tx.length>(l==='en'?2600:1100)) P.long.push([name,tx.length]);
    // 聞かれたことに答えているか（3つ目の質問）
    if(k===2){ const ti=idx<=4?0:(idx<=7?1:2); const hits=(tx.match(new RegExp(TOPIC[l][ti].source,'g'+(TOPIC[l][ti].flags.includes('i')?'i':'')))||[]).length; if(hits<2) P.offTopic.push([name,t.q,hits]); }
    S.forEach((s,i)=>prevS.push({s,g:G[i]})); }); }
const pct=(a,b)=>Math.round(a/b*1000)/10+'%';
console.log('返事',N,'（理屈ボタン',NL,'）');
console.log('理屈ボタンなのに前の鑑定とほぼ同じ',P.logicSame.length,pct(P.logicSame.length,NL));
console.log('理屈ボタンなのに命式の言葉での説明が少ない',P.logicNoTerm.length,pct(P.logicNoTerm.length,NL));
console.log('同じ返事の中で同じことを2回',P.repIn.length,pct(P.repIn.length,N));
console.log('前の返事と同じ文をくり返す',P.repAcross.length,pct(P.repAcross.length,N));
console.log('問いかけも「また話してね」も無く、講義のように終わる',P.noInvite.length,pct(P.noInvite.length,N));
console.log('長すぎる（日中韓1100字・英2600字超）',P.long.length,pct(P.long.length,N));
console.log('聞かれたテーマにほとんど触れない',P.offTopic.length);
fs.writeFileSync(path.join(D,'fatal.json'),JSON.stringify(P,null,1));
for(const k of Object.keys(P)) P[k].slice(0,12).forEach(x=>console.log('  ['+k+']',JSON.stringify(x).slice(0,230)));
