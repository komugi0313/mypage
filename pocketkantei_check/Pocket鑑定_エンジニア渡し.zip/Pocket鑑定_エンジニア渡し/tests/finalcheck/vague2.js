// ふわっとした言い方の判定（厳しめ・上位モデル）：読み手が「どういうこと？」と止まる文だけを数える
const fs=require('fs'),path=require('path'),{execFile}=require('child_process');const D=__dirname;const KEY=process.env.GEMINI_KEY.trim();
function curl(url,body){return new Promise(res=>{const p=execFile('curl',['-s','-m','120','-X','POST','-H','Content-Type: application/json','--data-binary','@-',url],{maxBuffer:1e7},(e,o)=>res(o||''));p.stdin.end(body);});}
const sys='You are a strict but fair reader-test editor. Read the whole fortune-telling REPLY as an ordinary reader would. Flag a sentence ONLY if a typical reader would genuinely stop and think 「どういうこと？」/"what does that actually mean?" because it claims some luck, help, protection, power, energy, flow or special quality WITHOUT saying, in that sentence or the one right before/after, who, when or in what concrete form. Do NOT flag: a conclusion that is then explained, a plain personality description, a concrete example, a timing statement, an explained chart term, or a sentence that is merely a bit general but still clearly understandable. Output ONLY JSON {"stuck":["sentence copied exactly", ...]} (empty array if none).';
(async()=>{ const R=JSON.parse(fs.readFileSync(path.join(D,'score.json'),'utf8')); let i=0;
  const run=async r=>{ const body=JSON.stringify({systemInstruction:{parts:[{text:sys}]},contents:[{role:'user',parts:[{text:'REPLY:\n'+r.text}]}],generationConfig:{temperature:0,maxOutputTokens:1500,thinkingConfig:{thinkingLevel:'low'}}});
    const o=await curl('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key='+KEY,body);
    try{ const t=JSON.parse(o).candidates[0].content.parts.map(p=>p.text||'').join(''); r.stuck=JSON.parse(t.replace(/^[^{]*/,'').replace(/[^}]*$/,'')).stuck||[]; }catch(e){ r.stuck=null; } };
  const q=R.slice(); const W=6; await Promise.all(Array.from({length:W},async()=>{ while(q.length){ await run(q.shift()); } }));
  fs.writeFileSync(path.join(D,'score2.json'),JSON.stringify(R,null,1));
  const ok=R.filter(r=>r.stuck), bad=ok.filter(r=>r.stuck.length);
  console.log('判定できた返事',ok.length,'/',R.length,'　「どういうこと？」と止まる文がある返事',bad.length,'('+Math.round(bad.length/ok.length*1000)/10+'%)');
  const byL={}; ok.forEach(r=>{ byL[r.l]=byL[r.l]||[0,0]; byL[r.l][0]++; if(r.stuck.length) byL[r.l][1]++; }); console.log(JSON.stringify(byL));
  bad.forEach(r=>console.log('  ',r.f,r.kind,JSON.stringify(r.stuck).slice(0,220)));
})();
