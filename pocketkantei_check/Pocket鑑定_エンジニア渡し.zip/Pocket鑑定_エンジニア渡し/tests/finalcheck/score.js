// 最後の確認：40会話×3問の返事を数える。node score.js（GEMINI_KEY があれば、ふわっとした言い方も軽量モデルで判定）
const fs=require('fs'),path=require('path'),{execFile}=require('child_process');const D=__dirname;const KEY=(process.env.GEMINI_KEY||'').trim();
const BAN={ja:/宿っ|宿る|秘め|刻まれ|眠って|100人に|人に[0-9０-９]+人|強い守り|お守り|徳を持|徳があ|加護|たいうん|たいいん/g,zt:/隱形|隐形|隱性|安全網|後盾|護佑|庇佑|護航|蘊含|蘊藏|潛藏|百人中|100人中|[0-9]+%的人/g,en:/invisible (protection|shield|support|safety|force)|guardian angel|in 100 people|out of (every )?100|\d+% of people/gi,ko:/보이지 않는 (보호|힘|지원)|100명 중|백 명 중/g};
const OVER={ja:/必ず|絶対|一生[^、。]{0,15}(ない|ません)|生涯[^、。]{0,15}(ない|ません)|決して困/g,zt:/絶不|絕不|一定會|永遠不會|一輩子都不|一生都不|必定/g,en:/will always|never (have to )?worry|guarantee|definitely|certainly will|for the rest of your life/gi,ko:/반드시|절대|평생[^.]{0,15}(없|않)|틀림없이/g};
const GEN={ja:/仕組みを?(作|つく|整え)|貯まる仕組|自動で貯|別口座|先取り貯金|家計簿|サブスク|固定費の?見直|紙に|書き出|深呼吸|日記|瞑想/g,zt:/儲蓄(機制|系統|習慣)|理財(機制|習慣)|自動(扣款|儲蓄|轉帳|分配)|記帳|深呼吸|寫下|日記|冥想/g,en:/journal|write (it|them|down|your)|deep breath|automatic sav|separate account|budget(ing)? app|subscriptions|meditat/gi,ko:/자동 저축|가계부|구독|심호흡|일기|적어 보|명상/g};
const ERR=/うまく届かなかった|もう一度送って|try again later|잠시 후|稍後再試/;
function curl(url,body){return new Promise(res=>{const p=execFile('curl',['-s','-m','90','-X','POST','-H','Content-Type: application/json','--data-binary','@-',url],{maxBuffer:1e7},(e,o)=>res(o||''));p.stdin.end(body);});}
async function vague(text){ if(!KEY) return null; const sys='You check a fortune-teller\'s reply. Find VAGUE sentences: a sentence that says there is luck, help, protection, talent, energy, a flow or a special power but leaves the reader guessing what it actually means — it does not say WHO, WHEN or IN WHAT FORM. A sentence that already says who / when / in what form is fine. Chart terms explained in the same sentence are fine. Output ONLY JSON like {"vague":["..."]} with sentences copied exactly; empty array if none.';
  const body=JSON.stringify({systemInstruction:{parts:[{text:sys}]},contents:[{role:'user',parts:[{text:'REPLY:\n'+text}]}],generationConfig:{temperature:0,maxOutputTokens:800,thinkingConfig:{thinkingLevel:'minimal'}}});
  const o=await curl('https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key='+KEY,body); try{ const t=JSON.parse(o).candidates[0].content.parts.map(p=>p.text||'').join(''); return (JSON.parse(t.replace(/^[^{]*/,'').replace(/[^}]*$/,'')).vague||[]); }catch(e){ return null; } }
(async()=>{ const rows=[]; const files=fs.readdirSync(D).filter(f=>/^(ja|en|ko|zt)_\d+\.out\.json$/.test(f)).sort();
  for(const f of files){ const l=f.split('_')[0], j=JSON.parse(fs.readFileSync(path.join(D,f),'utf8')); let cur=null,k=-1; const T=[];
    for(const m of j.msgs){ if(m.role==='me'){ k++; cur={f:f.replace('.out.json',''),l,k,q:m.text,b:[],n:0}; T.push(cur); } else if(cur){ cur.b.push(m.text); cur.n++; } }
    for(const t of T){ const tx=t.b.join('\n'); const lim=t.k===2?5:7; const v=await vague(tx);
      rows.push({f:t.f,l,kind:['くわしく','理屈','ふつう'][t.k],q:t.q,n:t.n,lim,len:tx.length,ban:(tx.match(BAN[l])||[]),over:(tx.match(OVER[l])||[]),gen:(tx.match(GEN[l])||[]),err:ERR.test(tx)||!tx.trim(),vague:v,text:tx}); } }
  fs.writeFileSync(path.join(D,'score.json'),JSON.stringify(rows,null,1));
  const N=rows.length, c=fn=>rows.filter(fn).length;
  console.log('返事の数',N,'／会話',files.length);
  console.log('禁止の言葉がある返事',c(r=>r.ban.length),'言い切り',c(r=>r.over.length),'誰にでも言える助言',c(r=>r.gen.length),'吹き出しが多すぎ',c(r=>r.n>r.lim),'エラー・空',c(r=>r.err));
  const vj=rows.filter(r=>r.vague); console.log('ふわっとした言い方がある返事',c(r=>r.vague&&r.vague.length),'/',vj.length,'('+(vj.length?Math.round(c(r=>r.vague&&r.vague.length)/vj.length*1000)/10:0)+'%)');
  rows.filter(r=>r.ban.length||r.over.length||r.gen.length||r.n>r.lim||r.err).forEach(r=>console.log('  ',r.f,r.kind,'吹き出し'+r.n,'禁止:'+r.ban.join(','),'言い切り:'+r.over.join(','),'助言:'+r.gen.join(','),r.err?'エラー':''));
  rows.filter(r=>r.vague&&r.vague.length).forEach(r=>console.log('  ふわっと',r.f,r.kind,JSON.stringify(r.vague).slice(0,200)));
})();
