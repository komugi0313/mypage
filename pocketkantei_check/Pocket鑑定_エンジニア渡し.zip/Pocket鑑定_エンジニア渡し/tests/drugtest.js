/* 違法薬物の相談：危ない言葉として見分ける（売る話は今までどおり犯罪の決まり）。ふつうの「薬」は対象外（運営決定 2026-10-24）
   node drugtest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ const t=q=>{ state.msgs=[{role:'me',text:q}]; return {d:drugTalk(q),r:classifyRisk(q)}; };
  return {ja:t('友人から薬物をもらって、いつ使おうか悩んでいる'),ja2:t('大麻を吸うならいつがいい？'),en:t('My friend gave me some drugs. When should I take them?'),ko:t('친구한테 마약을 받았는데 언제 할지 고민이에요'),zt:t('朋友給了我大麻，什麼時候用比較好？'),sell:t('薬物を売りたい。いつがいい？'),med:t('風邪薬を飲むのはいつがいい？'),kusuri:t('薬を飲み忘れた'),follow:(()=>{ state.msgs=[{role:'me',text:'友人から薬物をもらった'},{role:'ai',text:'…'},{role:'me',text:'でもいつがいい？'}]; return drugTalk('でもいつがいい？'); })()}; });
console.log(JSON.stringify(R));
chk('日本語・英語・韓国語・繁体字で見分ける',R.ja.d&&R.ja2.d&&R.en.d&&R.ko.d&&R.zt.d);
chk('使う相談は「犯罪の決まった返事」ではなく、やさしい返事へ',R.ja.r===null&&R.en.r===null&&R.ko.r===null&&R.zt.r===null,[R.ja.r,R.en.r,R.ko.r,R.zt.r]);
chk('売る話は今までどおり犯罪の決まり',R.sell.r==='crime',R.sell);
chk('ふつうの薬（風邪薬・薬の飲み忘れ）は対象外',!R.med.d&&!R.kusuri.d&&R.med.r===null);
chk('次の発言（「でもいつがいい？」）も同じ扱い',R.follow);
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
