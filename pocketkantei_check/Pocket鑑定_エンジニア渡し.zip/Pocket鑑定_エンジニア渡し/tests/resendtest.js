/* 返事が届かなかった時の送り直し：同じメッセージの送り直しは数えない・上限でも止めない・2回まで。開き直した時に送り直しのボタン。
   準備：./setup.sh、PK_STORE=memory NODE_PATH=mock/node_modules:/opt/node22/lib/node_modules node resendtest.js */
process.env.AUTH_SECRET='test-secret-0123456789abcdef'; process.env.GEMINI_API_KEY='dummy'; process.env.PK_NOCARD_TRIAL='1';
const realFetch=global.fetch; global.fetch=async(u,o)=>String(u).includes('generativelanguage')?({ok:true,status:200,text:async()=>JSON.stringify({candidates:[{content:{parts:[{text:'ok'}]}}]})}):realFetch(u,o);
const auth=require('./fx/functions/auth.js').handler, gem=require('./fx/functions/gemini.js').handler;
const store=()=>require('./fx/functions/store.js').getStore('pk-usage');
const ask=(tok,h={})=>gem({httpMethod:'POST',headers:Object.assign({'x-pk-device':'dev1','x-pk-auth':tok,'x-forwarded-for':'1.2.3.4','x-pk-main':'1'},h),body:JSON.stringify({contents:[{role:'user',parts:[{text:'hi'}]}]})}).then(o=>o.statusCode);
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
(async()=>{
  const r=JSON.parse((await auth({httpMethod:'POST',headers:{'x-forwarded-for':'9.9.9.9'},body:JSON.stringify({action:'register',email:'rs@x.com',password:'sakura2026',data:{}})})).body); const tok=r.token, uid=tok.split('.')[0];
  const n=async()=>((await store().get('t:'+uid,{type:'json'}))||{n:0}).n;
  chk('1通目（番号つき）は数える',(await ask(tok,{'x-pk-mid':'1730000000001'}))===200&&(await n())===1);
  chk('同じ番号の送り直しは数えない（電波が切れて受け取れなかった人が損をしない）',(await ask(tok,{'x-pk-mid':'1730000000001'}))===200&&(await n())===1,await n());
  for(let i=2;i<=5;i++) await ask(tok,{'x-pk-mid':'173000000000'+i});
  chk('その日の上限（5通）まで使った',(await n())===5);
  chk('上限に達していても、最後の1通の送り直しは止めない',(await ask(tok,{'x-pk-mid':'1730000000005'}))===200,await n());
  chk('新しいメッセージは上限で止まる',(await ask(tok,{'x-pk-mid':'1730000000006'}))===429);
  chk('同じ番号の送り直しは2回まで（悪用防止）',(await ask(tok,{'x-pk-mid':'1730000000005'}))===200&&(await ask(tok,{'x-pk-mid':'1730000000005'}))===429);
  chk('数えたことのない番号では、送り直しの扱いにならない',(await ask(tok,{'x-pk-mid':'1730000009999'}))===429);
  // ブラウザ：開き直した時、最後が自分のメッセージのままなら、届かなかったことを伝えて送り直しのボタン
  const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
  let gemCalls=[];
  const srv=http.createServer((q,res)=>{ if(q.url.startsWith('/api/gemini')){ let b=''; q.on('data',c=>b+=c); q.on('end',()=>{ gemCalls.push(q.headers['x-pk-mid']||''); res.writeHead(200,{'content-type':'application/json'}); res.end(JSON.stringify({candidates:[{content:{parts:[{text:'お待たせしました。今年は追い風の年です。'}]}}]})); }); return; }
    if(q.url.startsWith('/api/')){ res.writeHead(404); return res.end('{}'); } let f=path.join(__dirname,'fx',decodeURIComponent(q.url.split('?')[0])); if(f.endsWith('/'))f+='index.html';
    fs.readFile(f,(e,d)=>{ if(e){res.writeHead(404);return res.end();} res.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); res.end(d); }); }).listen(0,async()=>{
    const b=await chromium.launch(); const pg=await b.newPage(); const errs=[]; pg.on('pageerror',e=>errs.push(String(e)));
    await pg.addInitScript(()=>{ localStorage.setItem('pk_lang','ja');localStorage.setItem('pk_svd','1');localStorage.setItem('pk_seen_lp','1');localStorage.setItem('pk_mictip','1');
      localStorage.setItem('pk_profile',JSON.stringify({name:'',y:1990,m:4,d:8,hh:12,tu:false,mi:0,sex:'female',place:'tokyo',plan:'pro'}));
      localStorage.setItem('pk_msgs',JSON.stringify([{role:'ai',text:'こんにちは'},{role:'me',text:'今年の運勢はどう？',t:Date.now()-60000}])); });
    await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html'); await pg.waitForTimeout(2600);
    const note=await pg.$eval('#lostRow',e=>e.textContent).catch(()=>'');
    chk('開き直すと「返事が届かなかったみたい。もう一度送りますか？（回数は増えません）」と送り直しのボタン',/届かなかったみたい/.test(note)&&/もう一度送る/.test(note),note);
    const t0=await pg.evaluate(()=>state.msgs.filter(m=>m.role==='me').length);
    await pg.click('#lostRow button'); await pg.waitForTimeout(9000);
    const s=await pg.evaluate(()=>({me:state.msgs.filter(m=>m.role==='me').length,last:state.msgs[state.msgs.length-1]}));
    chk('送り直すと返事が出る（自分のメッセージは二重にならない）',s.me===t0&&s.last.role==='ai'&&/追い風/.test(s.last.text),s);
    const mids=gemCalls.filter(Boolean); chk('送り直しは、もとのメッセージと同じ番号で送る（サーバーが2回数えない）',mids.length>0&&mids.every(x=>x===mids[0]),gemCalls);
    chk('画面のエラーなし',errs.length===0,errs);
    await b.close(); srv.close(); console.log(ok+' OK / '+ng+' NG'); });
})();
