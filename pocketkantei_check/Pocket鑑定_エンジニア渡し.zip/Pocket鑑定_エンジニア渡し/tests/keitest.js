/* 命式の中の刑・自刑は使わない（当流派。運営確認 2026-10-24）。運と命式の刑・2人の相性の刑は今までどおり
   node keitest.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);fs.readFile(path.join(ROOT,u),(e,b)=>{if(e){r.writeHead(404);return r.end();}r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'});r.end(b);});});
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{const b=await chromium.launch(),pg=await b.newPage();await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1');await pg.waitForTimeout(1500);
const R=await pg.evaluate(()=>{ let natalKei=0, charts=0, withKeiPair=0; const KEI=[['子','卯'],['寅','巳'],['巳','申'],['申','寅'],['丑','戌'],['戌','未'],['未','丑'],['辰','辰'],['午','午'],['酉','酉'],['亥','亥']];
  for(let y=1960;y<=2010;y++) for(const [m,d,hh] of [[1,17,12],[4,8,9],[7,22,15],[10,3,21]]){ const A=computeChart({name:'',y,m,d,tu:false,hh,mi:0,sex:'male',place:'tokyo'}); const p=A.pro; charts++;
    const br=p.pillars.map(x=>x.branch); if(KEI.some(([a,b])=>{ const i=br.indexOf(a); return i>=0&&br.some((x,j)=>j!==i&&x===b); })) withKeiPair++;
    if(window.natalRelationsX(p).some(r=>r.kind==='刑')||window.fullProfile(p).rels.some(r=>r.kind==='刑')) natalKei++; }
  /* 運と命式の刑は残る：2007年1月17日（丙戌・辛丑・辛亥）の年運 2027 丁未 は丑・戌と刑 */
  const A=computeChart({name:'',y:2007,m:1,d:17,tu:true,hh:12,mi:0,sex:'male',place:'tokyo'}); state.chart=A; state.profile={y:2007,m:1,d:17,sex:'male'};
  const tr=(window.transitRels?window.transitRels(A.pro,'未'):[]).some(r=>r.kind==='刑');
  return {charts,withKeiPair,natalKei,tr}; });
console.log(JSON.stringify(R));
chk('命式の中に刑の組み合わせがある人が十分いる',R.withKeiPair>20,R.withKeiPair);
chk('命式の中の刑・自刑を出さない（'+R.charts+'人）',R.natalKei===0,R.natalKei);
chk('運と命式の刑は残る（2007年1月17日 × 2027 丁未）',R.tr,R.tr);
console.log(`\n${ok} OK / ${ng} NG`); await b.close(); srv.close(); process.exit(ng?1:0);});
