/* 命式の中ですでに開いている庫（墓と冠帯が命式の中で冲）→「その分野で波の大きい人生」が指示文に入るか（無料・計算だけ）。node natopen.js */
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'..','site');
const srv=http.createServer((q,r)=>{ let u=decodeURIComponent(q.url.split('?')[0]); if(u.startsWith('/api/')){r.writeHead(404);return r.end();} fs.readFile(path.join(ROOT,u),(e,b)=>{ if(e){r.writeHead(404);return r.end();} r.writeHead(200,{'content-type':u.endsWith('.html')?'text/html; charset=utf-8':'application/javascript'}); r.end(b); }); });
let ok=0,ng=0; const chk=(n,c,x)=>{ if(c){ok++;console.log('OK ',n);} else {ng++;console.log('NG ',n,x===undefined?'':JSON.stringify(x));} };
srv.listen(0,async()=>{ const b=await chromium.launch(), pg=await b.newPage(); await pg.addInitScript(()=>{localStorage.setItem('pk_seen_lp','1');});
  await pg.goto('http://127.0.0.1:'+srv.address().port+'/index.html?start=1'); await pg.waitForTimeout(1500);
  const R=await pg.evaluate(()=>{ const out={bad:[],n:0,open:0,ex:[]};
    const BO={甲:'未',癸:'未',丁:'丑',己:'丑',庚:'丑',乙:'戌',丙:'戌',戊:'戌',辛:'辰',壬:'辰'}, CL={辰:'戌',戌:'辰',丑:'未',未:'丑'};
    for(let y=1950;y<=2010;y++){ for(const [m,d,hh] of [[1,15,3],[4,8,9],[7,22,15],[10,3,21],[12,28,12]]){
      const A=computeChart({name:'x',y,m,d,tu:false,hh,mi:0,sex:(y%2?'female':'male'),place:''}); state.chart=A; state.profile={sex:'female'};
      const M=luckMap(); if(!M) continue; out.n++;
      const P=A.pro.pillars, bo=BO[P[2].stem], kan=CL[bo], has=P.some(p=>p.branch===bo)&&P.some(p=>p.branch===kan);
      const blk=luckMapBlock(), inBlk=/ALREADY OPEN IN THE CHART/.test(blk);
      if(has!==(M.natalOpen.length>0)||has!==inBlk) out.bad.push([y,m,d,hh,has,M.natalOpen.length,inBlk]);
      if(has){ out.open++; if(out.ex.length<3) out.ex.push(y+'/'+m+'/'+d+' '+hh+'時: '+(blk.match(/ALREADY OPEN[^]*?dips\. /)||[''])[0].slice(0,230)); }
    } } return out; });
  console.log('命式',R.n,'人のうち、すでに庫が開いている人',R.open); R.ex.forEach(x=>console.log('  例 '+x));
  chk('すでに開いている庫を、命式のとおりに見つける（墓と冠帯の両方がある人だけ）',R.bad.length===0,R.bad.slice(0,5));
  chk('見つけた人の指示文に「波の大きい人生」が入る',R.open>0);
  console.log(ok+' OK / '+ng+' NG'); await b.close(); srv.close(); });
