/* 紹介ページを言語ごとに書き出します。
   使い方：node tools/build-lp.js            （本番ドメイン https://pocketkantei.jp）
           PK_SITE=https://xxx.web.app node tools/build-lp.js   （別のドメインのとき）
   ・元は site/lp.html だけです。文章を直すのは lp.html の I18N / PAGE_TITLE / PAGE_DESC だけで、
     直したら必ずこれを実行し、できたファイルも一緒にデプロイします。
   ・作るもの：
       site/lp.html の <!--PK_HEAD--> の中（日本語のタイトル・説明・言語ごとのページの案内）
       site/en/index.html  site/ko/index.html  site/zt/index.html （それぞれの言語だけのページ）
       site/sitemap.xml  site/robots.txt
   ・言語ごとのページは、開いた瞬間から本文・タイトル・シェア時のカードがその言語になります。 */
const fs=require('fs'), path=require('path');
const SITE=(process.env.PK_SITE||'https://pocketkantei.jp').replace(/\/+$/,'');
const DIR=path.join(__dirname,'..','site');
const SRC=path.join(DIR,'lp.html');
let src=fs.readFileSync(SRC,'utf8');

function grab(name){ // lp.html の中の var NAME={...}; を取り出す
  const i=src.indexOf('var '+name+'={'); if(i<0) throw new Error('not found: '+name);
  let d=0,j=src.indexOf('{',i),q=null,esc=false;
  for(let k=j;k<src.length;k++){ const c=src[k];
    if(q){ if(esc) esc=false; else if(c==='\\') esc=true; else if(c===q) q=null; continue; }
    if(c==="'"||c==='"'||c==='`'){ q=c; continue; }
    if(c==='{') d++; else if(c==='}'){ d--; if(d===0) return Function('return '+src.slice(j,k+1))(); } }
  throw new Error('unclosed: '+name);
}
const I18N=grab('I18N'), TITLE=grab('PAGE_TITLE'), DESC=grab('PAGE_DESC'), PATH=grab('PK_PATH');
const LANGS=Object.keys(PATH);                       // ja en ko zt
const HREFLANG={ja:'ja',en:'en',ko:'ko',zt:'zh-Hant'};
const OGLOC={ja:'ja_JP',en:'en_US',ko:'ko_KR',zt:'zh_TW'};
const KANJI={ja:1,zt:1};
const attr=v=>String(v).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const text=v=>String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const url=l=>SITE+PATH[l];

function head(l){
  const t=TITLE[l]||TITLE.en, d=DESC[l]||DESC.en, a=[];
  a.push('<title>'+text(t)+'</title>');
  a.push('<meta name="description" content="'+attr(d)+'">');
  a.push('<link rel="canonical" href="'+url(l)+'">');
  LANGS.forEach(x=>a.push('<link rel="alternate" hreflang="'+HREFLANG[x]+'" href="'+url(x)+'">'));
  a.push('<link rel="alternate" hreflang="x-default" href="'+url('ja')+'">');  // 言語が合わない人は lp.html（その人の言語に自動で切りかわる）
  a.push('<meta property="og:type" content="website">');
  a.push('<meta property="og:site_name" content="Pocket Kantei">');
  a.push('<meta property="og:title" content="'+attr(t)+'">');
  a.push('<meta property="og:description" content="'+attr(d)+'">');
  a.push('<meta property="og:url" content="'+url(l)+'">');
  a.push('<meta property="og:image" content="'+SITE+'/icon-512.png">');
  a.push('<meta property="og:locale" content="'+OGLOC[l]+'">');
  LANGS.filter(x=>x!==l).forEach(x=>a.push('<meta property="og:locale:alternate" content="'+OGLOC[x]+'">'));
  a.push('<meta name="twitter:card" content="summary">');
  return '<!--PK_HEAD-->\n'+a.join('\n')+'\n<!--/PK_HEAD-->';
}
const HEAD_RX=/<!--PK_HEAD-->[\s\S]*?<!--\/PK_HEAD-->/;
if(!HEAD_RX.test(src)) throw new Error('lp.html に <!--PK_HEAD--> がありません');

// 1) 日本語（lp.html そのもの）
src=src.replace(HEAD_RX,head('ja'));
fs.writeFileSync(SRC,src);

// 2) 言語ごとのページ
for(const l of LANGS.filter(x=>x!=='ja')){
  const T=Object.assign({},I18N.en,I18N[l]);
  for(const k in T) if(typeof T[k]==='string') T[k]=T[k].replace(/\u30fb/g,'\u00b7');   // 日本語以外は「・」→「·」
  let h=src.replace(HEAD_RX,head(l));
  h=h.replace('<html lang="ja">','<html lang="'+HREFLANG[l]+'">');
  const before=h;
  h=h.replace("var PK_PAGE={lang:'ja',hard:false};","var PK_PAGE={lang:'"+l+"',hard:true};");
  if(h===before) throw new Error('PK_PAGE が見つかりません');
  // 本文を最初から入れておく（JSが動く前・検索エンジンにも、その言語で見える）
  h=h.replace(/(<[a-z0-9]+\b[^>]*?\bdata-t="([^"]+)"[^>]*>)(<\/)/g,(m,o,k,c)=>T[k]!=null?o+text(T[k])+c:m);
  h=h.replace(/(<[a-z0-9]+\b[^>]*?\bdata-t-html="([^"]+)"[^>]*>)(<\/)/g,(m,o,k,c)=>T[k]!=null?o+T[k]+c:m);
  if(!KANJI[l]) h=h.replace('Pocket<em>本格鑑定</em>','Pocket<em>Kantei</em>');
  fs.mkdirSync(path.join(DIR,l),{recursive:true});
  fs.writeFileSync(path.join(DIR,l,'index.html'),h);
}

// 3) サイトマップ（言語ごとのページの対応も書く）と robots.txt
const alt=LANGS.map(x=>'    <xhtml:link rel="alternate" hreflang="'+HREFLANG[x]+'" href="'+url(x)+'"/>').join('\n');
const sm='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n'+
  LANGS.map(l=>'  <url>\n    <loc>'+url(l)+'</loc>\n'+alt+'\n  </url>').join('\n')+'\n</urlset>\n';
fs.writeFileSync(path.join(DIR,'sitemap.xml'),sm);
fs.writeFileSync(path.join(DIR,'robots.txt'),'User-agent: *\nAllow: /\n\nSitemap: '+SITE+'/sitemap.xml\n');
console.log('OK',SITE,LANGS.map(l=>PATH[l]).join(' '));
