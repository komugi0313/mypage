// 関数：ウェブ版（テレコムクレジット）の決済結果の通知を受け取り、アカウントのプランを書き込む（入口は index.js、URL は /api/telecom）。
// ・テレコムクレジットの形に合わせる部分は telecom-connect.js だけ。ここは、そろえた形の通知を受けてプランを付け外しする。
// ・書き込み先：保存箱 pk-accounts の u:<uid> の rec.sub
//     { plan, period('m'|'y'), trial, start, expires, willRenew, store:'TELECOM', telecomId, updated }
//   チャットの回数（gemini.js）と画面（auth.js の planInfo）は、この rec.sub だけを見る（アプリ版の billing.js と同じ形）。
// ・お客さんが損をしないための決まり（最終点検 2026-10-26）
//   - 同じ通知が2回来ても、1回分しか反映しない（eventId で見分ける）
//   - ウェブの購読がある人に、別の継続課金の申し込みが届いたら、古い方の継続課金を必ず止める（二重請求を防ぐ）
//   - 解約したのに継続課金の成功が届いたら（＝解約後に請求された）、もう一度止め、期間は延ばした上で、運営に知らせる印を残す（rec.billAlert）。
//     返金するかどうかは運営が決める（ここでは返金の約束をしない）
//   - 継続課金の失敗では何もしない（期限が来ると自動で無料に戻る）

const C = require('./telecom-connect.js');
const PLANS = ['std', 'pro', 'vip'];
const TRIAL_DAYS = 3;   // auth.js の WEB_TRIAL_DAYS と同じ

exports.handler = async (event) => {
  if (!C.verify(event)) return { statusCode: 401, headers: { 'Content-Type': 'text/plain' }, body: 'UNAUTHORIZED' };
  const evs = C.parse(event) || [];
  if (!evs.length) return C.reply(false);
  const A = require('./auth.js')._t;
  const store = await A.getStore(event);
  if (!store) return { statusCode: 503, headers: { 'Content-Type': 'text/plain' }, body: 'NO_STORE' };
  for (const ev of evs) {
    try { await applyEvent(store, ev, A); }
    catch (e) { console.error('[telecom]', ev && ev.kind, e); return { statusCode: 500, headers: { 'Content-Type': 'text/plain' }, body: 'ERROR' }; }   // 決済会社が送り直せるように失敗を返す
  }
  return C.reply(true);
};

// 1か月後（同じ日。無い日は月末）・1年後
function addPeriod(ms, period) {
  const d = new Date(ms + 9 * 3600e3), y = d.getUTCFullYear(), m = d.getUTCMonth(), day = d.getUTCDate();
  const ny = period === 'y' ? y + 1 : y + (m === 11 ? 1 : 0), nm = period === 'y' ? m : (m + 1) % 12;
  const last = new Date(Date.UTC(ny, nm + 1, 0)).getUTCDate();
  return Date.UTC(ny, nm, Math.min(day, last), d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds()) - 9 * 3600e3;
}

async function applyEvent(store, ev, A) {
  const uid = String(ev.uid || '').toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(uid)) { console.warn('[telecom] uid が無い通知', ev.kind); return; }
  const key = `u:${uid}`, rec = await store.get(key, { type: 'json' });
  if (!rec) { console.warn('[telecom] アカウントが無い（退会済みなど）', ev.kind); if (ev.kind === 'start' || ev.kind === 'renew') { await C.stop(ev.telecomId, null, null).catch(() => {}); } return; }   // 退会した人に請求が続かないよう止める
  const at = +ev.at || Date.now();
  const eid = String(ev.eventId || `${ev.telecomId || ''}:${ev.kind}:${at}`);
  const seen = rec.telecomSeen || [];
  if (seen.includes(eid)) return;   // 同じ通知の2回目
  const cur = rec.sub || {};
  const isMine = cur.store === 'TELECOM' && (!ev.telecomId || !cur.telecomId || cur.telecomId === ev.telecomId);
  const now = Date.now();

  if (ev.kind === 'start') {
    const [plan, p] = String(ev.planKey || '').split('_'), period = p === 'y' ? 'y' : 'm';
    if (!PLANS.includes(plan)) { console.warn('[telecom] プランが分からない', ev.planKey); return; }
    // 古いウェブの継続課金が動いたままなら、必ず止める（二重請求を防ぐ）
    if (cur.store === 'TELECOM' && cur.telecomId && cur.telecomId !== ev.telecomId && cur.willRenew !== false) {
      const r = await C.stop(cur.telecomId, cur, rec).catch(e => ({ ok: false, code: String(e) }));
      if (!r.ok) rec.billAlert = { kind: 'old_recurring_not_stopped', telecomId: cur.telecomId, code: r.code, at: now };
    }
    const trial = !rec.sub && !rec.hadTrial && ev.trial !== false;   // 一度も有料プラン（お試しを含む）を始めたことがない人だけ（checkout と同じ決まり）
    rec.sub = { plan, period, trial, start: at, expires: trial ? at + TRIAL_DAYS * 864e5 : (+ev.periodEnd || addPeriod(at, period)), willRenew: true, store: 'TELECOM', telecomId: String(ev.telecomId || ''), updated: now };
    rec.hadTrial = true;
  } else if (ev.kind === 'renew') {
    if (!isMine) { console.warn('[telecom] 今の購読と違う継続課金', ev.telecomId); rec.billAlert = { kind: 'unknown_renewal', telecomId: ev.telecomId, at: now }; }
    else {
      const period = cur.period === 'y' ? 'y' : 'm';
      const start = (+cur.expires && +cur.expires > at - 7 * 864e5) ? +cur.expires : at;   // 前の期間の終わりから続ける（遅れて届いた時も同じ）
      if (cur.willRenew === false) {
        // 解約したのに請求された：もう一度止め、運営に知らせる印を残す（払った分の期間は使えるようにする）
        const r = await C.stop(cur.telecomId, cur, rec).catch(e => ({ ok: false, code: String(e) }));
        rec.billAlert = { kind: 'charged_after_cancel', telecomId: cur.telecomId, stopAgain: !!r.ok, at: now };
        console.error('[telecom] 解約後の請求', uid.slice(0, 8));
      }
      rec.sub = Object.assign({}, cur, { trial: false, start, expires: +ev.periodEnd || addPeriod(start, period), updated: now });
    }
  } else if (ev.kind === 'stop') {
    if (isMine) rec.sub = Object.assign({}, cur, { willRenew: false, updated: now });
  } else if (ev.kind === 'refund') {
    if (isMine) rec.sub = Object.assign({}, cur, { willRenew: false, expires: Math.min(+cur.expires || now, now), updated: now });
  } else if (ev.kind === 'fail') {
    if (isMine) rec.sub = Object.assign({}, cur, { payFailedAt: now, updated: now });   // 期限が来たら自動で無料に戻る
  } else return;
  rec.telecomSeen = seen.concat(eid).slice(-50);
  await store.setJSON(key, rec);
}

exports._t = { addPeriod, applyEvent };
