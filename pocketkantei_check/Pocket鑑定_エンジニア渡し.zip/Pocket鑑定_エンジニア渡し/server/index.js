// Cloud Functions for Firebase の入口。ここで関数の名前・地域・シークレットを決め、中身は各ファイルに任せます。
//
//   関数名      URL（Firebase Hosting の転送。firebase.json）  中身
//   gemini      /api/gemini                                   gemini.js   … AIの中継・回数と原価の上限
//   auth        /api/auth                                     auth.js     … アカウント・同期・プラン・ウェブ決済・プッシュ設定
//   billing     /api/billing                                  billing.js  … RevenueCat の Webhook
//   survey      /api/survey                                   survey.js   … 登録時のアンケート → Firestore pk-survey
//   nicoPush    （毎時0分の予約。URL なし）                    push-lib.js … ニコからのメッセージを送る
//
// 各ファイルの中身は「event（httpMethod・headers・body）を受け取り、{ statusCode, headers, body } を返す」形です。
// 下の wrap() が、Firebase のリクエスト・レスポンスとの間をつなぎます。

const { onRequest } = require('firebase-functions/v2/https');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const { defineSecret } = require('firebase-functions/params');

const REGION = 'asia-northeast1';   // 東京。変える時は firebase.json の region も同じにする

// シークレット（Secret Manager）。値は `firebase functions:secrets:set 名前` で入れる（仕様書 2.2）
const GEMINI_API_KEY = defineSecret('GEMINI_API_KEY');
const AUTH_SECRET = defineSecret('AUTH_SECRET');
const RESEND_API_KEY = defineSecret('RESEND_API_KEY');
const REVENUECAT_WEBHOOK_AUTH = defineSecret('REVENUECAT_WEBHOOK_AUTH');
const TELECOM_CHECKOUT_URLS = defineSecret('TELECOM_CHECKOUT_URLS');

function wrap(handler) {
  return async (req, res) => {
    const event = {
      httpMethod: req.method,
      headers: req.headers || {},
      body: req.rawBody ? req.rawBody.toString('utf8') : (typeof req.body === 'string' ? req.body : ''),
    };
    let r;
    try { r = await handler(event); }
    catch (e) { console.error(e); r = { statusCode: 500, headers: { 'Content-Type': 'application/json' }, body: '{"ok":false,"code":"SERVER"}' }; }
    const h = (r && r.headers) || {};
    for (const k of Object.keys(h)) res.set(k, String(h[k]));
    res.status((r && r.statusCode) || 200).send((r && r.body) || '');
  };
}

exports.gemini = onRequest(
  { region: REGION, timeoutSeconds: 120, memory: '512MiB', secrets: [GEMINI_API_KEY, AUTH_SECRET] },
  wrap(require('./gemini.js').handler));

exports.auth = onRequest(
  { region: REGION, timeoutSeconds: 60, memory: '512MiB', secrets: [AUTH_SECRET, RESEND_API_KEY, TELECOM_CHECKOUT_URLS] },
  wrap(require('./auth.js').handler));

exports.billing = onRequest(
  { region: REGION, timeoutSeconds: 60, secrets: [AUTH_SECRET, REVENUECAT_WEBHOOK_AUTH] },
  wrap(require('./billing.js').handler));

exports.survey = onRequest(
  { region: REGION, timeoutSeconds: 30 },
  wrap(require('./survey.js').handler));

// 毎時0分（UTC）：その時刻にメッセージを受け取る人へ送る。9分で打ち切り、残りは翌日の同じ時刻に回る
exports.nicoPush = onSchedule(
  { schedule: '0 * * * *', timeZone: 'Etc/UTC', region: REGION, timeoutSeconds: 540, memory: '512MiB', secrets: [GEMINI_API_KEY, AUTH_SECRET] },
  async () => {
    const L = require('./push-lib.js'), S = require('./store.js');
    const hour = new Date().getUTCHours();
    const r = await L.runHour(S.getStore('pk-accounts'), S.getStore('pk-usage'), hour, Date.now(), { limitMs: 8 * 60e3 });
    console.log('nico-push', hour, JSON.stringify(r));
  });
