// 運営だけが見る「月のまとめ」（運営指示 2026-10-29：VIP の上のプランが要るかを、使い切る人の数で判断するため）
//
// ・数えるのは「人数」だけ。名前・メールアドレス・会話は入れない。保存箱 pk-stats（Firestore）の st:<月>:<項目> に { n } で持つ。
// ・月は日本時間の暦月（YYYY-MM）。その月に起きたことを、その月に数える。
//   <プラン>:used  … 本格鑑定を1回以上使った人（支払いの区切りごとに1回）
//   <プラン>:p80   … 本格鑑定を8割以上使った人
//   <プラン>:full  … 本格鑑定を使い切った人
//   new:<プラン>   … 新しい申し込み（無料お試しで始めた人を含む）
//   up:<前>><後>   … 上のプランへの変更
//   upfull:<前>><後> … そのうち、直前（40日以内）に本格鑑定を使い切っていた人
// ・使い切った印（qf:<uid>）は回数の保存箱 pk-usage に置く（40日で自動で消える。store.js の expFor）。
//
// 見る方法：GET /api/stats?m=2026-11（m を省くと今月から3か月分）。ヘッダ x-pk-admin に合言葉（シークレット PK_ADMIN_KEY）。
//   画面は site/admin-stats.html（合言葉を入れると表になる。ページ自体にはデータは入っていない）

const PLANS = ['std', 'pro', 'vip'];
const UPS = ['std>pro', 'std>vip', 'pro>vip'];
const FULL_KEEP_MS = 40 * 864e5;

function month(ts) { return new Date((+ts || Date.now()) + 9 * 3600e3).toISOString().slice(0, 7); }
function statsStore() { try { return require('./store.js').getStore('pk-stats'); } catch (e) { return null; } }
function usageStore() { try { return require('./store.js').getStore('pk-usage'); } catch (e) { return null; } }

// 1つ足す（失敗しても、本来の処理は止めない）
async function add(name, ts) {
  try {
    const s = statsStore(); if (!s) return;
    const k = `st:${month(ts)}:${name}`;
    const v = await s.get(k, { type: 'json' }).catch(() => null);
    await s.setJSON(k, { n: ((v && +v.n) || 0) + 1, t: Date.now() });
  } catch (e) {}
}

// 本格鑑定を1回数えた直後に呼ぶ（n＝この区切りで使った回数、quota＝そのプランの上限）。区切りを越えた時だけ足す
async function deepCounted(plan, n, quota, uid) {
  if (!PLANS.includes(plan) || !(quota > 0)) return;
  if (n === 1) await add(`${plan}:used`);
  if (n === Math.ceil(quota * 0.8)) await add(`${plan}:p80`);
  if (n === quota) {
    await add(`${plan}:full`);
    if (uid) { try { const u = usageStore(); if (u) await u.setJSON(`qf:${uid}`, { t: Date.now(), plan }); } catch (e) {} }
  }
}

// 購読が始まった・変わった時に呼ぶ（billing.js・telecom.js）。cur＝それまでの購読、plan＝新しいプラン
const RANK = { std: 1, pro: 2, vip: 3 };
async function planChanged(cur, plan, uid, isNew) {
  if (!PLANS.includes(plan)) return;
  cur = cur || {};
  const active = cur.plan && +cur.expires > Date.now();
  if (active && (RANK[plan] || 0) > (RANK[cur.plan] || 0)) {
    const kind = `${cur.plan}>${plan}`;
    await add(`up:${kind}`);
    try {
      const u = usageStore(); const f = u && await u.get(`qf:${uid}`, { type: 'json' }).catch(() => null);
      if (f && Date.now() - (+f.t || 0) < FULL_KEEP_MS) await add(`upfull:${kind}`);
    } catch (e) {}
  } else if (isNew && !active) {
    await add(`new:${plan}`);
  }
}

async function readMonth(s, m) {
  const g = async k => { const v = await s.get(`st:${m}:${k}`, { type: 'json' }).catch(() => null); return (v && +v.n) || 0; };
  const out = { month: m, plans: {}, new: {}, up: {} };
  for (const p of PLANS) { out.plans[p] = { used: await g(`${p}:used`), p80: await g(`${p}:p80`), full: await g(`${p}:full`) }; out.new[p] = await g(`new:${p}`); }
  for (const u of UPS) out.up[u] = { n: await g(`up:${u}`), afterFull: await g(`upfull:${u}`) };
  return out;
}

exports.handler = async (event) => {
  const need = process.env.PK_ADMIN_KEY || '';
  if (need.length < 16) return json(404, { ok: false, code: 'NOT_SET' });   // 合言葉を入れていない時は、使えない
  const h = {}; for (const k in (event.headers || {})) h[k.toLowerCase()] = event.headers[k];
  if (!safeEq(String(h['x-pk-admin'] || ''), need)) return json(401, { ok: false, code: 'UNAUTHORIZED' });
  if (event.httpMethod !== 'GET') return json(405, { ok: false, code: 'METHOD' });
  const s = statsStore(); if (!s) return json(503, { ok: false, code: 'NO_STORE' });
  const q = event.query || {};
  let months;
  if (/^\d{4}-\d{2}$/.test(String(q.m || ''))) months = [String(q.m)];
  else { const now = new Date(Date.now() + 9 * 3600e3); months = [0, 1, 2].map(i => new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1)).toISOString().slice(0, 7)); }
  const res = []; for (const m of months) res.push(await readMonth(s, m));
  return json(200, { ok: true, months: res });
};

function safeEq(a, b) { const c = require('crypto'); const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && c.timingSafeEqual(x, y); }
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(obj) }; }
exports._t = { add, deepCounted, planChanged, month, readMonth };
