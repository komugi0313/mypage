// データの保存先（キーと値の小さな保存箱）。
// ・本番（Google Cloud Functions for Firebase）：Firestore に保存します。
// ・テスト：tests/mock の仮の保存領域（メモリ上）を使います（環境変数 PK_STORE=memory）。
//
// どちらも同じ5つの操作だけを持ちます（ほかのファイルは、この5つだけを使います）。
//   get(key)                    → 文字列（無ければ null）
//   get(key, { type: 'json' })  → JSON を読んだ値（無ければ null）
//   set(key, 文字列) / setJSON(key, 値) / delete(key)
//   list({ prefix })            → { blobs: [{ key }, …] }（key がその文字で始まるもの）
//
// 保存箱の名前（name）が、Firestore のコレクション名になります：pk-accounts / pk-usage / pk-survey
// Firestore の1文書は1MBまでなので、長い値（会話履歴など）は分けて保存し、読む時につなげます（<name>__parts）。

const PART = 250000;   // 1つに入れる文字数（UTF-8 で最大 約750KB。1MB の上限に余裕を持たせる）

let _db = null;
function db() {
  if (_db) return _db;
  const { initializeApp, getApps } = require('firebase-admin/app');
  const { getFirestore } = require('firebase-admin/firestore');
  if (!getApps().length) initializeApp();
  _db = getFirestore();
  return _db;
}
// Firestore の文書IDに使えない文字（/）や、特別な名前（. ..）を避ける
function docId(key) { return encodeURIComponent(String(key)).replace(/\./g, '%2E'); }
// サロゲートペア（絵文字など）の途中で切らないように分ける
function split(s) {
  const out = []; let i = 0;
  while (i < s.length) {
    let j = Math.min(s.length, i + PART);
    if (j < s.length) { const c = s.charCodeAt(j - 1); if (c >= 0xD800 && c <= 0xDBFF) j--; }
    out.push(s.slice(i, j)); i = j;
  }
  return out.length ? out : [''];
}

function firestoreStore(name) {
  const col = () => db().collection(name);
  const parts = () => db().collection(`${name}__parts`);
  async function readRaw(key) {
    const snap = await col().doc(docId(key)).get();
    if (!snap.exists) return null;
    const d = snap.data() || {};
    let v = String(d.v == null ? '' : d.v);
    const n = +d.n || 1;
    if (n > 1) {
      const ps = await Promise.all(Array.from({ length: n - 1 }, (_, i) => parts().doc(`${docId(key)}~${i + 1}`).get()));
      v += ps.map(p => (p.exists ? String((p.data() || {}).v || '') : '')).join('');
    }
    return { v, n };
  }
  return {
    async get(key, opt) {
      const r = await readRaw(key);
      if (!r) return null;
      if (opt && opt.type === 'json') { try { return JSON.parse(r.v); } catch (e) { return null; } }
      return r.v;
    },
    async set(key, value) {
      const s = String(value), ps = split(s), id = docId(key);
      const old = await col().doc(id).get();
      const oldN = old.exists ? (+(old.data() || {}).n || 1) : 1;
      for (let i = 1; i < ps.length; i++) await parts().doc(`${id}~${i}`).set({ v: ps[i] });
      await col().doc(id).set({ k: String(key), v: ps[0], n: ps.length, t: Date.now() });
      for (let i = ps.length; i < oldN; i++) await parts().doc(`${id}~${i}`).delete();
    },
    async setJSON(key, value) { return this.set(key, JSON.stringify(value)); },
    async delete(key) {
      const id = docId(key), old = await col().doc(id).get();
      if (!old.exists) return;
      const n = +(old.data() || {}).n || 1;
      for (let i = 1; i < n; i++) await parts().doc(`${id}~${i}`).delete();
      await col().doc(id).delete();
    },
    async list(opt) {
      const pre = String((opt && opt.prefix) || '');
      let q = col();
      if (pre) q = q.where('k', '>=', pre).where('k', '<', pre + '');
      const snap = await q.select('k').get();
      return { blobs: snap.docs.map(d => ({ key: String(d.get('k')) })), directories: [] };
    },
  };
}

// 保存箱を取り出す。つながらない時は null（呼ぶ側は「回数の確認なしで通す」などの安全な動きをします）
function getStore(name) {
  try {
    if (process.env.PK_STORE === 'memory') return require('pk-test-store').getStore(name);
    return firestoreStore(name);
  } catch (e) { return null; }
}

module.exports = { getStore, _t: { split, docId, firestoreStore, db } };
