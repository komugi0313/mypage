// テレコムクレジットとのつなぎ目。★テレコムクレジットの接続仕様書を受け取ったら、このファイルだけを書きます★
//
// ほかの部分（プランの付け外し・二重請求の防止・解約後の請求の検知・お知らせメール・画面）は telecom.js と auth.js でできています。
// ここに書くのは、次の4つだけです。
//   1. verify(event)            … 届いた通知が本物か（テレコムクレジットからか）
//   2. parse(event)             … 通知の中身を、下の「そろえた形」に直す
//   3. reply(ok)                … テレコムクレジットに返す応答（仕様書で決まった文字など）
//   4. stop(telecomId, sub, rec)… 継続課金を止める（解約）。利用者が「解約する」を押した時に auth.js から呼ばれる
// 4つとも書いて、テスト用の決済で確かめたら、READY を true にし、環境変数 PK_TELECOM_CANCEL_READY=1 にします。
// それまでは、ウェブ版の購入は開きません（auth.js の checkout が NOT_READY を返す）。
//
// event の形（index.js の wrap が作る）：{ httpMethod, headers, body（文字列）, query（URLの ? 以降）, ip（送信元） }
//
// 「そろえた形」（parse が返す配列の1つ1つ）：
//   { kind, uid, planKey, telecomId, eventId, at, periodEnd }
//   kind      … 'start'（初回の申し込み。お試しで始めた時も）／'renew'（継続課金が成功）／'fail'（継続課金が失敗）
//               ／'stop'（テレコムクレジット側で継続課金が止まった）／'refund'（返金・取り消し）
//   uid       … アカウントの uid（checkout で決済画面のURLに入れた {uid}。仕様書の「利用者を見分ける項目」で戻ってくる）
//   planKey   … 'std_m' 'std_y' 'pro_m' 'pro_y' 'vip_m' 'vip_y'（商品の番号で分からない時は planKeyOfAmount(金額) が使える）
//   telecomId … 継続課金のID（解約の時に使う）
//   eventId   … 通知ごとの番号（同じ通知が2回来た時に、2回目を無視するため。無ければ telecomId と日時をつなげたもの）
//   at        … 通知の日時（ミリ秒）
//   periodEnd … 次の課金日（ミリ秒）。仕様書で分かる時だけ。無ければ telecom.js が1か月後・1年後を計算する

const crypto = require('crypto');

// ★仕様書に合わせて4つを書いたら true にする
const READY = false;

// 1. 本物の通知か。
//   今の形：テレコムクレジットに登録する「結果通知のURL」に合言葉を付けておく（例：https://<本番のドメイン>/api/telecom?k=<合言葉>）。
//   合言葉はシークレット TELECOM_WEBHOOK_SECRET（16文字以上のランダムな文字）。送信元のIPが決まっていれば TELECOM_IPS（カンマ区切り）にも入れる。
//   仕様書に署名（ハッシュ）の決まりがあれば、それもここで確かめる。
function verify(event) {
  const need = process.env.TELECOM_WEBHOOK_SECRET || '';
  if (need.length < 16) return false;
  const got = String((event.query && event.query.k) || '');
  if (!safeEq(got, need)) return false;
  const ips = String(process.env.TELECOM_IPS || '').split(',').map(s => s.trim()).filter(Boolean);
  if (ips.length && !ips.includes(String(event.ip || ''))) return false;
  return true;
}

// 2. 通知の中身を「そろえた形」に直す。
//   ★仕様書の項目名（利用者を見分ける項目・金額・結果・継続課金のID など）に合わせて書く。今は、テスト用の形（JSON）だけを読む。
function parse(event) {
  if (process.env.PK_TELECOM_TEST === '1') {
    let b; try { b = JSON.parse(event.body || '{}'); } catch (e) { return []; }
    return (Array.isArray(b.events) ? b.events : [b]).filter(x => x && x.kind);
  }
  // 例（項目名は仕様書で確かめること）：
  //   const p = Object.assign({}, event.query, Object.fromEntries(new URLSearchParams(event.body || '')));
  //   return [{ kind: p.<結果> === '<成功>' ? (p.<初回か> ? 'start' : 'renew') : 'fail', uid: p.<利用者の項目>, planKey: planKeyOfAmount(p.<金額>),
  //             telecomId: p.<継続課金のID>, eventId: p.<取引番号>, at: Date.now() }];
  return [];
}

// 3. テレコムクレジットに返す応答。★仕様書に「成功の時は○○の文字を返す」などの決まりがあれば、それに合わせる
function reply(ok) {
  return { statusCode: ok ? 200 : 400, headers: { 'Content-Type': 'text/plain; charset=utf-8' }, body: ok ? 'OK' : 'NG' };
}

// 4. 継続課金を止める（解約）。★仕様書の解約API（または解約用URL）を、telecomId で呼ぶ。
//   成功したら { ok: true }、失敗したら { ok: false, code: '<理由>' }。sub の書き換えは auth.js がする。
//   お試し中に止めた時は、初回の課金も起きないことを、テスト用の決済で必ず確かめる。
async function stop(telecomId, sub, rec) {
  if (process.env.PK_TELECOM_TEST === '1') { (global.__tcStops = global.__tcStops || []).push(telecomId); return { ok: global.__tcStopFail ? false : true, code: global.__tcStopFail ? 'TEST_FAIL' : undefined }; }   // テスト用
  if (!READY) return { ok: false, code: 'NOT_READY' };
  if (!telecomId) return { ok: false, code: 'NO_TELECOM_ID' };
  // 例：const r = await fetch('<解約APIのURL>', { method: 'POST', body: new URLSearchParams({ <項目>: telecomId, ... }) });
  //     return r.ok && /<成功の印>/.test(await r.text()) ? { ok: true } : { ok: false, code: 'TELECOM_' + r.status };
  return { ok: false, code: 'NOT_IMPLEMENTED' };
}

// 金額（税込・円）→ プランと期間。テレコムクレジットの通知に商品の番号が無い時に使える（価格を変えたらここも変える）
const PRICE = { 3300: 'std_m', 36300: 'std_y', 5900: 'pro_m', 64900: 'pro_y', 9800: 'vip_m', 107800: 'vip_y' };
function planKeyOfAmount(yen) { return PRICE[Math.round(+yen)] || ''; }

function safeEq(a, b) { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }

module.exports = { READY, verify, parse, reply, stop, planKeyOfAmount };
