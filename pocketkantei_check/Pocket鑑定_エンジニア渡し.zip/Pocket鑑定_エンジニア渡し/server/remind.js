// 無料お試しが終わる前のお知らせメール（運営決定 2026-10-22）。index.js の trialRemind（毎時）から呼ぶ。
// ・対象：購読が「お試し中」（rec.sub.trial）で、お試しの終わり（rec.sub.expires）が 12〜36時間後、
//         自動更新がオン（解約していない）、まだお知らせしていない人。
// ・ウェブ版（テレコムクレジット）でも、決済の結果通知で rec.sub に { trial:true, expires:お試しの終わり, store:'TELECOM' } を
//   書けば、同じように届く。
// ・送ったら rec.sub.remindedAt を記録して、二度送らない。
// ・メールは Resend（auth.js の sendMail）。言語は登録時の言語（rec.lang）。無ければ日本語。

const PLAN_NAME = { std: 'Standard', pro: 'Pro', vip: 'VIP' };
const T = {
  ja: { subj: 'まもなく無料お試しが終わります',
    body: 'Pocket本格鑑定をお試しいただき、ありがとうございます。\n\n3日間の無料お試しは {d}（日本時間）に終わります。そのあとは {p} プランが自動で始まり、料金がかかります。{x}\n\nこのまま続ける場合は、何もしなくて大丈夫です。\n続けない場合は、お試しが終わる前に解約してください。料金はかかりません。\n・ウェブ版：メニューの「料金プラン」→「解約する」\n・iPhone / Android アプリ：料金プランの画面の「購読の管理・解約」（ストアのアカウント設定）' },
  en: { subj: 'Your free trial ends soon',
    body: 'Thank you for trying Pocket Kantei.\n\nYour 3-day free trial ends on {d} (Japan time). After that, the {p} plan starts automatically and you will be charged.{x}\n\nIf you would like to continue, there is nothing you need to do.\nIf not, please cancel before the trial ends and you will not be charged.\n- Web: menu "Plans" → "Cancel plan"\n- iPhone / Android app: "Manage / cancel subscription" on the Plans screen (your store account settings)' },
  ko: { subj: '곧 무료 체험이 끝나요',
    body: 'Pocket Kantei를 체험해 주셔서 감사합니다.\n\n3일 무료 체험은 {d}(일본 시간)에 끝납니다. 그 후에는 {p} 요금제가 자동으로 시작되며 요금이 청구됩니다.{x}\n\n계속 이용하실 경우에는 아무것도 하지 않으셔도 됩니다.\n계속하지 않으실 경우에는 체험이 끝나기 전에 해지해 주세요. 요금이 청구되지 않습니다.\n・웹 버전: 메뉴의 「요금제」 → 「해지하기」\n・iPhone / Android 앱: 요금제 화면의 「구독 관리·해지」(스토어 계정 설정)' },
  zt: { subj: '免費試用即將結束',
    body: '感謝你試用 Pocket本格鑑定。\n\n3天免費試用將於 {d}（日本時間）結束。之後 {p} 方案會自動開始並收費。{x}\n\n如要繼續使用，無需任何操作。\n如不繼續，請在試用結束前取消，就不會收費。\n・網頁版：選單「方案」→「取消方案」\n・iPhone / Android App：方案畫面的「管理・取消訂閱」（商店帳號設定）' },
};
// お試しのあとにかかる金額（運営指示 2026-11-02：金額が書いていないと、年額の人が知らないまま大きな金額を引き落とされ、苦情や支払いの取り消しにつながる）
//   ウェブ版（テレコムクレジット・円）は金額を書く。アプリ版はストアが国ごとに金額を決めるので、ストアに表示された金額だと書く
const PRICE_YEN = { std: { m: 3300, y: 36300 }, pro: { m: 5900, y: 64900 }, vip: { m: 9800, y: 107800 } };   // telecom-connect.js の PRICE と同じ（税込）
const PRICE_TXT = {
  ja: { m: n => `金額は月額${n}円（税込）です。`, y: n => `金額は年額${n}円（税込）で、一度にお支払いいただきます。`, store: '料金は、お申し込みの時にストアに表示された金額です。' },
  en: { m: n => ` The price is ¥${n} per month (tax included).`, y: n => ` The price is ¥${n} per year (tax included), charged at once.`, store: ' The price is the amount shown in the store when you signed up.' },
  ko: { m: n => ` 금액은 월 ${n}엔(세금 포함)입니다.`, y: n => ` 금액은 연 ${n}엔(세금 포함)이며, 한 번에 결제됩니다.`, store: ' 요금은 신청하실 때 스토어에 표시된 금액입니다.' },
  zt: { m: n => `費用為每月 ${n} 日圓（含稅）。`, y: n => `費用為每年 ${n} 日圓（含稅），將一次收取。`, store: '費用為您申請時商店顯示的金額。' } };
function priceLine(s, lang) {
  const L = PRICE_TXT[lang] || PRICE_TXT.ja;
  if (String(s.store || '').toUpperCase() === 'TELECOM') {
    const per = s.period === 'y' ? 'y' : 'm', yen = (PRICE_YEN[s.plan] || {})[per];
    if (yen) return L[per](yen.toLocaleString('en-US'));
  }
  return L.store;
}
function fmtJst(ms) { const d = new Date(ms + 9 * 3600e3); const p = n => String(n).padStart(2, '0'); return `${d.getUTCFullYear()}/${p(d.getUTCMonth() + 1)}/${p(d.getUTCDate())} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}`; }

async function runRemind(store, now, opt = {}) {
  const send = opt.send || require('./auth.js')._t.sendMail;
  const res = { checked: 0, sent: 0 };
  let keys = [];
  try { keys = ((await store.list({ prefix: 'u:' })).blobs || []).map(b => b.key); } catch (e) { return res; }
  for (const k of keys) {
    if (opt.limitMs && Date.now() - now > opt.limitMs) break;
    let rec; try { rec = await store.get(k, { type: 'json' }); } catch (e) { continue; }
    const s = rec && rec.sub; res.checked++;
    if (!s || !s.trial || s.willRenew === false || s.remindedAt || !rec.email) continue;
    const left = +s.expires - now;
    if (!(left > 12 * 3600e3 && left <= 36 * 3600e3)) continue;
    const t = T[rec.lang] || T[String(rec.lang || '').slice(0, 2)] || T.ja;
    const lang = T[rec.lang] ? rec.lang : (T[String(rec.lang || '').slice(0, 2)] ? String(rec.lang).slice(0, 2) : 'ja');
    const body = t.body.replace('{d}', fmtJst(+s.expires)).replace('{p}', PLAN_NAME[s.plan] || s.plan || '').replace('{x}', priceLine(s, lang));
    const ok = await send(rec.email, t.subj, body, '').catch(() => false);
    if (ok) { rec.sub = Object.assign({}, s, { remindedAt: now }); await store.setJSON(k, rec); res.sent++; }
  }
  return res;
}
module.exports = { runRemind, fmtJst, T, priceLine };
