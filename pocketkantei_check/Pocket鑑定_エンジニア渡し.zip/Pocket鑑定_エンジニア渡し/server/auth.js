// 関数：アカウント（メールアドレス＋パスワード）とデータ同期（Cloud Functions for Firebase。入口は index.js）。
// ・メールアドレス＋パスワードで登録／ログインする。登録するとすぐ使える（確認はあとからでもよい）。
// ・メールアドレスの確認：登録の直後に6桁の確認コードをメールで送る。アプリでコードを入れると「確認済み」になる。
// ・メールアドレスの変更（登録時の打ち間違いも）：新しいアドレスに確認コードを送り、コードが合った時だけ切り替える。
// ・アカウントの uid は、登録した時のメールアドレスから作り、その後は変えない（課金・回数・通知が uid にひも付くため）。
//   メールアドレス → uid の対応は e:<メールアドレスのハッシュ> に保存する（古いアカウントは u:<メールアドレスのハッシュ> を直接見る）。
// ・パスワードは scrypt（ランダムsalt付き）でハッシュ化して保存。平文は保存しない。
// ・ログイン状態は署名付きトークン（HMAC-SHA256）。端末にはトークンだけを保存し、パスワードは保存しない。
// ・命式の入力・会話履歴などの端末データ（pk_*）をアカウントに保存し、機種変更しても同じメアド＋パスワードで復元できる。
// ※要設定：シークレット AUTH_SECRET（32文字以上のランダムな文字列。仕様書 2.2）
//
// POST /api/auth  { action, ... }
//   register { email, password, data, lang } → { ok, token, email, verified:false, mailSent }   確認コードのメールも送る
//   login    { email, password }            → { ok, token, email, data, verified }
//   save     { token, data }                → { ok, updated }
//   load     { token }                      → { ok, data, updated }
//   change   { token, password, newPassword } → { ok, token }
//   delete   { token, password }            → { ok }
//   forgot   { email, lang }                → { ok }   登録があれば再設定メールを送る（登録の有無は答えない）
//   reset    { code, newPassword }          → { ok, token, email, data }   メールのリンクのコードで新しいパスワードを設定
//   verify_send   { token, lang }                       → { ok }            確認コードを送り直す（1時間に3通まで）
//   verify        { token, code }                       → { ok, verified:true }
//   email_change  { token, password, newEmail, lang }   → { ok }            新しいアドレスに確認コードを送る
//   email_confirm { token, code }                       → { ok, email, verified:true }   コードが合えばアドレスを切り替える
// ※パスワード再設定メールの送信に必要（Resend https://resend.com）：
//   RESEND_API_KEY（ResendのAPIキー）／ MAIL_FROM（送信元。例："Pocket Kantei <no-reply@72k.ai>"。Resendで認証済みのドメイン）
const crypto = require('crypto');

const MAX_DATA = 1500000;        // 保存データの上限（文字数）。会話履歴60件＋設定で十分な大きさ
const TOKEN_DAYS = 365;          // ログイン状態の有効期間
const LOCK_FAILS = 5;            // パスワードをこの回数続けて間違えると
const LOCK_MIN = 15;             // この分数ロック
const REG_PER_IP_DAY = 20;       // 同一IPからの新規登録の上限（1日）
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const RESET_MIN = 30;            // 再設定リンクの有効時間（分）
const RESET_PER_HOUR = 3;        // 同じアカウントへの再設定メールの上限（1時間）
const FORGOT_PER_IP_DAY = 30;    // 同一IPからの再設定依頼の上限（1日）
const CODE_MIN = 30;             // 確認コードの有効時間（分）
const CODE_TRIES = 5;            // 確認コードを間違えられる回数（超えたら送り直し）
const CODE_PER_HOUR = 3;         // 確認コードのメールの上限（同じアカウント・1時間）

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false, code: 'METHOD' });
  const site = String(process.env.SITE_URL || '').replace(/\/$/, '');
  const origin = event.headers.origin || event.headers.referer || '';
  if (site && origin && !origin.startsWith(site)) return json(403, { ok: false, code: 'ORIGIN' });
  if ((event.body || '').length > MAX_DATA + 20000) return json(413, { ok: false, code: 'TOO_LARGE' });

  const secret = process.env.AUTH_SECRET || '';
  if (secret.length < 16) return json(500, { ok: false, code: 'NO_SECRET' });
  const store = await getStore(event);
  if (!store) return json(503, { ok: false, code: 'NO_STORE' });

  let b; try { b = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { ok: false, code: 'BAD_JSON' }); }
  const action = String(b.action || '');
  const h = lower(event.headers || {});
  const ip = String(h['fastly-client-ip'] || h['x-forwarded-for'] || '').split(',')[0].trim() || 'noip';   // Firebase Hosting 経由では fastly-client-ip

  try {
    if (action === 'register') {
      const email = normEmail(b.email), pw = String(b.password || '');
      if (!EMAIL_RE.test(email)) return json(400, { ok: false, code: 'BAD_EMAIL' });
      if (pw.length < 8 || pw.length > 128) return json(400, { ok: false, code: 'BAD_PASSWORD' });
      const data = cleanData(b.data); if (data === null) return json(413, { ok: false, code: 'TOO_LARGE' });
      const rk = `r:${jstDay()}:${ip}`, rc = await readNum(store, rk);
      if (ip !== 'noip' && rc >= REG_PER_IP_DAY) return json(429, { ok: false, code: 'RATE' });   // IP が分からない時は使わない
      if (await findRec(store, email)) return json(409, { ok: false, code: 'EXISTS' });
      // uid はメールアドレスから作る。前の持ち主がアドレスを変えて、その場所が使われている時だけランダムにする
      let uid = userId(email);
      if (await store.get(`u:${uid}`)) uid = crypto.randomBytes(32).toString('hex');
      const salt = crypto.randomBytes(16).toString('hex');
      const now = Date.now();
      const rec = { uid, email, verified: false, salt, hash: hashPw(pw, salt), ver: 1, created: now, updated: now, fails: 0, lockUntil: 0, lang: String(b.lang || 'ja').slice(0, 5), data };
      // アカウントを消して同じアドレスで作り直しても、無料お試しは2回目にならない（最終点検 2026-10-26）
      try { if (await store.get(`ht:${userId(email)}`)) rec.hadTrial = true; } catch (e) {}
      const mailSent = await issueCode(rec, 'vcode', email, b.lang, now);
      await store.setJSON(`u:${uid}`, rec);
      await store.set(`e:${userId(email)}`, uid);
      await store.set(rk, String(rc + 1));
      return json(200, { ok: true, email, verified: false, mailSent, token: makeToken(uid, rec.ver, secret), plan: planInfo(rec) });
    }

    if (action === 'login') {
      const email = normEmail(b.email), pw = String(b.password || '');
      const f = EMAIL_RE.test(email) ? await findRec(store, email) : null;
      if (!f) { hashPw(pw, 'x'); return json(401, { ok: false, code: 'BAD_LOGIN' }); } // 登録有無を応答時間で漏らしにくくする
      const key = f.key, rec = f.rec;
      if (rec.lockUntil && rec.lockUntil > Date.now()) return json(429, { ok: false, code: 'LOCKED', retryMin: Math.ceil((rec.lockUntil - Date.now()) / 60000) });
      if (!safeEq(hashPw(pw, rec.salt), rec.hash)) {
        rec.fails = (rec.fails || 0) + 1;
        if (rec.fails >= LOCK_FAILS) { rec.lockUntil = Date.now() + LOCK_MIN * 60000; rec.fails = 0; }
        await store.setJSON(key, rec);
        return json(401, { ok: false, code: 'BAD_LOGIN' });
      }
      if (rec.fails || rec.lockUntil) { rec.fails = 0; rec.lockUntil = 0; await store.setJSON(key, rec); }
      return json(200, { ok: true, email: rec.email, verified: isVerified(rec), token: makeToken(uidOf(rec), rec.ver, secret), data: rec.data || {}, updated: rec.updated, plan: planInfo(rec) });
    }

    // パスワードを忘れた：登録があれば再設定メールを送る。登録の有無は応答で分からないようにする
    if (action === 'forgot') {
      const email = normEmail(b.email);
      if (!EMAIL_RE.test(email)) return json(400, { ok: false, code: 'BAD_EMAIL' });
      if (!process.env.RESEND_API_KEY || !process.env.MAIL_FROM) return json(500, { ok: false, code: 'NO_MAIL' });
      const fk = `f:${jstDay()}:${ip}`, fc = await readNum(store, fk);
      if (ip !== 'noip' && fc >= FORGOT_PER_IP_DAY) return json(429, { ok: false, code: 'RATE' });
      await store.set(fk, String(fc + 1));
      const f = await findRec(store, email);
      if (!f) return json(200, { ok: true });
      const key = f.key, rec = f.rec;
      const now = Date.now();
      const sent = (rec.resetSent || []).filter(t => t > now - 3600e3);
      if (sent.length >= RESET_PER_HOUR) return json(200, { ok: true });   // 送りすぎ防止（応答は同じ）
      const raw = crypto.randomBytes(24).toString('hex');
      rec.reset = { h: sha256(raw), exp: now + RESET_MIN * 60000 };
      rec.resetSent = sent.concat(now);
      await store.setJSON(key, rec);
      const lang = MAIL_TEXT[b.lang] ? b.lang : 'en';
      const link = `${siteUrl(event)}/index.html#reset=${uidOf(rec)}.${raw}`;
      const ok = await sendResetMail(email, link, lang);
      if (!ok) { console.error('[auth] reset mail failed'); return json(200, { ok: true }); }   // 登録の有無が外から分からないよう、失敗しても同じ応答（記録だけ残す）
      return json(200, { ok: true });
    }
    // メールのリンクから新しいパスワードを設定 → そのままログイン
    if (action === 'reset') {
      const [uid, raw] = String(b.code || '').split('.');
      const np = String(b.newPassword || '');
      if (!/^[0-9a-f]{64}$/.test(uid || '') || !/^[0-9a-f]{48}$/.test(raw || '')) return json(400, { ok: false, code: 'BAD_RESET' });
      if (np.length < 8 || np.length > 128) return json(400, { ok: false, code: 'BAD_PASSWORD' });
      const key = `u:${uid}`;
      const rec = await store.get(key, { type: 'json' });
      if (!rec || !rec.reset || rec.reset.exp < Date.now() || !safeEq(sha256(raw), rec.reset.h)) return json(400, { ok: false, code: 'BAD_RESET' });
      rec.salt = crypto.randomBytes(16).toString('hex'); rec.hash = hashPw(np, rec.salt);
      rec.ver = (rec.ver || 1) + 1;            // 他の端末のログインは無効になる
      rec.reset = null; rec.fails = 0; rec.lockUntil = 0; rec.updated = Date.now();
      await store.setJSON(key, rec);
      return json(200, { ok: true, email: rec.email, verified: isVerified(rec), token: makeToken(uidOf(rec), rec.ver, secret), data: rec.data || {}, updated: rec.updated, plan: planInfo(rec) });
    }

    // ここから先はトークン必須
    const t = readToken(b.token, secret);
    if (!t) return json(401, { ok: false, code: 'BAD_TOKEN' });
    const key = `u:${t.uid}`;
    const rec = await store.get(key, { type: 'json' });
    if (!rec || rec.ver !== t.ver) return json(401, { ok: false, code: 'BAD_TOKEN' });

    if (action === 'save') {
      const data = cleanData(b.data); if (data === null) return json(413, { ok: false, code: 'TOO_LARGE' });
      rec.data = data; rec.updated = Date.now();
      await store.setJSON(key, rec);
      return json(200, { ok: true, updated: rec.updated });
    }
    if (action === 'load') return json(200, { ok: true, email: rec.email, verified: isVerified(rec), data: rec.data || {}, updated: rec.updated, plan: planInfo(rec) });

    // ---- メールアドレスの確認 ----
    if (action === 'verify_send') {
      if (isVerified(rec)) return json(200, { ok: true, verified: true });
      if (!mailReady()) return json(500, { ok: false, code: 'NO_MAIL' });
      const sent = await issueCode(rec, 'vcode', rec.email, b.lang, Date.now());
      if (sent === 'RATE') return json(429, { ok: false, code: 'CODE_RATE' });
      await store.setJSON(key, rec);
      if (!sent) return json(502, { ok: false, code: 'MAIL_FAIL' });
      return json(200, { ok: true });
    }
    if (action === 'verify') {
      if (isVerified(rec)) return json(200, { ok: true, verified: true });
      const r = checkCode(rec, 'vcode', b.code);
      if (r !== true) { await store.setJSON(key, rec); return json(400, { ok: false, code: r }); }
      rec.verified = true; rec.vcode = null; rec.updated = Date.now();
      await store.setJSON(key, rec);
      return json(200, { ok: true, verified: true });
    }
    // ---- メールアドレスの変更（打ち間違いの直しも）----
    if (action === 'email_change') {
      if (!safeEq(hashPw(String(b.password || ''), rec.salt), rec.hash)) return json(401, { ok: false, code: 'BAD_LOGIN' });
      const ne = normEmail(b.newEmail);
      if (!EMAIL_RE.test(ne)) return json(400, { ok: false, code: 'BAD_EMAIL' });
      if (ne === rec.email) return json(400, { ok: false, code: 'SAME_EMAIL' });
      if (await findRec(store, ne)) return json(409, { ok: false, code: 'EXISTS' });
      if (!mailReady()) return json(500, { ok: false, code: 'NO_MAIL' });
      const sent = await issueCode(rec, 'pend', ne, b.lang, Date.now());
      if (sent === 'RATE') return json(429, { ok: false, code: 'CODE_RATE' });
      await store.setJSON(key, rec);
      if (!sent) return json(502, { ok: false, code: 'MAIL_FAIL' });
      return json(200, { ok: true, newEmail: ne });
    }
    if (action === 'email_confirm') {
      const r = checkCode(rec, 'pend', b.code);
      if (r !== true) { await store.setJSON(key, rec); return json(400, { ok: false, code: r }); }
      const ne = rec.pend.email, old = rec.email, ml = mailT(b.lang || rec.pend.lang);
      if (await findRec(store, ne)) { rec.pend = null; await store.setJSON(key, rec); return json(409, { ok: false, code: 'EXISTS' }); }
      const uid = uidOf(rec);
      rec.uid = uid; rec.email = ne; rec.verified = true; rec.pend = null; rec.vcode = null; rec.updated = Date.now();
      await store.setJSON(key, rec);
      await store.set(`e:${userId(ne)}`, uid);
      await store.delete(`e:${userId(old)}`);
      // 前のアドレスにも知らせる（本人でない変更に気づけるように）。届かなくても変更は有効
      try { await sendMail(old, ml.chgSubj, ml.chgBody.replace('{e}', ne)); } catch (e) {}
      return json(200, { ok: true, email: ne, verified: true });
    }
    // ウェブ版の購入：テレコムクレジットの決済画面のURLを作って返す。
    //   環境変数 TELECOM_CHECKOUT_URLS（JSON）にプランごとのURLのひな形を入れる（テレコムクレジットの接続仕様に合わせて作る）。
    //   ひな形の {uid} {email} {lang} は置き換える（決済の結果通知で、どのアカウントの支払いかを見分けるため uid を渡す）。
    //   無料お試し（運営決定 2026-10-22：最初の3日間無料 → 4日目から自動で有料）：
    //     {trial}  … お試しで始める時 1、そうでない時 0
    //     {first}  … 初回の課金日（日本時間 YYYYMMDD。お試しの時は3日後、そうでない時は今日）
    //     {trialDays} … 3
    //   テレコムクレジットの「初回0円・○日後から継続課金」の設定（またはパラメーター）に合わせて、ひな形に入れる。
    //   未設定の間は NOT_READY（アプリは「準備中」と表示）。
    if (action === 'checkout') {
      // プラン（std / pro / vip）と期間（m＝月額 / y＝年額）。ひな形のキーは "std_m" "std_y" "pro_m" … の6つ
      const plan = String(b.plan || ''), period = b.period === 'y' ? 'y' : 'm';
      let urls = {}; try { urls = JSON.parse(process.env.TELECOM_CHECKOUT_URLS || '{}'); } catch (e) {}
      const tpl = urls[`${plan}_${period}`];
      if (!tpl) return json(400, { ok: false, code: 'NOT_READY' });
      // 解約（継続課金の停止）が動くまでは、購入URLが設定されていても売らない（「いつでも解約OK」が嘘にならないように。最終点検 2026-10-26）
      if (!TELECOM_CANCEL_READY) return json(400, { ok: false, code: 'NOT_READY' });
      // すでに有料プランを使っている人には、二重の購入をさせない（最終点検 2026-10-26）
      if (planInfo(rec).plan !== 'free') return json(409, { ok: false, code: 'HAS_PLAN' });
      // お試しは、一度も有料プラン（お試しを含む）を始めたことがない人だけ
      const trial = !rec.sub && !rec.hadTrial;
      const firstDay = jstYmd(Date.now() + (trial ? WEB_TRIAL_DAYS : 0) * 864e5);
      const url = String(tpl).replace(/\{uid\}/g, encodeURIComponent(t.uid)).replace(/\{email\}/g, encodeURIComponent(rec.email)).replace(/\{lang\}/g, encodeURIComponent(String(b.lang || 'ja').slice(0, 5)))
        .replace(/\{trial\}/g, trial ? '1' : '0').replace(/\{first\}/g, firstDay).replace(/\{trialDays\}/g, String(WEB_TRIAL_DAYS));
      return json(200, { ok: true, url });
    }
    // ウェブ版（テレコムクレジット）の解約：利用者が自分で行う（運営の手作業なし）。
    //   決済会社の継続課金を止め（telecomStopRecurring）、成功したら「期限まで利用可・自動更新なし」にする。
    //   アプリ（App Store / Google Play）の購読はストアでしか解約できないため、ここでは扱わない。
    if (action === 'cancel') {
      const sub = rec.sub || {};
      if (String(sub.store || '').toUpperCase() !== 'TELECOM' || !(+sub.expires > Date.now())) return json(400, { ok: false, code: 'NOT_WEB_PLAN' });
      if (sub.willRenew === false) return json(200, { ok: true, plan: planInfo(rec) });
      const r = await TC.stop(sub, rec);
      if (!r.ok) return json(502, { ok: false, code: r.code || 'CANCEL_FAIL' });
      rec.sub = Object.assign({}, sub, { willRenew: false, cancelledAt: Date.now(), updated: Date.now() });
      await store.setJSON(key, rec);
      return json(200, { ok: true, plan: planInfo(rec) });
    }
    // 購入・復元の直後に、ストアからの通知（billing.js）が反映されたかを確かめる軽い問い合わせ
    if (action === 'status') return json(200, { ok: true, verified: isVerified(rec), plan: planInfo(rec) });
    // Nicoからのメッセージ（プッシュ通知）の設定：オン・オフ、時刻、端末の通知トークン（push-lib.js）
    if (action === 'push_set') {
      const r = await require('./push-lib.js').setPush(store, t.uid, { on: b.on, token: b.pushToken, mode: b.mode, hour: b.hour, tz: b.tz, lang: b.lang, platform: b.platform });
      return json(200, { ok: true, push: r });
    }
    // アプリを開いた時：Nicoから届いたメッセージ（受け取り箱）を返す。チャットへの表示はアプリが id を見て重ならないように行う
    if (action === 'push_inbox') {
      const r = await require('./push-lib.js').takeInbox(store, t.uid, Date.now(), b.tz);
      return json(200, { ok: true, items: r.items, push: r.push });
    }
    if (action === 'change') {
      if (!safeEq(hashPw(String(b.password || ''), rec.salt), rec.hash)) return json(401, { ok: false, code: 'BAD_LOGIN' });
      const np = String(b.newPassword || '');
      if (np.length < 8 || np.length > 128) return json(400, { ok: false, code: 'BAD_PASSWORD' });
      rec.salt = crypto.randomBytes(16).toString('hex'); rec.hash = hashPw(np, rec.salt);
      rec.ver = (rec.ver || 1) + 1; rec.updated = Date.now();   // 他の端末のログインは無効になる
      await store.setJSON(key, rec);
      return json(200, { ok: true, token: makeToken(uidOf(rec), rec.ver, secret) });
    }
    if (action === 'delete') {
      if (!safeEq(hashPw(String(b.password || ''), rec.salt), rec.hash)) return json(401, { ok: false, code: 'BAD_LOGIN' });
      // 有料プランが自動更新される状態のままなら、先に解約してもらう（アカウントを消しても、ストアやカードの請求は止まらないため。最終点検 2026-10-26）
      const pi0 = planInfo(rec);
      if (pi0.plan !== 'free' && pi0.willRenew && !b.force) return json(409, { ok: false, code: 'ACTIVE_SUB', store: pi0.store || '' });
      if (rec.sub || rec.hadTrial) { try { await store.set(`ht:${userId(rec.email)}`, '1'); } catch (e) {} }
      await store.delete(key);
      try { if ((await store.get(`e:${userId(rec.email)}`)) === t.uid) await store.delete(`e:${userId(rec.email)}`); } catch (e) {}
      try { await require('./push-lib.js').removeAll(store, t.uid); } catch (e) {}
      return json(200, { ok: true });
    }
    return json(400, { ok: false, code: 'BAD_ACTION' });
  } catch (e) {
    // 保存箱（Firestore）に接続できない時は NO_STORE として返し、原因を見分けやすくする
    const blob = /blob/i.test(String((e && (e.name || '')) + ' ' + (e && e.message || '')));
    return json(blob ? 503 : 500, { ok: false, code: blob ? 'NO_STORE' : 'SERVER' });
  }
};

function sha256(s) { return crypto.createHash('sha256').update(String(s)).digest('hex'); }
function siteUrl(event) {
  const u = process.env.SITE_URL; if (u) return u.replace(/\/$/, '');
  const h = lower(event.headers || {}); return `https://${h.host || 'localhost'}`;
}
// 再設定メールの文面（アプリの表示言語で送る）
const MAIL_TEXT = {
  ja: ['パスワードの再設定', 'Pocket本格鑑定のパスワード再設定のご依頼を受け付けました。下のボタンから新しいパスワードを設定してください（30分間有効）。', '新しいパスワードを設定する', 'お心当たりがない場合は、このメールを破棄してください。パスワードは変更されません。'],
  en: ['Reset your password', 'We received a request to reset your Pocket Kantei password. Tap the button below to set a new password (valid for 30 minutes).', 'Set a new password', 'If you did not request this, you can ignore this email. Your password will not change.'],
  zh: ['重设密码', '我们收到了重设 Pocket 鉴定密码的请求。请点击下方按钮设置新密码（30分钟内有效）。', '设置新密码', '如非本人操作，请忽略此邮件，密码不会被更改。'],
  zt: ['重設密碼', '我們收到了重設 Pocket 鑑定密碼的請求。請點擊下方按鈕設定新密碼（30分鐘內有效）。', '設定新密碼', '如非本人操作，請忽略此郵件，密碼不會被變更。'],
  ko: ['비밀번호 재설정', 'Pocket 감정 비밀번호 재설정 요청을 받았습니다. 아래 버튼을 눌러 새 비밀번호를 설정하세요 (30분간 유효).', '새 비밀번호 설정', '요청하지 않으셨다면 이 메일을 무시하세요. 비밀번호는 바뀌지 않습니다.'],
  vi: ['Đặt lại mật khẩu', 'Chúng tôi đã nhận yêu cầu đặt lại mật khẩu Pocket Kantei. Nhấn nút bên dưới để đặt mật khẩu mới (hiệu lực 30 phút).', 'Đặt mật khẩu mới', 'Nếu bạn không yêu cầu, hãy bỏ qua email này. Mật khẩu sẽ không thay đổi.'],
  es: ['Restablecer contraseña', 'Recibimos una solicitud para restablecer tu contraseña de Pocket Kantei. Pulsa el botón para crear una nueva (válido 30 minutos).', 'Crear nueva contraseña', 'Si no lo solicitaste, ignora este correo. Tu contraseña no cambiará.'],
  pt: ['Redefinir senha', 'Recebemos um pedido para redefinir sua senha do Pocket Kantei. Toque no botão abaixo para criar uma nova (válido por 30 minutos).', 'Criar nova senha', 'Se não foi você, ignore este e-mail. Sua senha não será alterada.'],
  id: ['Atur ulang kata sandi', 'Kami menerima permintaan untuk mengatur ulang kata sandi Pocket Kantei Anda. Ketuk tombol di bawah untuk membuat kata sandi baru (berlaku 30 menit).', 'Buat kata sandi baru', 'Jika Anda tidak memintanya, abaikan email ini. Kata sandi tidak akan berubah.'],
  th: ['ตั้งรหัสผ่านใหม่', 'เราได้รับคำขอให้ตั้งรหัสผ่าน Pocket Kantei ใหม่ แตะปุ่มด้านล่างเพื่อตั้งรหัสผ่านใหม่ (ใช้ได้ 30 นาที)', 'ตั้งรหัสผ่านใหม่', 'หากคุณไม่ได้ขอ ให้เพิกเฉยต่ออีเมลนี้ รหัสผ่านจะไม่เปลี่ยน']
};
function escHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
async function sendResetMail(to, link, lang) {
  const t = MAIL_TEXT[lang] || MAIL_TEXT.en;
  const html = `<div style="font-family:sans-serif;max-width:480px;margin:auto;padding:24px;color:#2b2b2b">`
    + `<h2 style="font-size:18px">${escHtml(t[0])}</h2><p style="line-height:1.7">${escHtml(t[1])}</p>`
    + `<p style="margin:24px 0"><a href="${escHtml(link)}" style="background:#4E8060;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none;font-weight:bold">${escHtml(t[2])}</a></p>`
    + `<p style="font-size:12px;color:#777;line-height:1.7">${escHtml(t[3])}<br>${escHtml(link)}</p></div>`;
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.MAIL_FROM, to: [to], subject: `Pocket Kantei — ${t[0]}`, html, text: `${t[1]}\n\n${link}\n\n${t[3]}` })
    });
    return r.ok;
  } catch (e) { return false; }
}
// ---- アカウントの検索・確認コード ----
// メールアドレスからアカウントを探す。e: の対応表 → なければ古い形（u:<メールアドレスのハッシュ>）。どちらも rec.email が一致した時だけ
async function findRec(store, email) {
  const idx = await store.get(`e:${userId(email)}`);
  if (idx) { const r = await store.get(`u:${idx}`, { type: 'json' }); if (r && r.email === email) return { key: `u:${idx}`, rec: r }; }
  const uid = userId(email), r = await store.get(`u:${uid}`, { type: 'json' });
  if (r && r.email === email) return { key: `u:${uid}`, rec: r };
  return null;
}
function uidOf(rec) { return rec.uid || userId(rec.email); }
// この仕組みより前に作られたアカウント（verified の欄がない）は、確認済みとして扱う
function isVerified(rec) { return rec.verified !== false; }
function mailReady() { return !!(process.env.RESEND_API_KEY && process.env.MAIL_FROM); }
// 6桁のコードを作ってメールで送る。rec[field] = { h, exp, tries, email, sent:[時刻] }。送れたら true、送りすぎは 'RATE'
async function issueCode(rec, field, to, lang, now) {
  if (!mailReady()) return false;
  const prev = rec[field] || {}, sent = (prev.sent || []).filter(x => x > now - 3600e3);
  if (sent.length >= CODE_PER_HOUR) return 'RATE';
  const code = String(crypto.randomInt(0, 1e6)).padStart(6, '0');
  rec[field] = { h: sha256(`${uidOf(rec)}:${code}`), exp: now + CODE_MIN * 60000, tries: 0, email: to, lang: MAIL2[lang] ? lang : 'en', sent: sent.concat(now) };
  const t = mailT(lang);
  return sendMail(to, t.codeSubj, t.codeBody, code);
}
// コードを確かめる。合えば true、違えば 'BAD_CODE'、期限切れ・回数切れは 'CODE_EXPIRED'（送り直してもらう）
function checkCode(rec, field, code) {
  const v = rec[field];
  if (!v || !v.h || v.exp < Date.now() || (v.tries || 0) >= CODE_TRIES) return 'CODE_EXPIRED';
  const c = String(code || '').replace(/\D/g, '');
  if (c.length === 6 && safeEq(sha256(`${uidOf(rec)}:${c}`), v.h)) return true;
  v.tries = (v.tries || 0) + 1;
  return v.tries >= CODE_TRIES ? 'CODE_EXPIRED' : 'BAD_CODE';
}
// 確認コード・アドレス変更のお知らせの文面（公開中の4言語。ほかは英語）
const MAIL2 = {
  ja: { codeSubj: 'メールアドレスの確認コード', codeBody: 'Pocket本格鑑定をご利用いただき、ありがとうございます。アプリの画面に、次の確認コードを入力してください（30分間有効）。\n\n確認コード：{c}\n\nお心当たりがない場合は、このメールを破棄してください。', chgSubj: 'メールアドレスが変更されました', chgBody: 'Pocket本格鑑定のアカウントのメールアドレスが、{e} に変更されました。お心当たりがない場合は、お問い合わせからご連絡ください。' },
  en: { codeSubj: 'Your verification code', codeBody: 'Thank you for using Pocket Kantei. Enter this code in the app (valid for 30 minutes).\n\nCode: {c}\n\nIf you did not request this, you can ignore this email.', chgSubj: 'Your email address was changed', chgBody: 'The email address of your Pocket Kantei account was changed to {e}. If this was not you, please contact us.' },
  ko: { codeSubj: '이메일 인증 코드', codeBody: 'Pocket Kantei를 이용해 주셔서 감사합니다. 앱 화면에 아래 인증 코드를 입력해 주세요 (30분간 유효).\n\n인증 코드: {c}\n\n요청하지 않으셨다면 이 메일을 무시하세요.', chgSubj: '이메일 주소가 변경되었습니다', chgBody: 'Pocket Kantei 계정의 이메일 주소가 {e}(으)로 변경되었습니다. 본인이 아니라면 문의해 주세요.' },
  zt: { codeSubj: '電子郵件驗證碼', codeBody: '感謝使用 Pocket 鑑定。請在 App 畫面輸入以下驗證碼（30分鐘內有效）。\n\n驗證碼：{c}\n\n如非本人操作，請忽略此郵件。', chgSubj: '電子郵件地址已變更', chgBody: '你的 Pocket 鑑定帳號的電子郵件地址已變更為 {e}。如非本人操作，請與我們聯絡。' }
};
function mailT(lang) { return MAIL2[lang] || MAIL2.en; }
// メールを送る（Resend）。本文の {c} は確認コード（HTML では大きく表示する）
async function sendMail(to, subject, body, code) {
  const text = body.replace('{c}', code || '');
  const html = `<div style="font-family:sans-serif;max-width:480px;margin:auto;padding:24px;color:#2b2b2b"><h2 style="font-size:18px">${escHtml(subject)}</h2>`
    + `<p style="line-height:1.7;white-space:pre-line">${escHtml(body).replace('{c}', `<b style="font-size:28px;letter-spacing:6px">${escHtml(code || '')}</b>`)}</p></div>`;
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.MAIL_FROM, to: [to], subject: `Pocket Kantei — ${subject}`, html, text })
    });
    return r.ok;
  } catch (e) { return false; }
}
const WEB_TRIAL_DAYS = 3;   // ウェブ版の無料お試しの日数（アプリはストアの設定で3日）
function jstYmd(ms) { return new Date(ms + 9 * 3600e3).toISOString().slice(0, 10).replace(/-/g, ''); }
function normEmail(s) { return String(s || '').trim().toLowerCase().slice(0, 254); }
// テレコムクレジットの継続課金を止める。※接続仕様書を受け取ってから実装する（解約API／解約用URLの呼び出し）。
//   実装するまでは NOT_READY を返す（ウェブ版の購入もまだ動かないため、利用者がここに来ることはない）。
// 下の解約（telecomStopRecurring）を実装して確かめてから、環境変数 PK_TELECOM_CANCEL_READY=1 にする（それまでウェブ版の購入は開かない）
const TELECOM_CANCEL_READY = process.env.PK_TELECOM_CANCEL_READY === '1';
async function telecomStopRecurring(sub, rec) {
  return { ok: false, code: 'NOT_READY' };
}
const TC = { stop: telecomStopRecurring };   // テストで差し替えられるように
// 購読の状態：billing.js（ストアからの通知）が rec.sub に書き込む。期限内なら有料プラン、切れていれば free
function planInfo(rec) {
  const s = rec && rec.sub;
  const trialEligible = !(rec && (rec.sub || rec.hadTrial));   // ウェブ版の「3日間無料」を出してよいか（サーバーが決める。最終点検 2026-10-26）
  if (s && s.plan && +s.expires > Date.now()) return { plan: s.plan, start: +s.start || 0, expires: +s.expires, willRenew: s.willRenew !== false, store: s.store || '', trial: !!s.trial, trialEligible };
  return { plan: 'free', trialEligible };
}
function userId(email) { return crypto.createHash('sha256').update(email).digest('hex'); }
function hashPw(pw, salt) { return crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex'); }
function safeEq(a, b) { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); }
function makeToken(uid, ver, secret) {
  const body = `${uid}.${ver}.${Date.now() + TOKEN_DAYS * 864e5}`;
  return `${body}.${crypto.createHmac('sha256', secret).update(body).digest('hex')}`;
}
function readToken(tok, secret) {
  const p = String(tok || '').split('.'); if (p.length !== 4) return null;
  const body = `${p[0]}.${p[1]}.${p[2]}`;
  if (!safeEq(crypto.createHmac('sha256', secret).update(body).digest('hex'), p[3])) return null;
  if (+p[2] < Date.now()) return null;
  return { uid: p[0], ver: +p[1] };
}
// 端末データ：pk_ で始まるキーの文字列だけを受け付ける（APIキーやログイン情報は除外）
function cleanData(d) {
  const o = {}; let n = 0;
  if (d && typeof d === 'object') for (const k of Object.keys(d)) {
    if (!/^pk_[A-Za-z0-9_]{1,40}$/.test(k) || k === 'pk_key' || k === 'pk_auth') continue;
    const v = String(d[k]); n += k.length + v.length; o[k] = v;
  }
  return n > MAX_DATA ? null : o;
}
async function readNum(store, k) { const v = await store.get(k); return v ? (parseInt(v, 10) || 0) : 0; }
// アカウントの保存箱（store.js）
async function getStore() { return require('./store.js').getStore('pk-accounts'); }
function jstDay() { const d = new Date(Date.now() + 9 * 3600 * 1000); return d.toISOString().slice(0, 10); }
function lower(o) { const r = {}; for (const k in o) r[k.toLowerCase()] = o[k]; return r; }
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(obj) }; }

// ---- テスト用エクスポート（本番動作には影響しない） ----
exports._t = { hashPw, makeToken, readToken, cleanData, normEmail, planInfo, getStore, userId, findRec, checkCode, TC, sendMail, jstYmd, WEB_TRIAL_DAYS };
