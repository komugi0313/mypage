// 関数：登録時のアンケートを受け取り、Firestore のコレクション pk-survey に保存する（Cloud Functions for Firebase。入口は index.js）。
// ・使い道：国・地域ごとの傾向を知り、サービスをより良くするため・次の商品開発のため（プライバシーポリシーに記載済み）。
// ・1端末につき1件（文書ID＝端末ID）。同じ端末から送り直した時は上書きします。
// ・Firestore の画面でそのまま見られ、CSV への書き出しや BigQuery での集計ができる形（項目ごとの欄）で保存します。
//
// POST /api/survey（application/x-www-form-urlencoded）
//   uid, name, email, topics, interests, source, freq, job, sex, age, country, lang
//   → 200 { ok:true }（保存できた）／ 400（形がおかしい）／ 403（他のサイトから）／ 503（保存できない）
// アプリは、2xx 以外の時は端末に残して、次に開いた時に送り直します（index.html の _svPost・pk_svq）。

const FIELDS = ['uid', 'name', 'email', 'topics', 'interests', 'source', 'freq', 'job', 'sex', 'age', 'country', 'lang'];
const MAX_BODY = 8000;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { ok: false, code: 'METHOD' });
  const site = String(process.env.SITE_URL || '').replace(/\/$/, '');
  const origin = (event.headers || {}).origin || (event.headers || {}).referer || '';
  if (site && origin && !origin.startsWith(site)) return json(403, { ok: false, code: 'ORIGIN' });
  const body = String(event.body || '');
  if (body.length > MAX_BODY) return json(413, { ok: false, code: 'TOO_LARGE' });

  const p = new URLSearchParams(body), rec = {};
  for (const k of FIELDS) rec[k] = String(p.get(k) || '').replace(/[\r\n\t]/g, ' ').trim().slice(0, 300);
  if (!EMAIL_RE.test(rec.email)) return json(400, { ok: false, code: 'BAD_EMAIL' });
  const id = (rec.uid.replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64)) || ('x' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8));
  rec.uid = id;
  rec.at = new Date().toISOString();

  try {
    await save(id, rec);
    return json(200, { ok: true });
  } catch (e) {
    return json(503, { ok: false, code: 'NO_STORE' });
  }
};

async function save(id, rec) {
  if (process.env.PK_STORE === 'memory') {   // テスト用
    const st = require('./store.js').getStore('pk-survey');
    return st.setJSON(`s:${id}`, rec);
  }
  const S = require('./store.js');
  await S._t.db().collection('pk-survey').doc(id).set(rec);
}
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(obj) }; }
