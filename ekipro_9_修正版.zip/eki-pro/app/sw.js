/* 易 EKI Pro — Service Worker
   アプリ本体をキャッシュし、オフラインでも開けるようにする。
   ※ AIによる鑑定文生成（Gemini）はオンライン時のみ。立卦・顧客管理・印刷はオフライン可。 */
const CACHE = 'eki-pro-v17'; /* v17=易の言葉に読み仮名を（）で付ける：易経（えききょう）・卦辞（かじ）・爻辞（こうじ）・本卦（ほんか）・之卦（しか）・互卦（ごか）・綜卦（そうか）・錯卦（さくか）・変爻（へんこう）・立卦（りっか）・上卦（じょうか）・下卦（かか）・内卦（ないか）・外卦（がいか）・初爻（しょこう）〜上爻（じょうこう）・四爻（しこう）・八卦の読み。天雷无妄（てんらいむぼう）・火雷噬嗑（からいぜいこう）に統一。オンライン鑑定にも同じ読みを指示。鑑定書は読み仮名ごと専門用語を出さない。 v16=オンライン鑑定の指示を改善：お客様の名前で呼ぶ（伏せ字・方言なし）、動いた爻と之卦を取り違えない、運気と爻の吉凶が食い違うときは爻を重く見て矛盾なく説明、原文は句読点まで正確に。圏外の定型文でも爻が凶のときは注意を添える。 v15=録音（声の議事録）ボタンを撤去、メモ欄を広く。顧客の履歴に相談テーマを日本語で表示。iPhoneで入力時に画面が拡大されないよう入力文字16px。圏外でも30日以内にログイン確認済みの会員は使える。 v14=アプリ画面・台本・要点・深掘り相談は易経の原文（卦の名前・卦辞・爻辞）を正確に示し、必ず「現代語にすると」を添える形に（教科書として原文を残す）。専門用語なしはお客様にお渡しする鑑定書だけ。 v13=お客様に話す言葉（台本・要点・判定・深掘り相談・鑑定書）を専門用語なしの現代語に（64卦の意味・爻の言葉を現代語に、卦の名前・漢文は出さない／オンライン鑑定にも厳守させ取りこぼしは置きかえ）。結果画面は「今回の結果」を現代語で表示し、卦の名前・図・原文は「鑑定士用の参考」に折りたたみ。「専門的に」の切り替えは廃止。 v12=鑑定書を充実：ご相談への答え・いまの状況・これからの流れ・生まれ持った性質と時期の目安（四柱推命・生年月日があるとき）・具体的なアドバイス・結びのことば。オンライン鑑定で生成／オフラインは定型文。 v11=鑑定書：鑑定士用の「要点」を載せない、同じ文のくり返しを除く、印刷で同じページが何枚も出る不具合を修正（鑑定書だけを1枚に）、背景を白に、行末の泣き別れ防止。 v10=アプリにログイン画面（会員ゲート：メール＋パスワード）を追加。決済接続までは PREVIEW_MODE=true で誰でも開ける。 v9=メールアドレスを忘れた・間違えた・変えたいを、お客様が自分で解決できるように。v8=二重申込はお客様の自己責任（返金なし）の案内に。v7=決済をテレコムクレジットに統一：申込（メール2回入力・最終確認・完了／失敗画面）・ログイン・マイページを新設。v6=料金を月額9,800円のみに統一（半年・年間プラン廃止）。v5=点検修正：命式をPRO版と同じ計算エンジンに・オンライン鑑定をサーバー中継に・本番でキー入力欄と引き継ぎメモを非表示・オンライン鑑定の印・AI表記の言い換え */
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon-180.png'
];

self.addEventListener('install', e => {
  self.skipWaiting();
  // 1件失敗しても他は残るよう個別に取得（本体index.htmlの取りこぼし防止）
  e.waitUntil(caches.open(CACHE).then(c => Promise.all(ASSETS.map(a => c.add(a).catch(() => {})))));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const sameOrigin = url.origin === location.origin;
  const isFont = /fonts\.(googleapis|gstatic)\.com/.test(url.host);

  // Gemini等の外部API・他オリジンは触らない（常にネットワーク）
  if (!sameOrigin && !isFont) return;

  // ページ遷移：ネット優先 → 失敗時はキャッシュした本体を返す（オフライン起動）
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req)
        .then(r => { const cp = r.clone(); caches.open(CACHE).then(c => c.put(req, cp)); return r; })
        .catch(() => caches.match('./index.html').then(m => m || caches.match('./')))
    );
    return;
  }

  // それ以外（CSS/JS/画像/フォント）：キャッシュ優先 → ネット（取得できたら保存）
  e.respondWith(
    caches.match(req).then(m => m || fetch(req).then(r => {
      if (r && r.status === 200 && (sameOrigin || /fonts\.gstatic/.test(url.host))) {
        const cp = r.clone();
        caches.open(CACHE).then(c => c.put(req, cp));
      }
      return r;
    }).catch(() => m))
  );
});
