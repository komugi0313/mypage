PRISMA GitHub Assets

This package contains:
- design-reference.png (master design reference)
- hero-desktop.png
- hero-mobile.png

NOTE:
The remaining files (person.webp, background.webp, logo.svg, favicon.svg)
cannot be faithfully extracted from a flattened design screenshot.
They should be exported from the original design source or recreated separately.

Claude Code prompt:
Use these images as fixed design assets. Do not regenerate or redesign them.
