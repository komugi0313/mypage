/*!
 * daily-engine.test.cjs — 日運エンジンの安全ガード（再発防止）
 * 実行:  node daily-engine.test.cjs
 * 目的:  「文面が潰れる／骨格がぶれる／同じ人で内容が変わる」を機械的に検出する。
 *        本番投入前・変更後は必ず全PASSであること（1つでもNGなら配信しない）。
 */
const KD = require("./daily-engine.js");
const E  = require("./engine.js");

let fails = 0;
function assert(name, cond, extra){
  if(!cond) fails++;
  console.log((cond ? "PASS" : "FAIL") + "  " + name + (cond ? "" : "  << " + (extra||"")));
}
function sig(p){ const L=p.lucky,PL=p.place,F=p.fortunes,S=p.season,TH=p.theme,EN=p.en;
  return [TH.message,EN.body,p.love,p.loveMove,p.weatherMsg,L.color,L.food,L.number,L.action,L.item,
    L.spotNature,L.spotCity,L.menu.join("/"),L.wear,L.act,L.advice,PL.nature,PL.city,
    F.friend,F.work,F.money,F.health,S.food,S.wear,p.onepoint,p.morning].join("|"); }

const date = {y:2026,m:7,d:26};

/* ① 決定論：同じ人・同じ日は必ず同じ（問い合わせ時の食い違い防止の要） */
const a = KD.generateDaily({y:1990,m:5,d:20}, date, {rel:"single",sex:"f",nick:"x"});
const b = KD.generateDaily({y:1990,m:5,d:20}, date, {rel:"single",sex:"f",nick:"x"});
assert("① 決定論（同一入力→完全一致）", JSON.stringify(a)===JSON.stringify(b));

/* ② 骨格不変：文面個別化(spread)を切り替えても四柱推命の読みは変わらない */
const off = KD.generateDaily({y:1990,m:5,d:20}, date, {rel:"single",sex:"f",spread:false});
const on  = KD.generateDaily({y:1990,m:5,d:20}, date, {rel:"single",sex:"f",spread:true});
assert("② 骨格不変 index",  off.index===on.index, off.index+"→"+on.index);
assert("② 骨格不変 weather",off.weather.name===on.weather.name);
assert("② 骨格不変 theme",  off.theme.god===on.theme.god);
assert("② 骨格不変 五行",   off.element.supplement===on.element.supplement);

/* ③ 文面が潰れない：同一日柱の全生年月日で、文面のユニーク率が高いこと（<50%なら重大） */
function bucketUnique(stem,branch){
  const dates=[]; for(let y=1950;y<=2010;y++)for(let m=1;m<=12;m++){const dim=new Date(y,m,0).getDate();
    for(let d=1;d<=dim;d++){const q=E.pillar(y,m,d); if(q.stem===stem&&q.branch===branch)dates.push({y,m,d});}}
  const set=new Set(); for(const bd of dates) set.add(sig(KD.generateDaily(bd,date,{rel:"single",sex:"f"})));
  return {n:dates.length, uniq:set.size, rate:set.size/dates.length};
}
["乙酉","甲子","癸亥","戊午"].forEach(k=>{
  const r=bucketUnique(k[0],k[1]);
  assert("③ 文面ユニーク率≥95% ("+k+")", r.rate>=0.95, r.uniq+"/"+r.n+" = "+(r.rate*100).toFixed(1)+"%");
});

/* ④ 別生年月日どうしは同一文面にならない（友人コピペ防止）。同一日柱内で無作為ペアを検査 */
(function(){
  const dates=[]; for(let y=1960;y<=2005;y++){const q=E.pillar(y,3,15); if(q.stem==="乙"&&q.branch==="酉")dates.push({y,m:3,d:15});}
  // 乙酉になる年をいくつか集めて総当たり
  const bs=[]; for(let y=1950;y<=2010&&bs.length<30;y++)for(let m=1;m<=12;m++){const dim=new Date(y,m,0).getDate();
    for(let d=1;d<=dim;d++){const q=E.pillar(y,m,d);if(q.stem==="乙"&&q.branch==="酉"){bs.push({y,m,d});break;}}}
  let dup=0,tot=0; for(let i=0;i<bs.length;i++)for(let j=i+1;j<bs.length;j++){tot++;
    if(sig(KD.generateDaily(bs[i],date,{rel:"single",sex:"f"}))===sig(KD.generateDaily(bs[j],date,{rel:"single",sex:"f"})))dup++;}
  assert("④ 別生年月日の同一文面ペア=0", dup===0, dup+"/"+tot+"ペアが一致");
})();

/* ⑤ 数値の健全性：2^53超の精度落ちが無いこと（個人シードが低位ビットまで分散） */
(function(){
  const lowbits=new Set();
  for(let y=1970;y<=2000;y++){ const p=KD.generateDaily({y,m:6,d:15},date,{rel:"single",sex:"f"});
    lowbits.add(p.lucky.food+"|"+p.lucky.number+"|"+p.love.slice(0,8)); }
  assert("⑤ 低位ビット分散（食材/数字/恋愛が多様）", lowbits.size>=15, "distinct="+lowbits.size);
})();

/* ⑥ 命式(フェーズ3)：カレンダー/メールが命式(喜神/忌神)で個人別になること */
(function(){
  let B; try{ B=require("./bazi.js"); }catch(e){ assert("⑥ bazi.js 読込", false, String(e)); return; }
  assert("⑥ PersonBazi 関数が存在", typeof B.PersonBazi==="function");
  const p=B.PersonBazi(1990,5,20,null,null,true,"f");
  assert("⑥ PersonBazi が命式を返す(ok)", p&&p.ok===true);
  // 同一日柱(乙酉)でも命式(喜神)が生年月日で分かれる＝カレンダー個人別化の根拠
  const A=B.PersonBazi(1950,2,19,null,null,true,"f");   // 身強
  const C=B.PersonBazi(1950,10,17,null,null,true,"f");  // 身弱
  const favStr=x=>Object.keys(x.fav).filter(e=>x.fav[e]==="喜").join("");
  assert("⑥ 同一日柱でも命式で喜神が変わる", favStr(A)!==favStr(C), favStr(A)+" vs "+favStr(C));
  // メール(generateDaily)が命式を反映し、身強/身弱で補う五行(fe)が変わる
  const rA=KD.generateDaily({y:1950,m:2,d:19},date,{rel:"single",sex:"f",personBazi:B.PersonBazi,timeUnknown:true});
  const rC=KD.generateDaily({y:1950,m:10,d:17},date,{rel:"single",sex:"f",personBazi:B.PersonBazi,timeUnknown:true});
  assert("⑥ メールに命式が反映(bazi!=null)", rA.bazi&&rA.bazi.sType, rA.bazi&&rA.bazi.sType);
  assert("⑥ 身強/身弱で補う五行が変わる", rA.element.supplement!==rC.element.supplement, rA.element.supplement+" vs "+rC.element.supplement);
  // ⑦ 出生時刻：不明は正午補完ではなく「三柱」（時柱を外す）／時刻ありは「四柱」
  const u3=B.PersonBazi(1988,11,7,null,null,true,"f");
  const k4=B.PersonBazi(1988,11,7,12,0,false,"f");
  assert("⑦ 時刻不明＝三柱(柱数3)", u3.pillars.length===3, "柱数="+u3.pillars.length);
  assert("⑦ 時刻あり＝四柱(柱数4)", k4.pillars.length===4, "柱数="+k4.pillars.length);
  // 三柱の結果が“正午”に依存しない＝正午補完ではない（12時の四柱とは別解になり得る）
  const favStr2=x=>Object.keys(x.fav).filter(e=>x.fav[e]==="喜").join("")+"/"+x.sType;
  assert("⑦ 三柱は正午四柱に引きずられない", favStr2(u3)!==favStr2(k4)||u3.pillars.length!==k4.pillars.length,
         "3柱="+favStr2(u3)+" 12時4柱="+favStr2(k4));
  // ⑧ カレンダー分野印の命式重み付け：忌の五行の日は良い印を出さない／喜・命式なしは出す
  assert("⑧ domainFavOk が関数", typeof KD.domainFavOk==="function");
  assert("⑧ 命式なし＝常にtrue(従来互換)", KD.domainFavOk(null,"甲")===true);
  // 身弱(喜=木水/忌=火土金)の人：財=土(戊/己)の日は忌→印を出さない、比劫=水(壬/癸)の日は喜→出す
  const wk=B.PersonBazi(1950,10,17,null,null,true,"f"); // 乙酉 身弱 喜=木水
  assert("⑧ 身弱に忌の五行の日は印オフ", KD.domainFavOk(wk.fav,"戊")===false, "戊(土)="+wk.fav["土"]);
  assert("⑧ 身弱に喜の五行の日は印オン", KD.domainFavOk(wk.fav,"壬")===true, "壬(水)="+wk.fav["水"]);
  // 身強(喜=火土金)の人：同じ財=土の日は喜→印を出す（同一日柱でも命式で印が変わる）
  const st=B.PersonBazi(1950,2,19,null,null,true,"f"); // 乙酉 身強 喜=火土金
  assert("⑧ 同一日柱でも命式で印が変わる", KD.domainFavOk(st.fav,"戊")!==KD.domainFavOk(wk.fav,"戊"),
         "身強:戊="+KD.domainFavOk(st.fav,"戊")+" 身弱:戊="+KD.domainFavOk(wk.fav,"戊"));
})();

/* ⑨ 24節気：全24件に note(豆知識)があり、日付判定とメール反映が正しい */
(function(){
  assert("⑨ SEKKIは24件", Array.isArray(KD.SEKKI)&&KD.SEKKI.length===24, "len="+(KD.SEKKI&&KD.SEKKI.length));
  const missing=KD.SEKKI.filter(s=>!s.note||!s.word||!s.name);
  assert("⑨ 全節気に note/word/name あり", missing.length===0, "欠け="+missing.map(s=>s.name).join(","));
  const s726=KD.getSekki(2026,7,26); assert("⑨ 7/26は大暑(夏)", s726.name==="大暑"&&s726.season==="夏", s726.name+"/"+s726.season);
  const s810=KD.getSekki(2026,8,10); assert("⑨ 8/10は立秋(秋)", s810.name==="立秋"&&s810.season==="秋", s810.name+"/"+s810.season);
  const s101=KD.getSekki(2026,1,1); assert("⑨ 1/1は冬至扱い(冬)", s101.season==="冬", s101.name+"/"+s101.season);
  const r=KD.generateDaily({y:1990,m:5,d:20},{y:2026,m:7,d:26},{rel:"single",sex:"f"});
  assert("⑨ メールに季節のnoteが載る", !!(r.season&&r.season.note&&r.season.word), r.season&&r.season.sekki);
})();

/* ⑩ 関心でテーマ出し分け：関心→注目分野が正しく選ばれ、内容が対応する運と一致 */
(function(){
  const bd={y:1990,m:5,d:20}, dt={y:2026,m:7,d:26}, base={rel:"single",sex:"f"};
  const love=KD.generateDaily(bd,dt,Object.assign({interests:["恋愛"]},base));
  const money=KD.generateDaily(bd,dt,Object.assign({interests:["お金・家計"]},base));
  const none=KD.generateDaily(bd,dt,Object.assign({interests:["グルメ","旅行"]},base));
  assert("⑩ 恋愛→focus=love", love.focus&&love.focus.domain==="love", love.focus&&love.focus.domain);
  assert("⑩ お金→focus=money", money.focus&&money.focus.domain==="money", money.focus&&money.focus.domain);
  assert("⑩ focus本文が該当運と一致", love.focus.text===love.love && money.focus.text===money.fortunes.money);
  assert("⑩ 対応関心なし→focus=null(安全)", none.focus===null);
  assert("⑩ 関心なし→focus=null", KD.generateDaily(bd,dt,base).focus===null);
  assert("⑩ 選択順で先頭の対応関心を採用", KD.generateDaily(bd,dt,Object.assign({interests:["旅行","仕事・キャリア","恋愛"]},base)).focus.domain==="work");
})();

/* ⑪ ラッキースポットの実用性：日常で行けない場所が混じっていない */
(function(){
  const NG=["滝","瀧","鍾乳洞","鉱山","岩場","渓谷","竹林","里山","農園","果樹園","高原","秋の山","日の出",
            "運河","水路","湖畔","港","砂浜","水鏡","石造り","ハーブ園","小川","太陽の見える","花火","サンデッキ"];
  const all=[]; ["木","火","土","金","水"].forEach(e=>{ all.push(...KD.SPOT[e].nature, ...KD.SPOT[e].city); });
  const bad=all.filter(s=>NG.some(w=>s.indexOf(w)>=0));
  assert("⑪ 行けない自然/町スポットが無い（自然・町とも）", bad.length===0, "要修正:"+bad.join(","));
  assert("⑪ 各五行に自然スポット4件以上", ["木","火","土","金","水"].every(e=>KD.SPOT[e].nature.length>=4));
})();

/* ⑫ pickIdx：個数がいくつでも“全要素”がまんべんなく出る（旧 (pseed*k)%len の潰れ対策） */
(function(){
  assert("⑫ pickIdx が関数", typeof KD.pickIdx==="function");
  // 連番pseedで len=6,15 の全要素が出るか（旧式は6→2,15→5しか出なかった）
  [6,15,8,20].forEach(len=>{
    const seen=new Set(); for(let p=0;p<len*40;p++) seen.add(KD.pickIdx(p,11,len));
    assert("⑫ len="+len+" を全網羅", seen.size===len, "出た種類="+seen.size);
  });
  // 実配信：ある人の120日で、同一五行日のスポットが2種類ではなく“ほぼ全部”出る
  const bd={y:1990,m:5,d:20}, opt={rel:"single",sex:"f"};
  const byFe={};
  let y=2026,m=7,d=1;
  for(let i=0;i<120;i++){ const r=KD.generateDaily(bd,{y,m,d},opt); (byFe[r.element.supplement]=byFe[r.element.supplement]||new Set()).add(r.lucky.spotNature);
    d++; const dim=new Date(y,m,0).getDate(); if(d>dim){d=1;m++;if(m>12){m=1;y++;}} }
  const worst=Math.min.apply(null,Object.keys(byFe).map(fe=>byFe[fe].size));
  assert("⑫ 120日で同一五行のスポットが3種類以上出る", worst>=3, "最小種類="+worst);
})();

/* ⑬ 全表示項目の“全網羅”監査：各項目が、五行ごとにバンク全数を使い切るか（回転の取りこぼし検出） */
(function(){
  // 各項目の「表示値の取り出し方」と「そのfeでのバンク全長」
  const FIELDS={
    "ラッキーカラー":{get:r=>r.lucky.color, bank:(fe)=>KD.COLORVAR[fe].length},
    "メニュー":{get:r=>r.lucky.menu[0], bank:(fe)=>KD.MENU[fe].length},
    "アイテム":{get:r=>r.lucky.item, bank:(fe)=>KD.ITEM[fe].length},
    "スポット自然":{get:r=>r.lucky.spotNature, bank:(fe)=>KD.SPOT[fe].nature.length},
    "町スポット":{get:r=>r.lucky.spotCity, bank:(fe)=>KD.SPOT[fe].city.length},
    "開運アクション":{get:r=>r.lucky.action, bank:(fe)=>KD.SPOT[fe].act.length}
  };
  // 多数の別人×多数日で、各fe・各項目の出現集合がバンク全長に達するか
  const seen={}; // key: field|fe -> Set
  const births=[]; for(let y=1975;y<=2000;y+=5)for(let mo=2;mo<=11;mo+=3)births.push({y,m:mo,d:12});
  for(const b of births){ let y=2026,m=1,d=1;
    for(let i=0;i<200;i++){ const r=KD.generateDaily(b,{y,m,d},{rel:"single",sex:"f"}); const fe=r.element.supplement;
      for(const name in FIELDS){ const k=name+"|"+fe; (seen[k]=seen[k]||new Set()).add(FIELDS[name].get(r)); }
      d++; const dim=new Date(y,m,0).getDate(); if(d>dim){d=1;m++;if(m>12){m=1;y++;}} }
  }
  let allFull=true, worstMsg="";
  for(const name in FIELDS){ for(const fe of ["木","火","土","金","水"]){ const k=name+"|"+fe; const got=(seen[k]||new Set()).size; const need=FIELDS[name].bank(fe);
    if(got<need){ allFull=false; worstMsg+=" "+name+"("+fe+")"+got+"/"+need; } } }
  assert("⑬ 全表示項目が五行ごとにバンク全数を使い切る", allFull, "未使用:"+worstMsg);
  // 量の下限（増量後の目安）
  const EE=["木","火","土","金","水"];
  assert("⑬ カラー≥16/五行", EE.every(e=>KD.COLORVAR[e].length>=16));
  assert("⑬ 食材≥12/五行", EE.every(e=>KD.FOOD[e].length>=12));
  assert("⑬ メニュー≥24/五行", EE.every(e=>KD.MENU[e].length>=24));
  assert("⑬ アイテム≥16/五行", EE.every(e=>KD.ITEM[e].length>=16));
  assert("⑬ スポット自然≥15/五行", EE.every(e=>KD.SPOT[e].nature.length>=15));
  assert("⑬ 町スポット≥15/五行", EE.every(e=>KD.SPOT[e].city.length>=15));
  assert("⑬ 開運アクション≥14/五行", EE.every(e=>KD.SPOT[e].act.length>=14));
  // 重複ゼロ（増量時の取りこぼし防止）
  const dupChk=(name,fn)=>{ let bad=""; EE.forEach(e=>{const a=fn(e); if(new Set(a).size!==a.length){const seen={};a.forEach(x=>seen[x]=(seen[x]||0)+1);bad+=" "+name+"["+e+"]:"+Object.keys(seen).filter(k=>seen[k]>1).join("/");}}); return bad; };
  let dups=""; [["カラー",e=>KD.COLORVAR[e].map(c=>c[0])],["食材",e=>KD.FOOD[e]],["メニュー",e=>KD.MENU[e]],["アイテム",e=>KD.ITEM[e]],["自然",e=>KD.SPOT[e].nature],["町",e=>KD.SPOT[e].city],["行動",e=>KD.SPOT[e].act]].forEach(([n,f])=>dups+=dupChk(n,f));
  assert("⑬ 全項目に重複が無い", dups==="", "重複:"+dups);
})();

/* ⑭ 服装は体感の季節（月ベース）で、季節違いが出ない（冬にサンダル等を防ぐ） */
(function(){
  assert("⑭ climateSeason: 8月=夏", KD.climateSeason(8)==="夏");
  assert("⑭ climateSeason: 1月=冬", KD.climateSeason(1)==="冬");
  assert("⑭ climateSeason: 4月=春/10月=秋", KD.climateSeason(4)==="春"&&KD.climateSeason(10)==="秋");
  const winterNG=["サンダル","ノースリーブ","半袖","タンクトップ","キャミソール"];
  const summerNG=["ダウン","チェスターコート","ダッフル","マフラー","タートルネック","ブーツ","厚手","裏起毛","キルティング"];
  const bd={y:1990,m:5,d:20};
  let bad="";
  for(let m=1;m<=12;m++){ for(let d=5;d<=25;d+=10){
    for(const sex of ["f","m"]){
      const r=KD.generateDaily(bd,{y:2026,m,d},{rel:"crush",sex});
      const w=(r.lucky.wear||"");
      const cs=KD.climateSeason(m);
      if(cs==="冬") winterNG.forEach(x=>{ if(w.indexOf(x)>=0) bad+=" "+m+"月/"+sex+":冬に"+x; });
      if(cs==="夏") summerNG.forEach(x=>{ if(w.indexOf(x)>=0) bad+=" "+m+"月/"+sex+":夏に"+x; });
    }
  }}
  assert("⑭ 服装に季節違いが無い（全12月×男女）", bad==="", "違反:"+bad);
})();

/* ⑮ 表示の整合：出会い・モテ運/恋チャンスの日（カレンダー◎）は、天気も晴れ以上＝“◎なのにくもり”を防ぐ */
(function(){
  assert("⑮ 正官テーマの文言が更新", KD.THEME_AXIS && KD.THEME_AXIS["正官"] && KD.THEME_AXIS["正官"].ax==="誠実に、信頼を築く", KD.THEME_AXIS&&KD.THEME_AXIS["正官"]&&KD.THEME_AXIS["正官"].ax);
  // 多数の人×日で「モテ/恋チャンスの日(沖でない)なのにくもり以下」が無い
  const births=[]; for(let y=1980;y<=2005;y+=5)for(let mo=1;mo<=12;mo+=2)births.push({y,m:mo,d:10});
  let bad=0, toukaLabelOK=true, checked=0;
  for(const b of births){ let y=2026,m=1,d=1;
    for(let i=0;i<120;i++){ const r=KD.generateDaily(b,{y,m,d},{rel:"single",sex:"f"});
      const br=r.pillars && r.pillars.today ? null : null; // brは内部。ここは結果で判定
      if((r.touka || r.en.lv===2) && r.en.lv!==3){
        // 沖(⚠️)でない日は index>=80(晴れ以上) を期待。沖判定は天気が にわか雨/くもり かつ penで下がるケースを許容するため、
        // ここでは「モテ/恋チャンスかつ index<52(にわか雨/くもり最下)」を違反とする緩めの整合チェック
        checked++;
        if(r.index<52) bad++;
      }
      if(r.special && r.special.type==='touka' && r.special.label!=='出会い・モテ運の日') toukaLabelOK=false;
      d++; const dim=new Date(y,m,0).getDate(); if(d>dim){d=1;m++;if(m>12){m=1;y++;}} }
  }
  assert("⑮ 桃花特別日の呼称が統一", toukaLabelOK);
  assert("⑮ モテ/恋チャンスの日が“くもり以下”に落ちない("+checked+"件検査)", bad===0, "違反="+bad);
})();

console.log("");
console.log(fails ? ("=== "+fails+" 件 FAIL（配信前に要修正）===") : "=== ALL PASS（安全）===");
process.exit(fails ? 1 : 0);
