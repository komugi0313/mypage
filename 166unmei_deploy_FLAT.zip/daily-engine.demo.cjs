/*!
 * daily-engine.demo.cjs — メール配信サーバ実装者向けサンプル
 * 実行:  node daily-engine.demo.cjs
 * 役割:  engine.js + daily-engine.js を Node で読み込み、1人分の「今日のメール内容」を
 *        決定論的に生成して表示する。サーバはこの generateDaily() の出力を
 *        メールHTMLテンプレートに差し込むだけでよい（本文ロジックの新規開発は不要）。
 */
const KD = require("./daily-engine.js"); // engine.js は自動で require される

// 登録フォーム(register.html)から得られる入力の例
const input = { y: 1990, m: 5, d: 20 };            // 生年月日（必須）
const dateJST = { y: 2026, m: 7, d: 26 };          // 配信日（★JSTで確定してから渡す。省略時はJST今日）
const opts = { nick: "あかり", rel: "single", sex: "f" };
// ※ 命式(喜神/忌神)も使う場合は opts.personBazi に my-tenki-demo と同じ関数を渡す（任意・無くても壊れない）

const payload = KD.generateDaily(input, dateJST, opts);

console.log("=== 生成された1日分のメール内容（決定論：同じ人・同じ日は常に同一） ===\n");
console.log(JSON.stringify(payload, null, 2));

// 決定論の確認（同じ入力→完全一致）
const again = KD.generateDaily(input, dateJST, opts);
console.log("\n決定論チェック:", JSON.stringify(payload) === JSON.stringify(again) ? "OK（毎回同一）" : "NG");
