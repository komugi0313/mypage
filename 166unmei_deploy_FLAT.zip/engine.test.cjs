/*!
 * engine.test.cjs — engine.js 回帰テスト（エンジニア引き継ぎ用）
 * 実行:  node engine.test.cjs
 * 目的:  日柱・関係判定・十神・十二運・決定論シードが崩れていないことを保証する。
 *        本番のメール配信をサーバへ移植した後も、このテストが全PASSであること。
 */
const E = require("./engine.js");

let fails = 0;
function assert(name, got, want){
  const ok = got === want;
  if(!ok) fails++;
  console.log((ok ? "PASS" : "FAIL") + "  " + name + "  got=" + got + (ok ? "" : "  want=" + want));
}

/* 1) 日柱回帰（暦の基準点。ここがズレると全機能が崩れる） */
assert("2000-01-01 = 戊午 (stem)",  E.pillar(2000,1,1).stem,  "戊");
assert("2000-01-01 = 戊午 (branch)",E.pillar(2000,1,1).branch,"午");
assert("2008-03-28 = 丁卯 (stem)",  E.pillar(2008,3,28).stem, "丁");
assert("2008-03-28 = 丁卯 (branch)",E.pillar(2008,3,28).branch,"卯");
assert("1981-06-10 = 己未 (stem)",  E.pillar(1981,6,10).stem, "己");
assert("1981-06-10 = 己未 (branch)",E.pillar(1981,6,10).branch,"未");

/* 2) 天地徳合の相手（干合かつ支合＝1/60） */
assert("partner(甲子).stem",  E.partner("甲","子").stem,  "己");
assert("partner(甲子).branch",E.partner("甲","子").branch,"丑");

/* 3) 関係判定 */
assert("stemRel(甲,己)=干合",   E.stemRel("甲","己"), "干合");
assert("branchRel(子,丑)=支合", E.branchRel("子","丑"), "支合");
assert("branchRel(子,午)=沖",   E.branchRel("子","午"), "沖");
assert("specialPair 天地徳合",  E.specialPair({stem:"甲",branch:"子"},{stem:"己",branch:"丑"}), "天地徳合");
assert("specialPair 律音",      E.specialPair({stem:"甲",branch:"子"},{stem:"甲",branch:"子"}), "律音");

/* 4) 十神（通変星）：甲日干から見て */
assert("juushin(甲,甲)=比肩", E.juushin("甲","甲"), "比肩");
assert("juushin(甲,己)=正財", E.juushin("甲","己"), "正財");
assert("juushin(甲,庚)=偏官", E.juushin("甲","庚"), "偏官");

/* 5) 十二運（甲は亥が長生・順行） */
assert("juniOf(甲,亥)=長生", E.juniOf("甲","亥"), "長生");
assert("juniOf(甲,午)=死",   E.juniOf("甲","午"), "死");

/* 6) 決定論（同じ人・同じ日は常に同じ＝食い違い防止の要） */
const a = E.dailyFacts({y:1990,m:5,d:20}, {y:2026,m:7,d:26});
const b = E.dailyFacts({y:1990,m:5,d:20}, {y:2026,m:7,d:26});
assert("決定論 seed一致",  a.seed,  b.seed);
assert("決定論 pseed一致", a.pseed, b.pseed);
assert("決定論 index一致", a.index, b.index);

/* 7) JST日付の確定（UTCずれ防止：todayJSTが {y,m,d} を返す） */
const tj = E.todayJST();
assert("todayJST 型OK", (typeof tj.y==="number" && typeof tj.m==="number" && typeof tj.d==="number"), true);

console.log("");
console.log(fails ? ("=== " + fails + " FAILURE(S) ===") : "=== ALL PASS ===");
process.exit(fails ? 1 : 0);
