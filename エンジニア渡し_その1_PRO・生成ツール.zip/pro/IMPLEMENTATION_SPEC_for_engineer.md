# 実装仕様書（エンジニア用）— 3サイト共通の会員・決済・API（PRO・ビギナー・易 EKI Pro）【最新版】

> **会員・決済・API の正はこの文書です。** 過去のやり取り・旧ドキュメントより、本書を優先してください。
> フロント（画面）は**完成済み**。エンジニアが作るのは **サーバー側API・決済・本番切替** です。
> 対応バージョン：PRO `pro/sw.js` の `CACHE = 'shichu-jidou-v463'`／ビギナー `beginner/sw.js` `'kyoukara-uranaishi-v101'`／易 EKI Pro `eki-pro/app/sw.js` `'eki-pro-v65'` ／ 最終更新：2026-10-13
> 3サイトの全体の依頼内容は、リポジトリ直下の `エンジニアへの実装依頼_3サイト.md` を先に読んでください。易 EKI Pro だけの追加分は `eki-pro/実装仕様_エンジニア向け.md`。
> `eki-pro/実装仕様_会員まわり_共通.md` は本書と**同じ内容の写し**です（食い違ったら本書が正）。
> 前提（発注者確認済み）：**Gemini（文章生成）はサーバー経由**（キーはサーバーだけに置く）／**決済はテレコムクレジット**／**Web先行 → のちに iOS・Android アプリ**。
> 行番号は目安です（2026-10-13 時点）。

---

## 0. 全体像

- **商品**：四柱推命 自動鑑定 PRO（`pro/`）・今日から占い師＝ビギナー（`beginner/`）・易 EKI Pro（`eki-pro/`）。販売事業者 **72k株式会社**。3商品とも **月額 9,800円（税込）の1プランのみ・7日間無料**。
- **フロント**：ビルド不要の**静的PWA**（HTML/CSS/JS）。各フォルダをそのまま静的ホスティングに載せれば動く。
- **バックエンド**：エンジニアが構築（基盤は自由。発注者の想定は Google 基盤〈Cloud Run 等〉）。作るもの：
  - **API 16本**（認証・会員8／顧客カルテ同期2／Gemini中継1／契約4／無料体験の確認1）。易 EKI Pro は**同期2本を使わず**（顧客名簿は端末内のみ）、申込前の `apply-start` を1本加える（＝15本）。
  - **決済結果の受け口**（テレコムクレジットからのサーバー間通知。名前は自由）
  - 定期処理・メール送信・回数上限
- **いちばん大事な機能**：利用者が**相談内容を打ち込み、その人の命式（易は卦）に沿った詳細鑑定をその場で受け取る**こと。この文章生成が `gemini` 中継。

### 構成図
```
[ ブラウザ / PWA / 将来アプリ ]
        │  fetch('/.netlify/functions/<名前>')   ※名前は名残。§3 の「API_BASE」参照
        ▼
[ あなたのサーバー ] ── API 16本（EKIは同期2本なし＋apply-start）＋ 決済結果の受け口
   ├─ 認証・会員（メール＋パスワード、トークン、契約ステータス）
   ├─ 顧客カルテ同期（PRO・ビギナーのみ）
   ├─ Gemini 中継（GEMINI_API_KEY はサーバーだけ）＋ 回数上限
   └─ 決済（テレコムクレジット）→ 契約ステータスを更新
```

---

## 1. 絶対に触ってはいけないもの

1. **計算エンジンは改変禁止**：`window.Bazi.computeChart`（`app-pro.html`・`meishi-sheet.html` の中に埋め込まれたスクリプト）、`computeMeishiki`（`meishi-sheet.html` の中）、`pklove.js`（恋愛ステータス表示）。命式・大運・立運・通変星・十二運・会局・吉凶星・空亡はエンジンが出力する。API実装で触る必要は一切ない。
2. **`pro/meishi-sheet.html` は `meishiki-original/meishi-sheet.html`・`beginner/meishi-sheet.html` とバイト単位で同一**に保つ（生成スクリプトはコピーしないので、変えたときは手で複製）。
3. **配信ファイルを変えたら、そのサイトの `sw.js` の `CACHE` を1つ上げる**（上げないと利用者の端末に更新が届かない）。
4. **ビギナーは直接編集しない**：`beginner/app-beginner.html`・`auth.html`・`pricing.html`・`mypage.html`（と `pklove.js`）は、PRO を直してから `python3 tools/sync_beginner_from_pro.py` で生成する。EKI の `upgrade.html`・`auth.html`・`mypage.html` も `python3 tools/eki_pay_from_pro.py eki-pro` で PRO から生成する。

---

## 2. 本番公開の切替チェックリスト（デプロイ前に必ず）

**生成（§1-4）をすべて終えてから、最後に3サイトそれぞれで行う**（生成すると PRO の値がビギナー・EKI に写るため）。実施後は各 `sw.js` の `CACHE` を1つ上げる。

| # | 内容 | PRO | ビギナー | EKI |
|---|---|---|---|---|
| 1 | 会員ゲート：`var PREVIEW_MODE = true;` → **`false`** | `app-pro.html` 746行 | `app-beginner.html` 764行 | `app/index.html` 547行 |
| 2 | 仮動作：`STUB: !/(^\|\.)(72k\.ai\|suimei\.jp\|ekipro\.jp)$/i.test(location.hostname)` → **`STUB: false`** | `auth.html` 229行・`mypage-pro.html` 185行・`pricing-pro.html` 378行（`TRIAL_CHECK`）・490行（`FIX`） | `auth.html` 229行・`mypage.html` 178行・`pricing.html` 364行（`TRIAL_CHECK`）・476行（`FIX`） | `auth.html` 231行・`mypage.html` 180行・`upgrade.html` 359行（`TRIAL_CHECK`）・471行（`FIX`）・`register.html` 154行（`CONFIG`） |
| 3 | 決済ページURL `var TELECOM_PAYMENT_URL={ month:'' };` と `var TELECOM_PARAM={ email:'email', order:'sendid' };` | `pricing-pro.html` 348〜349行 | `pricing.html` 334〜335行 | `upgrade.html` 329〜330行 |
| 4 | テスト用キー欄を削除 | `app-pro.html` の `<details id="gtest-wrap">`（988行）と `?gtest=1` で表示する1行（7991行）と、テスト用キーを読む1行（7985行 `geminiKey=…bazi_gkey…`。`geminiKey='';` に固定してもよい） | 同左（生成元の PRO を直して生成） | `app/index.html` の `#demoKeyCard`（708行）・`#geminiCard`（963行）と、`?gtest=1` で表示する1行（2950行）。2つの欄を消してもアプリは止まらない作り（2026-10-13 確認済み）。1156行の `GEMINI_API_KEY = ""` は空のまま |
| 5 | `DEMO_MODE` は `false` のまま | `app-pro.html` 743行 | `app-beginner.html` 761行 | `app/index.html` 557行 |
| 6 | `functions/gemini.js` | 会員確認は実装済み → **本番で環境変数 `MEMBER_CHECK_URL` を必ず設定**（§5） | 同左 | 同左 |

- **安全装置**：本番ドメイン（`72k.ai`・`suimei.jp`・`ekipro.jp` とそのサブドメイン）で開いたときは、1・2 を書きかえ忘れても画面側で自動的に `PREVIEW_MODE=false`・`STUB=false` になる。**それ以外のドメイン（`*.run.app`・`*.netlify.app`・アプリの `localhost` 等）では効かない**＝`PREVIEW_MODE=true` なら誰でも全機能が使え、`STUB=true` ならログイン・解約が見せかけで成功する。本番運用・検証をそのようなドメインで行う場合は、必ず表のとおり書きかえるか、判定式にドメインを足す。
- **テスト用キー**：URL に `?gtest=1` を付けたとき（またはファイルを直接開いたとき）だけ、端末に保存したテスト用キーで Google を直接呼ぶ。本番のURLでは、キーを保存した端末でも必ずサーバー中継を使う（2026-10-13 修正）。
- **`PREVIEW_MODE=true` の意味**：会員ゲートを無条件に解除（`if(PREVIEW_MODE){ unlock(); return; }`）。`file://` で直接開いたときも確認用に自動解除。
- **圏外での利用**：30日以内にネットでログイン確認できた会員（`member_token` があり、`member_status`・`member_period_end` が「使える状態」、`member_checked_at` が30日以内）は、通信できないときも待たずにアプリが開く。つながっていれば裏で `auth-check` を呼び、使えなくなっていたら閉じる。
- **使える状態**（フロントの `usable()`。アプリ・`auth.html`・マイページで同じ）：`active`／`trialing`／`canceling`、または `canceled` でも `periodEnd`（YYYY-MM-DD・日本時間）の23:59:59まで。＝**解約しても、無料期間・お支払い済みの期間の最終日までは使える**（規約・特商法の約束どおり）。

---

## 3. サーバーAPI仕様（16本 ＋ 決済結果の受け口）

- すべて **HTTPS／`POST`／`Content-Type: application/json`**（`gemini` だけ Google の generateContent 形式をそのまま通す）。
- **API_BASE**：フロントはパス `'/.netlify/functions'` を使う（名前は名残で、Netlify である必要はない）。`/.netlify/functions/<名前>` を各関数へリライトするか、下の定数を実URLに書きかえる（§9）。別オリジンにするなら CORS を許可する。
- **認証はトークン方式（必須）**：`auth-login` 成功時にサーバーがトークン（長期・失効可能）を発行して返す。フロントは**パスワードを端末に保存しない**（旧版の `member_pw`・`member_remember` は起動時に削除）。以後、マイページ・顧客カルテ・`gemini` は `Authorization: Bearer <member_token>`、`auth-check`・`auth-logout` は body の `token` で本人確認する。
- **商品の見分け**：フロントは商品名を送らない。呼び出し元のオリジン（`72k.ai`／`www.suimei.jp`／`ekipro.jp`）と、お申し込み番号の頭文字（`P-`／`B-`／`E-`）で見分ける。**契約は「メール × 商品」ごと**に持ち、**トークンは発行したサイトの商品でだけ有効**にする（PRO のトークンで EKI を開けないように）。
- **body の `email` を信用しない**：`mypage-*`・契約系の API は、body の `email` ではなく**トークンの本人**のデータだけを扱う。

### 3-1. 認証・会員（8本）
呼び出し元：`auth.html`（ログイン・パスワード設定・設定メール・アドレスを忘れた/間違えた・アドレス変更の確定）、アプリ本体（`app-pro.html` 等。ログイン・確認・ログアウト）、マイページ（ログアウト）、料金ページの完了画面（アドレス直し）。
**会員は「テレコムクレジットの決済結果の通知」でサーバーが作る**（§4）。画面からの「新規登録」は無い（`auth.html?view=register` は料金ページ〈EKI は `register.html`〉へ転送）。

| API | body | 成功 | 失敗 | 役割 |
|---|---|---|---|---|
| `auth-login` | `{ email, password }` | `{ ok:true, status, email, token, periodEnd }` | HTTP 401（違う）／429・403（失敗が続いて一時的に止めたとき。画面は「しばらくログインできません」と案内） | ログイン。フロントは `member_email`・`member_token`・`member_status`・`member_period_end`・`member_checked_at` を保存（「ログインしたままにする」を外すと `member_token` だけ sessionStorage、`member_checked_at` は保存しない） |
| `auth-check` | `{ token }` | `{ ok:true, status, periodEnd }` | HTTP 401（無効・ログアウト済み） | アプリ起動時のログイン確認。401 ならログイン状態を消してログイン画面へ |
| `auth-logout` | `{ token }` | `{ ok:true }` | ― | トークンを失効。フロントは結果を待たない |
| `auth-setpw` | `{ token, password }` | `{ ok:true, email }` | HTTP 400／401／404／410（期限切れ・使用済み・見つからない。画面は「送り直し」へ） | 設定メールのリンク（`auth.html?view=setpw&token=…`）でパスワードを決める。初回と再設定で共通。パスワードは8文字以上（画面で確認済み）。トークンは短命・ワンタイム |
| `auth-reset` | `{ email }` | `{ ok:true }` | ― | 設定メールの送信。**登録の有無にかかわらず同じ応答** |
| `auth-email-hint` | `{ orderId }` | `{ ok:true, hint }`（例 `ta***@ex***.com`） | **HTTP 400 または 404**（body `{ ok:false }`） | メールアドレスを忘れた：お申し込み番号から登録アドレスの一部を返す。回数制限必須 |
| `auth-fix-email` | `{ orderId, email }` | `{ ok:true }` | **HTTP 400 または 404**（body `{ ok:false }`） | 申込時の打ち間違いをお客様が自分で直し、設定メールを送り直す。**パスワード未設定の会員に限る**・回数制限必須 |
| `email-change-confirm` | `{ token }` | `{ ok:true, email }` | HTTP 400 等＋`{ ok:false }` | マイページで申請したアドレス変更の確定（`auth.html?view=email&token=…`）。短命・ワンタイム |

- **ご契約状況の取得に失敗したら 2xx 以外で返す**：マイページは、2xx 以外や決まった `status` 以外の返事を「取得できなかった」として扱い、解約・カード変更を押せないようにする（2026-10-14 修正。以前は「ご契約がありません」と誤って出ていた）。
- **失敗は HTTP ステータスで返す**：料金ページの完了画面（`auth-fix-email`）は**HTTP ステータスだけ**で成否を判断する。HTTP 200 で `{ok:false}` を返すと「送り直しました」と表示されてしまう。

**`status`（契約ステータス）**

| status | 意味 | アプリ |
|---|---|---|
| `active` | ご利用中（課金中） | 開く |
| `trialing` | 無料お試し中 | 開く |
| `canceling` | 解約手続き済み（期間の最終日まで利用可・以後の請求なし） | 開く（`periodEnd` まで） |
| `canceled` | 解約済み | `periodEnd` の最終日までは開く。過ぎたら開かない |
| `past_due` | お支払いが確認できない（課金失敗） | 開かない（マイページでカード変更へ） |
| `unpaid` | 未払い | 開かない |
| `none` | 契約なし | 開かない |

- **`periodEnd` は必ず `YYYY-MM-DD`（日本時間の日付）**。フロントは整形せずに判定と表示に使う（マイページでは「2026-10-17まで」と表示）。
- 期間が満了した解約済みの会員は、`auth-check` で **401 ではなく `{ ok:true, status:'canceled', periodEnd }`** を返すと、画面が「ご利用期間が終了しました（解約済み）／お申し込みページへ」と案内できる（401 だとただのログイン画面になる）。
- 表示名：マイページの `STATUS_JA` は7種すべて対応。アプリ・`auth.html` の `statusJa()` は `canceling` 以外の6種（`canceling` はアプリが開くので表示されない）。
- 通信：アプリの会員ゲートは8秒で打ち切る（電波の弱い会場で止まらないように）。`auth.html`・マイページは打ち切りなし。

### 3-2. 顧客カルテ同期（2本・PRO とビギナーのみ）
呼び出し元：`app-pro.html`（ビギナーは生成された `app-beginner.html`）だけ。マイページ画面からは呼ばない。易 EKI Pro は使わない（顧客名簿は端末内のみ。規約にも「当社のサーバーには保存しません」と記載）。ログイン中（`member_email` あり）のときだけ同期し、未ログイン・サーバー未接続のときは端末内だけで動く。

| API | body | 成功 | 役割 |
|---|---|---|---|
| `mypage-get` | `{ email }`＋`Authorization: Bearer` | `{ data: <ドキュメント> }` | トークン本人のデータを返す |
| `mypage-put` | `{ email, data: <ドキュメント> }`＋`Authorization: Bearer` | `{ data: <保存後のドキュメント> }` | 保存（サーバー側でも統合。下記）。1会員あたり数MBを想定 |

**ドキュメント形式（`data`）** — フロントの `mpSanitize`（`app-pro.html` 7208〜7229行）が受け付ける形。決まった形以外の値は捨てられる：
```json
{ "schema": 1, "updatedAt": 0,
  "clients": [ {
    "id": "英数字と _- の1〜64字",
    "name": "お名前（〜100字）", "kana": "ふりがな（〜100字）",
    "date": "YYYY-MM-DD（必須。無い・形が違う人は端末側で捨てる）", "time": "HH:MM", "notime": false,
    "sex": "female | male", "pref": "出生地の経度（数字の文字列）", "corr": "full | longitude | none", "zishi": "today | next",
    "memo": "鑑定メモ（〜20000字）",
    "next": "次回お伝えすること（〜4000字・PROの「前回のふり返り」で使う）",
    "tags": ["〜40字 × 30個まで"],
    "readings": [ { "id": "…", "kind": "英数〜32字", "title": "〜200字", "text": "〜200000字", "ts": 0 } ],
    "ts": 1727600000000, "deleted": false
  } ] }
```
- 削除した人は `{ id, deleted:true, ts }` だけが残る（名前・メモ・鑑定は空になる）。**サーバーはこの形をそのまま保存して返す**。
- **統合の規則（フロントの `mpMerge` と同じにする）**：両方の `clients[]` を `id` ごとに比べ、`ts`（更新時刻）が新しい方を採用。同じ `ts` なら後から渡した側（フロントではサーバーの応答）を採用。`deleted:true` は消えた印として残す（複数端末でも消えたまま）。`updatedAt` は両者の大きい方（フロントは更新しない）。
- **`mypage-put` の返事で端末のカルテを丸ごと置きかえず、統合する**（フロント実装済み）。サーバー側も、受け取ったデータで既存データを消さないよう統合する。
- 端末の保存キー：ログイン中は `bazi_mypage_v2@<メールアドレス>`（会員ごと）、未ログインのときは `bazi_mypage_v2`（ログインしたときに会員のキーへ引き継ぐ）。`bazi_clients_v1` は旧形式（初回の移行用）。
- **解約後のデータ**：規約 第12条・プライバシーポリシー 7 で「サーバーの顧客カルテは解約から1年間保管し、その間に再契約して同じメールでログインすれば引き継がれる」と約束している。再契約後の `mypage-get` は同じメールのデータを返す。1年を過ぎたら削除。
- **ロック中の書き出し**：解約後・期限切れでアプリがロックされていても、ロック画面の `#mg-export` から**その端末でログインしていた会員の分（と未ログイン時の分）だけ**を JSON で書き出せる（共用の端末でも、ほかの会員のカルテは書き出さない。2026-10-13 修正）。認証ゲートを作り直すときも消さない。
- ログアウト時、アプリは顧客カルテをサーバーに保存できたことを確かめてから端末から消す（保存できないときは端末に残し、その旨を表示）。

### 3-3. Gemini 中継（1本）
呼び出し元：
- PRO・ビギナー：`app-pro.html`／`app-beginner.html`（相談・自動鑑定・日運/月運・本格鑑定・相性）、`meishi-sheet.html`（鑑定書）。
- EKI：`app/index.html`（鑑定・深掘り相談・鑑定書）。

いずれも URL は定数ではなく `'/.netlify/functions/gemini'` と直接書いてある（`app-pro.html` 6332行・`meishi-sheet.html` 4223行・`app-beginner.html` 6351行・EKI `app/index.html` 2668行）。`netlify.toml` では `/api/gemini` も同じ関数の別名。

**APIキーは絶対にフロントに出さず、サーバーの環境変数で持つ。** 雛形 `functions/gemini.js`（3サイトとも同じ仕組み。EKI は全体の大きさの上限だけ5,800,000字）あり。

**フロントが送る body**（Google `generateContent` にそのまま渡せる形。モデル名は送らない＝サーバーが決める）：
```json
{
  "system_instruction": { "parts": [ { "text": "…指示…" } ] },
  "contents": [ { "role": "user", "parts": [ { "text": "…相談内容と命式データ…" } ] } ],
  "generationConfig": { "maxOutputTokens": 1536, "thinkingConfig": { "thinkingBudget": 0 } }
}
```
- `maxOutputTokens`：PRO・ビギナーは **1536（冒頭の答え）／3072（くわしい読み解き・全文）**、鑑定書は **3200**。EKI は **4096**（`temperature: 0.8`）。`thinkingConfig` は、PRO・ビギナーのアプリでは flash 系のときだけ付く。EKI は常に `thinkingBudget:0`。鑑定書は付けない（雛形が flash 系では必ず0にする）。
- **ヘッダ**：
  - `Authorization: Bearer <member_token>`（会員確認。フロントが自動で付ける）
  - `x-pk-deep: 1` … 深め（DEEP）の鑑定（自動鑑定・鑑定書など）。サーバーは `GEMINI_MODEL_DEEP` を使う
  - `x-pk-part: detail` … PRO・ビギナーの相談1件の**2回目**（くわしい読み解き）と、鑑定書の作り直し（ビギナーで専門用語が残ったとき等）。**回数に数えない**
  - `x-eki-kind: detail` … 易の鑑定1件の**2回目**（台本・要点などの残り）。**回数に数えない**
  - `x-eki-kind: sho` … 易の鑑定書の作成。**回数に数えない**
  - `x-pk-device` … 易だけが送る端末の識別子（会員確認がないときの予備）
- **答えを先に出す2回呼び出し**：相談1件（易は鑑定1件）で、まず短い「答え」を作ってすぐ表示し、続けて残りを作る＝**サーバーへの呼び出しは2回**。2回目には上の目印ヘッダが付く。**回数は「鑑定1件＝1回」で数える**（画面の数え方・規約の「1日200回」と同じ）。
- **応答**：Google の generateContent 応答JSONをステータスコードごとそのまま返す（フロントは `candidates[0].content.parts` の text を読む。PRO・ビギナーは parts を連結、EKI は `parts[0]` だけ。`error` があれば失敗扱い）。
- **フロントの待ち方**（アプリ本体）：70秒で打ち切り。失敗（エラー・空の応答）のときは PRO・ビギナーは2.5秒後に1回、EKI は混雑・通信エラーのときに最大2回まで再試行し、それでもだめなら**端末内の鑑定に自動で切り替える**（サーバーが落ちてもアプリは止まらない）。**401＝「ログインし直してください」、403＝「マイページでご契約状況をご確認ください」**と案内し分けるので、`gemini` は未ログインに 401、使えない状態に 403 を返す。※PRO・ビギナーの鑑定書（`meishi-sheet.html`）は打ち切り時間なし・401／403 も区別せず、失敗したら2.5秒後に1回やり直して定型文の鑑定書に切り替える。
- **会員確認（必須）**：雛形は環境変数 `MEMBER_CHECK_URL` に `{ token }` を POST し、`{ ok, status, periodEnd }` で「使える状態」（§2）か判定する（確認先が2xx以外→401、使えない状態→403、確認先に届かない→503）。Origin の確認だけでは curl 等で第三者に費用を使われるため、必ず有効にする。
- **お名前は送られてこない**：フロントがお名前を印（PRO・ビギナーのアプリ〔本人〕〔お相手〕、鑑定書〔ご本人〕、易〔お名前〕）に置きかえて送り、受け取った文章の中で戻す。
- **フロントの後処理**：受け取った文章から「AI」の言い回しを消し、読みがなの誤り（てんいつきじん→てんおつきじん、ぎょうざい／きょうざい→ごうざい）を直す（`noAIWord`）。**サーバーは本文を加工せずに返す**。

**回数の上限（規約・料金ページ・特商法に数値で明記済み。サーバーで会員ごとに数える）**

| サイト | 上限 | フロントの定数（目安。改ざんできるので正はサーバー） |
|---|---|---|
| PRO・ビギナー | **詳細鑑定 1日200回**（鑑定1件＝1回） | `AI_DAILY_CAP=200`（`app-pro.html` 6277行。端末の日付で数え、超えた日は端末内の鑑定に切替） |
| EKI（無料期間中） | **1日3回**（鑑定＋深掘り相談の合計。鑑定書の作成は数えない） | `TRIAL_DAILY_LIMIT=3`（日本時間の暦日で数える。超えても内蔵データの鑑定は使える） |
| EKI（有料） | **1日100回・1か月3,000回**（＋1分15回の連打制限。1分の数値は非公表＝規約第8条「頻度に上限」が根拠） | `PAID_DAILY_CAP=100`・`PAID_MONTHLY_CAP=3000`・`PAID_RATE_PER_MIN=15`（定義のみ・画面では未使用） |

- 回数は**日本時間の暦日**で0に戻す。数えるのは会員ID単位（同じ会員が複数の端末でログインしても合算）。
- 上限を変えるときは、LP・料金ページ・規約 第8条・特商法表記の数値も同時に直す（表示と違う上限はクレームになる）。
- **雛形 `gemini.js` には上の上限は入っていない**。雛形にあるのはボット対策の高い天井だけ（トークンごと1日400回 `PK_MAX_DEVICE_DAY`・IPごと1日800回 `PK_MAX_IP_DAY`。目印ヘッダの付いた呼び出しは数えない）。しかも数える先の Netlify Blobs が使えない環境では**天井なしで通る**。本番サーバーで上の表どおりに実装すること。

### 3-4. 契約・マイページ（4本）
呼び出し元：マイページ（`mypage-pro.html`／`mypage.html`）。**必ずトークンで本人確認してから応答**（メールアドレスだけで他人の契約を見たり解約したりできないように）。

| API | body | 成功 | 役割 |
|---|---|---|---|
| `check-subscription` | `{ email }`＋Bearer | `{ status, plan, orderId, trialEnd, nextChargeAt, periodEnd }` | ご契約状況。**`trialEnd`・`nextChargeAt` は表示用の文字列**（例 `2026年10月17日`。そのまま表示）、**`periodEnd` だけは必ず `YYYY-MM-DD`**（判定に使う）。未ログインは HTTP 401（ログイン案内を表示） |
| `card-update-url` | `{ email }`＋Bearer | `{ url }` | テレコムクレジットの**カード変更ページのURL**（フロントはそこへ移動）。変更後も無料期間・契約を引き継ぐ |
| `email-change` | `{ email, newEmail }`＋Bearer | `{ ok:true }`（新しいアドレスがほかの契約で使われているときは HTTP 409。画面がその旨を案内） | 新しいアドレスへ確認メールを送り、`email-change-confirm` で確定（確定までは旧アドレスのまま） |
| `cancel-subscription` | `{ email, orderId }`＋Bearer（`orderId`＝マイページに表示中の契約。`check-subscription` で返したもの） | `{ ok:true, status:'canceling', periodEnd }`（任意で `canceledAt`・`cancelId`） | 解約。継続課金を停止。**無料期間中なら初回課金をしない（0円）**。無料期間中・課金後とも `periodEnd` の最終日まで利用可。**`periodEnd` は必ず返す**。`canceledAt`（受付日時）・`cancelId`（受付番号）を返すと完了画面にも表示する（解約受付メールと同じ内容）。`orderId` がトークン本人の契約でなければ断る。**解約できなかったときは 2xx 以外か `{ ok:false }` を返す**（画面は `ok:true` のときだけ「完了しました」と出す）。401 なら画面は「もう一度ログイン」を案内 |

- **同じメール・同じ商品で契約が2件あるとき**（二重申込。自動で取り消さない＝§4-2）：`check-subscription` は「まだ解約していない契約のうち新しい方」（なければ最新）を返し、`cancel-subscription` は送られた `orderId` の契約を解約する。解約後にマイページを開き直すと、もう1件が表示されて、それも解約できる。アプリ（`auth-login`／`auth-check` の `status`）は、使える契約が1件でもあればその状態を返す。

### 3-5. 無料体験の確認（1本・3サイト）

| API | body | 成功 | 役割 |
|---|---|---|---|
| `trial-check` | `{ email }` | `{ ok:true, used:true\|false }` | そのメールアドレスで、**この商品の**無料体験を使ったことがあるか（過去の申込・会員の記録。解約済みも含む）。トークン不要（申込前に呼ぶ）。**回数制限必須**（メールアドレスの登録有無を総当たりで調べられないように） |

- 呼び出し元：申込の確認画面（`pricing-pro.html`／`pricing.html`／EKI `upgrade.html`。`TRIAL_CHECK.URL`）。`used:true` なら確認画面に赤字で「⚠ 無料体験は、お一人様1回までです。このメールアドレスでは、以前にお申し込みいただいた記録があります。」と出す。**申し込みは止めない**。5秒で打ち切り、失敗しても何も出さない。
- 画面は端末の記録（`member_email`・お申し込み完了の記録 `trial_used`）でも同じ表示を出す。
- カードが2回目かどうかは決済ページより前には分からないので、画面では確かめない。同一カード・同一メールの2回目は、結果通知の時点で記録だけしておく（§4-2）。

---

## 4. 決済（テレコムクレジット）とお申し込みの流れ

> 3商品とも**同じ流れ・同じAPI**。料金は **月額 9,800円（税込）のみ**（`PLAN.month`）。

### 4-1. 流れ（お客様の画面）
1. **申込画面**（PRO `pricing-pro.html`／ビギナー `pricing.html`／EKI は `register.html` でお名前・任意のプロフィールを入れたあと `upgrade.html`）：メールアドレスを**2回入力**（不一致はエラー）＋規約・特商法・プライバシー・自動更新への同意 → **最終確認画面**（特商法：メール・プラン・料金・無料期間の終了日・初回課金日・更新日・解約期限・回数上限・解約と返金を表示）。
2. 「この内容で申し込む（決済ページへ）」→ フロントが**お申し込み番号**を作り（`P-YYYYMMDD-XXXXX-XXXXX`。ビギナー `B-`、EKI `E-`。英大文字と数字で I・O・0・1 は使わない。日付は端末の日付）、`TELECOM_PAYMENT_URL` に**お申し込み番号とメールアドレス**を付けてテレコムクレジットの決済ページへ移動（パラメータ名は `TELECOM_PARAM`。**接続仕様書の名前に合わせて書きかえる**）。`TELECOM_PAYMENT_URL` が空の間は「準備中」と表示して進まない。
3. お客様が決済ページでカードを登録（無料期間付きの継続課金）。
4. **テレコムクレジット → サーバーへ決済結果の通知**（サーバー間）。サーバーは通知を仕様どおり検証し、お申し込み番号・メールで**会員を作成（`status=trialing`）**、「ログイン用パスワードの設定」メール（`auth.html?view=setpw&token=…`）を送る。同じ通知が何度来ても1件だけ作る（お申し込み番号で重複を防ぐ）。
5. 決済ページの**戻り先**：PRO `pricing-pro.html`／ビギナー `pricing.html`／EKI `upgrade.html` の `?result=ok`（完了：送り先メール・お申し込み番号・届かないときの案内。番号とメールはこの端末の `pending_order` から表示）／`?result=ng`（中断・失敗。`?result=back` も同じ表示）。**戻り先URLの表示だけで会員を作らない**（URLは誰でも打てる）。
6. メールのリンクでパスワードを決める → ログイン → アプリ。
7. 無料期間は**お申し込み日を1日目とする7日間**。**8日目に初回 9,800円** → `active`。以後その日が毎月の更新日（**その日がない月は月末日**）。次回の請求を止める期限は**更新日の前日23:59（日本時間）**。課金失敗 → `past_due`（アプリは開かず、マイページでカード変更へ誘導）。
8. **無料期間の終わりのお知らせはしない**（発注者決定 2026-10-13。終了前のお知らせメールなし）。代わりに、**何日まで無料で、何日から自動で月額9,800円になるか**を、確認画面・完了画面（`?result=ok`。`pending_order` の日時から日本時間で計算）・マイページ・特商法に日付で明記し、「終了前のお知らせメールはお送りしません」とも書いている。**パスワード設定メールにも、無料期間の最終日と初回課金日を日付で書く**。あわせて**お申し込み番号も書く**（別のブラウザで決済した等で完了画面に番号が出ないことがあり、「メールアドレスを忘れた・間違えた」に必要なため）。

- **易 EKI Pro の `apply-start`**：`register.html` が `{ email, profile:{ name, sex, age, pref, job, exp } }` を送る（返事は読まない・失敗しても先へ進む）。お申し込み番号はまだ無いので、決済結果とは**メールでひも付ける**。会員はまだ作らない。
- 無料期間・継続課金・カード変更・解約・結果通知の具体的なやり方（APIか管理画面か、無料期間を決済ページ側で設定できるか、通知の形式と検証方法、カード変更ページのURLの作り方）は、**テレコムクレジットの接続仕様書で確認**する。

### 4-2. 間違い・トラブルへの備え（画面は実装済み）
| 起きること | 画面での案内 | サーバー・運営で必要なこと |
|---|---|---|
| メールアドレスの打ち間違い | お客様が自分で直す：完了画面の「アドレスを直して送り直す」、またはログイン画面「メールアドレスを忘れた・間違えた」でお申し込み番号を入れて直す | `auth-fix-email`（パスワード未設定の会員のみ・回数制限） |
| メールアドレスを忘れた | お申し込み番号で登録アドレスの一部を表示 | `auth-email-hint`（回数制限）・`auth-reset` |
| パスワードを忘れた | 「パスワードを忘れた」→設定メール | `auth-reset`・`auth-setpw` |
| メールアドレスを変えたい | マイページ →確認メール→リンクで確定 | `email-change`・`email-change-confirm` |
| 設定メールが届かない | 迷惑メール等の案内、`auth.html?view=reset` で再送 | 送信元 `info@72k.ai`（SPF・DKIM） |
| 決済できない・途中で閉じた | `?result=ng` 画面・やり直し | 通知が来ない限り会員を作らない |
| 二重申込 | 最終確認「ボタンは1回だけ」、二度押し防止、ログイン済みの端末には「もう一度お申し込みしないでください」 | 下記 |
| カードの期限切れ・変更 | マイページ「お支払いカードを変更する」 | `card-update-url` |
| 解約 | マイページ「解約する」（無料期間中は0円、課金後は期間末まで利用可） | `cancel-subscription`。**マイページで解約できないときはメールでも受け付ける**（特商法に明記）。当社の障害で解約できなかった場合は、連絡を受けた日を解約日として扱う |
| 見覚えのない請求 | マイページ「困ったとき」 | お申し込み番号・請求日・金額で照合できるよう、決済通知を保存 |

- **二重申込は自動で取り消さない**（発注者決定 2026-10-13）：同じメール・同じ商品で2件目の申込が来ても、規約 第3条・特商法のとおり**それぞれ契約として作る**（返金なし。不要な方はお客様がマイページで解約。§3-4 の「契約が2件あるとき」）。
- **無料体験はお一人様1回（ゆるく運用）**（発注者決定 2026-10-13）：確認画面の赤字表示（§3-5）で知らせるだけで、**申し込みは止めない**。2回目（同一メール・同一カード）と分かっても、**自動で取り消したり、無料なしで即時に課金したりはしない**（7日分の重複利用は許容）。同一カードを判定できる値がテレコムクレジットで取れるなら記録しておき、`trial-check` の判定に使う。規約 第5条第3項（当社の判断で無料期間を付与しないことがある）は裁量として残す。
- **障害時の返金**：当社の障害で**連続48時間以上**使えなかった場合は日割りで返金（規約 第9条第4項・特商法）。サービスを終了するときは30日前までに知らせ、前払い分を日割りで返金（規約 第9条第2項）。テレコムクレジットで一部返金（または次回からの減額）の方法を確認し、障害の開始・終了時刻を記録する。
- 特商法・規約・プライバシーポリシー（事業者情報・販売URL・`og:url` は記入済み：72k株式会社／PRO `https://72k.ai/`・ビギナー `https://www.suimei.jp/`・EKI `https://ekipro.jp/`）。変えるときだけ差し替える。

---

## 5. 環境変数（`functions/gemini.js`。他の関数は実装に応じて）

| 変数 | 本番 | 内容 |
|---|---|---|
| `GEMINI_API_KEY` | **必須** | Gemini のキー（ブラウザには出さない）。請求先を有効にした有料プロジェクトのキーに限る（プライバシーポリシーの約束） |
| `MEMBER_CHECK_URL` | **必須** | 会員確認の関数のURL（`{token}` を受けて `auth-check` と同じ `{ok,status,periodEnd}` を返す）。**`URL` が設定された環境でこれが未設定だと 503 で止まる**（誰でもキーを使える状態を防ぐため） |
| `URL` | **必須（Netlify 以外）** | 自サイトのURL。Netlify では自動で入る。**Netlify 以外では自動で入らないので手で設定**（未設定だと、送信元の確認と「`MEMBER_CHECK_URL` 未設定なら止める」安全装置が両方とも働かない） |
| `ALLOWED_ORIGINS` | 1つのサーバーで3商品を扱うなら**必須** | 追加で許可する送信元（カンマ区切り・**オリジンの完全一致**。例 `https://72k.ai,https://www.suimei.jp,https://ekipro.jp`） |
| `DEPLOY_PRIME_URL` | 自動（Netlify） | Netlify のプレビューURL（許可に含まれる） |
| `GEMINI_MODEL`／`GEMINI_MODEL_DEEP` | 任意 | 通常／`x-pk-deep:1` のときのモデル。どちらも既定 `gemini-2.5-flash` |
| `PK_ALLOW_NO_MEMBER_CHECK` | **本番では設定しない** | `1` で会員確認なしで動かす（公開前の確認環境だけ） |
| `PK_OWNER_TOKEN` | 任意 | ヘッダ `x-pk-owner` が一致したとき天井を数えない（動作確認用） |
| `PK_MAX_DEVICE_DAY`／`PK_MAX_IP_DAY` | 任意 | ボット対策の天井（既定 400／800） |
| `PK_PRICE_IN`／`PK_PRICE_OUT`／`PK_PRICE_CACHE`／`PK_FX_JPY` | 任意 | 原価の記録用の単価（ログ `[pro-cost]` と応答ヘッダ `x-pk-tok` に出す） |

- **雛形は Netlify Functions 用の書き方**（`exports.handler`、`event.httpMethod/headers/body` を受けて `{statusCode,headers,body}` を返す。数えるのは `@netlify/blobs`）。他の基盤で動かすときは作り直す。
- 雛形が返すエラー：401 `LOGIN`、403 `MEMBER`／`ORIGIN`、405（POST以外）、413 `TOO_LONG`（`role:'user'` の付いた最後の入力が40,000字超、または全体が900,000字超。EKI は `role` を送らないので全体の上限5,800,000字だけが効く）、429 `BUSY`、451 `REGION`、500 `NO_KEY`、502 `UPSTREAM`、503 `SETUP`／`MEMBER_CHECK`。
- 雛形のやり直し：通常（DEEP でない）呼び出しが Google から 429 のときは0.9秒後に1回だけ再試行。DEEP が失敗したら、`GEMINI_MODEL_DEEP` と `GEMINI_MODEL` が違うときだけ通常モデルで1回やり直す（既定は同じなのでやり直さない）。

---

## 6. ファイル構成（PRO＝`pro/`。ビギナー・EKI も同じ考え方）

| ファイル | 役割 |
|---|---|
| `index.html` | LP。**PRO だけ**、`member_email` があり `member_status` が `active`／`trialing` の端末は即 `app-pro.html` へ（ビギナー・EKI の LP には無い） |
| `app-pro.html` | 鑑定ツール本体（命式・相談・詳細鑑定・相性・顧客カルテ・会員ゲート） |
| `meishi-sheet.html` | 鑑定書（印刷用）。本体から `localStorage['bazi_sheet_featbook']` 等で受け渡し。3か所でバイト同一 |
| `auth.html` | ログイン／パスワード設定／設定メール／ログインできないとき／アドレス変更の確定 |
| `mypage-pro.html` | マイページ（契約状況・カード変更・アドレス変更・解約・困ったとき） |
| `pricing-pro.html` | 申込（メール2回入力・最終確認）→ 決済ページ／戻り（`?result=ok`・`ng`）の画面 |
| `terms-pro.html`／`privacy-pro.html`／`tokushoho-pro.html` | 規約・プライバシー・特商法 |
| `textbook-pro.html`・`ritsuun.html`・`kaigou.html` ほか | 教科書ページ |
| `pklove.js` | 恋愛ステータス表示（**改変禁止**） |
| `functions/gemini.js` | Gemini 中継の雛形（§3-3・§5） |
| `netlify.toml` | 関数の場所と `/api/gemini` の別名 |
| `sw.js` | Service Worker（`CACHE`＋`ASSETS`） |
| `manifest-pro.webmanifest` | PWA（`start_url: index.html`。ビギナーは `app-beginner.html`、EKI は `app/index.html`） |
| `demo.mp4`／`demo.webm`／`demo-poster.png` | LP の動画とポスター（`preload="none"`。**`ASSETS` に入れない**） |

- **Service Worker**：ページを開くとき（navigate）はネット優先（PRO・ビギナー3.5秒、EKI 3秒で応答がなければ保存版で開く）。PRO・ビギナーは、それ以外の GET は保存版を先に返して裏で更新（stale-while-revalidate）、POST（API）と別オリジンには触らない。EKI の `app/sw.js` は、ページ以外は保存版優先（あれば裏で更新しない）で、Google Fonts だけは別オリジンでも保存する。ファイルを増やしたら `ASSETS[]` に足して `CACHE` を上げる。
- **文字の見えやすさの安全装置**：全 HTML の `</body>` 直前に `<script id="pk-contrast-guard">`（中身は `tools/contrast_guard.js`）。読みにくい文字色だけを自動で直す（計算・鑑定・API には関係なし）。ページを足したら `python3 tools/add_contrast_guard.py` → 生成スクリプトの順に実行。
- **PRO だけの機能**：`app-pro.html` の `<!--PRO-ONLY:start（説明）-->`〜`<!--PRO-ONLY:end-->`（8007〜8316行の1ブロック）。「今月の運勢をまとめて作る（LINE用の文章）」「前回のふり返り（次回お伝えすること＝顧客の `next`）」「鑑定トーク例」。すべて端末内で動き、**サーバーの追加作業はない**（`next` が同期データに入るだけ）。今月の運勢の結び・送信済みの印は端末内（`pk_bm_sign|…`・`pk_bm_sent|…`）で同期しない。生成時にビギナーから取り除かれる。
- **相談の入口**：入力欄の下の `#cs-box`（相談の例 `#cs-chips`・入力 `#cs-q`）と「この相談を鑑定する」（`#f-go`）。相談を書いて押すと命式を出したあと相談の鑑定をし、空欄なら命式全体の自動鑑定をする。画面の右下に「相談する」（`#cs-fab`）。画面だけの機能でサーバーは関係しない。

---

## 7. セキュリティ必須事項

1. **`GEMINI_API_KEY` はサーバーのみ**。本番でテスト用キー欄を削除（§2 #4）。
2. 全通信 HTTPS。パスワードはハッシュ保存（bcrypt／argon2 等）。
3. トークン認証：`auth-login` で発行したトークンを `auth-check`・`mypage-*`・契約系・`gemini` で検証。ログアウト・パスワード変更で失効。
4. `auth-*` は回数制限・総当たり対策。設定メール・変更メールのリンクは短命・ワンタイム。
5. 決済結果の通知はテレコムクレジットの仕様どおり検証してから反映。戻り先URL（`?result=ok`）では会員を作らない。
6. 契約・マイページ系の API は、body のメールではなくトークンの本人だけを扱う。

---

## 8. Web の次：iOS / Android アプリ

- リポジトリ直下の `app/` に Capacitor の土台あり（`appId` は仮の `com.example.shichupro`、`scripts/sync-web.sh` が `pro/` を写す）。
- アプリでは相対パスの `/.netlify/functions` が届かないので、API は絶対URL＋CORS にする。`localhost` では本番ドメインの安全装置（§2）が効かず、`gemini.js` の送信元確認にも `ALLOWED_ORIGINS` の追加が要る。
- **審査**：アプリ内でデジタル課金する場合、Apple／Google は原則ストア内課金を求める。**Web＝テレコムクレジット／アプリ＝ストア課金と決済が分かれる**前提で設計する（`status` 管理はサーバー共通）。

---

## 9. フロントの主要定数（書きかえ箇所の早見）

| 定数 | 場所 | 現在値 | 本番 |
|---|---|---|---|
| `API` | `app-pro.html` 749行（ビギナー 767行） | `'/.netlify/functions'` | 実APIのベース（リライトなら据え置き） |
| `MP_API` | `app-pro.html` 7196行（ビギナー 7215行） | `'/.netlify/functions'` | 同上 |
| `'/.netlify/functions/gemini'`（直接記述） | `app-pro.html` 6332行・`meishi-sheet.html` 4223行 | ― | 同上 |
| `PREVIEW_MODE` | `app-pro.html` 746行 | `true` | `false` |
| `CONFIG.API`／`CONFIG.STUB` | `auth.html`・`mypage-pro.html` の `var CONFIG` | `'/.netlify/functions'`／本番ドメイン以外で true の式 | 実ベース／`false` |
| `TRIAL_CHECK.URL`／`TRIAL_CHECK.STUB` | `pricing-pro.html`（`var TRIAL_CHECK`） | `'/.netlify/functions/trial-check'`／本番ドメイン以外で true の式 | 実URL／`false` |
| `FIX.URL`／`FIX.STUB` | `pricing-pro.html` 490行 | `'/.netlify/functions/auth-fix-email'`／同上の式 | 実URL／`false` |
| `TELECOM_PAYMENT_URL`／`TELECOM_PARAM`／`ORDER_PREFIX` | `pricing-pro.html` 348〜350行 | `{month:''}`／`{email:'email',order:'sendid'}`／`'P'` | 決済URL／接続仕様書の名前／そのまま |
| `geminiModel` | `app-pro.html` 2740行 | `'gemini-2.5-flash'` | 変更不要（本番のモデルはサーバーの `GEMINI_MODEL` で決まる。フロントの値はテスト用の直接呼び出しと `thinkingConfig` の有無だけに効く） |
| `AI_DAILY_CAP` | `app-pro.html` 6277行・`meishi-sheet.html` 4179行 | `200` | 規約と同じ値のまま |

- **生成で写る値**：ビギナーには PRO の `PREVIEW_MODE`・`STUB`・決済URL が、EKI の `upgrade.html`・`auth.html`・`mypage.html` には `STUB`・決済URL がそのまま写る（`ORDER_PREFIX` だけ B／E に置きかわる）。決済URLが商品ごとに違うなら、生成後に各サイトで設定する。

**localStorage／sessionStorage のキー**（どれも端末内だけ。サーバーと同期するのは顧客カルテだけ）
- 会員：`member_email`・`member_token`（「ログインしたままにする」を外すと sessionStorage）・`member_status`・`member_period_end`・`member_checked_at`。旧 `member_pw`・`member_remember` は起動時に削除。
- 申込：`pending_order`（お申し込み番号・メール・日時の控え）・`selected_plan`・`trial_used`（この端末で申込を完了したメールの記録。確認画面の赤字表示に使う）、EKI `eki_apply`（`register.html` → `upgrade.html` の受け渡し・1時間有効）。
- 顧客カルテ：`bazi_mypage_v2@<メール>`／`bazi_mypage_v2`・`bazi_clients_v1`（旧）。鑑定書：`bazi_sheet_featbook`・`meishiki_saved_v1`。
- 回数：`ai_daily_YYYYMMDD`（PRO・ビギナー、端末の日付）、EKI `eki_trial_YYYYMMDD`（日本時間）・`eki_trial_start`。
- そのほか：`bazi_brand_name`／`bazi_brand_logo`／`bazi_brand_color`（鑑定書の屋号）、`pk_bm_sign|…`・`pk_bm_sent|…|YYYY-MM`（PRO だけ）、EKI `eki_pro_v1`（顧客名簿・設定）・`eki_dev`（端末の識別子）、テスト用 `bazi_gkey`／EKI `eki_pro_key`（本番のURLでは使われない）、`bazi_gmodel`（本番でも読まれるが、`thinkingConfig` を付けるかどうかだけに効く）。

---

## 10. 受け入れ確認（サーバー実装後・3サイトとも）

- [ ] 申込 → 決済 → **結果通知で会員作成（trialing）** → 設定メール → パスワード設定 → ログイン → アプリが開く。
- [ ] 決済の中断・失敗は `?result=ng`。`?result=ok` を手で打っても会員は作られない。
- [ ] 同じメールで2件申し込むと2件とも契約になり（自動で取り消さない）、マイページで1件ずつ解約できる。
- [ ] `trial-check`：以前に申し込んだメールなら `used:true` で、確認画面に赤字が出る（申し込みは止まらない）。回数制限がかかっている。
- [ ] `auth-login`：正しければ `{ok:true,status,email,token,periodEnd}`、誤りは 401。`auth-check`・`auth-logout` もトークンで動く。
- [ ] `active`／`trialing`／`canceling` で開く。`canceled` は `periodEnd` の最終日まで開き、翌日から開かない。`past_due`／`unpaid`／`none` は開かない（`PREVIEW_MODE=false` で確認）。
- [ ] `auth-setpw`（期限切れ・使用済みは 400／410）・`auth-reset`（会員の有無で応答を変えない）。
- [ ] `auth-email-hint`・`auth-fix-email`（失敗は HTTP 400／404。パスワード設定後は直せない）・`email-change`→`email-change-confirm`。いずれも回数制限あり。
- [ ] マイページ：状態ごとの表示、カード変更ページへの移動、解約（無料期間中は0円・`periodEnd` まで利用可）。他人のメールアドレスを送っても他人の契約は見えない・解約できない。
- [ ] 8日目に 9,800円が課金され `active`（終了前のお知らせメールは送らない。パスワード設定メールに無料期間の最終日と初回課金日を書く）。課金失敗で `past_due`。解約の受付メール（受付日時・受付番号・利用できる最終日）。
- [ ] `mypage-get`／`put`（PRO・ビギナー）：2台の端末で編集しても消えない。消した人は両方で消える。
- [ ] `gemini`：会員なら鑑定文が返る。非会員・トークンなし・許可していない送信元は断る。**相談1件（易は鑑定1件）＝1回**で数え、PRO・ビギナー1日200回、EKI 無料期間1日3回・有料1日100回・月3,000回で止まる（`x-pk-part: detail`・`x-eki-kind: detail`／`sho` は数えない）。
- [ ] 30日以内にログインを確認した端末は、圏外でもアプリが開く。
- [ ] §2 の本番切替を3サイトとも実施し、各 `sw.js` の `CACHE` を上げた。
- [ ] 計算エンジンは無改変。基準ケース `1981-06-10 22:28 女性` で 月柱 甲午／順行／立運8年6ヶ月／大運 甲午→乙未→丙申→丁酉。

---

### 補足（発注者メモ）
- 発注者の Netlify 等の確認用URLは私的な動作確認用で、本番には関与しない。デモ段階は一般公開しない。
- 会員情報の保管・運用はエンジニアに任せる。個人情報の扱いは各サイトの `privacy*.html` と合わせる（サーバーの顧客カルテと会員情報は解約から1年で削除、アクセス記録は1年）。
