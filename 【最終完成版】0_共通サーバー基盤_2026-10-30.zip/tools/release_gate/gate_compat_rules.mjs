// 発売前の点検（相性の流派の決まり）：鑑定者本人が伝えた決まり（CLAUDE.md「相性の決まり」・写真の表）どおりに、
// PRO／ビギナーの相性の判定（compatBalance）が「律音・三合・方合・半会・支合」を1つも落としていないかを、たくさんの組み合わせで確かめる。
// あわせて、神殺・合冲の表が鑑定者本人の表（写真 2026-10-23）と1マスずつ同じか（アプリと鑑定書の両方）、恋愛相談の4項目が必ず入るかも確かめる。
// 文章作成は使わない（呼び出し0回）。使い方：node tools/release_gate/gate_compat_rules.mjs <pro|beginner> [組み合わせの数=400]
const { chromium } = await import('/opt/node22/lib/node_modules/playwright/index.mjs');
import http from 'http'; import fs from 'fs'; import path from 'path';
const ROOT=path.resolve(path.dirname(new URL(import.meta.url).pathname),'../..'), site=process.argv[2]||'pro', N=+(process.argv[3]||400);
const dir=site==='pro'?'pro':'beginner', page0=site==='pro'?'app-pro.html':'app-beginner.html';
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};
const srv=http.createServer((q,r)=>{let p=decodeURIComponent(q.url.split('?')[0]);if(p.endsWith('/'))p+='index.html';const f=path.join(ROOT,dir,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){r.writeHead(404);r.end();return;}r.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(r);}).listen(0);
await new Promise(r=>srv.on('listening',r)); const port=srv.address().port;
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({serviceWorkers:'block'}); let calls=0;
await ctx.route('**/.netlify/functions/**',r=>{ if(/gemini/.test(r.request().url())) calls++; r.fulfill({status:200,contentType:'application/json',body:'{"ok":true}'}); });
const p=await ctx.newPage(); await p.goto(`http://127.0.0.1:${port}/${page0}`); await p.waitForTimeout(2500);
const res=await p.evaluate((N)=>{
  // 鑑定者本人の決まり（CLAUDE.md「相性の決まり」・写真の表）
  const CP_SANGO=[['申','子','辰'],['亥','卯','未'],['寅','午','戌'],['巳','酉','丑']], FP_HOUGO=[['寅','卯','辰'],['巳','午','未'],['申','酉','戌'],['亥','子','丑']];
  const CP_RIKUGO={子:'丑',丑:'子',寅:'亥',亥:'寅',卯:'戌',戌:'卯',辰:'酉',酉:'辰',巳:'申',申:'巳',午:'未',未:'午'};
  let seed=20261022; const rnd=()=>{ seed=(seed*1103515245+12345)%2147483648; return seed/2147483648; };
  const fails=[], fixed=[[2008,3,28,14,0,false,'female'],[2006,6,7,12,0,true,'male'],[2007,1,17,12,0,true,'male'],[2006,8,19,12,0,true,'male']];
  const mk=(y,m,d,h,mi,tu,sex)=>{ const c=baziCompute({year:y,month:m,day:d,hour:h,minute:mi,sex,tu},0,'none'); return tu?markTimeUnknown(c):c; };   // 時刻不明は画面と同じく時柱を外す
  const people=fixed.map(x=>mk(...x));
  for(let k=0;k<N;k++){ const y=1950+Math.floor(rnd()*60), m=1+Math.floor(rnd()*12), d=1+Math.floor(rnd()*28), tu=rnd()<0.3; people.push(mk(y,m,d,Math.floor(rnd()*24),Math.floor(rnd()*60),tu,rnd()<0.5?'male':'female')); }
  const pairs=[[0,1],[0,2],[0,3]]; for(let k=4;k+1<people.length;k+=2) pairs.push([k,k+1]);
  // 月柱と日柱が同じ干支になる組を、わざと作って確かめる（律音の月×日）
  for(let k=4;k<people.length&&k<44;k++){ const a=people[k]; for(let j=4;j<people.length;j++){ const c=people[j]; if(j!==k&&a.pillars[1].ganzhi===c.pillars[2].ganzhi){ pairs.push([k,j]); break; } } }
  let checked=0, rit=0, ritMD=0, han=0;
  pairs.forEach(([i,j])=>{ const A=people[i], B=people[j]; const R=compatBalance(A,B), it=R.items, has=(kind,where)=>it.some(x=>x.kind.indexOf(kind)===0&&(!where||x.where.indexOf(where)>=0));
    const okA=q=>!(q===3&&A.timeUnknown), okB=q=>!(q===3&&B.timeUnknown), PN=['年柱','月柱','日柱','時柱'], gA=A.pillars.map(x=>x.ganzhi), gB=B.pillars.map(x=>x.ganzhi);
    const tag=A.birth.clock+' × '+B.birth.clock;
    // 律音
    if(gA[2]===gB[2]){ rit++; if(!has('律音（日柱どうし）')) fails.push(tag+'：日柱どうしの律音がない'); } else if(has('律音（日柱どうし）')) fails.push(tag+'：律音でないのに日柱どうしの律音');
    if(gA[1]===gB[2]){ ritMD++; if(!has('律音（あなたの月柱×お相手の日柱）')) fails.push(tag+'：月柱×日柱の律音がない'); }
    if(gA[2]===gB[1]){ ritMD++; if(!has('律音（あなたの日柱×お相手の月柱）')) fails.push(tag+'：日柱×月柱の律音がない'); }
    // 支合（全部の柱どうし）・半会（2支）
    for(let x=0;x<4;x++){ if(!okA(x)) continue; for(let y=0;y<4;y++){ if(!okB(y)) continue; const ba=A.pillars[x].branch, bb=B.pillars[y].branch, w='本人の'+PN[x]+'「'+gA[x]+'」×お相手の'+PN[y]+'「'+gB[y]+'」';
      const kanS=(typeof KANGO!=='undefined')&&KANGO[A.pillars[x].stem]===B.pillars[y].stem;
      if(CP_RIKUGO[ba]===bb&&!has('支合',w)&&!(kanS&&has('天地徳合',w))) fails.push(tag+'：支合がない '+w);
      const CEN={子:1,午:1,卯:1,酉:1}, hanOK=ba!==bb&&(CEN[ba]||CEN[bb])&&CP_SANGO.some(g=>g.includes(ba)&&g.includes(bb));   // 半合は子午卯酉を含む2支だけ（鑑定者本人の表＝写真 2026-10-23）
      if(hanOK){ han++; if(!has('半合',w)) fails.push(tag+'：半会（半合）がない '+w); } else if(has('半合',w)) fails.push(tag+'：子午卯酉を含まないのに半合 '+w); } }
    // 三合・方合（2人で持ち寄ってそろう）
    const abr=A.pillars.map((q,x)=>okA(x)?q.branch:null), bbr=B.pillars.map((q,y)=>okB(y)?q.branch:null);
    [[CP_SANGO,'三合'],[FP_HOUGO,'方合']].forEach(([T,kind])=>T.forEach(g=>{ const inA=g.filter(z=>abr.includes(z)), inB=g.filter(z=>bbr.includes(z)), uni=g.filter(z=>abr.includes(z)||bbr.includes(z));
      if(uni.length===3&&inA.length>=1&&inB.length>=1&&inA.length<3&&inB.length<3&&!it.some(x=>x.kind===kind&&x.where.indexOf(g.join(''))>=0)) fails.push(tag+'：'+kind+'（'+g.join('')+'）がない'); }));
    checked++; });
  return {checked,rit,ritMD,han,fails};
},N);
// ── 鑑定者本人の表（写真 2026-10-23）＝正典。アプリ（画面の表）と鑑定書（meishi-sheet.html）の両方を1マスずつ照らし合わせる
const PHOTO={
  NIKKAN:{ 天乙貴人:'丑未 子申 酉亥 酉亥 丑未 子申 丑未 寅午 卯巳 卯巳', 大極貴人:'子午 子午 卯酉 卯酉 丑辰未戌 丑辰未戌 寅亥 寅亥 巳申 巳申', 福星貴人:'子寅 丑亥 子戌 酉 申 未 午 巳 辰 卯',
    文昌貴人:'巳 午 申 酉 申 酉 亥 子 寅 卯', 羊刃:'卯 辰 午 未 午 未 酉 戌 子 丑', 飛刃:'酉 戌 子 丑 子 丑 卯 辰 午 未', 暗禄:'亥 戌 申 未 申 未 巳 辰 寅 丑', 金与禄:'辰 巳 未 申 未 申 戌 亥 丑 寅', 紅艶:'午 申 寅 未 辰 辰 戌 酉 子 申' },
  GETSU:{ 天徳貴人:'巳庚丁申壬辛亥甲癸寅丙乙', 月徳貴人:'壬庚丙甲壬庚丙甲壬庚丙甲', 天徳合:'申乙壬巳丁丙寅己戊亥辛庚', 月徳合:'丁乙辛己丁乙辛己丁乙辛己', 華蓋:'辰丑戌未辰丑戌未辰丑戌未' },
  NICHI:{ 咸池:'酉午卯子酉午卯子酉午卯子', 駅馬:'寅亥申巳寅亥申巳寅亥申巳', 劫殺:'巳寅亥申巳寅亥申巳寅亥申', 亡神:'亥申巳寅亥申巳寅亥申巳寅', 血刃:'戌酉申未午巳辰卯寅丑子亥', 囚獄:'午卯子酉午卯子酉午卯子酉', 隔角:'卯卯午午午酉酉酉子子子卯' },
  KAIGOU:'庚辰 庚戌 壬辰 壬戌 戊戌', ROKUBA:'壬午 癸巳', NICHIJIN:'丙午 戊午 壬子',
  KEI:'卯 未戌 巳申 子 辰 寅申 午 丑戌 寅巳 酉 丑未 亥', CHU:'午未申酉戌亥子丑寅卯辰巳', HA:'酉辰亥午丑申卯戌巳子未寅', GAI:'未午巳辰卯寅丑子亥戌酉申',
  KANGO:'甲己 乙庚 丙辛 丁壬 戊癸', RIKUGO:'子丑 寅亥 卯戌 辰酉 巳申 午未' };
const tableCheck=(T)=>{ const S='甲乙丙丁戊己庚辛壬癸', B='子丑寅卯辰巳午未申酉戌亥', bad=[], srt=x=>[...x].sort().join('');
  try{
    for(const n in PHOTO.NIKKAN){ PHOTO.NIKKAN[n].split(' ').forEach((v,i)=>{ const got=((T.KICHI_NIKKAN[S[i]]||{})[n]||[]).join(''); if(srt(got)!==srt(v)) bad.push(n+'('+S[i]+')='+(got||'なし')+'→'+v); }); }
    for(const n in PHOTO.GETSU){ [...PHOTO.GETSU[n]].forEach((v,i)=>{ const got=(T.KICHI_GETSU[B[i]]||{})[n]; if(got!==v) bad.push(n+'(月支'+B[i]+')='+(got||'なし')+'→'+v); }); }
    for(const n in PHOTO.NICHI){ [...PHOTO.NICHI[n]].forEach((v,i)=>{ const b=B[i]; let got; if(n==='血刃') got=T.BLOOD[b]; else if(n==='隔角') got=T.KAKU[b]; else got=(T.KICHI_NICHI[T.SANGO_KEY[b]]||{})[n]; if(got!==v) bad.push(n+'('+b+')='+(got||'なし')+'→'+v); }); }
    [['KAIGOU','魁罡'],['ROKUBA','禄馬貴人'],['NICHIJIN','日刃']].forEach(([k,nm])=>{ const want=PHOTO[k].split(' '), got=T[k]||[]; if(srt(want.join(''))!==srt(got.join(''))||want.length!==got.length) bad.push(nm+'='+(got.join('・')||'なし')+'→'+want.join('・')); });
  }catch(e){ bad.push('表が読めない '+e.message); }
  return bad; };
// アプリ（画面）の表
const appT=await p.evaluate(()=>{ const set=x=>x instanceof Set?[...x]:Object.keys(x||{}); return { KICHI_NIKKAN, KICHI_GETSU, KICHI_NICHI, SANGO_KEY, BLOOD, KAKU, KAIGOU:set(KAIGOU), ROKUBA:set(ROKUBA), NICHIJIN:(typeof NICHIJIN!=='undefined')?set(NICHIJIN):[],
  KEI:'子丑寅卯辰巳午未申酉戌亥'.split('').map(a=>'子丑寅卯辰巳午未申酉戌亥'.split('').filter(b=>(a!==b&&(isKei2(a,b)||isKei3(a,b)))||(a===b&&JIKEI.has(a))).join('')),
  CHU:'子丑寅卯辰巳午未申酉戌亥'.split('').map(a=>'子丑寅卯辰巳午未申酉戌亥'.split('').find(b=>isChong(a,b))).join(''), HA, GAI, KANGO, RIKUGO }; });
const bad=tableCheck(appT);
{ const B='子丑寅卯辰巳午未申酉戌亥', srt=x=>[...x].sort().join('');
  PHOTO.KEI.split(' ').forEach((v,i)=>{ if(srt(appT.KEI[i])!==srt(v)) bad.push('刑('+B[i]+')='+appT.KEI[i]+'→'+v); });
  [...PHOTO.CHU].forEach((v,i)=>{ if(appT.CHU[i]!==v) bad.push('冲('+B[i]+')='+appT.CHU[i]+'→'+v); });
  [...PHOTO.HA].forEach((v,i)=>{ if(appT.HA[B[i]]!==v) bad.push('破('+B[i]+')='+appT.HA[B[i]]+'→'+v); });
  [...PHOTO.GAI].forEach((v,i)=>{ if(appT.GAI[B[i]]!==v) bad.push('害('+B[i]+')='+appT.GAI[B[i]]+'→'+v); });
  PHOTO.KANGO.split(' ').forEach(x=>{ if(appT.KANGO[x[0]]!==x[1]||appT.KANGO[x[1]]!==x[0]) bad.push('干合 '+x); });
  PHOTO.RIKUGO.split(' ').forEach(x=>{ if(appT.RIKUGO[x[0]]!==x[1]||appT.RIKUGO[x[1]]!==x[0]) bad.push('支合 '+x); }); }
console.log('  '+(bad.length?'NG':'OK')+' 神殺・合冲の表＝鑑定者本人の表（写真）と1マスずつ同じ（アプリ）'+(bad.length?'  … '+bad.slice(0,8).join(' / '):''));
if(bad.length) res.fails.push('アプリの表: '+bad.join(' / '));
// 鑑定書（meishi-sheet.html）の表：ファイルの中の表をそのまま読んで照らし合わせる
{ const src=fs.readFileSync(path.join(ROOT,dir,'meishi-sheet.html'),'utf8'), grab=(name)=>{ const m=new RegExp('var '+name+'=(\\{[\\s\\S]*?\\});').exec(src); if(!m) return null; return Function('return '+m[1])(); };
  const sT={ KICHI_NIKKAN:grab('KICHI_NIKKAN'), KICHI_GETSU:grab('KICHI_GETSU'), KICHI_NICHI:grab('KICHI_NICHI'), SANGO_KEY:grab('SANGO_KEY'), BLOOD:grab('BLOOD'), KAKU:grab('KAKU'), KAIGOU:Object.keys(grab('KAIGOU')||{}), ROKUBA:Object.keys(grab('ROKUBA')||{}), NICHIJIN:Object.keys(grab('NICHIJIN')||{}) };
  const kg2=/var KG2=\{([^}]*)\}/.exec(src); const kgs=kg2?kg2[1].split(',').map(x=>x.split(':')[0].trim()).sort().join(''):'';
  const sb=tableCheck(sT); if(kgs!==PHOTO.KAIGOU.split(' ').sort().join('')) sb.push('命式の特徴の魁罡='+kgs);
  console.log('  '+(sb.length?'NG':'OK')+' 神殺の表＝写真と同じ（鑑定書）'+(sb.length?'  … '+sb.slice(0,8).join(' / '):''));
  if(sb.length) res.fails.push('鑑定書の表: '+sb.join(' / ')); }
// 恋愛相談の4項目（配偶宮の蔵干・パートナーの星が喜神か・出会いの場・縁が動く月）：書いていない文にはツールが書き足す
{ const lv=await p.evaluate(()=>{ if(typeof loveFourLines!=='function'||typeof pkEnsureLove!=='function') return {L:null,t:'',n:''}; const c=baziCompute({year:1981,month:6,day:10,hour:22,minute:28,sex:'female',tu:false},0,'none'); const L=loveFourLines(c); const t=pkEnsureLove('テスト。',c,'この人は遊び人ですか？'), n=pkEnsureLove('テスト。',c,'仕事運は？'), g=pkEnsureLove('2027年3月ごろ（きみずうの月）に出会いが動きます。',c,'彼氏はできますか');
    return { L:L&&L.pro, t, n, g }; });
  const e=[]; const L=lv.L||[];
  if(!/日支「未」/.test(L[0]||'')||!/蔵干（司令）は 丁（偏印）。/.test(L[0]||'')||/乙（偏官）|己（比肩）/.test(L[0]||'')) e.push('配偶宮の蔵干（司令だけ）');   /* 蔵干は司令だけ（鑑定者本人の指示 2026-10-24） */
  if(!/パートナーの星（官星＝五行の「木」）は、あなたの喜神（きしん：あると調子が上がる五行）です/.test(L[1]||'')) e.push('パートナーの星が喜神か');
  if(!/2人の相性とは別の見方/.test(L[1]||'')) e.push('相性とは別の見方の一言');
  if(!/月柱/.test(L[2]||'')||!/仕事/.test(L[2]||'')) e.push('出会いの場');
  if(!/2027年3月(?:ごろ|〜4月上旬)（癸卯の月）/.test(L[3]||'')||/亥の月）＝[^／]*半合/.test(L[3]||'')) e.push('縁が動く月');
  if(!/【恋愛で(必ず見る4つ|大事な4つのこと)】/.test(lv.t)||(lv.t.match(/\n・/g)||[]).length!==4) e.push('書き足し');
  if(lv.n!=='テスト。') e.push('恋愛でない相談に書き足している');
  if(!/2027年3月(?:ごろ|〜4月上旬)（癸卯の月）/.test(lv.g||'')) e.push('月の干支の直し（きみずう→癸卯）');
  if(!/出会いの場：|出会いやすい場所は/.test(lv.g||'')) e.push('「出会い」の言葉だけで出会いの場ありと判定している');
  console.log('  '+(e.length?'NG':'OK')+' 恋愛相談の4項目（1981-06-10 女性で確認）'+(e.length?'  … '+e.join('・'):''));
  if(e.length) res.fails.push('恋愛相談の4項目: '+e.join('・')); }
// 文章を書く側の事実まちがいの直し（十干の陰陽・月支元命の数）
{ const ff=await p.evaluate(()=>typeof pkFactFix==='function'?[pkFactFix('日干は丁（火の陽＝温かさ）'),pkFactFix('月支元命（性格の中心）に「偏印」が3つある'),pkFactFix('正官（せいかん）（行動力と決断力の星）が巡る'),String(pkIsLoveQ('11月にデートに誘われています。好きになる可能性はありますか？'))]:['','','','']);
  const e=[]; if(!/丁（火の陰/.test(ff[0])) e.push('丁＝火の陰'); if(!/月支元命（性格の中心）が「偏印」で、命式全体ではこの星が3つ/.test(ff[1])) e.push('月支元命の数'); if(!/正官（せいかん）（規律・責任・誠実の星）/.test(ff[2])) e.push('正官の説明'); if(ff[3]!=='true') e.push('デートの相談を恋愛と見分ける');
  console.log('  '+(e.length?'NG':'OK')+' 十干の陰陽・月支元命の数の直し'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('事実の直し: '+e.join('・')); }
// 文章作成の干支の字のまちがい（日付についた干支を暦どおりに直す。pkFactFix ⑧。PRO・易・鑑定書は同じ中身＝下の中身くらべで確かめる。2026-11-06）
{ const g=await p.evaluate(()=>typeof pkFactFix==='function'?pkFactFix('2026年11月6日（木申）がよい。2026年11月8日（丁戌（ひのといぬ））。2027年（丙未・19歳）。2026年12月（辛子の月）。2026年11月7日（土）（乙酉）。2026年11月〜12月上旬（己亥・庚子の月）。2026年11月（戊亥の月）。曜日：2026年11月6日（水）。'):'');
  const e=[]; [['2026年11月6日（甲申）','木申→甲申'],['2026年11月8日（丙戌）','丁戌→丙戌'],['2027年（丁未・19歳）','丙未→丁未'],['2026年12月（庚子の月）','辛子→庚子の月'],['2026年11月7日（土）（乙酉）','正しい干支は変えない'],['（己亥・庚子の月）','月の範囲は変えない'],['2026年11月（己亥の月）','戊亥→己亥'],['2026年11月6日（金）','曜日']].forEach(([x,n])=>{ if(String(g).indexOf(x)<0) e.push(n); });
  if(/ひのといぬ/.test(g)) e.push('まちがった干支の読みが残った');
  console.log('  '+(e.length?'NG':'OK')+' 日付についた干支・曜日のまちがいの直し'+(e.length?'  … '+e.join('・')+'｜'+String(g).slice(0,200):'')); if(e.length) res.fails.push('干支の直し: '+e.join('・')); }
// 大運・年運・月運・日運の名前つきの干支のまちがい（pkRunGzFix）と、お客様へのお伝え方の言いかえで文がくずれないこと（pkPlainTalk。2026-11-06）
{ const r=await p.evaluate(()=>{ if(typeof pkRunGzFix!=='function'||typeof pkPlainTalk!=='function') return null; const a=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},'','none'), b=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},'','none'));
    const x=pkRunGzFix('今の大運（癸未）は学びの10年。2027年の年運「丙未」は動く年。2026年12月の月運は戊子の月。2026年11月7日の日運「甲酉」。お相手の今の大運は乙子です。',a,b);
    const S=['明日（11月7日）は、乙酉と丁卯が冲で重なる日に、お持ちの丁卯の日が巡り、揺らぎやすい日です。','今日（11月6日）は甲申の日で、追い風の日です。','2人の日柱「丁卯」は同じで、わかり合いやすい関係です。','明日は、日支と月支が冲になる日なので、連絡は控えめに。','今年は丙午の年で、劫財（ごうざい：仲間の星）が巡ります。'].map(t=>pkPlainTalk(t));
    return {x, cur:curDu(a).ganzhi, curB:curDu(b).ganzhi, S, br:S.map(t=>_pkTalkBroken(t))}; });
  const e=[]; if(!r) e.push('仕組みがない'); else { if(r.x.indexOf('今の大運（'+r.cur+'）')<0) e.push('今の大運'); if(r.x.indexOf('2027年の年運「丁未」')<0) e.push('年運'); if(r.x.indexOf('月運は庚子')<0) e.push('月運'); if(r.x.indexOf('日運「乙酉」')<0) e.push('日運'); if(r.x.indexOf('お相手の今の大運は'+r.curB)<0) e.push('お相手の大運');
    if(r.br.some(Boolean)||r.S.some(t=>/、と[がのは]|は、と|お持ちの日|はの日|人のは|「」/.test(t))) e.push('お伝え方の文がくずれた：'+r.S.join('／')); }
  console.log('  '+(e.length?'NG':'OK')+' 運の名前つきの干支の直し・お伝え方の文がくずれない'+(e.length?'  … '+e.join('・')+'｜'+(r?r.x:''):'')); if(e.length) res.fails.push('運の干支・お伝え方: '+e.join('・')); }
// 鑑定書（本格版・やさしい版）と易の干支の直し、節入りの決め方が3つのツールで同じか（2026-11-06「鑑定書も必ず直してください」）
{ const e=[]; const ctx2=await b.newContext({serviceWorkers:'block',timezoneId:'Asia/Tokyo'}); await ctx2.clock.setFixedTime(new Date('2026-11-06T10:00:00+09:00'));
  await ctx2.route('**/.netlify/functions/**',r=>r.fulfill({status:200,contentType:'application/json',body:'{"ok":true}'}));
  const srvE=http.createServer((q,r)=>{let pp=decodeURIComponent(q.url.split('?')[0]);if(pp.endsWith('/'))pp+='index.html';const f=path.join(ROOT,'eki-pro',pp);if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){r.writeHead(404);r.end();return;}r.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(r);}).listen(0); await new Promise(r=>srvE.on('listening',r));
  const op=async(u)=>{ const q=await ctx2.newPage(); q.on('dialog',d=>d.accept()); await q.goto(u); await q.waitForTimeout(3000); return q; };
  const P2=await op(`http://127.0.0.1:${port}/${page0}`), E2=await op(`http://127.0.0.1:${srvE.address().port}/app/index.html`);
  const SH=await op(`http://127.0.0.1:${port}/meishi-sheet.html#d=2008-03-28&t=14:00&sex=female&corr=none&z=today&clk=1`), SB=await op(`http://127.0.0.1:${port}/meishi-sheet.html#d=2008-03-28&t=14:00&sex=female&corr=none&z=today&clk=1&bg=1`);
  const T='今の大運（癸未）は学びの10年。2027年の年運「丙未」は動く年。2026年12月の月運は戊子の月。2026年11月7日の日運「甲酉」。大運「甲丑」では。';
  for(const [nm,q] of [['鑑定書（本格版）',SH],['鑑定書（やさしい版）',SB]]){ const x=await q.evaluate(t=>typeof window.sheetRunGzFix==='function'&&window.__sheetLast&&window.__sheetLast()?window.sheetRunGzFix(t,window.__sheetLast()):'',T);
    if(!x) e.push(nm+'：仕組みがない'); else [['今の大運（癸丑）','今の大運'],['2027年の年運「丁未」','年運'],['月運は庚子','月運'],['日運「乙酉」','日運'],['大運では。','まちがいで1つに決まらない干支を外す']].forEach(([w,n])=>{ if(x.indexOf(w)<0) e.push(nm+'：'+n); }); }
  { const x=await P2.evaluate(()=>{ const a=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},'','none'); return pkRunGzFix('大運「甲丑」では。今の大運（癸丑）は。',a,null); }); if(x!=='大運では。今の大運（癸丑）は。') e.push('PRO：1つに決まらないまちがいの干支を外す／正しい干支は残す：'+x); }
  { const x=await E2.evaluate(()=>typeof window.ekiBadGzStrip==='function'?window.ekiBadGzStrip('（甲丑）の流れ。丙午の年。'):''); if(/甲丑/.test(x)||x.indexOf('丙午の年')<0) e.push('易：六十干支にない形を外す：'+x); }
  // 節入り：PRO（pkSetsuStart）・易・鑑定書で、節入りの前日・当日・翌日の「○年○月○日（…の月）」が同じに直り、暦の節月（その日を含む節月）の干支になること
  const strs=await P2.evaluate(()=>{ const L=[]; for(const y of [2026,2027]) for(let m=1;m<=12;m++){ const sd=pkSetsuStart(y,m).getDate(); [sd-1,sd,sd+1].forEach(d=>L.push(y+'年'+m+'月'+d+'日（甲子の月）')); } return L; });
  const exp=await P2.evaluate(s=>s.map(x=>{ const m=x.match(/(\d+)年(\d+)月(\d+)日/); const sm=pkSmOf(new Date(+m[1],+m[2]-1,+m[3],12)); return _pillarForDate(new Date(sm.y,sm.m-1,20,12),'month').ganzhi; }),strs);
  const fx=async(q,g)=>q.evaluate(([s,g])=>{ const F=g==='pro'?pkFactFix:(g==='eki'?window.__ekiFactFix:window.__sheetFactFix); return F?s.map(x=>F(x)):[]; },[strs,g]);
  const A=await fx(P2,'pro'), EE=await fx(E2,'eki'), S2=await fx(SH,'sheet'); let bad=0, dif=0;
  A.forEach((x,i)=>{ if(x.indexOf('（'+exp[i]+'の月）')<0) bad++; if(x!==EE[i]||x!==S2[i]) dif++; });
  if(!EE.length||!S2.length) e.push('易・鑑定書の pkFactFix が呼べない'); if(bad) e.push('節入りの月の干支がちがう '+bad+'件'); if(dif) e.push('3つのツールで節入りの決め方がちがう '+dif+'件');
  await ctx2.close(); srvE.close();
  console.log('  '+(e.length?'NG':'OK')+' 鑑定書（本格版・やさしい版）・易の干支の直し、節入りが3ツールで同じ（'+strs.length+'日）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('鑑定書・易の干支: '+e.join('・')); }
// 六十干支にない形は名前がなくても外し、前後を自然につなぐ（pkFactFix ⑨。3ツール同じ中身。2026-11-06）
{ const r=await p.evaluate(()=>{ if(typeof pkFactFix!=='function') return null; window.__pkGzFixLog=[]; const L=[['この流れは（甲丑）で、よい。','この流れは、よい。'],['「乙子」の気配。','その気配。'],['流れは甲丑の年に。','流れはその年に。'],['甲・丑の話。甲と丑。丁子の香り。丙午の年。','甲・丑の話。甲と丑。丁子の香り。丙午の年。'],['この時期は乙子が巡り、動く。','この時期は巡り、動く。']]; const out=L.map(([a,b])=>[pkFactFix(a),b]); return {out, drop:(window.__pkGzFixLog||[]).filter(x=>x.st==='drop').length}; });
  const e=[]; if(!r) e.push('仕組みがない'); else { r.out.forEach(([x,w])=>{ if(x!==w) e.push(x+'≠'+w); }); if(r.drop<4) e.push('根拠のチェック表に🗑の記録がない'); if(r.out.some(([x])=>/はで|のの|はは|がで|（、|、、/.test(x))) e.push('助詞が続く・読点が続く'); }
  console.log('  '+(e.length?'NG':'OK')+' 六十干支にない形を外して自然につなぐ'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('ない干支: '+e.join('・')); }
// 縁が動く月の三合・刑（2008-03-28 14時 女性：11月己亥＝亥卯未の三合〈時支の未〉、12月庚子＝配偶宮卯と刑）
{ const m=await p.evaluate(()=>{ if(typeof loveFourLines!=='function') return ''; const c=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'); const L=loveFourLines(c); return (L&&L.pro[3]||'')+'|'+pkIsLoveQ('今年の冬に出会う可能性がある男性は？'); });
  const e=[]; if(/己亥の月/.test(m)&&!/己亥の月）＝[^／]*三合（亥卯未/.test(m)) e.push('三合（亥卯未）'); if(/庚子の月/.test(m)&&!/庚子の月）＝配偶宮「卯」と刑/.test(m)) e.push('子卯の刑'); if(!/\|true$/.test(m)) e.push('「出会う」を恋愛相談と見分ける');
  console.log('  '+(e.length?'NG':'OK')+' 縁が動く月の三合・刑'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('縁が動く月: '+e.join('・')); }
{ const mf=await p.evaluate(()=>{ if(typeof pkMonthFactFix!=='function') return ['','']; const c=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'); return [pkMonthFactFix('12月の星回りには、配偶宮に咸池や正官の気配が重なる。',c),pkMonthFactFix('2027年7月ごろは卯と未で三合になります。',c)]; });
  const e=[]; if(!/12月の星回りには、この月に咸池や偏官/.test(mf[0])) e.push('12月の星（偏官）・配偶宮の取りちがえ'); if(!/卯と未で半合/.test(mf[1])) e.push('三合→半合');
  console.log('  '+(e.length?'NG':'OK')+' 月の話の事実あわせ'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('月の話: '+e.join('・')); }
{ const r=await p.evaluate(()=>{ if(typeof pkEnsureLove!=='function') return ''; const c=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'); return pkEnsureLove('配偶宮の蔵干は甲と乙。パートナーの星（官星）は忌神です。出会いは地元の紹介から。11月と12月に縁が動きます。',c,'冬に出会う男性は？'); });
  const ok2=/庚子の月）＝配偶宮「卯」と刑|2026年12月(?:ごろ|〜翌1月上旬)（気持ちがすれ違いやすい月）/.test(r); console.log('  '+(ok2?'OK':'NG')+' 注意の月（刑・冲）が文になければ書き足す'); if(!ok2) res.fails.push('注意の月の書き足し'); }
{ const y=await p.evaluate(()=>{ if(typeof pkYearKichiFix!=='function') return ''; const c=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'); return pkYearKichiFix('2027年や2028年に天徳貴人（強い守りの星）が巡ります。',c); });
  const ok3=/天徳貴人（強い守りの星）（天徳貴人が巡るのは2028年）/.test(y); console.log('  '+(ok3?'OK':'NG')+' 年の吉凶星の事実あわせ（天徳貴人は2028年だけ）'); if(!ok3) res.fails.push('年の吉凶星'); }
// 3つのツールに同じ直しが入っているか（PRO＝元、易・鑑定書は同じ中身。ビギナーはPROから生成）
{ const grab=(f,name,end)=>{ try{ const t=fs.readFileSync(path.join(ROOT,f),'utf8'); const a=t.indexOf('function '+name+'('); if(a<0) return null; return t.slice(a,t.indexOf(end,a)+end.length); }catch(e){ return null; } };
  const e=[]; [['pkFactFix',"  return t; }catch(e){ return t; } }"],['pkStampYears',"}catch(e){ return String(s).replace(/\\u0003/g,''); } }"]].forEach(([n,end])=>{ const base=grab('pro/app-pro.html',n,end);
    ['eki-pro/app/index.html','pro/meishi-sheet.html','beginner/app-beginner.html'].forEach(f=>{ const g=grab(f,n,end); if(!g||g!==base) e.push(f+' の '+n); }); });
  console.log('  '+(e.length?'NG':'OK')+' 3つのツール（PRO・ビギナー・易）と鑑定書に同じ直しが入っている'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('3つのツールの直し: '+e.join('・')); }
{ const r=await p.evaluate(()=>{ if(typeof pkPillarStarFix!=='function') return ''; const c=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none')); return pkPillarStarFix('日柱に咸池があり、月柱には華蓋（芸術の星）が巡っています。',c); });
  const ok4=/日柱に咸池があり、年柱には華蓋/.test(r); console.log('  '+(ok4?'OK':'NG')+' 柱の星の事実あわせ（華蓋は年柱）'); if(!ok4) res.fails.push('柱の星'); }
// 易：根拠のない星の話（吉凶星・月の星）を外す直し＝PROの柱・月・年の星の事実あわせと同じ目的
{ const src=fs.readFileSync(path.join(ROOT,'eki-pro/app/index.html'),'utf8'); const a=src.indexOf('function ekiStarGuard('); let r='';
  if(a>=0){ const body=src.slice(a,src.indexOf('}catch(e){ return t; } }',a)+'}catch(e){ return t; } }'.length); r=Function(body+'; return ekiStarGuard;')()('来年は良い年です。月柱に華蓋があります。11月は正官が巡ります。パートナーの星はあなたの喜神です。2027年は変化の年です。'); }
  const ok5=r==='来年は良い年です。2027年は変化の年です。';
  { const g=Function(src.slice(a,src.indexOf('}catch(e){ return t; } }',a)+'}catch(e){ return t; } }'.length)+'; return ekiStarGuard;')(); const r2=g('2人は良い縁です。お相手はあなたから見て傷官です。お相手の土はあなたの忌神です。話し合いを大切に。');
    const b2=src.indexOf('function ekiSameSexWord('), ss=Function(src.slice(b2,src.indexOf('}catch(e){ return t; } }',b2)+'}catch(e){ return t; } }'.length)+'; return ekiSameSexWord;')();
    const ok6=r2==='2人は良い縁です。話し合いを大切に。'&&ss('異性として惹かれます','女性同士のカップルです')==='恋愛の相手として惹かれます'&&ss('異性として惹かれます','彼と私')==='異性として惹かれます'&&ss('異性の縁が動きます','男性同士で付き合っています')==='恋愛の縁が動きます';
    console.log('  '+(ok6?'OK':'NG')+' 易：お相手の星・喜神忌神の根拠のない話を外す／同性の相談で男女前提の言い方をしない'); if(!ok6) res.fails.push('易の同性・お相手の星'); } console.log('  '+(ok5?'OK':'NG')+' 易：根拠のない星の話を外す（PROの星の事実あわせと同時に）'); if(!ok5) res.fails.push('易の星の直し'); }
{ const r=await p.evaluate(()=>{ if(typeof pkFactFix!=='function'||typeof pkYearKichiFix!=='function') return ['','']; const c=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none'));
    return [pkFactFix('日干が丁（火の陰・ひのえ）で、日支に卯'), pkYearKichiFix('2027年は紅艶（魅力の星）が巡り、2028年は駅馬（移動の星）が重なります。',c)]; });
  const e=[]; if(!/丁（火の陰・ひのと）/.test(r[0])) e.push('丁の読み'); if(/が巡るのは/.test(r[1])) e.push('正しく書けた年の星に書き添えている');
  console.log('  '+(e.length?'NG':'OK')+' 十干の読みの取りちがえ・年の星の書き添え'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('読み・年の星: '+e.join('・')); }
{ const r=await p.evaluate(()=>typeof pkFactFix==='function'?pkFactFix('木はあなたの喜神です。水は忌神（きじん）（過剰になりやすい五行）です。'):'');
  const ok6=/喜神（きしん：あると調子が上がる五行）/.test(r)&&/忌神（きじん：多いと疲れやすい五行）です/.test(r)&&!/過剰になりやすい/.test(r);
  console.log('  '+(ok6?'OK':'NG')+' 喜神・忌神に読みと意味を添える（3つのツール共通）'); if(!ok6) res.fails.push('喜神・忌神の説明'); }
// 惹かれ合う星（相手の命式に自分の咸池・紅艶・貴人）：彼2006-06-07（時刻不明）×彼女2008-03-28 14時
{ const r=await p.evaluate(()=>{ if(typeof compatBalance!=='function'||typeof crossStars!=='function') return ''; const him=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none')), her=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none');
    return compatBalance(him,her).items.map(x=>x.kind+'|'+x.where).join('\n')+'\n#'+pkEnsureCross('テスト',him,her); });
  const e=[]; if(!/本人の咸池がお相手に\|お相手の年柱「戊子」・月柱「乙卯」・日柱「丁卯」/.test(r)) e.push('咸池（子・卯）'); if(!/本人の紅艶がお相手に\|お相手の時柱「丁未」/.test(r)) e.push('紅艶（未）'); if(!/お相手の月徳貴人が本人に/.test(r)) e.push('月徳貴人');
  if(!/【惹かれ合う星|【2人が惹かれ合うところ】/.test(r)) e.push('鑑定文への書き足し');
  console.log('  '+(e.length?'NG':'OK')+' 相性：惹かれ合う星（相手の命式に自分の咸池・紅艶・貴人）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('惹かれ合う星: '+e.join('・')); }
// 2人の日運を並べて見る（2026-11-03：2人とも駅馬・偏財、彼女=天徳合／彼=月徳貴人、冲・刑なし）
{ const r=await p.evaluate(()=>{ if(typeof compatDaysBody!=='function') return ''; const him=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none')), her=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none');
    return compatDaysBody(her,him,'2026-11-03','さくら','彼'); });
  const e=[]; if(!/11月3日（辛巳の日）/.test(r)) e.push('日の干支'); if(!/日の星：偏財／吉凶星：天徳合・劫殺・駅馬/.test(r)) e.push('彼女の日の星'); if(!/月徳合・亡神・駅馬/.test(r)||/月徳貴人・月徳合・亡神/.test(r)) e.push('彼の日の星')   /* 月徳貴人（丙）は巳の蔵干にあるだけ＝天干だけで見る決まり（2026-10-25）では付かない */; if(!/2人とも駅馬/.test(r)) e.push('2人とも駅馬');
  if(!/class="kd-plain"/.test(r)||/kd-plain[\s\S]*?(偏財|駅馬|天徳|冲|刑)[\s\S]*?<\/div><\/div>$/.test(r.slice(r.indexOf('class="kd-plain"')))) e.push('やさしい言い方に専門用語');
  console.log('  '+(e.length?'NG':'OK')+' 2人の日運を並べて見る'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('2人の日運: '+e.join('・')); }
// 惹かれ方の向き（彼2006-06-07×彼女2008-03-28：彼→彼女＝咸池・紅艶／彼女→彼＝恋愛の星なし）
{ const r=await p.evaluate(()=>{ if(typeof attractionDir!=='function') return ''; const him=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none')), her=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none');
    const ad=attractionDir(her,him,'彼女','彼'); return ad?ad.pro+'|'+pkEnsureCross('テスト',her,him):''; });
  const ok7=/彼女→彼＝恋愛の星なし（助けの星2つ：月徳貴人・大極貴人）／彼→彼女＝恋愛の星2つ（咸池・紅艶）/.test(r)&&/＝彼のほうが異性として惹かれやすい/.test(r)&&/惹かれ方の向き|異性として(?:とても|少し)?惹かれやすい組み合わせ/.test(r.split('|')[1]||'');
  const s7=await p.evaluate(()=>{ const her=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'); const f=(y,m,d)=>attractionDir(her,markTimeUnknown(baziCompute({year:y,month:m,day:d,hour:12,minute:0,sex:'male',tu:true},0,'none')),'本人','お相手'); return [f(2006,6,7).pro,f(2007,1,17).pro].join('|'); });
  const okS=/お相手のほうが異性として惹かれやすい（強い：咸池と紅艶の両方・日柱にも当たる/.test(s7.split('|')[0])&&/お相手のほうが異性として惹かれやすい（中くらい：咸池だけ・日柱にも当たる/.test(s7.split('|')[1]);
  console.log('  '+(ok7&&okS?'OK':'NG')+' 相性：惹かれ方の向き（強さ：強い／中くらい／弱め）'); if(!(ok7&&okS)) res.fails.push('惹かれ方の向き'); }
// お相手を知るためのチェックポイント（お相手＝2006-06-07 時刻不明：劫財が巡りで多い・配偶宮に咸池・官星なし）
{ const r=await p.evaluate(()=>{ if(typeof checkPoints!=='function') return ''; const him=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none')); const o=checkPoints(him,true); return o.check.map(x=>x.pro).join('\n')+'\n#'+o.check.map(x=>x.plain).join('\n'); });
  const e=[]; if(!/^劫財（/m.test(r)) e.push('劫財'); if(!/配偶宮（日支）に咸池/.test(r)) e.push('配偶宮の咸池'); if(!/官星（正官・偏官）がない/.test(r)) e.push('官星なし');
  if(/(比肩|劫財|食神|傷官|偏財|正財|偏官|正官|偏印|印綬|咸池|配偶宮|官星)/.test(r.split('#')[1]||'')) e.push('やさしい言い方に専門用語');
  console.log('  '+(e.length?'NG':'OK')+' 相性：お相手を知るためのチェックポイント'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('チェックポイント: '+e.join('・')); }
// 縁が動く年（これから3年）：1998-07-10 女性（時刻不明）＝2027年 天乙貴人・配偶宮「午」と支合／2026年 配偶宮と刑
{ const r=await p.evaluate(()=>{ if(typeof loveFourLines!=='function') return ''; const c=markTimeUnknown(baziCompute({year:1998,month:7,day:10,hour:12,minute:0,sex:'female',tu:true},0,'none')); window.chart=c; const L=loveFourLines(c); return L?L.pro[3]:''; });
  const okY=/縁が動く年（これから3年）：2027年（丁未）＝天乙貴人が巡る・配偶宮「午」と支合/.test(r)&&/2026年（丙午）＝配偶宮「午」と刑/.test(r);
  console.log('  '+(okY?'OK':'NG')+' 恋愛相談：縁が動く年（これから3年）'); if(!okY) res.fails.push('縁が動く年'); }
{ const r=await p.evaluate(()=>typeof plainGloss==='function'?plainGloss('惹かれ方は合・律音などで見る'):''); const ok8=/律音（＝干支がまったく同じ組み合わせ）/.test(r)&&!/変化の分岐点/.test(r);
  console.log('  '+(ok8?'OK':'NG')+' 律音の言葉の説明（相性で「変化の分岐点」と出さない）'); if(!ok8) res.fails.push('律音の説明'); }
// 2人の縁が動く月（彼女2008-02-10 10時×彼2008-03-02 時刻不明）：2026年12月＝彼女 半合・彼 支合／2027年7月＝彼の配偶宮 冲・刑
{ const r=await p.evaluate(()=>{ if(typeof compatMonths!=='function') return []; const her=baziCompute({year:2008,month:2,day:10,hour:10,minute:0,sex:'female',tu:false},0,'none'); const him=markTimeUnknown(baziCompute({year:2008,month:3,day:2,hour:12,minute:0,sex:'male',tu:true},0,'none')); return compatMonths(her,him).map(x=>x.y+'-'+x.m+'|'+x.A.g.join('・')+'|'+x.B.g.join('・')+'|'+x.A.w.join('')+'|'+x.B.w.join('')); });
  const f=k=>r.find(x=>x.startsWith(k+'|'))||''; const e=[];
  if(!/配偶宮「辰」と半合\|配偶宮「丑」と支合/.test(f('2026-12'))) e.push('2026年12月');
  if(!/\|\|冲刑$/.test(f('2027-7'))&&!/\|冲刑$/.test(f('2027-7'))) e.push('2027年7月の注意');
  if(!/咸池・配偶宮「辰」と支合\|咸池・紅艶・配偶宮「丑」と半合/.test(f('2027-9'))) e.push('2027年9月');
  console.log('  '+(e.length?'NG':'OK')+' 相性：2人の縁が動く月'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('2人の縁が動く月: '+e.join('・')); }
// 2人の役割と場面（1〜5・鑑定者本人の指示 2026-10-24）：彼女2008-03-28 14時×彼2006-06-07 時刻不明
{ const r=await p.evaluate(()=>{ if(typeof compatRoles!=='function') return null; const her=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'); const him=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none'));
    const o=compatRoles(her,him); document.getElementById('rel-type').value='work'; const w=compatRoles(her,him); document.getElementById('rel-type').value='love';
    const b70=markTimeUnknown(baziCompute({year:1970,month:5,day:15,hour:12,minute:0,sex:'male',tu:true},0,'none'));
    return {role:o.role.map(x=>x.pro).join('\n'),plain:[...o.role,...o.energy,...o.stars,...o.scene].map(x=>x.plain).join('\n'),energy:o.energy.map(x=>x.pro).join('\n'),scene:o.scene.map(x=>x.pro).join('\n'),work:w.role.map(x=>x.pro).join('\n'),st:compatRoles(her,b70).stars.map(x=>x.pro).join('\n'),an:compatAnalysis(her,him,RELTYPES.love),ens:pkEnsureRoles('x',her,him)}; });
  const e=[]; if(!r) e.push('compatRoles がない'); else {
    if(!/本人から見て、お相手の日干「丁」は比肩＝友だちのように対等な相手/.test(r.role)) e.push('役割（恋人）');
    if(!/比肩＝仲間であり、ライバルでもある相手/.test(r.work)) e.push('役割（仕事）');
    if(!/本人の喜神（きしん：あると調子が上がる五行）をお相手は5つ（木2・火3）、忌神（きじん：多いと疲れやすい五行）を1つ（土1）持つ＝本人はお相手と一緒にいると調子が上がりやすい/.test(r.energy)) e.push('調子（喜神・忌神）');
    if(!/お相手の月柱「辛巳」が本人の駅馬に当たる/.test(r.st)) e.push('駅馬');
    if(!/^日柱どうし＝ふだんの2人の関係：良い（律音）/m.test(r.scene)) e.push('場面（日柱どうしを先に）');
    if(/(比肩|劫財|食神|傷官|偏財|正財|偏官|正官|偏印|印綬|喜神|忌神|駅馬|文昌|律音|支合|冲|日柱|月柱|年柱)/.test(r.plain)) e.push('やさしい言い方に専門用語');
    if(!/【2人の役割と場面＝ツールの判定/.test(r.an)) e.push('鑑定文への渡し');
    if(!/【2人の役割と(場面|、一緒にいるとき)/.test(r.ens)) e.push('書き足し');   /* ビギナーのやさしい画面は【2人の役割と、一緒にいるとき】 */ }
  console.log('  '+(e.length?'NG':'OK')+' 相性：2人の役割と場面（役割・親子・調子・文昌貴人と駅馬・柱どうしの場面）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('2人の役割と場面: '+e.join('・')); }
// 鑑定文に深みを出す（鑑定者本人の承認 2026-10-25「②」）：この2人だけの材料を渡す・読みが無ければ足す・書き足しは箇条書きにせず関係する見出しの中へ
{ const r=await p.evaluate(()=>{ if(typeof compatWeave!=='function'||typeof pkEnsureWeave!=='function') return null; const her=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'); const him=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none'));
    const t='2人は良い縁です。\n\n【惹かれ合うところ】\nよく似ています。\n\n【ぶつかりやすいところ】\n言い方に注意。\n\n【長続きのコツ】\n話しましょう。';
    return {ln:compatWeaveLines(her,him),w:pkEnsureWeave(t,her,him),w2:pkEnsureWeave('【この2人だけの読み】\nもう書いてある。\n\n【惹かれ合うところ】\nx',her,him),ask:pkEnsureWeave('質問への答えです。',her,him),c:pkEnsureCross(t,her,him),r:pkEnsureRoles(t,her,him)}; });
  const e=[]; if(!r) e.push('関数がない'); else {
    if(!/【この2人だけの材料/.test(r.ln)||!/良い点「律音（日柱どうし）」/.test(r.ln)||!/役割：/.test(r.ln)||!/調子：/.test(r.ln)) e.push('材料');
    if(!/^2人は良い縁です。\n\n【この2人だけの読み】\nまず、/.test(r.w)) e.push('読みの書き足し（1行目のあと）');
    if((r.w2.match(/【この2人だけの読み】/g)||[]).length!==1||r.ask!=='質問への答えです。') e.push('二重・質問への答えに足さない');
    if(!/【惹かれ合うところ】\nよく似ています。\n\n(?:【(?:惹かれ合う星|2人が惹かれ合うところ)[^\n]*\n)?[^・\n【][^\n]*\n\n【ぶつかりやすいところ】/.test(r.c)||/【惹かれ合うところ】[\s\S]*【2人が惹かれ合うところ】/.test(r.c)) e.push('惹かれ合う星を見出しの中へ文章で');
    if(!/【ぶつかりやすいところ】\n言い方に注意。\n\n【2人の役割と(?:場面|、一緒にいるとき)[^\n]*\n[^・\n][^\n]*\n\n【長続きのコツ】/.test(r.r)) e.push('役割と場面を見出しの中へ文章で'); }
  console.log('  '+(e.length?'NG':'OK')+' 相性：鑑定文に深み（この2人だけの材料・読み・書き足しを文章で）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('鑑定文に深み: '+e.join('・')); }
{ const r=await p.evaluate(()=>typeof pkFixAge==='function'&&typeof pkStampYears==='function'?pkStampYears(pkFixAge('2029年（己酉（つちのととり）の年（35歳ごろ））は動きます。',1990,1990),1990,1990):'');
  const ok=/39歳/.test(r)&&!/35歳/.test(r); console.log('  '+(ok?'OK':'NG')+' 重なったかっこの年齢（2029年（己酉（よみ）の年（35歳ごろ））も計算し直す）'); if(!ok) res.fails.push('重なったかっこの年齢: '+r); }
{ const r=await p.evaluate(()=>{ if(typeof formatReading!=='function'||typeof pkFactFix!=='function') return ''; const d=document.createElement('div'); d.innerHTML=formatReading('天干どうしが引き合う**干合**（かんごう：干どうしが結びつく）が成り立ちます。'); return d.textContent+'|'+pkFactFix('ふたの関係が動き、鍋のふたの色。','',''); });
  const ok=/干合（かんごう：干どうしが結びつく）/.test(r)&&!/（＝干どうし/.test(r)&&/ふたりの関係が動き、鍋のふたの色/.test(r); console.log('  '+(ok?'OK':'NG')+' 太字の用語に読みを2つ付けない・「ふたの関係」を「ふたりの関係」に'); if(!ok) res.fails.push('読みの重なり・ふたり: '+r); }
{ const r=await p.evaluate(()=>{ if(typeof pkFixAge!=='function') return ''; window.personNameB='翔'; const o=pkFixAge('2031年（辛亥・本人23歳／お相手26歳）辛亥（かのとい・健太さん20歳／翔さん21歳）の年。2027年1月ごろ（健太さん40歳／翔さん30歳ごろ）。2028年（翔さん40歳・健太さん43歳）。2030年に母が70歳（2030年）。',1985,1988); window.personNameB=''; return o; });
  const ok=/2027年1月ごろ（健太さん42歳／翔さん39歳ごろ）/.test(r)&&/辛亥（かのとい・健太さん46歳／翔さん43歳）/.test(r)&&/翔さん40歳・健太さん43歳/.test(r)&&/母が70歳/.test(r); console.log('  '+(ok?'OK':'NG')+' 月のあと・名前つきの2人の年齢も計算し直す（家族の年齢は変えない）'); if(!ok) res.fails.push('名前つきの2人の年齢: '+r); }
// 2人の支合・半合に年運・大運が加わって三合・方合がそろう時期（鑑定者本人の指示 2026-10-25「必ず出現させてください」）：彼女2008-03-28 14時×彼2006-06-07 時刻不明
{ const r=await p.evaluate(()=>{ if(typeof compatTrioLines!=='function') return null; const her=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'), him=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none'));
    const L=compatTrioLines(her,him), d=document.createElement('div'); d.innerHTML=compatSummaryHTML(her,him,RELTYPES.love);
    return {pro:L.pro.join('\n'),plain:L.plain.join('\n'),ens:pkEnsureTrio('結論。\n\n【惹かれ合うところ】\nx\n\n【縁が深まる時期】\n2027年。\n\n【長続きのコツ】\ny',her,him,''),ok2:pkEnsureTrio('結論。\n\n【惹かれ合うところ】\nx\n\n【縁が深まる時期】\n2031年と2043年は三合、2045〜の大運も三合（2031年・2045年）、2037年と2049年は方合（2037年）、2034年は寅午戌の三合。\n\n【長続きのコツ】\ny',her,him,''),sum:d.innerHTML,sec:compatTrioHTML(her,him)}; });
  const e=[]; if(!r) e.push('関数がない'); else {
    if(!/本人の時柱「未」×お相手の日柱「卯」の半合[^\n]*?に「亥」が巡ると、亥卯未の三合（木）がそろう[^\n]*年運＝2031年（辛亥・本人23歳／お相手25歳）/.test(r.pro)) e.push('半合＋年運で三合');
    if(!/本人の命式の中の日柱「卯」×時柱「未」の半合/.test(r.pro)||(r.pro.match(/亥卯未の三合/g)||[]).length!==1) e.push('1人の命式の中の半合（同じ三合は1つにまとめる）');
    if(!/お相手の命式の中の年柱「戌」×月柱「午」の半合に「寅」が巡ると、寅午戌の三合（火）[^\n]*2034年（甲寅/.test(r.pro)) e.push('お相手の命式の中の半合＋年運で三合');
    if(!/お相手の大運「己亥」＝2056年（お相手50歳）から10年間/.test(r.pro)||!/本人の大運「辛亥」/.test(r.pro)) e.push('大運で三合');
    if(!/本人の時柱「未」×お相手の月柱「午」の支合に「巳」が巡ると、巳午未の方合（火）がそろう[^\n]*2037年（丁巳/.test(r.pro)) e.push('支合＋年運で方合');
    if(/(三合|方合|半合|支合|大運|柱|亥|巳)/.test(r.plain)) e.push('やさしい言い方に専門用語');
    if(!/【縁が深まる時期】\n2027年。\n\n【(?:2人の合が三合・方合になる時期|2人の結びつきが強まる時期)】\n[^・\n]/.test(r.ens)) e.push('書き足し（時期の見出しの中へ）');
    if(/【(?:2人の合が三合・方合になる時期|2人の結びつきが強まる時期)】/.test(r.ok2)) e.push('書いてあるのに書き足している');
    if(!/三合・方合になる時期<\/b>：2031年/.test(r.sum)||!/id="tr-sec"/.test(r.sec)) e.push('まとめ・欄'); }
  console.log('  '+(e.length?'NG':'OK')+' 相性：2人の支合・半合が年運・大運で三合・方合になる時期'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('三合・方合になる時期: '+e.join('・')); }
// ③ 根拠のチェック表（鑑定者本人の指示 2026-10-25）：事実なら残す・作り話（どこにも成り立たない）だけ外す・同じ文に事実があれば外さない
{ const r=await p.evaluate(()=>{ if(typeof pkEvidence!=='function') return null; const her=baziCompute({year:2008,month:3,day:28,hour:14,minute:0,sex:'female',tu:false},0,'none'), him=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},0,'none'));
    const full=['2人の日柱は律音です。','本人の時柱「未」とお相手の日柱「卯」が半合です。','2031年（辛亥）には亥卯未の三合がそろいます。','2028年には亥卯未の三合がそろいます。','2029年（己酉）は配偶宮に酉が巡り、お相手の日支である卯と冲になります。','未来に向けて、子どもの話もしましょう。','冲はありません。'].join('\n');
    const ev=pkEvidence('2029年（35歳）に動きます。',full,her,him);
    const k=baziCompute({year:2000,month:1,day:11,hour:12,minute:0,sex:'male',tu:false},0,'none');   /* 日柱 戊辰 */
    const e2=pkEvidence('','日柱は'+k.pillars[2].ganzhi+'で魁罡を持ちます。\n日柱は'+k.pillars[2].ganzhi+'で魁罡と禄馬貴人を持ちます。',k,null);
    return {rows:ev.rows.map(x=>x.st+'|'+x.what).join('\n'),text:ev.text,gz:k.pillars[2].ganzhi,r2:e2.rows.map(x=>x.st+'|'+x.what).join('\n'),t2:e2.text,html:pkEvidenceHTML(ev)}; });
  const e=[]; if(!r) e.push('関数がない'); else {
    if(!/^fix\|2029年（35歳）/m.test(r.rows)) e.push('年齢の直しを記録');
    if(!/^ok\|律音/m.test(r.rows)||!/^ok\|半合「未卯」/m.test(r.rows)||!/^ok\|三合（2031年）/m.test(r.rows)||!/^ok\|冲（2029年）/m.test(r.rows)) e.push('事実を計算どおりと判定');
    if(!/^warn\|三合（2028年）/m.test(r.rows)) e.push('年ちがいは確かめてほしい');
    if(/未来|子ども/.test(r.rows)||/冲はありません/.test(r.rows)) e.push('ふつうの言葉・打ち消しを数えている');
    if(r.text.split('\n').length!==7) e.push('事実の文を外している');
    if(r.gz!=='戊辰'||!/^drop\|魁罡/m.test(r.r2)||/魁罡を持ちます。\n/.test(r.t2)) e.push('戊辰の魁罡（作り話）を外す');
    if(!/no-print/.test(r.html)||!/先生の画面だけ/.test(r.html)) e.push('表（先生の画面だけ・印刷しない）'); }
  console.log('  '+(e.length?'NG':'OK')+' ③ 根拠のチェック表（事実は残す・作り話だけ外す）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('根拠のチェック表: '+e.join('・')); }
// 相談の要点（鑑定者本人の指示 2026-10-25「これをきちんとツールで出るようにしてください」）：2008-02-15 15時 女性・留学と母の反対と適職
{ const r=await p.evaluate(()=>{ if(typeof pkConsultFocusText!=='function') return null; const c=baziCompute({year:2008,month:2,day:15,hour:15,minute:0,sex:'female',tu:false},0,'none'); window.chart=c; const w='来年アメリカに留学しようか悩んでいます。母が反対しています。どちらがいいですか。適職も教えて。';
    return {f:pkConsultFocusText(c,w), e:pkEnsureConsult('日本に留まるほうがおすすめです。',c,w), ok:pkEnsureConsult('留学するほうが命式に合っています。2027年は空亡なので準備、2028年から。駅馬があります。印星が母。適職は食神・傷官を生かす仕事。',c,w)}; });
  const e=[]; if(!r) e.push('関数がない'); else {
    if(!/今の大運＝壬子（印綬＝印・水＝忌神）/.test(r.f)) e.push('今の大運と喜忌');
    if(!/2027年（丁未・19歳）＝[^\n]*空亡の年/.test(r.f)) e.push('来年が空亡');
    if(!/命式の駅馬＝月柱「寅」/.test(r.f)||!/2028年（戊申）＝命式の駅馬が冲される/.test(r.f)) e.push('駅馬と冲の年');
    if(!/答えの方向（ツールの判定・1行目はこれに合わせる）：出る（留学・移動する）ほうが命式に合う。2027年は空亡の年なので準備・短期で試す年にし、本格的に動くのは2028年（戊申・20歳）から/.test(r.f)) e.push('答えの方向');
    if(!/母＝印星（印綬・偏印）＝水＝忌神/.test(r.f)||!/今の大運が印星/.test(r.f)) e.push('六親（母＝印星）');
    if(!/適職の手がかり：喜神の星＝食傷（火）/.test(r.f)||!/月柱（仕事・職場・暮らしの環境）と冲・刑/.test(r.f)) e.push('適職・柱の場面');
    if(!/命式からの答えの方向：出る|遠くへ出るほうが合って/.test(r.e)||!/2027年は空亡の年|2027年は、新しく大きく始めることが形になりにくい/.test(r.e)) e.push('書き足し（判定と逆の答え・空亡）');   /* ビギナーのやさしい画面は専門用語なしの言い方 */
    if(/【この相談で大事なこと】/.test(r.e)&&/(空亡|駅馬|印星|大運)/.test(r.e.split('【この相談で大事なこと】')[1])) e.push('やさしい言い方に専門用語');
    if(/【この相談で(?:ツールが|命式から)確かめたこと】/.test(r.ok)) e.push('書いてあるのに書き足している'); }
  { const t=await p.evaluate(()=>{ const c=baziCompute({year:2001,month:2,day:9,hour:16,minute:0,sex:'female',tu:false},0,'none'); return pkConsultFocusText(c,'彼氏がいるけど他に好きな人ができた'); });   /* 中和（喜神・忌神なし）でも空にしない */
    if(/喜神（[^）]*）＝／|忌神（[^）]*）＝$/m.test(t)||!/はっきりした喜神/.test(t)) e.push('中和の喜神・忌神が空'); }
  console.log('  '+(e.length?'NG':'OK')+' 相談の要点（大運・4年の年運・空亡・駅馬・六親・適職・答えの方向）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('相談の要点: '+e.join('・')); }
// 相談文に出てくるお相手の相性（鑑定者本人の指示 2026-10-25「これをツールで出るようにしてください」）：2001-02-09 16時 女性・今の彼 2000-03-20・好きな人 1995-04-04 16時
{ const r=await p.evaluate(()=>{ if(typeof pkConsultPeopleText!=='function') return null; const c=baziCompute({year:2001,month:2,day:9,hour:16,minute:0,sex:'female',tu:false},0,'none'); window.chart=c;
    const q='彼氏がいるけど他に好きな人が出来てしまって悩んでる。彼は２０００年３月２０日、好きな人は１９９５年４月４日16時生まれ男性';
    return {t:pkConsultPeopleLines(c,q).pro.join('\n'), pl:pkConsultPeopleLines(c,q).plain.join('\n'), e:pkEnsurePeople('どちらも良い人です。',c,q), ok:pkEnsurePeople('命式の相性だけで見ると、好きな人のほうが良い。くらべると、今の彼のよいところは方合で土台が安定、好きな人のよいところは天地徳合で惹かれ合う。生まれ持った相性だけで見ると同じ。',c,q), n:pkConsultPeopleText(c,'彼氏のことで悩んでいます')}; });
  const e=[]; if(!r) e.push('関数がない'); else {
    if(!/【お相手：今の彼（2000年3月20日（時刻不明）・男性・恋人・パートナーとして見た相性）】判定＝良い点が注意点を上回る組み合わせ（良い点6／注意点1）/.test(r.t)) e.push('今の彼（時刻不明）');
    if(!/【お相手：好きな人（1995年4月4日 16時・男性・恋人・パートナーとして見た相性）】判定＝良い点が注意点を上回る組み合わせ（良い点12.5／注意点4）/.test(r.t)||!/天地徳合（本人の月柱「庚寅」×お相手の年柱「乙亥」）/.test(r.t)) e.push('好きな人（16時）');
    if(!/暮らしの土台（方合・三合・支合など）が強いのは 今の彼／惹かれ合い（恋愛の星）が強いのは 好きな人/.test(r.t)||!/2026年12月(?:〜翌1月上旬)?・2027年9月(?:〜10月上旬)?は注意の月/.test(r.t)) e.push('くらべた結果・決める時期');
    if(!/命式の相性だけで見ると、好きな人のほうが良い組み合わせ（差3.5点）/.test(r.t)||!/今の彼（良い点6／注意点1・差＋5）：よいところ＝強いぶつかり（天戦地冲）がない/.test(r.t)||!/気をつけたいところ＝天戦地冲（年柱どうし/.test(r.t)) e.push('命式の相性のくらべ（数字・理由）');
    if(!/【お相手ごとの相性/.test(r.e)||/【お相手ごとの相性/.test(r.ok)) e.push('書き足し');
    if(r.n) e.push('生年月日のない相談に出している');
    const fm=await p.evaluate(()=>{ const c=baziCompute({year:1982,month:6,day:1,hour:12,minute:0,sex:'female',tu:false},0,'none'); const q='夫は1980年5月5日、義母は1955年3月3日、息子は2010年8月8日です。家族がうまくいくにはどうしたらいいですか？'; const L=pkConsultPeopleLines(c,q); return {who:L.P.map(o=>o.lab+'/'+o.rel+'/'+o.sex).join(','), two:!!L.V.two, love:pkIsLoveQ(q), love2:pkIsLoveQ('夫と離婚すべきか、息子のことも心配'), txt:pkConsultPeopleText(c,q)+pkEnsurePeople('本文。',c,q), ov:window.__pkRelOv}; });   /* 家族の相談を恋愛のくらべにしない（2026-10-25） */
    if(fm.who!=='夫/married/male,義母/family/female,息子/family/male'||fm.two||fm.love||!fm.love2||/二股のまま|二股を勧めない|命式の相性のくらべ|(義母|息子)[^\n]*惹かれ方/.test(fm.txt)||!/家族・親子として見た相性/.test(fm.txt)||fm.ov) e.push('家族の相談（夫・義母・息子）を恋愛のくらべにした：'+fm.who);
    const tb=await p.evaluate(()=>{ const c=baziCompute({year:2001,month:2,day:9,hour:16,minute:0,sex:'female',tu:false},0,'none'); const q='彼氏がいる。彼は2000年3月20日、好きな人は1995年4月4日16時生まれ男性'; const full=pkEnsurePeople('本文。',c,q), sp=pkCmpSplit(full,c,q); return {full,disp:sp.text,html:sp.html}; });   /* B＝画面は表・コピーは文章（鑑定者本人の指示 2026-10-25） */
    if(!/【(命式の相性のくらべ(?:（ツールの判定）)?|生まれ持った相性のくらべ)】\n今の彼：/.test(tb.full)||/【(命式の相性のくらべ|生まれ持った相性のくらべ)/.test(tb.disp)||!/class="cmp-t"/.test(tb.html)||!/cmp-sec/.test(tb.html)) e.push('くらべの表（画面は表・コピーは文章）');
    const fl=await p.evaluate(()=>{ const c=baziCompute({year:2001,month:2,day:9,hour:16,minute:0,sex:'female',tu:false},0,'none'); const q='彼氏がいる。彼は2000年3月20日、好きな人は1995年4月4日16時生まれ男性'; const plain=document.documentElement.classList.contains('bg-on'); return [pkEnsurePeople('今の彼を選ぶのがおすすめです。\n本文',c,q).split('\n')[0], pkEnsurePeople((plain?'生まれ持った相性だけで見ると、好きな人のほうが合う組み合わせです。':'命式の相性だけで見ると、好きな人のほうが良い組み合わせです。')+'\n本文',c,q).split('\n').length]; });
    if(!/相性だけで見ると、好きな人のほうが(良い|合う)組み合わせです/.test(fl[0])) e.push('1行目の判定（逆のときに上に入れる）'); if(fl[1]<2) e.push('1行目の判定（二重）');
    const fc=await p.evaluate(()=>{ const c=baziCompute({year:2001,month:2,day:9,hour:16,minute:0,sex:'female',tu:false},0,'none'); return pkEnsurePeople('相性から見ると、今の彼とお付き合いを続けるほうが合っています。\n本文',c,'彼氏がいる。彼は2000年3月20日、好きな人は1995年4月4日16時生まれ男性').split('\n').slice(0,2).join('|'); });
    if(/今の彼とお付き合いを続けるほうが合っています/.test(fc)||!/好きな人のほうが(良い|合う)/.test(fc)) e.push('1行目が逆のときは置きかえる（'+fc.slice(0,60)+'）');
    if(!/生まれ持った相性だけで見ると、好きな人のほうが合う組み合わせです/.test(r.pl)||/(天戦地冲|方合|干合|紅艶|比肩|劫財|食神|命式)/.test(r.pl)) e.push('やさしい言い方（専門用語なし）');
    const ev=await p.evaluate(()=>{ const c=baziCompute({year:2001,month:2,day:9,hour:16,minute:0,sex:'female',tu:false},0,'none'); const ex=pkConsultPeople(c,'彼氏がいる。彼は2000年3月20日、好きな人は1995年4月4日16時生まれ男性').map(x=>x.c); return pkEvidence('','2027年（丁未）は好きな人との三合の巡りで縁が動きます。',c,null,ex).rows.map(r=>r.st).join(','); });
    if(ev!=='ok') e.push('根拠のチェック表に相談のお相手が入っていない（'+ev+'）'); }
  console.log('  '+(e.length?'NG':'OK')+' 相談文に出てくるお相手の相性（2人をくらべる）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('相談のお相手: '+e.join('・')); }
// 同性カップル（鑑定者本人の指示 2026-10-24）：女性同士 1990-03-03×1990-02-02＝パートナーの星はお相手の性別（女性＝財星）・「異性」と書かない／男女は今までどおり
{ const r=await p.evaluate(()=>{ if(typeof pkSameSexWord!=='function') return null; const mk=(y,m,d,sex)=>markTimeUnknown(baziCompute({year:y,month:m,day:d,hour:12,minute:0,sex,tu:true},0,'none'));
    const A=mk(1990,3,3,'female'), B=mk(1990,2,2,'female'), M=mk(1990,3,3,'male'), F=mk(1981,6,10,'female'), G=mk(1983,5,5,'male'); window.chart=A; window.chartB=B;
    const cm=compatMonths(A,B), an=compatAnalysis(A,B,RELTYPES.love), en=pkSameSexWord(pkEnsureCross('x',A,B),A,B);
    window.chart=F; window.chartB=G; const fg=compatMonths(F,G).map(x=>x.A.g.join('・')).join('|'), hk=pkSameSexWord(attractionDir(F,G,'本人','お相手')?.pro||'異性',F,G);
    return {dec:cm.map(x=>x.y+'-'+x.m+'|'+x.A.g.join('・')+'|'+x.B.g.join('・')).join('\n'),an:an,en:en,fg:fg,hk:hk,mm:compatMonths(M,B).map(x=>x.A.g.join('・')).join('|'),mm2:(()=>{ const X=mk(1985,7,12,'male'), Y=mk(1988,11,5,'male'); window.chart=X; window.chartB=Y; const g=compatMonths(X,Y).map(x=>x.A.g.concat(x.B.g).join('・')).join('|'), an2=compatAnalysis(X,Y,RELTYPES.love), en2=pkSameSexWord(pkEnsureCross('x',X,Y)+(attractionDir(X,Y,'本人','お相手')||{}).pro,X,Y);
      if(/正財|偏財/.test(g)) return 'パートナーの星が財星になった'; if(!/正官|偏官/.test(g)) return 'パートナーの星（官星）が出ない'; if(!/【同性のカップル（男性同士）＝厳守】/.test(an2)) return '鑑定文への決まり'; if(/異性/.test(an2+en2)) return '「異性」と書いている'; return 'ok'; })()}; });
  const e=[]; if(!r) e.push('pkSameSexWord がない'); else {
    if(!/^2026-12\|パートナーの星（正財）・咸池\|月の十二支にパートナーの星（正財）$/m.test(r.dec)) e.push('女性同士のパートナーの星（財星）');
    if(/異性/.test(r.an)||/異性/.test(r.en)) e.push('同性で「異性」と書いている');
    if(!/【同性のカップル（女性同士）＝厳守】/.test(r.an)) e.push('鑑定文への同性の決まり');
    if(/正財|偏財/.test(r.fg)) e.push('男女：女性の本人のパートナーの星が財星になった');
    if(!/正財|偏財/.test(r.mm)) e.push('男性×女性：パートナーの星（財星）');
    if(/異性/.test(r.hk)===false&&/恋愛の相手として/.test(r.hk)) e.push('男女で言い方を変えてしまった');
    if(!/^ok/.test(r.mm2||'')) e.push('男性同士：'+(r.mm2||'')); }
  console.log('  '+(e.length?'NG':'OK')+' 相性：同性カップル（パートナーの星＝お相手の性別・男女前提の言い方をしない）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('同性カップル: '+e.join('・')); }
// 読みの言い直し・「お互いに惹かれ合う」の直し（2026-10-24 同性カップルの鑑定文で見つかったもの）
{ const r=await p.evaluate(()=>{ if(typeof pkFixMutual!=='function') return null; const mk=(y,m,d,sex)=>markTimeUnknown(baziCompute({year:y,month:m,day:d,hour:12,minute:0,sex,tu:true},0,'none'));
    const A=mk(1990,3,3,'female'), B=mk(1990,2,2,'female'); return [window.pkFixYomi('本人が壬（みずのと、ではなく、みずのえ）で'), pkFixMutual('お互いに心から惹かれ合い、支え合える。',A,B)]; });
  const e=[]; if(!r) e.push('pkFixMutual がない'); else { if(r[0]!=='本人が壬（みずのえ）で') e.push('読みの言い直し：'+r[0]); if(r[1]!=='心から引き合い、支え合える。') e.push('お互いに惹かれ合う：'+r[1]); }
  console.log('  '+(e.length?'NG':'OK')+' 読みの言い直し／片方だけ恋愛の星のとき「お互いに惹かれ合う」と書かない'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('読み・お互いに: '+e.join('・')); }
// 惹かれ合う星の点数は1方向の合計1点まで（鑑定者本人の指示 2026-10-24）
{ const r=await p.evaluate(()=>{ let seed=11, over=[], n=0; const rnd=()=>{ seed=(seed*1103515245+12345)%2147483648; return seed/2147483648; };
    for(let i=0;i<300;i++){ const mk=()=>baziCompute({year:1960+Math.floor(rnd()*45),month:1+Math.floor(rnd()*12),day:1+Math.floor(rnd()*28),hour:Math.floor(rnd()*24),minute:0,sex:rnd()<0.5?'male':'female',tu:false},0,'none'); const A=mk(), B=mk();
      const it=compatBalance(A,B).items; ['本人の','お相手の'].forEach(pre=>{ const sm=it.filter(x=>x.kind.indexOf(pre)===0&&/が(?:お相手|本人)に$/.test(x.kind)).reduce((t,x)=>t+x.w,0); if(sm>0) n++; if(sm>1.001) over.push(A.birth.clock+'×'+B.birth.clock+' '+pre+sm); }); }
    return {n,over}; });
  const ok9=r.n>50&&r.over.length===0; console.log('  '+(ok9?'OK':'NG')+' 惹かれ合う星の点数は1方向1点まで（'+r.n+'方向を確認）'+(ok9?'':'  … '+r.over.slice(0,3).join(' / '))); if(!ok9) res.fails.push('惹かれ合う星の上限'); }
// 大人×未成年（18歳未満）の恋愛は鑑定しない（鑑定者本人の指示 2026-10-24）：相性の判定と相談文の両方。PROと易で同じ中身
{ const r=await p.evaluate(()=>{ if(typeof pkMinorLoveBlock!=='function'||typeof pkMinorLoveQ!=='function') return null; const mk=(y,m,d,sex)=>markTimeUnknown(baziCompute({year:y,month:m,day:d,hour:12,minute:0,sex,tu:true},0,'none'));
    const M=mk(1980,3,8,'male'), F=mk(2009,4,5,'female'), G=mk(2010,1,1,'male'), A=mk(1990,3,3,'female');
    return {love:!!pkMinorLoveBlock(M,F,RELTYPES.love), married:!!pkMinorLoveBlock(F,M,RELTYPES.married), work:!!pkMinorLoveBlock(M,F,RELTYPES.work), family:!!pkMinorLoveBlock(M,F,RELTYPES.family), teens:!!pkMinorLoveBlock(F,G,RELTYPES.love), adults:!!pkMinorLoveBlock(M,A,RELTYPES.love),
      q1:pkMinorLoveQ('１９８０年３月８日生まれの男性　好きな子がいます　相手の生年月日が２００９年４月５日女性です　告白していいか？',null), q2:pkMinorLoveQ('5歳の子どもが好きな食べ物は？',35), q3:pkMinorLoveQ('高校生のときに付き合った人と再会した',40), dk:dangerKind('17歳の女の子に告白したい'), q4:pkMinorLoveQ('夫は1980年5月5日、義母は1955年3月3日、息子は2010年8月8日です。家族がうまくいくにはどうしたらいいですか？',40), tq:(typeof pkAboutToolQ==='function')?[pkAboutToolQ('これってAIが答えているんですか？'),pkAboutToolQ('人間が占っているんですか？'),pkAboutToolQ('AIの仕事に転職すべき？'),dangerKind('これってAIが答えているんですか？')]:null}; });
  const e=[]; if(!r) e.push('仕組みがない'); else { if(!r.love||!r.married) e.push('恋愛の相性を止めていない'); if(r.work||r.family) e.push('仕事・家族まで止めた'); if(r.teens) e.push('未成年どうしを止めた'); if(r.adults) e.push('大人どうしを止めた'); if(!r.q1) e.push('相談文（全角の生年月日）'); if(r.q2||r.q3) e.push('止めなくてよい相談を止めた'); if(r.q4) e.push('家族の相談（子どもの生年月日）を止めた'); if(!r.tq) e.push('「AIですか」の決まった答えがない'); else if(!r.tq[0]||!r.tq[1]||r.tq[2]||r.tq[3]!=='tool') e.push('「AIですか」の見分け'); { const il=await p.evaluate(()=>[pkInLawWord('お母さまとは距離を','義母と夫と息子'),pkInLawWord('お母さまとは距離を','母と義母'),pkFixYomi('2026年（丙午・44歳）（丙午・ひのえうま）は'),pkFixYomi('今年（\n2026年\n〔丙午・\n45歳〕）は'),(typeof pkFixAnsHeads==='function'?pkFixAnsHeads('結論です。\nお相手のお伝え方\n本文\nどうすればよいか\n・a')+'|'+pkFixAnsHeads('結論です。\n【お伝え方】\n本文\n【どうすればよいか】\n・a')+'|'+pkFixAnsHeads('2人はとても良い相性です。\nお二人は自然と心が通い合う関係で、一緒にいると落ち着けます。将来も安心です。長く続く縁です。\n【この2人だけの読み】\n本文'):'')]); if(il[0]!=='お義母さまとは距離を'||il[1]!=='お母さまとは距離を'||il[2]!=='2026年（丙午・44歳）は'||il[3]!=='今年（2026年〔丙午・45歳〕）は'||(String(il[4]||'').match(/お客様へのお伝え方/g)||[]).length<3) e.push('義母の呼び方・かっこの重なり：'+il.join('/')); const se=fs.readFileSync(path.join(ROOT,'eki-pro/app/index.html'),'utf8'); if(!/pkNoGambleTiming\(pkSoftDeceased\(pkInLawWord\(p\[k\],q\),q\),q\)/.test(se)) e.push('易に義母の呼び方・亡くなった方・宝くじの直しがない'); } { const h=await p.evaluate(()=>[pkEmptyQ('あいうえお'),pkEmptyQ('😢😢😢'),pkEmptyQ('てんしょく'),pkEmptyQ('😢 つらい'),dangerKind('あいうえお'),pkSoftDeceased('お母さまは誇らしく感じていらっしゃいました。','亡くなった母は私をどう思っていた？'),pkNoGambleTiming('当たりは占いでは当てられません。宝くじは2026年に買うと当たりやすいです。','宝くじはいつ買えばいい？')]); if(!h[0]||!h[1]||h[2]||h[3]||h[4]!=='empty'||h[5]!=='お母さまは誇らしく感じていらっしゃったと受けとめてよいでしょう。'||/2026年/.test(h[6])) e.push('意味のない相談・亡くなった方・宝くじの時期：'+JSON.stringify(h)); const se=fs.readFileSync(path.join(ROOT,'eki-pro/app/index.html'),'utf8'), src2=fs.readFileSync(path.join(ROOT,dir,page0),'utf8'), cutH=t=>{ const a=t.indexOf('var PK_EMPTY_MSG='), b=t.indexOf('function pkInLawWord',a); return a<0||b<0?null:t.slice(a,b).replace(/^\s+/gm,''); }; if(!cutH(se)||cutH(se)!==cutH(src2)) e.push('易と同じ中身になっていない（意味のない相談・亡くなった方・宝くじ）'); if(!/if\(pkEmptyQ\(q\)\) return \{block:'empty'\}/.test(se)) e.push('易で意味のない相談を止めていない'); } { const hx=await p.evaluate(()=>{ const c=baziCompute({year:1990,month:1,day:15,hour:10,minute:0,sex:'male',tu:false},0,'none'); return {pro:heroHTML(c),pl:heroHTML(c,true),gz:c.pillars[2].ganzhi}; }); const srcB=fs.readFileSync(path.join(ROOT,'beginner/app-beginner.html'),'utf8');   /* 表紙カード：魁罡は必ず拾う・ビギナーは専門用語なし・今年の言葉はA（2026-10-26） */
  if(hx.gz!=='庚辰'||!/魁罡日/.test(hx.pro)||!/★ リーダー星/.test(hx.pl)||/魁罡|日柱|納音|空亡|偏官|立運/.test(hx.pl.replace(/<[^>]+>/g,''))||!/仕事の評価・立場が動く/.test(hx.pro+hx.pl)||!/id="bg-kaigou"/.test(srcB)) e.push('表紙カード（魁罡・ビギナーの専門用語・今年の言葉）'); } { const mo=await p.evaluate(()=>{ const c=baziCompute({year:1970,month:6,day:6,hour:12,minute:0,sex:'female',tu:false},0,'none'); const F=pkConsultFocus(c,'宝くじは当たりますか？いつ買えばいいですか？'); return {pro:F.pro.join('\n'),money:!!F.R.money,keep:pkNoGambleTiming('2027年は金運が上がりやすい年です。宝くじは2027年に買うと当たりやすいです。','宝くじはいつ買えばいい？')}; }); if(!mo.money||!/金運（お金の星＝財星/.test(mo.pro)||!/2027年は金運が上がりやすい年です。/.test(mo.keep)||/買うと当たり/.test(mo.keep)) e.push('金運の時期（宝くじの相談でも金運の流れは出す）：'+JSON.stringify(mo).slice(0,200)); } }
  const src=fs.readFileSync(path.join(ROOT,'eki-pro/app/index.html'),'utf8'), mine=fs.readFileSync(path.join(ROOT,dir,page0),'utf8'), cut=t=>{ const a=t.indexOf('var PK_MINOR_MSG='), b=t.indexOf('}catch(e){ return false; } }',a); return a<0||b<0?null:t.slice(a,b); };
  if(!cut(src)||cut(src)!==cut(mine)) e.push('易と同じ中身になっていない');
  if(!/if\(pkAboutToolQ\(q\)\) return \{block:'tool'\}/.test(src)||!/sf\.block==='tool'\?PK_TOOL_MSG/.test(src)) e.push('易に「AIですか」の決まった答えがない'); if(!/if\(k==='minor'\)/.test(src)||!/pkMinorLoveQ\(q,ekiSelfAge\(\)\)/.test(src)) e.push('易で止めていない');
  console.log('  '+(e.length?'NG':'OK')+' 大人×未成年の恋愛は鑑定しない（相性・相談文・易）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('未成年: '+e.join('・')); }
// 「盗んでしまった」など、してしまったことの相談は運勢で判断しない（鑑定者本人の指示 2026-10-24）。PROと易で同じ中身
{ const r=await p.evaluate(()=>typeof pkConfessQ!=='function'?null:[dangerKind('アルバイト先で窃盗してしまった　どうしたらいいか'),dangerKind('万引きしてしまいました'),dangerKind('財布を盗まれました。犯人は見つかりますか'),dangerKind('会社でお金を横領された')]);
  const e=[]; if(!r) e.push('仕組みがない'); else { if(r[0]!=='confess'||r[1]!=='confess') e.push('してしまった相談を止めていない'); if(r[2]||r[3]) e.push('被害の相談を止めた'); }
  const src=fs.readFileSync(path.join(ROOT,'eki-pro/app/index.html'),'utf8'), mine=fs.readFileSync(path.join(ROOT,dir,page0),'utf8'), cut=t=>{ const a=t.indexOf('var PK_CONFESS_MSG='), b=t.indexOf('}catch(e){ return false; } }',a); return a<0||b<0?null:t.slice(a,b); };
  if(!cut(src)||cut(src)!==cut(mine)) e.push('易と同じ中身になっていない'); if(!/pkConfessQ\(q\)\) return \{block:'confess'\}/.test(src)) e.push('易で止めていない');
  console.log('  '+(e.length?'NG':'OK')+' してしまったことの相談は運勢で判断しない（PRO・ビギナー・易）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('してしまった相談: '+e.join('・')); }
// 蔵干は司令だけ（鑑定者本人の指示 2026-10-24）：恋愛の配偶宮の蔵干・チェックポイントが司令の1つだけを使う
{ const r=await p.evaluate(()=>{ let seed=5, bad=[]; const rnd=()=>{ seed=(seed*1103515245+12345)%2147483648; return seed/2147483648; };
    for(let i=0;i<60;i++){ const c=baziCompute({year:1960+Math.floor(rnd()*45),month:1+Math.floor(rnd()*12),day:1+Math.floor(rnd()*28),hour:Math.floor(rnd()*24),minute:0,sex:rnd()<0.5?'male':'female',tu:false},0,'none'); window.chart=c;
      const L=loveFourLines(c), m=(L&&L.pro[0]||'').match(/蔵干（司令）は ([^。]*)。/), rep=repHidden(c.pillars[2]);
      if(!m||m[1]!==rep.stem+'（'+(rep.tenStar||tenStarOf(c.dayMaster.stem,rep.stem))+'）') bad.push(c.birth.clock+' '+(m?m[1]:'なし')); }
    return bad; });
  const okZ=r.length===0; console.log('  '+(okZ?'OK':'NG')+' 蔵干は司令だけ（恋愛の配偶宮の蔵干・60人）'+(okZ?'':'  … '+r.slice(0,3).join(' / '))); if(!okZ) res.fails.push('蔵干は司令だけ'); }
// 合の決まり（鑑定者本人の教科書 第11回・指示 2026-10-26）：午未は合化なし／命式の干合・支合は隣り合う柱だけ強い／巡りの会局は基本吉／蔵干の干合は司令だけ／干合の教科書の言葉はお客様に渡す文でやわらかく（PRO・易・鑑定書で同じ中身）
{ const r=await p.evaluate(()=>{ const e=[]; if(RIKUGO_EL['午']||RIKUGO_EL['未']) e.push('午未が合化している');
    let seed=13; const rnd=()=>{ seed=(seed*1103515245+12345)%2147483648; return seed/2147483648; }; let nz=0, ns=0;
    for(let i=0;i<300;i++){ const c=baziCompute({year:1950+Math.floor(rnd()*60),month:1+Math.floor(rnd()*12),day:1+Math.floor(rnd()*28),hour:Math.floor(rnd()*24),minute:0,sex:rnd()<0.5?'male':'female'},0,'none');
      natalRels(c.pillars).forEach(x=>{ if((x.kind==='支合'||x.kind==='干合'||x.kind==='蔵干の干合')&&typeof x.near!=='boolean') e.push('強さがない '+x.kind+x.text);
        if(x.kind==='支合'&&/午/.test(x.text)&&/未/.test(x.text)&&x.el) e.push('午未に五行');
        if(x.kind==='蔵干の干合'){ nz++; const L={年:0,月:1,日:2,時:3}, P=c.pillars, s2=x.text.slice(0,2);
          if(x.zk==='zz'&&!(repHidden(P[L[x.pos[0]]]).stem+repHidden(P[L[x.pos[1]]]).stem===s2)) e.push('司令でない '+x.text);
          if(x.zk==='tm'&&repHidden(P[1]).stem!==s2[1]) e.push('月支の司令でない '+x.text);
          if(x.zk==='same'&&!(P[L[x.pos[0]]].stem===s2[0]&&repHidden(P[L[x.pos[0]]]).stem===s2[1])) e.push('同じ柱の司令でない '+x.text);
          if(x.zk==='same') ns++; } });
      kaikyokuScan(c).periods.forEach(q=>{ if(q.tone!=='good') e.push('巡りの会局が吉でない '+q.kind+q.text); }); }
    if(nz<50) e.push('蔵干の干合が少なすぎる('+nz+')');
    // 害・破は当流派では使わない（鑑定者本人の指示 2026-10-26）：命式・巡り・相性・命式の特徴のどこにも出さない
    { let s2=29; const r2=()=>{ s2=(s2*1103515245+12345)%2147483648; return s2/2147483648; }; for(let i=0;i<200;i++){ const mk=()=>baziCompute({year:1950+Math.floor(r2()*60),month:1+Math.floor(r2()*12),day:1+Math.floor(r2()*28),hour:Math.floor(r2()*24),minute:0,sex:r2()<0.5?'male':'female'},0,'none'); const A=mk(), B=mk();
      if(natalRels(A.pillars).some(x=>x.kind==='害'||x.kind==='破')) e.push('命式に害・破');
      if(BR.some(t=>runBranchRels({branch:t},A.pillars.map(p=>({label:p.label[0],branch:p.branch}))).some(x=>x.kind==='害'||x.kind==='破'))) e.push('巡りに害・破');
      if(bxFeatureList(A.pillars).some(t=>/^(害|破)（/.test(t))) e.push('命式の特徴に害・破');
      if(compatBalance(A,B).items.some(x=>/^(害|破)/.test(x.kind))) e.push('相性に害・破'); } }
    if(ns<5) e.push('同じ柱の干合が少なすぎる('+ns+')');
    if(/三合＞方合|三合よりやや穏やか/.test(document.documentElement.innerHTML+kkReadText('方合','火','喜',[],'natal'))) e.push('方合が三合より弱い言い方のまま');
    { const src=document.documentElement.outerHTML; if(/<b>冲・害・刑<\/b>|刑・害（けい・がい）/.test(src)) e.push('画面に害の説明が残っている'); }
    const t=pkSoftWord('丁壬の淫泆の合は情に流されやすく好色、戊癸の無情の合は薄情で孤独。女性は交際的でセクシー。');
    if(/好色|薄情|セクシー|淫泆|無情/.test(t)) e.push('やわらかくなっていない：'+t);
    return [...new Set(e)]; });
  const one=t=>{ const m=t.match(/var pkSoftWord=function[^\n]*/); return m?m[0]:''; }, mine=one(fs.readFileSync(path.join(ROOT,dir,page0),'utf8'));
  ['eki-pro/app/index.html','pro/meishi-sheet.html'].forEach(f=>{ if(!mine||one(fs.readFileSync(path.join(ROOT,f),'utf8'))!==mine) r.push(f+' のやわらげが同じ中身でない'); });
  { const bsrc=fs.readFileSync(path.join(ROOT,'beginner/app-beginner.html'),'utf8'); if(!/function secBond\(c\)/.test(bsrc)||!/secFlow,secBond,secShake/.test(bsrc)) r.push('ビギナーのやさしい画面に「結びつき」の欄がない'); if(!/function secType\(c\)/.test(bsrc)||!/secMe,secType,secPower/.test(bsrc)) r.push('ビギナーのやさしい画面に「生まれ持った型」（格局）の欄がない'); if(!/凶星の干合：/.test(fs.readFileSync(path.join(ROOT,'pro/app-pro.html'),'utf8'))) r.push('PROの札に凶星の干合がない'); }
  const okG=r.length===0; console.log('  '+(okG?'OK':'NG')+' 合の決まり（午未・隣り合う柱・巡りは吉・蔵干は司令・干合の言葉）'+(okG?'':'  … '+r.slice(0,4).join(' / '))); if(!okG) res.fails.push('合の決まり: '+r.slice(0,3).join(' / ')); }
// 格局（教科書 第16回・資料18・鑑定者本人の判断 2026-10-26）：教科書の実例2つが必ず教科書と同じ答えになる。命式・蔵干・通変星・十二運も実例どおり
{ const r=await p.evaluate(()=>{ const e=[]; const mk=(y,m,d,h,mi)=>{ const c=baziCompute({year:y,month:m,day:d,hour:h,minute:mi,sex:'male'},0,'none'); window.chart=c; return c; };
    const row=c=>c.pillars.map((x,i)=>x.stem+x.branch+repHidden(x).stem+' '+(i===2?'-':tenStarOf(c.dayMaster.stem,x.stem))+' '+tenStarOf(c.dayMaster.stem,repHidden(x).stem)+' '+x.terrain).join('|');
    const A=mk(1942,1,8,19,30), B=mk(1980,12,26,0,0);
    if(row(A)!=='辛巳戊 比肩 印綬 死|辛丑癸 比肩 食神 養|辛酉庚 - 劫財 建禄|戊戌辛 印綬 比肩 冠帯') e.push('1942の命式：'+row(A));
    if(row(B)!=='庚申庚 印綬 印綬 死|戊子癸 正官 比肩 建禄|癸酉辛 - 偏印 病|壬子癸 劫財 比肩 建禄') e.push('1980の命式：'+row(B));
    window.chart=A; const ka=kakukyoku(A); if(ka.name!=='従革格') e.push('1942の格局：'+ka.name);
    window.chart=B; const kb=kakukyoku(B); if(kb.name!=='建禄月劫格'||!(kb.extra||[]).some(x=>x.name==='帰禄格')) e.push('1980の格局：'+kb.name+'／'+(kb.extra||[]).map(x=>x.name).join(''));
    { const plain=document.documentElement.classList.contains('bg-on'); const t0=pkEnsureKaku('本文です。',B);
      if(plain){ if(typeof window.pkBTypeOf==='function'&&!/【生まれ持った型】\n自分の足で立つ自立型/.test(t0)) e.push('鑑定文の安全装置（生まれ持った型）がない：'+t0.slice(0,60)); }
      else { if(!/【命式の型（格局）】\n建禄月劫格＝/.test(t0)||/資料18/.test(t0)) e.push('鑑定文の安全装置（格局）がない：'+t0.slice(0,60)); if(pkEnsureKaku('建禄月劫格の人です。',B)!=='建禄月劫格の人です。') e.push('書いてあるのに格局を足した'); } }
    const T=JSON.stringify(KAKU_NAIKAKU); ['殺印生化格','時上偏財格','専食禄格','傷官破れ尽す格','官殺混雑格','財官双美'].forEach(n=>{ if(T.indexOf(n)<0) e.push('内格の表に'+n+'がない'); }); if(/殺印化生格/.test(T)) e.push('殺印化生格のまま');
    return e; });
  const okK=r.length===0; console.log('  '+(okK?'OK':'NG')+' 格局（教科書の実例2つ・資料18の名前）'+(okK?'':'  … '+r.join(' / '))); if(!okK) res.fails.push('格局: '+r.join(' / ')); }
// かっこの中の年にも干支・年齢を付ける（2026-10-24「（2026年内・2027年）」で見つかったもの）。PRO・易・鑑定書で同じ中身
{ const r=await p.evaluate(()=>typeof pkStampYears!=='function'?'':pkStampYears('関係を育てる時期です（2026年内・2027年）。',1985,0,false));
  const okB=r==='関係を育てる時期です（2026年〔丙午・41歳〕内・2027年〔丁未・42歳〕）。'||r==='関係を育てる時期です（2026年〔41歳〕内・2027年〔42歳〕）。';   /* ビギナーのやさしい表示は干支なし */ console.log('  '+(okB?'OK':'NG')+' かっこの中の年にも干支・年齢を付ける'+(okB?'':'  … '+r)); if(!okB) res.fails.push('かっこの中の年'); }
// 先生が選んだ蔵干は本人だけに使い、お相手は司令のまま（2026-10-24）
{ const r=await p.evaluate(()=>{ const A=baziCompute({year:2007,month:9,day:18,hour:13,minute:30,sex:'female',tu:false},'126.98','full'), B=baziCompute({year:1981,month:6,day:10,hour:22,minute:28,sex:'female',tu:false},0,'none');
    const _c0=chart; chart=A; const a0=repHidden(A.pillars[2]).stem, b0=repHidden(B.pillars[2]).stem; zouOverride['日柱']=0; const a1=repHidden(A.pillars[2]).stem, b1=repHidden(B.pillars[2]).stem; zouOverride={}; chart=_c0; return [a0,a1,b0,b1].join(','); });
  const okO=r==='乙,甲,丁,丁'; console.log('  '+(okO?'OK':'NG')+' 先生が選んだ蔵干は本人だけ・お相手は司令（'+r+'）'); if(!okO) res.fails.push('蔵干の選択'); }
// 先生が選んだ蔵干を鑑定書にも引き継ぐ（2026-10-24）：アプリが zo を渡し、鑑定書（3か所同じ）が読む
{ const app=fs.readFileSync(path.join(ROOT,dir,page0),'utf8'), sh=['pro','beginner','meishiki-original'].map(d=>fs.readFileSync(path.join(ROOT,d,'meishi-sheet.html'),'utf8'));
  const okZ=/q\.set\('zo',_zo\)/.test(app)&&sh.every(t=>/var ZO=\{\}/.test(t)&&/ZO\[p\.label\]/.test(t))&&sh[0]===sh[1]&&sh[0]===sh[2];
  console.log('  '+(okZ?'OK':'NG')+' 先生が選んだ蔵干を鑑定書にも引き継ぐ（鑑定書は3か所同じ）'); if(!okZ) res.fails.push('鑑定書の蔵干'); }
// 天徳・月徳など十干で見る星は天干だけ（2026-10-25）：寅月生まれの天徳貴人＝丁。丁が蔵干にだけある柱には付けない
{ const r=await p.evaluate(()=>{ const kt={天徳貴人:'丁'}; return [matchKichi(kt,'丁','卯',['乙']).join(''),matchKichi(kt,'甲','午',['丙','己','丁']).join('')].join('|'); });
  const okT=r==='天徳貴人|'; console.log('  '+(okT?'OK':'NG')+' 天徳・月徳は天干だけで見る（蔵干は数えない）'); if(!okT) res.fails.push('天徳・月徳は天干だけ'); }
// 惹かれ方のしくみ（2026-10-25）：彼女2008-03-28 14:30×彼2006-06-07 時刻不明
{ const r=await p.evaluate(()=>{ if(typeof attractionDetailLines!=='function') return null; document.getElementById('rel-type').value='love'; const A=baziCompute({year:2008,month:3,day:28,hour:14,minute:30,sex:'female',tu:false},'','none'), B=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},'','none'));
    const L=attractionDetailLines(A,B,'本人','お相手'), P=attractionDetailLines(A,B,'あなた','お相手'); return {pro:L.map(x=>x.pro).join('\n'), plain:P.map(x=>x.plain).join('\n'), html:compatAttractHTML(A,B).length, an:/【惹かれ方のしくみ/.test(compatAnalysis(A,B,RELTYPES.love))}; });
  const e=[]; if(!r) e.push('仕組みがない'); else {
    if(!/本人→お相手の恋愛の星：咸池＝「酉」（年支「子」から）→お相手の命式にない／咸池＝「子」（日支「卯」から）→お相手の命式にない／紅艶＝「未」（日干「丁」から）→お相手の命式にない＝恋愛の星は当たらない/.test(r.pro)) e.push('本人→お相手');
    if(!/お相手→本人の恋愛の星：咸池＝「卯」（年支「戌」から）→本人の月柱・日柱にある／咸池＝「子」（日支「卯」から）→本人の年柱にある／紅艶＝「未」（日干「丁」から）→本人の時柱にある＝恋愛の星が当たる/.test(r.pro)) e.push('お相手→本人');
    if(!/比肩＝パートナーの星（官星）ではない/.test(r.pro)||!/時柱が「酉・子・未」なら本人→お相手にも恋愛の星が当たる/.test(r.pro)) e.push('パートナーの星・時刻不明');
    if(/(咸池|紅艶|比肩|官星|財星|日干|年支|日支|命式)/.test(r.plain)) e.push('やさしい言い方に専門用語');
    if(!r.html||!r.an) e.push('画面・鑑定文への渡し'); }
  console.log('  '+(e.length?'NG':'OK')+' 惹かれ方のしくみ（恋愛の星の十二支・相手にあるか・パートナーの星とのちがい・時刻不明）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('惹かれ方のしくみ: '+e.join('・')); }
// 相性の結果のまとめ・目次・たためる欄（2026-10-25）
{ const r=await p.evaluate(()=>{ if(typeof compatSummaryHTML!=='function'||typeof pkCvFold!=='function') return null; document.getElementById('rel-type').value='love'; const A=baziCompute({year:2008,month:3,day:28,hour:14,minute:30,sex:'female',tu:false},'','none'), B=markTimeUnknown(baziCompute({year:2006,month:6,day:7,hour:12,minute:0,sex:'male',tu:true},'','none'));
    const h=compatSummaryHTML(A,B,RELTYPES.love), f=pkCvFold('<section>中身</section>','cm-w','見出し',1); return {h, f}; });
  const e=[]; if(!r) e.push('仕組みがない'); else { if(!/相性の判定<\/b>：良い点が注意点を上回る組み合わせ（良い点13\.5／注意点4\.5）/.test(r.h)) e.push('判定'); if(!/お相手のほうが強く惹かれている（強い）/.test(r.h)) e.push('惹かれ方'); if(!/2人とも縁が動く月<\/b>：/.test(r.h)||!/注意の月<\/b>：/.test(r.h)) e.push('月'); if(!/pkCvJump\(&#39;ck-w&#39;\)/.test(r.h)) e.push('目次');
    if(!/class="cv-fold closed" id="cm-w" data-keep="1"/.test(r.f)||!/cv-head/.test(r.f)) e.push('たためる欄'); }
  console.log('  '+(e.length?'NG':'OK')+' 相性の結果のまとめ・目次・たためる欄'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('まとめ・目次: '+e.join('・')); }
// お名前の印が残らない（1文字のお名前・2026-10-25）
{ const r=await p.evaluate(()=>{ const pa=personName, pb=personNameB; personName='健太'; personNameB='翔'; const out=_unmaskNames('〔本人〕さんと〔翔〕さん、〔お相手〕さん。2027年〔丁未・42歳〕',[['健太','〔本人〕']]); personName=pa; personNameB=pb; return out; });
  const okN=r==='健太さんと翔さん、翔さん。2027年〔丁未・42歳〕'; console.log('  '+(okN?'OK':'NG')+' お名前の印が残らない（1文字のお名前）'+(okN?'':'  … '+r)); if(!okN) res.fails.push('お名前の印'); }
// 占いの言葉の自動直し（音声入力オプション・2026-10-27）：3サイトの voice-fix.js が同じ中身・安全装置が働く・画面に仕組みがある
{ const e=[]; const { createRequire } = await import('module'); const req=createRequire(import.meta.url);
  const srcOf=f=>fs.readFileSync(path.join(ROOT,f),'utf8').replace(/const PRODUCT = "[a-z-]+";/,'');
  const fx=['pro','beginner','eki-pro'].map(d=>d+'/functions/voice-fix.js');
  try{ const a=srcOf(fx[0]); fx.slice(1).forEach(f=>{ if(srcOf(f)!==a) e.push(f+' が同じ中身でない'); });
    const m=req(path.join(ROOT,fx[0])).__test;
    if(!/甲午/.test(m.SYSTEM)||!/律音/.test(m.SYSTEM)||!/月刃格/.test(m.SYSTEM)||!/魁罡/.test(m.SYSTEM)) e.push('用語一覧が入っていない');
    if(/：子$|^ね：/m.test(m.SYSTEM)) e.push('1〜2文字の読みが入っている');
    const g=m.guard; const t1=g('きのえとへんかんが交わってげっしがんになります。','甲と偏官が交わって月支元命になります。'), t2=g('出た卦は地点体、動いたのは三校で、之卦は地沢臨です。','地天泰、三爻、地沢臨'), t3=g('1981年6月10日生まれです。月柱は木の絵馬です。','月柱は甲午です。'), t4=g('生まれは1981年です。','生まれは1980年です。');
    if(t1!=='甲と偏官が交わって月支元命になります。') e.push('正しい直しを戻した'); if(g('月始めに会社の月誌が届きました','月始めに会社の月報が届きました').indexOf('月誌')<0) e.push('ふつうの言葉の言いかえを通した'); if(m.DICT['にっちゅう']!=='日柱'||m.DICT['じちゅう']!=='時柱'||m.DICT['げっし']!=='月支'||m.DICT['はっけ']!=='八卦'||m.DICT['りっちん']!=='律音'||m.DICT['こう']) e.push('1語だけの読みの表'); if(t2.indexOf('地点体')<0) e.push('言葉だけの並びを通した'); if(t3.indexOf('1981')<0) e.push('消えた文を通した'); if(t4.indexOf('1981')<0) e.push('数字の変化を通した');
  }catch(err){ e.push('読めない：'+err.message); }
  const pg=await p.evaluate(()=>!!(window.__pkVfx&&window.__pkVfx.intro&&window.__pkVfx.end)); if(!pg) e.push('画面に自動直しの仕組みがない'); { const pgSrc=fs.readFileSync(path.join(ROOT,dir,page0),'utf8'); const vb=pgSrc.slice(pgSrc.indexOf('<!--VOICE-INPUT:start'),pgSrc.indexOf('<!--VOICE-INPUT:end')); if(/残り'\+|回まで無料|回が終わりました/.test(vb)) e.push('回数を画面に出している'); }
  try{ const { execFileSync } = await import('child_process'); const o=execFileSync('node',[path.join(ROOT,'tools/release_gate/gate_voice_count.cjs')],{encoding:'utf8'}).trim(); if(o!=='OK') e.push('おためしの回数：'+o); }catch(err){ e.push('おためしの回数：'+String((err.stdout||err.message)).trim()); }
  ['pro/privacy-pro.html','beginner/privacy.html','eki-pro/privacy.html'].forEach(f=>{ if(!/占いの言葉の自動直し/.test(fs.readFileSync(path.join(ROOT,f),'utf8'))) e.push(f+' にプライバシーの説明がない'); });
  console.log('  '+(e.length?'NG':'OK')+' 占いの言葉の自動直し（3サイト同じ・安全装置・おためしの回数・画面・プライバシー）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('自動直し: '+e.join('・')); }
// 事実の差しこみの印（〔F:…〕）と出す前の照らし合わせ（pkFactGate）（先生の指示 2026-11-07「いつになったらミスが無くなるのか」）：
//  ① 3つのツール（PRO・易・鑑定書＋ミラー・生成したビギナー）に同じ中身が入っている ② 印が計算どおりの言葉になる（ビギナーは干支なし）・知らない印/閉じない印は外す
//  ③ 材料の事実が印になる（生年月日は変えない） ④ 計算と合わない事実の文だけを外し、正しい文は外さない ⑤ 1行目が消えたら通信なしの答えに切りかえる ⑥ 通信なしの答え（ツールが全部書く）を照らしても1文も外れない
{ const e=[]; const blk=f=>{ const t=fs.readFileSync(path.join(ROOT,f),'utf8'); const m=t.match(/\/\* PK-FACT-MARKS:start[\s\S]*?\/\* PK-FACT-MARKS:end \*\//); return m?m[0]:''; };
  const B0=blk('pro/app-pro.html'); if(!B0) e.push('PROに仕組みがない');
  [dir+'/'+page0,'eki-pro/app/index.html','pro/meishi-sheet.html','meishiki-original/meishi-sheet.html','beginner/meishi-sheet.html'].forEach(f=>{ if(blk(f)!==B0) e.push(f+' の中身がPROと同じでない'); });
  { const ek=fs.readFileSync(path.join(ROOT,'eki-pro/app/index.html'),'utf8'); if(!/pkFmRule\(ekiFmEnv\(\)\)/.test(ek)||!/pkFmExpand\(t,_fmE\)/.test(ek)||!/pkFactGate\(_o,_fmE\)/.test(ek)) e.push('易の文章作成に印・照らし合わせが入っていない');
    const sh=fs.readFileSync(path.join(ROOT,'pro/meishi-sheet.html'),'utf8'); if(!/sys=pkFmMaterial\(sys,_fmE\)\+pkFmRule\(_fmE\)/.test(sh)||!/pkFmExpand\(txt,_fmE\)/.test(sh)||!/pkFactGate\(txt,_fmE\)/.test(sh)) e.push('鑑定書の詳細鑑定に印・照らし合わせが入っていない'); }
  const r=await p.evaluate(()=>{ const out={}; const c0=chart; try{
    chart=baziCompute({year:1981,month:6,day:10,hour:22,minute:28,sex:'female',tu:false},'','none');
    const du=curDu(chart), dg=du.ganzhi||(du.stem+du.branch), P=chart.pillars, dayP=P[2].stem+P[2].branch;
    const T=pkfmToday(), D=new Date(T.y,T.m-1,T.d+10,12), dy=D.getFullYear(), dm=D.getMonth()+1, dd=D.getDate(), W='日月火水木金土'.charAt(D.getDay()), WX='日月火水木金土'.charAt((D.getDay()+3)%7), DG=pkfmDGz(dy,dm,dd);
    out.cal=[pkfmDGz(2026,11,8),pkfmYGz(2027),pkfmMGz(2026,12),pkfmWd(2026,11,8)].join(',');
    const env=pkFmEnvPro(false,false,'材料：血刃が巡る',''), envP=pkFmEnvPro(false,true,'','');
    const src='〔F:y2027〕年に〔F:du_now〕の流れ。日柱（〔F:p_day〕）。〔F:d'+dy+'-'+dm+'-'+dd+'〕（'+W+'）に。〔F:zz9〕は〔F:s:血刃〕と〔F:s:天乙貴人〕。〔F:y2028';
    out.ex=pkFmExpand(src,env).text; out.exP=pkFmExpand(src,envP).text;
    out.want={y:'2027年（丁未・46歳）',du:'今の大運（'+dg+'）',p:'日柱（'+dayP+'）',d:dm+'月'+dd+'日（'+W+'）'+DG+'の日',dP:dm+'月'+dd+'日（'+W+'）',yP:'2027年（46歳）'};
    out.mat=pkFmMaterial('2027年（丁未・46歳）と'+dm+'月'+dd+'日（'+W+'）、今の大運（'+dg+'）、日柱「'+dayP+'」。生年月日：1981年6月10日 22:28',env);
    out.matWant=['〔F:y2027〕','〔F:d'+pkfmFwdY(dm,dd)+'-'+dm+'-'+dd+'〕','〔F:du_now〕','〔F:p_day〕','1981年6月10日'];
    const good=['2027年（丁未・46歳）に動くのが合っています。',dm+'月'+dd+'日（'+W+'）は'+DG+'の日です。','日柱（'+dayP+'）の人です。','今の大運（'+dg+'）は大事な10年。'];
    const bad=['2027年（丙午・46歳）は動きやすい年です。','2028年（戊申・50歳）も良い年です。',dm+'月'+dd+'日（'+WX+'）が向いています。','日柱（甲子）の人です。','大運「'+(dg==='癸亥'?'壬戌':'癸亥')+'」に入ると変わります。','甲丑の気配があります。'];
    const g1=pkFactGate('【結論】'+good[0]+'\n'+good.slice(1).join('')+bad.join('')+'\n'+'この流れを大切に、自分のペースで準備を重ねていきましょう。焦らずに、できることから一つずつ進めると、気持ちも整っていきます。まわりの人の声にも耳を傾けながら、無理のない計画を立ててください。毎日の小さな積み重ねが、次の一歩を支えてくれます。',pkFmEnvPro(false,false,'',''));
    out.g1={rows:g1.rows.length,keep:good.every(x=>g1.text.indexOf(x)>=0),gone:bad.every(x=>g1.text.indexOf(x)<0),off:pkFactGateOff(g1)};
    const g2=pkFactGate(bad[0]+'\n'+good.join(''),pkFmEnvPro(false,false,'','')); out.g2off=pkFactGateOff(g2);
    // 通信なしの答え（ツールが全部書く）は、照らし合わせても1文も外れない
    let seed=5; const rnd=()=>{ seed=(seed*1103515245+12345)%2147483648; return seed/2147483648; }; const Q=['転職するなら今年と来年のどちらがいいですか','11月20日と11月27日、告白するならどちらがいいですか','結婚できますか','金運が上がる時期は','明日彼に連絡してもいいですか'];
    out.fp=[]; for(let k=0;k<25;k++){ const tu=rnd()<0.3; let c=baziCompute({year:1950+Math.floor(rnd()*60),month:1+Math.floor(rnd()*12),day:1+Math.floor(rnd()*28),hour:Math.floor(rnd()*24),minute:0,sex:rnd()<0.5?'male':'female',tu},'','none'); if(tu) c=markTimeUnknown(c); chart=c; const q=Q[k%Q.length];
      let t=String(consultParts(q).local||''); try{ t=pkEnsureBig(t,chart,q); t=pkEnsureConsult(t,chart,q); t=pkEnsureLove(t,chart,q); t=pkEnsureDays(t,chart,q); }catch(_e){}
      const g=pkFactGateRun(t,false,false,q); if(g.rows.length) out.fp.push(chart.birth.clock+'：'+g.rows[0].what+'｜'+g.rows[0].calc); }
    // ① 誰の柱か：お相手の名前・呼び名（彼さん・太郎さん）の柱を本人の干支に書きかえない／本人の柱のまちがいは直す／照らし合わせはお相手の柱で照らす（2026-11-07）
    { const pa=personName, pb=personNameB, cb0=(typeof chartB!=='undefined')?chartB:null; personName='さくら'; personNameB='太郎';
      const A=baziCompute({year:1981,month:6,day:10,hour:22,minute:28,sex:'female',tu:false},'','none'), B=baziCompute({year:1969,month:11,day:16,hour:9,minute:0,sex:'male',tu:false},'','none'); chart=A; chartB=B;
      const gA=i=>A.pillars[i].ganzhi, gB=i=>B.pillars[i].ganzhi, wrong=gA(1)===pkfmGz(0)?pkfmGz(2):pkfmGz(0);
      const src='さくらさんから見て、彼さんの月柱「'+gB(1)+'」が当たります。太郎さんの日柱「'+gB(2)+'」です。本人の月柱「'+wrong+'」です。';
      const fx=pkPillarGzFix(src,A,B); out.w1={keepB:fx.indexOf('彼さんの月柱「'+gB(1)+'」')>=0&&fx.indexOf('太郎さんの日柱「'+gB(2)+'」')>=0, fixA:fx.indexOf('本人の月柱「'+gA(1)+'」')>=0};
      const env2=pkFmEnvPro(true,false,'',''); const g=pkFactGate('彼さんの月柱「'+gA(1)+'」が当たります。太郎さんの日柱「'+gB(2)+'」です。さくらさんの月柱「'+gA(1)+'」です。',env2);
      out.w1.gate=g.rows.length===1&&g.text.indexOf('太郎さんの日柱')>=0&&g.text.indexOf('さくらさんの月柱')>=0;
      { const ns=(pkFmPerson(A,'本人').ns||[])[2]||[], all=['天乙貴人','文昌貴人','駅馬','華蓋','咸池','紅艶'], no=all.find(x=>ns.indexOf(x)<0), yes=ns.find(x=>all.indexOf(x)>=0||x==='天徳貴人');
        const g3=pkFactGate('日柱にある'+no+'が助けます。'+(yes?'日柱にある'+yes+'が支えます。':''),pkFmEnvPro(false,false,'','')); out.w1.star=g3.rows.length===1&&(!yes||g3.text.indexOf(yes)>=0); }   // 命式にない星（鑑定書の「日柱にある天乙貴人」）
      personName=pa; personNameB=pb; chartB=cb0; }
    // 運の柱（今月の月柱）を本人の柱として直さない・来年の年運の干支のずれは年の言葉を直す・「今の大運」に次の大運を書いたら直す／星の説明つきなら文を外す（2026-11-07）
    { const c=baziCompute({year:1981,month:6,day:10,hour:22,minute:28,sex:'female',tu:false},'','none'); chart=c; const NY=pkNenInfo().Y, mp=c.pillars[1].ganzhi, wr=mp===pkfmGz(5)?pkfmGz(7):pkfmGz(5);
      const D=[mp].concat(c.decadeFortunes.map(d=>d.ganzhi)), cu=curDu(c).ganzhi, nx=D[D.indexOf(cu)+1];
      const t1='今月の月柱は'+wr+'です。', r1=pkPillarGzFix(t1,c,null), g1=pkFactGate(t1,pkFmEnvPro(false,false,'',''));
      const r2=pkFmRelYearFix('来年の年運は'+pkfmYGz(NY)+'（天干偏印）です。',{nenY:NY});
      const r3=pkRunGzFix('今の大運は'+nx+'です。',c,null), r4=pkRunGzFix('前の文です。今の大運は'+nx+'（干は印綬の星）の時期です。次の文です。',c,null);
      const g5=pkFactGate('今の大運は'+nx+'です。ほかの文です。',pkFmEnvPro(false,false,'',''));
      const r6=pkFmRelYearFix((NY+1)+'年（今年）と'+NY+'年（来年）',{nenY:NY}), ns0=(pkFmPerson(c,'本人').ns||[]).flat(), st0=['駅馬','華蓋','文昌貴人','咸池','紅艶'].find(x=>ns0.indexOf(x)<0);
      const g7=pkFactGate('ご自身の命式にはもともと **'+st0+'**があります。ほかの文です。',pkFmEnvPro(false,false,'',''));
      const kb0=kubo(c), yN=[0,1,2,3,4,5,6,7,8,9,10,11].map(k=>NY+k).find(y=>kb0.indexOf(pkfmYGz(y).charAt(1))<0&&kb0.indexOf(pkfmYGz(y-1).charAt(1))>=0), g8=pkFactGate(yN+'年を迎えるとひと休みの時期が明け、温かい空気に変わります。ほかの文です。',pkFmEnvPro(false,false,'',''));
      const T9=pkfmToday(), d9=new Date(T9.y,T9.m-1,T9.d+12,12), F9=pkDayFacts(c,d9), all9=['妨害殺','血刃','亡神','劫殺','囚獄','飛刃','天乙貴人','月徳貴人'], ns9=(pkFmPerson(c,'本人').ns||[]).flat(), no9=all9.find(x=>(F9.stars||[]).indexOf(x)<0&&ns9.indexOf(x)<0), yes9=(F9.stars||[]).find(x=>all9.indexOf(x)>=0);
      const g9=pkFactGate((d9.getMonth()+1)+'月'+d9.getDate()+'日のような日は、'+no9+'などの影響で行き違いが起きやすくなります。'+(yes9?(d9.getMonth()+1)+'月'+d9.getDate()+'日は'+yes9+'が巡ります。':'')+'ほかの文です。',pkFmEnvPro(false,false,'',''));
      const g10=pkFactGate('命式全体の五行を見ると、'+no9+'（注意の星）を持っています。ほかの文です。',pkFmEnvPro(false,false,'',''));
      out.w10=!no9||g10.rows.length===1;   // 「命式全体を見ると…○○を持っています」で命式にない星（2026-11-07）
      out.w9=!no9||(g9.rows.length===1&&(!yes9||g9.text.indexOf(yes9)>=0));   // その日にも命式にもない星を言った文（「のような」「など」でも）を外す（2026-11-07）
      out.w6={yr:r6===(NY+1)+'年（来年）と'+NY+'年（今年）', star:g7.rows.length===1&&!/[*＊]/.test(g7.rows[0].note), ake:!yN||g8.rows.length===0};   // 「○年を迎えるとひと休みが明け」は空亡と書いていない   // 「2027年（今年）」（立春前）・外した文の引用に＊を出さない（2026-11-07）
      out.w5={run:r1===t1&&g1.rows.length===0, rel:r2==='今年の年運は'+pkfmYGz(NY)+'（天干偏印）です。', now:r3==='今の大運は'+cu+'です。', drop:r4==='前の文です。次の文です。', gate:g5.rows.length===1, r3, r4}; }
    // 西暦のない来年の月に西暦・同じつなぎの言葉の重なり（先生の指示 2026-11-11。今日を 2026-11-11 に固定して確かめる＝今日が変わっても同じ結果）
    { const _td=pkfmToday; try{ pkfmToday=function(){ return {y:2026,m:11,d:11}; };
      const C=[['この先は、2月から6月上旬にかけて縁が動きます。','この先は、2027年2月から6月上旬にかけて縁が動きます。'],['12月〜2月は準備の時期です。','2026年12月〜2027年2月は準備の時期です。'],['1月・3月が縁の動く月です。','2027年1月・3月が縁の動く月です。'],
        ['11月から12月上旬は動きやすい時期です。',0],['2月に告白されたとのことですね。',0],['3月生まれの方です。',0],['毎年2月は体調に気をつけて。',0],['来年の2月から6月がよいでしょう。',0],['2027年2月から6月が狙い目です。',0],['冬（12月〜2月）は休む季節です。',0],['12月の寒さのように静かです。',0],['今月（10月〜11月上旬）は足場を固めます。',0],['12月から翌1月上旬にかけて。',0],['2月4日の立春まで。',0],['年は立春で切りかわり、2月〜翌年1月で1年。',0],
        ['お二人の命式を合わせると、2人の地支（しし：十二支）を合わせると巳午未がそろいます。','お二人の命式で、2人の地支（しし：十二支）を合わせると巳午未がそろいます。'],['命式を見ると、日柱を見ると落ち着いた人です。','命式で、日柱を見ると落ち着いた人です。'],['本人から見ると、お相手から見ると印象が違います。',0],['命式を見ると穏やかで、日柱を見ると芯が強い人です。',0]];
      const bad=C.filter(x=>pkFmDupConnFix(pkFmMonYearFix(x[0]))!==(x[1]||x[0])).map(x=>pkFmDupConnFix(pkFmMonYearFix(x[0])));
      const ff=pkFinalFix('この先は、2月から6月上旬にかけて縁が動きます。','',false);
      out.w11={ok:!bad.length&&ff.indexOf('2027年2月から6月上旬')>=0, bad:bad.slice(0,3), ff:ff.slice(0,60)}; }finally{ pkfmToday=_td; } }
    // ③④ 今年のずれ・「〜11月上旬」を日付にしない
    { const NY=pkNenInfo().Y; out.w3=pkFmRelYearFix('今年の'+(NY+1)+'年に。',{nenY:NY})==='来年の'+(NY+1)+'年に。';
      { const _yy=pkfmToday().y+6, _ex=pkFmExpand('まず〔F:y'+_yy+'〕（〔F:y'+_yy+'〕歳）には縁が動きます。',pkFmEnvPro(false,false,'','')).text; out.w4b=!/年歳/.test(_ex)&&_ex.indexOf(String(_yy)+'年')>=0; }   // 年の印に「歳」を付けたくずれ（2026-11-11）
      { const _ex=pkFmExpand('今は〔F:du_now〕という、内面を深める10年です。',pkFmEnvPro(false,false,'','')).text; out.w12={ex:!/今は今/.test(_ex), pt:pkPlainTalk('今は今の大運（戊戌）という、内面を深める10年です。')==='今は、内面を深める10年です。', hd:/^【お客様へのお伝え方】/m.test(pkFixAnsHeads('結論の文です。\n\n【田中さんへのお伝え方】\n本文の文です。本文の文です。本文の文です。本文の文です。')), nm:pkTypoFix('本人さんとお相手さん')==='ご本人とお相手'}; }   // 「今は今という」・名前入りの見出し・本人さん（2026-11-12）
      { const f=pkRuleWordFix; out.w13={hp:f('前の文。\n子と未の害があります。突破力があります。')==='前の文。\n突破力があります。', zou:f('蔵干は余気が乙です。司令は戊です。')==='司令は戊です。', kaku:f('格局は余気から透出します。')==='格局は余気から透出します。', yo:f('養生では用神の水を意識。')==='養生では整えたい五行の水を意識。', kyo:!/凶/.test(f('強旺格は男性は大吉、女性は凶とされます。')), fut:f('二股を続けてもよいでしょう。')==='', keep:f('自己破産・読破・破綻・損害・妨害殺')==='自己破産・読破・破綻・損害・妨害殺'}; }   // 頼むだけだった決まりを出す前に直す（2026-11-12）
      { const E=function(x){ return pkFmExpand(x,pkFmEnvPro(false,false,'','')).text; }, NY0=pkNenInfo().Y+3;
        const r1=E('結婚は'+NY0+'年（47歳）の西暦や'+(NY0+6)+'年の西暦などがよいでしょう。'), r2=E('この年は'+NY0+'年（'+NY0+'年・'+NY0+'年）ごろです。'), r3=E((NY0)+'年1月から翌2月上旬は注意です。'), r4=E((NY0)+'年12月から翌1月上旬は注意です。');
        out.w15={nishi:!/の西暦/.test(r1), dup:!/（\d{4}年・\d{4}年）/.test(r2), yoku:!/1月から翌2月/.test(r3), keep:/12月から翌1月/.test(r4)}; }   // 実機点検で出た文のくずれ（2026-11-14）
      out.w4=pkFmExpand('いま〜〔F:d'+pkfmFwdY(11,6)+'-11-6〕上旬の時期',pkFmEnvPro(false,false,'','')).text.indexOf('いま〜11月上旬の時期')>=0&&pkFactFix('いま〜11月6日（火）上旬','','')==='いま〜11月6日（火）上旬'; }
  }catch(err){ out.err=String(err&&err.message||err); } chart=c0; return out; });
  if(r.err) e.push('動かない：'+r.err);
  else { if(r.cal!=='丙戌,丁未,庚子,日') e.push('暦の計算：'+r.cal);
    ['y','du','p','d'].forEach(k=>{ if(r.ex.indexOf(r.want[k])<0) e.push('印の置きかえ（'+k+'）：'+r.ex.slice(0,120)); });
    if(/〔F|F:|年年|\u0011|\u0012/.test(r.ex)) e.push('印・「年」の重なりが残る：'+r.ex.slice(0,120));
    if(r.ex.indexOf('血刃')<0||r.ex.indexOf('天乙貴人')>=0) e.push('星の印（材料にある星だけ）');
    if(r.exP.indexOf(r.want.yP)<0||r.exP.indexOf(r.want.dP)<0||/[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]|大運|日柱/.test(r.exP)) e.push('ビギナーの印（干支・専門用語なし）：'+r.exP.slice(0,120));
    r.matWant.forEach(w=>{ if(r.mat.indexOf(w)<0) e.push('材料の印（'+w+'）：'+r.mat.slice(0,120)); });
    if(r.g1.rows!==6||!r.g1.keep||!r.g1.gone||r.g1.off) e.push('照らし合わせ：'+JSON.stringify(r.g1));
    if(!r.g2off) e.push('1行目が消えたのに切りかえない');
    if(r.fp.length) e.push('通信なしの答えの正しい文を外した：'+r.fp.slice(0,2).join(' / '));
    if(!r.w1||!r.w1.keepB||!r.w1.fixA||!r.w1.gate||!r.w1.star) e.push('誰の柱か（お相手の呼び名・名前）：'+JSON.stringify(r.w1));
    if(!r.w5||!r.w5.run||!r.w5.rel||!r.w5.now||!r.w5.drop||!r.w5.gate) e.push('運の柱・来年の年運・今の大運：'+JSON.stringify(r.w5));
    if(!r.w6||!r.w6.yr||!r.w6.star||!r.w6.ake) e.push('西暦（今年）・引用の＊：'+JSON.stringify(r.w6));
    if(!r.w9) e.push('その日にない星の名前を外さない'); if(!r.w10) e.push('命式にない星を「持っています」');
    if(!r.w11||!r.w11.ok) e.push('西暦のない来年の月・つなぎの言葉の重なり：'+JSON.stringify(r.w11));
    if(!r.w3) e.push('今年と西暦のずれを直さない'); if(!r.w4) e.push('「〜11月上旬」を日付として扱った'); if(!r.w4b) e.push('「（2032年歳）」のくずれが残る'); if(!r.w12||!r.w12.ex||!r.w12.pt||!r.w12.hd||!r.w12.nm) e.push('今は今・名前入りの見出し・本人さん：'+JSON.stringify(r.w12)); if(!r.w15||Object.values(r.w15).some(v=>!v)) e.push('の西暦・同じ年のかっこ・翌の直し：'+JSON.stringify(r.w15)); if(!r.w13||Object.values(r.w13).some(v=>!v)) e.push('害・破／余気・中気／用神／強旺格の凶／二股の直し：'+JSON.stringify(r.w13)); }
  console.log('  '+(e.length?'NG':'OK')+' 事実の差しこみの印・出す前の照らし合わせ（3ツール同じ・置きかえ・ビギナー・材料・正しい文を外さない・切りかえ・誰の柱か・今年のずれ・上旬・来年の月の西暦・つなぎの重なり）'+(e.length?'  … '+e.join('・'):'')); if(e.length) res.fails.push('事実の印・照らし合わせ: '+e.join('・')); }
// 実機点検 2026-11-15 で直したところ：①何十年も先の大運を年齢・西暦で出さない ③「明日（11月16日（月）の日）」「明日（11月16日）（甲午）」 ④「2027年（2027年・35歳）」「（戊申・47歳）（戊申の年・…）」
//  ⑤注意点0なのに「打ち消し合う」と書かない ⑥「お互いにの五行の補い合い」 ⑨年運・大運の十二運のまちがい
{ const e=[]; const r=await p.evaluate(()=>{ const o={bad:[]}; const c0=chart; try{
    const mk=(y,m,d,h,mi,sex,tu)=>{ const c=baziCompute({year:y,month:m,day:d,hour:h,minute:mi,sex,tu},0,'none'); return tu?markTimeUnknown(c):c; };
    const A=mk(1981,6,10,22,28,'female',false); chart=A;
    // ① 何十年も先の大運（今の年齢＋25歳より先）の年齢・西暦を出さない
    let seed=1115; const rnd=()=>{ seed=(seed*1103515245+12345)%2147483648; return seed/2147483648; };
    for(let k=0;k<60;k++){ const c=mk(1960+Math.floor(rnd()*40),1+Math.floor(rnd()*12),1+Math.floor(rnd()*28),12,0,rnd()<0.5?'male':'female',true); chart=c; const na=c.now&&c.now.age; if(!na) continue;
      let z=null; try{ z=jyuZone(c); }catch(e){} if(z&&z.far&&z.farAge>na+25&&!z.farTooFar) o.bad.push('jyuZone が遠い大運に印を付けない');
      const t=localAnswer(c,'来年結婚できますか'); const m=t.match(/主役になる大運は\**(\d+)歳/); if(m&&+m[1]>na+25) o.bad.push('遠い大運：'+na+'歳の人に'+m[1]+'歳'); }
    chart=A;
    // ③④ かっこのくずれ
    const env=pkFmEnvPro(false,false,'',''), E=x=>pkFmExpand(x,env).text, Y=pkfmToday().y+1, ag=Y-1981;
    const C=[['明日（11月16日（月）の日）は、良い日です。','明日（11月16日（月））は、良い日です。'],['甲午の日・甲午の日は','甲午の日は'],[Y+'年（'+Y+'年・'+ag+'歳）は',Y+'年（'+ag+'歳）は'],['2028年（戊申・47歳）（戊申の年・劫財）は','2028年（戊申・47歳・劫財）は'],['2033年（2033年・2033年）','2033年']];
    C.forEach(([x,w])=>{ const v=pkFmTidy(x); if(v!==w) o.bad.push('かっこ：'+v); });
    if(/年（\d{4}年[・）]/.test(E(Y+'年（'+Y+'年・'+ag+'歳）は縁が動きます。'))) o.bad.push('年の重なりが展開後に残る');
    { const D=pkDayDir(A,'明日、彼に連絡してもいいですか'); if(!D) o.bad.push('明日の日運が出ない'); else if(/）（/.test(D.talk+D.pro)) o.bad.push('明日の二重かっこ：'+D.talk.slice(0,50)); }
    // ⑤ 注意点0なのに「打ち消し合う」
    let n5=0; for(let k=0;k<160;k++){ const a=mk(1960+Math.floor(rnd()*45),1+Math.floor(rnd()*12),1+Math.floor(rnd()*28),12,0,'female',true), b=mk(1960+Math.floor(rnd()*45),1+Math.floor(rnd()*12),1+Math.floor(rnd()*28),12,0,'male',true); const cb=compatBalance(a,b);
      if(cb.bad===0&&cb.good>0){ n5++; if(/打ち消し|同じくらい/.test(cb.verdict)||/同じくらい/.test(pkCbPlain(cb))) o.bad.push('注意点0で打ち消し合う：'+cb.verdict); }
      // ⑥ この2人だけの読み
      const K=pkRelHeads('kizuna'); const w=pkEnsureWeave('結論の文です。\n\n【'+K[0]+'】\n本文の文です。',a,b); if(/にの/.test(w)) o.bad.push('「にの」のつなぎ：'+(w.match(/[^。\n]{0,10}にの[^。\n]{0,10}/)||[''])[0]); }
    if(!pkCbPlain({cls:'mid',good:2.5,bad:0,net:2.5}).match(/良いところがあり/)) o.bad.push('やさしい言い方の判定');
    // ⑨ 十二運
    if(pkFmJuniFix('2028年の年運は戊申（＝劫財と長生の巡り）です。',{P:[{pil:['','','己未','']}]})!=='2028年の年運は戊申（＝劫財と沐浴の巡り）です。') o.bad.push('年運の十二運を直さない');
    if(pkFmJuniFix('2028年の年運は戊申（＝劫財と長生の巡り）です。',{two:true,P:[{pil:['','','己未','']}]})!=='2028年の年運は戊申（＝劫財と長生の巡り）です。') o.bad.push('相性で十二運を書きかえた');
    o.n5=n5;
  }catch(err){ o.bad.push('動かない：'+String(err&&err.message||err)); } chart=c0; return o; });
  r.bad.forEach(x=>e.push(x));
  console.log('  '+(e.length?'NG':'OK')+' 実機点検 2026-11-15（遠い大運・かっこのくずれ・明日の二重かっこ・注意点0の判定〈'+(r.n5||0)+'組〉・にのつなぎ・十二運）'+(e.length?'  … '+[...new Set(e)].slice(0,6).join('・'):'')); if(e.length) res.fails.push('実機点検 2026-11-15: '+[...new Set(e)].join('・')); }
// 恋愛・仕事の持ち味（長所・気をつけたいこと・向いている仕事・アドバイス。鑑定者本人の指示 2026-11-11）：
//  ① 材料 KANSHI60_TRAITS が PRO・生成したビギナー・鑑定書（＋ミラー）で同じ中身 ② 60干支×7項目がそろい、干支名・星の名前・専門用語・AI・＊がない
//  ③ 相談の中身で出すほうを決める（相談なし＝両方／仕事＝仕事だけ／恋愛＝恋愛だけ／どちらでもない・安全・つらさ＝出さない／13歳未満は恋愛なし）
//  ④ 書き足しは1回だけ（もう一度通しても増えない）・見出しだけあるときは抜けた項目だけ足す・ビギナーのやさしい画面は専門用語なしの見出し ⑤ 鑑定書の定型文・詳細鑑定に入っている
{ const e=[]; const blk=f=>{ const m=fs.readFileSync(path.join(ROOT,f),'utf8').match(/\/\*PK-KANSHI-TRAITS:start\*\/([\s\S]*?)\/\*PK-KANSHI-TRAITS:end\*\//); return m?m[1]:''; };
  const B0=blk('pro/app-pro.html'); if(!B0) e.push('PROに材料がない');
  [dir+'/'+page0,'pro/meishi-sheet.html','meishiki-original/meishi-sheet.html','beginner/meishi-sheet.html'].forEach(f=>{ if(blk(f)!==B0) e.push(f+' の中身がPROと同じでない'); });
  { const sh=fs.readFileSync(path.join(ROOT,'pro/meishi-sheet.html'),'utf8');
    if(!/b\+=sheetTraitHTML\(dayGZ,'work'/.test(sh)||!/b\+=sheetTraitHTML\(dayGZ,'love'/.test(sh)) e.push('鑑定書の本格版（定型文）に入っていない');
    if(!/kan\.恋愛\+'<\/p>'\+sheetTraitHTML\(dayGZ,'love'/.test(sh)||!/kan\.仕事(?:,true,true\))?\+'<\/p>'\+sheetTraitHTML\(dayGZ,'work'/.test(sh)) e.push('鑑定書のやさしい版に入っていない');
    if(!/sheetTraitMaterial\(/.test(sh)||!/txt=window\.sheetEnsureTraitsTxt\(txt,/.test(sh)) e.push('鑑定書の詳細鑑定（材料・書き足し）に入っていない'); }
    { /* 向いている仕事は1つの出どころ（2026-11-17）：鑑定書の言葉の表と決め方が、アプリの pkJobFit（PK_GRP_JOB・喜神→月支元命）と同じか（3か所の鑑定書） */
      const ap=fs.readFileSync(path.join(ROOT,dir,page0),'utf8'), am=/const PK_GRP_JOB=(\{[^\n]*?\});/.exec(ap), A=am?Function('return '+am[1])():null;
      ['pro','beginner','meishiki-original'].forEach(dd=>{ const st=fs.readFileSync(path.join(ROOT,dd,'meishi-sheet.html'),'utf8'), m=/var SHEET_GRP_JOB=(\{[^\n]*?\});/.exec(st), S=m?Function('return '+m[1])():null;
        if(!A||!S||JSON.stringify(A)!==JSON.stringify(S)) e.push(dd+'の鑑定書：向いている仕事の言葉がアプリ（PK_GRP_JOB）とちがう');
        if(!/\['向いている仕事',\(function\(\)\{ var JF=sheetJobFit\(!!plain\);/.test(st)||!/window\.__sheetJobR=r;/.test(st)) e.push(dd+'の鑑定書：持ち味の向いている仕事が sheetJobFit を使っていない');
        if(/\+kan\.仕事\+|\+MEIGEN\[genmei\]\.shi(?:\)|\+)/.test(st)||!/sheetWorkDetail\(kan\.仕事,/.test(st)||!/var _JF=sheetJobFit\(/.test(st)) e.push(dd+'の鑑定書：60干支・月支元命の仕事の文に、sheetJobFit 以外の職業の一覧が残っている'); }); }
  const r=await p.evaluate(()=>{ const o={bad:[]}; const c0=chart; try{
    const K=Object.keys(KANSHI60_TRAITS), F=['恋長','恋注','恋助','仕長','仕注','仕適','仕助'], NG=/[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]|命式|通変|大運|十二運|蔵干|比肩|劫財|食神|傷官|偏財|正財|偏官|正官|偏印|印綬|魁罡|空亡|AI|[*＊]|男性|女性/;
    if(K.length!==60||K.join('')!==Object.keys(KANSHI60_DETAIL).join('')) o.bad.push('60干支がそろわない');
    K.forEach(k=>F.forEach(f=>{ const v=KANSHI60_TRAITS[k][f]; if(!v||v.length<10) o.bad.push(k+f+'がない'); else if(NG.test(v)) o.bad.push(k+f+'に専門用語など：'+v); }));
    const kd=q=>{ const x=pkTraitKinds(q,null); return (x.love?'L':'')+(x.work?'W':''); };
    [['','LW'],['今の仕事を続けるか転職か迷っています','W'],['彼と結婚できますか','L'],['金運はどうですか',''],['もう死にたいです',''],['彼の仕事が忙しくて会えません。付き合いを続けるべきですか','L'],['適職を教えてください','W'],['職場の恋愛は結婚につながりますか','LW']].forEach(([q,w])=>{ if(kd(q)!==w) o.bad.push('出すほう「'+q+'」＝'+kd(q)+'（正しくは'+(w||'なし')+'）'); });
    const T=pkfmToday(); const mk=(y,m,d,sex,tu)=>{ const c=baziCompute({year:y,month:m,day:d,hour:12,minute:0,sex,tu},'','none'); return tu?markTimeUnknown(c):c; };
    const c=mk(1976,5,18,'male',true), d=KANSHI60_TRAITS[c.pillars[2].ganzhi], pl=document.documentElement.classList.contains('bg-on');
    const hL=pl?'【恋愛での持ち味】':'【恋愛の持ち味】', hW=pl?'【お仕事での持ち味】':'【仕事の持ち味】';
    const a1=pkEnsureTraits('この方はまじめな人です。',c,''), a2=pkEnsureTraits(a1,c,'');
    if(a1.indexOf(hL)<0||a1.indexOf(hW)<0||a1.indexOf(d.恋長)<0||a1.indexOf((typeof pkJobFit==='function'&&pkJobFit(c,pl)||{}).text||d.仕適)<0||a1.indexOf('向いている仕事：')<0) o.bad.push('相談なしで両方が出ない：'+a1.slice(0,80));
    if(a2!==a1) o.bad.push('2回通すと増える');
    if(pl&&/[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]/.test(a1)) o.bad.push('やさしい画面に干支が出た');
    const w=pkEnsureTraits('転職はよい流れです。',c,'今の仕事を続けるか転職か迷っています'); if(w.indexOf(hW)<0||w.indexOf(hL)>=0) o.bad.push('仕事の相談で仕事だけにならない');
    const l=pkEnsureTraits('結婚の縁はあります。',c,'彼と結婚できますか'); if(l.indexOf(hL)<0||l.indexOf(hW)>=0) o.bad.push('恋愛の相談で恋愛だけにならない');
    if(pkEnsureTraits('金運は上向きます。',c,'金運はどうですか')!=='金運は上向きます。') o.bad.push('どちらでもない相談に足した');
    const h=pkEnsureTraits('前の文。\n\n'+hW+'\n・長所：粘り強い人です。\n\n【次の見出し】\n次の文。',c,'転職したいです');
    const sec=h.split(hW)[1].split('【次の見出し】')[0];
    if((h.match(new RegExp(hW.replace(/[【】]/g,'\\$&'),'g'))||[]).length!==1||sec.indexOf('向いている仕事：')<0||sec.indexOf('アドバイス：')<0||sec.indexOf('気をつけたいこと：')<0||sec.indexOf(d.仕長)>=0) o.bad.push('見出しだけあるときに抜けた項目を見出しの中に足さない：'+sec.slice(0,120));
    const kid=mk(T.y-5,3,3,'female',true); const k1=pkEnsureTraits('元気な子です。',kid,''); if(k1.indexOf(hL)>=0||k1.indexOf(hW)<0) o.bad.push('13歳未満に恋愛を出した');
    const m1=pkTraitsText(c,pl,''); if(m1.indexOf(d.恋長)<0||m1.indexOf((typeof pkJobFit==='function'&&pkJobFit(c,pl)||{}).text||d.仕適)<0||m1.indexOf(hL)<0) o.bad.push('文章作成への材料がない');   // 向いている仕事は pkJobFit にそろえた（2026-11-17）
    if(pkTraitsText(c,pl,'金運はどうですか')!=='') o.bad.push('どちらでもない相談に材料を渡した');
    if(proReadUser(c).indexOf(d.仕長)<0) o.bad.push('命式全体の鑑定の頼み方に材料がない');
  }catch(err){ o.bad.push('動かない：'+String(err&&err.message||err)); } chart=c0; return o; });
  r.bad.forEach(x=>e.push(x));
  console.log('  '+(e.length?'NG':'OK')+' 恋愛・仕事の持ち味（材料が3か所同じ・60干支×7項目・出すほう・1回だけ・見出しの中に足す・やさしい画面・鑑定書）'+(e.length?'  … '+e.slice(0,6).join('・'):'')); if(e.length) res.fails.push('恋愛・仕事の持ち味: '+e.join('・')); }
// 時期のそろえ（先生の指示 2026-11-16「悩み事をきちんとした言葉で適正時期で診断判断して出力して欲しい」）：
//  A 本文が「本格的に・いちばん・チャンスの年」として出した年が、ツールの時期（1行目・まとめ）にないとき、理由のない文は年を置きかえ、理由のある文は1回だけ年を添える（pkTimingConsistFix）。過去・注意・2つの年・ツールにもある年は触らない
//  B 相性の「2人の結びつきが強くまとまる時期」の大運を「あなたの2049年（あなた68歳／お相手73歳）からの10年」と書かない（_trDuPlain）
{ const e=[]; const r=await p.evaluate(()=>{ const o={bad:[],nB:0}; const c0=chart; try{
    const mk=(y,m,d,h,mi,sex)=>baziCompute({year:y,month:m,day:d,hour:h,minute:mi,sex},'','none'), pl=document.documentElement.classList.contains('bg-on'), GZ=/[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]/;
    const A=mk(1981,6,10,22,28,'female'); chart=A;
    const cases=[['来年結婚できますか','love','結婚のご縁が本格的に動き出すのは','年頃です。','結婚のご縁がいちばん強まります'],['金運はどうですか','money','','年は収入アップのチャンスの年です。','金運がいちばん高まります'],['転職はいつがいいですか','work','','年が転職のいちばんのチャンスです。','転職のいちばんのチャンスです']];
    cases.forEach(([q,k,pre,post,rs])=>{ const T=pkTcTopic(A,q); if(!T||T.k!==k){ o.bad.push(q+'：時期の種類が出ない'); return; }
      let Y=T.list[T.list.length-1]+1; while(T.list.indexOf(Y)>=0) Y++; const t0=T.list[0];
      const head='いちばん動きやすいのは'+t0+'年です。\n\n';
      const x1=pkTimingConsistFix(head+pre+Y+'年（'+(pl?'':'辛亥・')+'50歳）'+post,A,q,pl);
      if(x1.indexOf(Y+'年')>=0||x1.split('\n\n')[1].indexOf(t0+'年')<0) o.bad.push(q+'：理由のない文の年を置きかえない：'+x1.split('\n\n')[1]);
      if(pl&&GZ.test(x1.split('\n\n')[1])) o.bad.push(q+'：やさしい画面に干支を付けた');
      const x2=pkTimingConsistFix(head+'また、'+Y+'年は配偶宮と支合するため、'+rs+'。\n'+Y+'年は星が巡るので、'+rs+'。',A,q,pl);
      if((x2.match(/（(?:命式の計算では|生まれ持った運の流れで見ると)、/g)||[]).length!==1||x2.indexOf(Y+'年は配偶宮')<0) o.bad.push(q+'：理由のある文に年を1回だけ添えない：'+x2.slice(0,160));
      if(pkTimingConsistFix(x2,A,q,pl)!==x2) o.bad.push(q+'：2回通すと変わる');
      const keep=[head+'2025年は'+rs+'でした。',head+Y+'年は'+rs+'が、出費にも注意。',head+t0+'年と'+Y+'年は'+rs+'。',head+t0+'年は'+rs+'。',head+'母の'+rs+'のは'+Y+'年です。'];
      keep.forEach(x=>{ if(pkTimingConsistFix(x,A,q,pl)!==x) o.bad.push(q+'：触らない文を変えた：'+x.split('\n\n')[1]); }); });
    if(pkTimingConsistFix('結婚のご縁が本格的に動き出すのは2099年です。',A,'もう死にたいです',pl)!=='結婚のご縁が本格的に動き出すのは2099年です。') o.bad.push('つらさの相談を変えた');
    { const T=pkTcTopic(A,'来年結婚できますか'); let Y=T.list[T.list.length-1]+1; window.__pkTcRows=[]; const f=pkFinalFix('いちばん縁が動きやすいのは'+T.list[0]+'年です。\n\n結婚のご縁が本格的に動き出すのは'+Y+'年です。','来年結婚できますか',false);
      if(f.indexOf(Y+'年')>=0) o.bad.push('pkFinalFix で時期をそろえない'); if(!(window.__pkTcRows||[]).length) o.bad.push('根拠のチェック表（✏️）に出ない'); }
    // B
    let seed=7; const rnd=()=>{ seed=(seed*1103515245+12345)%2147483648; return seed/2147483648; };
    for(let k=0;k<400&&o.nB<6;k++){ const a=mk(1950+Math.floor(rnd()*50),1+Math.floor(rnd()*12),1+Math.floor(rnd()*28),12,0,'female'), b=mk(1950+Math.floor(rnd()*50),1+Math.floor(rnd()*12),1+Math.floor(rnd()*28),12,0,'male');
      const L=compatTrioLines(a,b); if(!L.T.some(t=>t.du.some(d=>!d.now))) continue; o.nB++;
      const st=x=>pkStampYears(x,birthYearOf(a),birthYearOf(b)), sum=compatSummaryHTML?String(compatSummaryHTML(a,b)||''):'';
      L.plain.concat([sum.replace(/<[^>]+>/g,' ')]).forEach(x=>{ if(/からの10年/.test(x)) o.bad.push('「からの10年」が残る：'+x.slice(0,120));
        const y=st(x); if(/\d{4}年（[^）]*歳／[^）]*）から[、新]/.test(y)) o.bad.push('大運の年に2人分の年齢：'+y.slice(0,160)); });
      L.T.forEach(t=>t.du.filter(d=>!d.now&&d.from<=new Date().getFullYear()+25).forEach(d=>{ const by=d.who==='本人'?birthYearOf(a):birthYearOf(b); if(L.plain.join('').indexOf((d.from-by)+'歳になる'+d.from+'年から')<0) o.bad.push('大運の年齢がない：'+d.who+d.from); })); }
    if(!o.nB) o.bad.push('大運の時期がある組が見つからない');
  }catch(err){ o.bad.push('動かない：'+String(err&&err.message||err)); } chart=c0; return o; });
  r.bad.forEach(x=>e.push(x));
  console.log('  '+(e.length?'NG':'OK')+' 時期のそろえ（恋愛・金運・仕事の本文の年・理由のある文に1回だけ添える・触らない文・pkFinalFix・✏️）と相性の大運の言い方（'+r.nB+'組）'+(e.length?'  … '+[...new Set(e)].slice(0,6).join('・'):'')); if(e.length) res.fails.push('時期のそろえ: '+[...new Set(e)].join('・')); }
// オンラインの1行目と話す順番③（2026-11-16）：恋人と別れるか・子どもの受験・引っ越しの時期・続けるか独立か（方向なし）は、
//  1行目が問いに答えていない／ツールと食いちがうときだけ通信なしと同じ1行目にし（良い1行目は残す）、③は1行目と同じツールの時期・順番にする
{ const e=[]; const r=await p.evaluate(()=>{ const o={bad:[],nd:0}; const c0=chart; try{
    const mk=(y,m,d,h,mi,sex)=>baziCompute({year:y,month:m,day:d,hour:h,minute:mi,sex},'','none'), pl=document.documentElement.classList.contains('bg-on'), JG=/命式|大運|通変|空亡|解空|喜神|忌神|[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]/;
    const L1=(c,q,l)=>pkLeadFix(l+'\n【お客様へのお伝え方】\n説明です。',c,q,false).split('\n')[0];
    const T3=(c,q)=>{ const h=pkTalkHTML('答えです。\n【お客様へのお伝え方】\n説明。',q,c,pl); const m=h.match(/③<\/span><div><div class="pkt-t">[^<]*<\/div><div class="pkt-b">(.*?)<\/div><\/div><\/li>/); return m?m[1].replace(/<[^>]+>/g,'').replace(/^「|」$/g,''):''; };
    let seed=11; const rnd=()=>{ seed=(seed*1103515245+12345)%2147483648; return seed/2147483648; };
    const P=[mk(1981,6,10,22,28,'female'),mk(1990,3,16,12,0,'male')]; for(let k=0;k<10;k++) P.push(mk(1960+Math.floor(rnd()*40),1+Math.floor(rnd()*12),1+Math.floor(rnd()*28),12,0,rnd()<0.5?'female':'male'));
    const nenY=pkNenInfo().Y;
    P.forEach(c=>{ chart=c;
      const qB='彼と別れるべきか悩んでいます', BK=pkBreakLead(c,qB,pl);
      if(!BK) o.bad.push('別れの1行目が出ない'); else {
        if(L1(c,qB,'別れたほうがいいでしょう。今の関係は負担が大きいです。')!==BK) o.bad.push('別れを決めた1行目を置きかえない');
        if(L1(c,qB,'あなたは本来とても魅力的な人です。')!==BK) o.bad.push('別れに答えていない1行目を置きかえない');
        const g='今は別れを急がず、気持ちを整理してから話し合うのがよい時期です。'; if(L1(c,qB,g)!==g) o.bad.push('良い別れの1行目を変えた');
        const t=T3(c,qB); if(!/順で考え/.test(t)||/別れ(?:た)?ほうが/.test(t)) o.bad.push('別れの③が順番になっていない：'+t);
        const cy=(loveFourLines(c).cautionYears||[]).filter(y=>y>=nenY); cy.forEach(y=>{ if(t.indexOf(y+'年')<0) o.bad.push('別れの③に揺れやすい年がない'); }); }
      const qK='子どもの受験が心配です', KE=pkKidExamLead(c,qK,pl);
      if(!KE) o.bad.push('受験の1行目が出ない'); else {
        if(L1(c,qK,'お子さんは合格できます。安心してください。').indexOf(KE.split('。')[0])!==0||/合格できます/.test(L1(c,qK,'お子さんは合格できます。安心してください。')))   /* 「お子さんの生年月日がわかれば…」の文は、今までの決まりで1行目のうしろへ移る */ o.bad.push('合格を言い切った1行目を置きかえない');
        const g='受験の結果を言い切ることはしませんが、今年のあなたはお子さんを支えやすい流れです。'; if(L1(c,qK,g)!==g) o.bad.push('良い受験の1行目を変えた');
        if(!/お子さんの生年月日/.test(T3(c,qK))) o.bad.push('受験の③'); }
      const qM='引っ越しはいつがいいですか', MY=pkMoveYears(c).filter(y=>!pkKuuBad(c,y)), MV=pkMoveLead(c,qM,pl);
      if(!MV) o.bad.push('引っ越しの1行目が出ない'); else {
        const t=T3(c,qM); if(t!==MV) o.bad.push('引っ越しの③が1行目とちがう：'+t);
        if(MY.length){ let Y=nenY; while(MY.indexOf(Y)>=0) Y++;
          if(L1(c,qM,'引っ越しは'+Y+'年がおすすめです。').indexOf(MV)!==0) o.bad.push('ツールにない年の引っ越しを置きかえない');
          const g='引っ越しは'+MY[0]+'年がおすすめです。'; if(L1(c,qM,g)!==g) o.bad.push('良い引っ越しの1行目を変えた');
          if(L1(c,qM,'運の流れは安定しています。').indexOf(MV)!==0) o.bad.push('年のない引っ越しの1行目に足さない'); } }
      const qW='今の仕事を続けるか独立するか';
      if(pkWorkNoDirQ(c,qW)){ o.nd++; const L0=pkOfflineLead(c,qW,pl); if(L1(c,qW,'あなたはまじめな努力家です。')!==L0) o.bad.push('続けるか独立かに答えていない1行目を置きかえない');
        const ym=(L0.match(/(?:19|20)\d\d(?=年)/)||[])[0]; if(ym&&T3(c,qW).indexOf(ym+'年')<0) o.bad.push('続けるか独立かの③の年が1行目とちがう'); }
      if(pl) [BK,KE,MV,T3(c,qB),T3(c,qK),T3(c,qM)].forEach(x=>{ if(x&&JG.test(x)) o.bad.push('やさしい画面に専門用語：'+x.slice(0,60)); }); });
    if(!o.nd) o.bad.push('方向が決まらない人が見つからない');
  }catch(err){ o.bad.push('動かない：'+String(err&&err.message||err)); } chart=c0; return o; });
  r.bad.forEach(x=>e.push(x));
  console.log('  '+(e.length?'NG':'OK')+' オンラインの1行目と③（別れ・子どもの受験・引っ越し・続けるか独立か〈方向なし '+r.nd+'人〉・良い1行目は残す・やさしい言い方）'+(e.length?'  … '+[...new Set(e)].slice(0,6).join('・'):'')); if(e.length) res.fails.push('オンラインの1行目と③: '+[...new Set(e)].join('・')); }
// 実機点検 2026-11-16（先生の指示「悩み事をきちんとした言葉で適正時期で診断判断して出力して欲しい」）：
//  時期のそろえ（お伝え方・箇条書き・「一番おすすめ」「めぐってくる」「〜を目標に」・期間・金運の期間）／年の残りが少ない今年／続けるか独立か（方向なし）はPRO・ビギナー同じ1行目／
//  来年の結婚を根拠なく「準備の年」にしない・空亡でない年の「大きな始まりは控え」を外す／別れの相談の何年も先までの先送り／頭の切れた1行目・「待たほうが」／
//  安全の相談の1行目・症状の言い当て・食べ物のすすめ／同じ一文のくり返し／文のくずれ（別の文字・印の重なり・読みと意味の重なり・今月のずれ・今年の五行）／一字の干支の読み／
//  お伝え方の言いかえのくずれ／持ち味の写しまちがいと見出しの重なり／月の星の取りちがえ／健康以外の食べ物のすすめ／ひと休みの年の説明の場所
{ const e=[]; const r=await p.evaluate(()=>{ const o={bad:[]}; const c0=chart; try{
    const mk=(y,m,d,h,mi,sex)=>baziCompute({year:y,month:m,day:d,hour:h,minute:mi,sex},'','none'), pl=document.documentElement.classList.contains('bg-on');
    const A=mk(1981,6,10,22,28,'female'), B=mk(1990,3,16,12,0,'male');
    const L1=(c,q,l)=>pkLeadFix(l+'\n【お客様へのお伝え方】\n説明です。',c,q,false).split('\n')[0];
    // 1 時期のそろえ（仕事）
    chart=B; { const q='転職はいつがいいですか', T=pkTcTopic(B,q); if(!T){ o.bad.push('仕事の時期が出ない'); } else { const tg=T.list[0], far=Math.max(tg,T.nenY)+9;
      const x=pkTimingConsistFix('本格的に動きやすいのは'+tg+'年です。\n【お客様へのお伝え方】\n本格的に環境を変えて新しい一歩を踏み出すのは、'+far+'年ごろが一番おすすめのタイミングです。\n【どうすればよいか】\n・'+T.nenY+'年から'+(far-1)+'年までの間は、資格の勉強に励み、実力を高める。\n・大運が切り替わる'+far+'年の時期を目標に据えて、新しい環境への扉を叩く。',B,q,pl);
      if(x.indexOf(far+'年')>=0) o.bad.push('ずっと先の年（目標・一番おすすめ）が残る：'+x.slice(0,300));
      if((x.match(new RegExp(tg+'年','g'))||[]).length<3) o.bad.push('ツールの年に置きかえない：'+x.slice(0,300));
      if(T.nenY<tg&&x.indexOf((far-1)+'年まで')>=0) o.bad.push('ずっと先まで準備を続ける期間が残る');
      if(pkTimingConsistFix(x,B,q,pl)!==x) o.bad.push('2回通すと変わる（仕事）'); }
      const S=pkWorkStart(B), N=pkNenInfo(); if(S.y===N.Y&&!/立春まで/.test(S.until||'')) o.bad.push('今年を動く年にしたのに立春までの期限がない');   /* 立春で区切る（2026-11-17 鑑定者本人「立春でいいのでは？」） */
      if(N.leftDays<90&&S.late&&pkOfflineLead(B,q,pl).indexOf('今年の残り')<0) o.bad.push('今年の残りは準備、と書かない');
      const L0=pkOfflineLead(B,q,pl), t3=pkTalkSpec(B,q,pl); if(t3!==L0) o.bad.push('仕事の時期の③が1行目とちがう：'+t3); }
    // 2 続けるか独立か（方向なし）：文章作成が独立と決めても、PRO・ビギナーで同じツールの1行目
    { let n=0; [A,B].concat([mk(1975,4,4,12,0,'male'),mk(1988,9,9,12,0,'female'),mk(1965,1,20,12,0,'male')]).forEach(c=>{ chart=c; const qW='今の会社を続けるか独立するか迷っています'; if(!pkWorkNoDirQ(c,qW)) return; n++;
      const L0=pkOfflineLead(c,qW,pl); if(L1(c,qW,'いまの会社を続けるよりも、独立に向けて準備を進めるのがおすすめです。')!==L0) o.bad.push('方向なしなのに独立と決めた1行目を残した'); });
      if(!n) o.bad.push('方向なしの人がいない'); }
    // 3 来年の結婚：根拠なく「準備の年」・空亡でない年の「大きな始まりは控え」
    chart=A; { const q='来年結婚できますか？', NY=pkNextYearLoveLead(A,q,pl);
      if(NY&&!NY.bad&&!NY.caut){ if(L1(A,q,'来年の結婚は、お互いの絆をじっくり深める準備の年にするのが自然です。').indexOf(NY.line.split('。')[0])!==0) o.bad.push('根拠のない「準備の年」の1行目を置きかえない');
        const y=pkFalseKuuFix('答え。\n【どうすればよいか】\n・'+NY.Y+'年の1年間は、婚姻届を出すような大きな始まりの決断は少し控え、将来の暮らしをじっくり話し合う時間に充てる。',A,q);
        if(/控え/.test(y)||y.indexOf('将来の暮らし')<0) o.bad.push('空亡でない年の「大きな始まりは控え」を外さない：'+y); }
      const ky=(A.annualFortunes||[]).map(a=>a.year).filter(y=>y>=pkNenInfo().Y&&pkKuuBad(A,y))[0]; if(ky){ const z='答え。\n'+ky+'年は大きな始まりの決断は控え、準備をしましょう。'; if(pkFalseKuuFix(z,A,q)!==z) o.bad.push('空亡の年の「控え」を外した'); } }
    // 4 別れ：何年も先までの先送り
    { const q='彼と別れるべきか迷っています', F=pkTalkSpec(A,q,pl), ny=pkNenInfo().Y;
      const x=pkBreakFarFix('答え。\n【お客様へのお伝え方】\n'+(ny+7)+'年頃には関係に大きな変化が訪れやすいので、それまでは焦らず関係を整えましょう。その時期に向かって気持ちが整います。\n【どうすればよいか】\n・相談する。\n・'+(ny+7)+'年頃の大きな転機に向けて、暮らしを考える。',A,q,pl);
      if(x.indexOf((ny+7)+'年')>=0||x.indexOf(F)<0||(x.split(F).length-1)!==1||/その時期に向か/.test(x)) o.bad.push('別れの先送りを考える順番にしない：'+x); }
    // 5 頭の切れた1行目・「待たほうが」
    { const q='彼と別れるべきか迷っています', x=pkLeadFragFix('は、ご自身の負担が大きいなら距離を置くことも大切です。\n【お客様へのお伝え方】\n説明。',q,pl);
      if(x.indexOf(pkOfflineLead(A,q,pl))!==0) o.bad.push('頭の切れた1行目を置きかえない：'+x.slice(0,60));
      if(pkLeadFragFix('もし迷うなら話し合いましょう。',q,pl)!=='もし迷うなら話し合いましょう。') o.bad.push('ふつうの1行目を変えた');
      if(pkFmTidy('今すぐ決めるのは少し待たほうが安心です。').indexOf('待ったほうが')<0) o.bad.push('待たほうが'); }
    // 6 安全の相談（体調）
    { const q='最近ずっと体調が悪いです', x=pkSafeAnsFix('お辛いお気持ちでいらっしゃるのですね。\n【お客様へのお伝え方】\n火が強まると、動悸やのぼせ、不眠といったサインが出やすくなります。ゆっくり休みましょう。\n【どうすればよいか】\n・あたたかい飲み物を飲んでリラックスする\n・休む時間をつくる',q);
      if(x.split('\n')[0].indexOf('医療機関')<0) o.bad.push('共感だけの1行目に答えを足さない'); if(/動悸|飲み物/.test(x)||x.indexOf('休む時間')<0||x.indexOf('ゆっくり休みましょう')<0) o.bad.push('体の相談の症状・飲み物の文：'+x);
      if(pkDupLineFix('いつでも応援しています。\n本文。\nいつでも応援しています。').split('いつでも応援').length!==2) o.bad.push('同じ一文のくり返し'); }
    // 7 文のくずれ（PK-FACT-MARKS）
    { const env={P:[{pil:A.pillars.map(x=>x.ganzhi)}],nenY:pkNenInfo().Y}, T=_jstToday(), M=T.getMonth()+1, M1=M%12+1;
      const chk=[['【どう ভয়াবহよいか】','【どうすればよいか】'],['日柱にある日柱（己未）は','日柱（己未）は'],['現在巡っている大運は 今の大運（戊戌）であり','現在巡っている大運は戊戌であり'],['大運癸未（今の大運（癸未）・傷官が巡る時期）','大運癸未（傷官が巡る時期）'],
        ['傷官（＝感性・才能の星）＝しょうかん・感性と才能の星が巡る','傷官（しょうかん＝感性・才能の星）が巡る'],['いまの今の流れ','今の流れ'],['今年のその年の運では','今年の運では'],['日柱（己未）の日柱（にっちゅう＝冠帯）を持つ','日柱（己未）（冠帯）を持つ'],['한국어テスト','テスト']];
      if(T.getDate()>7) chk.push(['今月（'+M1+'月）から','来月（'+M1+'月）から']);
      chk.forEach(([a,b])=>{ const y=pkFmTidy(a); if(y!==b) o.bad.push('くずれ：'+a+'→'+y); });
      if(pkFmTidy('今月（'+M+'月）は')!=='今月（'+M+'月）は') o.bad.push('正しい今月を変えた');
      const yg=pkfmYGz(pkNenInfo().Y), SE={甲:'木',乙:'木',丙:'火',丁:'火',戊:'土',己:'土',庚:'金',辛:'金',壬:'水',癸:'水'}, e1=SE[yg[0]], wr='木火土金水'.split('').filter(x=>x!==e1)[0];
      const z=pkYrElFix('今年は'+wr+'のエネルギーが強まっています。',{P:[{pil:[]}]}); if(z.indexOf(e1+'のエネルギー')<0&&z.indexOf(wr)>=0&&!/[申子辰亥卯未寅午戌巳酉丑]/.test('')) { const br=yg[1], BE={寅:'木',卯:'木',巳:'火',午:'火',辰:'土',戌:'土',丑:'土',未:'土',申:'金',酉:'金',亥:'水',子:'水'}; if(BE[br]!==wr) o.bad.push('今年の五行のまちがいを直さない：'+z); }
      if(pkYrElFix('今年は'+e1+'のエネルギーが強まっています。',{P:[{pil:[]}]}).indexOf(e1)<0) o.bad.push('今年の正しい五行を変えた'); }
    // 8 一字の干支の読み
    { const y=pkFixYomi('長所：日干庚（かのえたつ＝金性）の星が日支辰（かのえたつ）に座す。様子（ようす）を見る。'); if(y.indexOf('日干庚（かのえ＝金性）')<0||y.indexOf('日支辰（たつ）')<0||y.indexOf('様子（ようす）')<0) o.bad.push('一字の干支の読み：'+y); }
    // 9 お伝え方の言いかえ
    { ['己未の日にお生まれのあなたは、力を持っています。','いまの今の大運（戊戌）（劫財・土）の時期は、結果が出やすい。','お金の星である財星が少ない配置です。'].forEach(x=>{ const y=pkPlainTalk(x); if(/^の日に|いまの今の|今の今の|お金の星であるお金|今の（/.test(y)) o.bad.push('言いかえのくずれ：'+y); }); }
    // 10 持ち味の写しまちがい・見出しの重なり
    { chart=B; const d=pkTraitData(B), hW=pl?'【お仕事での持ち味】':'【仕事の持ち味】', bad=d.仕助.replace('を','').replace('つ','');
      const x=pkEnsureTraits('答え。\n'+hW+'\n・長所：'+d.仕長+'\n・アドバイス：'+bad+'\n【くわしい読み解き】\n'+hW+'\n・長所：魁罡なので芯が強い。\n月支元命は正財です。',B,'転職はいつがいいですか');
      if(x.indexOf(d.仕助)<0) o.bad.push('写しまちがいを材料に戻さない'); if(x.split(hW).length!==2||x.indexOf('月支元命は正財です。')<0||/魁罡なので/.test(x)) o.bad.push('見出しの重なり：'+x); }
    // 11 月の星の取りちがえ
    { chart=A; const ml=monthFortuneList(A,12).filter(Boolean), ev=ml[1], X=['比肩','劫財','食神','傷官','偏財','正財','偏官','正官','偏印','印綬'].filter(x=>x!==ev.star&&x!==ev.bStar)[0];
      const y=pkMonthFactFix(ev.calMonth+'月から'+(ev.calMonth%12+1)+'月上旬にかけては、月柱に巡る'+X+'（よみ）の影響があります。',A); if(y.indexOf('月柱に巡る'+ev.star)<0) o.bad.push('月の星を直さない：'+y); }
    // 12 健康以外の食べ物のすすめ・金運の期間
    { const y=pkOffTopicDiet('甘いものや脂っこいものを控え、基盤を固めると好機をつかめます。','金運を上げたい'); if(/甘いもの/.test(y)||y.indexOf('基盤を固め')<0) o.bad.push('健康以外の食べ物のすすめ：'+y);
      if(pkOffTopicDiet('甘いものを控えましょう。','体調を整えたい')!=='甘いものを控えましょう。') o.bad.push('健康の相談の食べ物を外した');
      chart=A; const q='金運を上げたい。いつ頃お金が回りますか', T=pkTcTopic(A,q); if(T&&T.list.length>=2){ const Ls=T.list.slice().sort(), x=pkTimingConsistFix('答え。\n【どうすればよいか】\n・財星が巡る'+(Ls[0]+1)+'年から'+(Ls[Ls.length-1]+1)+'年の時期に合わせて、蓄えを意識する',A,q,pl); if(x.indexOf(Ls[0]+'年')<0||x.indexOf(Ls[Ls.length-1]+'年')<0) o.bad.push('金運の期間をツールの年にしない：'+x); } }
    // 13 ひと休みの年の説明の場所
    { const y=pkKuuNoteMove('動き出すのは2027年以降が安心です。（「ひと休みの年」は、力が抜けやすい年のことです）\n・2028年〔ひと休みの年〕以降に動く'); if(/安心です。（「ひと休み/.test(y)||y.indexOf('以降に動く（「ひと休みの年」は')<0) o.bad.push('ひと休みの年の説明の場所：'+y); }
    // 14 年運の干支のまちがい（今日が立春前）・25年より先の大運
    { const y=pkFmTidy2('今年（2026年の年運・2027年2月4日の立春まで）は丁未の年運にあたり、'); if(y.indexOf('丙午の年運')<0) o.bad.push('年運の干支を年に合わせない：'+y); }
  }catch(err){ o.bad.push('動かない：'+String(err&&err.message||err)); } chart=c0; return o; });
  r.bad.forEach(x=>e.push(x));
  console.log('  '+(e.length?'NG':'OK')+' 実機点検 2026-11-16（時期のそろえ・年の残り・続けるか独立か・来年の結婚・別れの先送り・頭の切れた1行目・安全の相談・文のくずれ・読み・言いかえ・持ち味・月の星・食べ物・ひと休み）'+(e.length?'  … '+[...new Set(e)].slice(0,8).join('・'):'')); if(e.length) res.fails.push('実機点検 2026-11-16: '+[...new Set(e)].join('・')); }
const ok=res.fails.length===0&&res.rit>=1&&res.ritMD>=1&&calls===0;
console.log(`■ 相性の流派の決まり / ${site}：${res.checked}組を確認（律音 日柱どうし ${res.rit}組・月柱×日柱 ${res.ritMD}組・半会 ${res.han}か所）`);
res.fails.slice(0,10).forEach(f=>console.log('  NG '+f));
console.log(`  → ${ok?'合格':'不合格'}（ちがい ${res.fails.length}件・文章作成の呼び出し ${calls}回）`);
await b.close(); srv.close(); process.exit(ok?0:1);
