// 発売前の最低限の点検（PRO/ビギナー）：計算・答えが返る・空っぽにならない・むだな呼び出しがない・オフライン
const { chromium } = await import('/opt/node22/lib/node_modules/playwright/index.mjs');
import http from 'http'; import fs from 'fs'; import path from 'path'; import { createRequire } from 'module';
const require_=createRequire(import.meta.url);
for (const k of ['URL','DEPLOY_PRIME_URL','MEMBER_CHECK_URL','ALLOWED_ORIGINS']) delete process.env[k];
const _log=console.log; console.log=(...a)=>{const t=a.join(' '); if(/AIza|key=/.test(t))return; if(/≈¥/.test(t)){_log('   [server] '+t.slice(0,90));return;} _log(...a);};
const ROOT=path.resolve(path.dirname(new URL(import.meta.url).pathname),'../..'), site=process.argv[2]||'pro', MODE=process.argv[3]||'online';
const dir=site==='pro'?'pro':'beginner', page0=site==='pro'?'app-pro.html':'app-beginner.html';
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};
const srv=http.createServer((q,r)=>{let p=decodeURIComponent(q.url.split('?')[0]);if(p.endsWith('/'))p+='index.html';const f=path.join(ROOT,dir,p);if(!fs.existsSync(f)||fs.statSync(f).isDirectory()){r.writeHead(404);r.end();return;}r.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});fs.createReadStream(f).pipe(r);}).listen(0);
await new Promise(r=>srv.on('listening',r)); const port=srv.address().port;
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({serviceWorkers:'block',viewport:{width:390,height:844},isMobile:true,hasTouch:true});
let calls=0; const R=[]; const ok=(name,pass,info='')=>{R.push({name,pass,info:String(info).slice(0,200)}); console.log((pass?'  OK ':'  NG ')+name+(info?'  … '+String(info).slice(0,160):''));};
await ctx.route('**/.netlify/functions/**',r=>r.fulfill({status:200,contentType:'application/json',body:'{"ok":true}'}));
const CL=[]; const T00=Date.now(); await ctx.route('**/.netlify/functions/gemini',async route=>{ calls++; const _rq=route.request(); const _b=_rq.postData()||''; const rec={n:calls,from:(_rq.frame()&&_rq.frame().url()||'').split('/').pop().slice(0,30),t:Date.now()-T00,part:(_b.match(/今回書くのは(冒頭の答えだけ|、くわしい読み解きだけ)/)||[])[1]||'?',len:_b.length}; CL.push(rec); if(/meishi/.test(rec.from)) _log('   [点検] sheet request at',rec.t);
  if(MODE!=='online'){ await route.abort('internetdisconnected'); return; }
  const req=route.request(); const h=require_(path.join(ROOT,dir,'functions','gemini.js')).handler; let r; const _tt=setTimeout(()=>_log('   ... handler still pending 30s for call',rec.n,rec.from),30000); try{ r=await h({httpMethod:'POST',headers:req.headers(),body:req.postData()||''}); }catch(e){ rec.err=String(e&&e.message||e).slice(0,200); await route.fulfill({status:500,body:'{}'}).catch(()=>{}); return; } clearTimeout(_tt); rec.status=r.statusCode; if(/meishi/.test(rec.from)) _log('   [点検] sheet handler done at',Date.now()-T00); rec.end=Date.now()-T00; try{ await route.fulfill({status:r.statusCode,headers:Object.assign({'Content-Type':'application/json'},r.headers||{}),body:r.body||''}); }catch(e){ rec.fulfillErr=e.message.slice(0,80); } return;
  await route.fulfill({status:r.statusCode,headers:Object.assign({'Content-Type':'application/json'},r.headers||{}),body:r.body||''}); });
if(MODE==='nonet') await ctx.addInitScript(()=>{ try{ Object.defineProperty(Navigator.prototype,'onLine',{get:()=>false,configurable:true}); }catch(e){} });
await ctx.addInitScript(()=>{ navigator.share=async d=>{window.__shared=d;}; navigator.canShare=()=>true; try{Object.defineProperty(navigator,'clipboard',{value:{writeText:async t=>{window.__clip=t;},readText:async()=>''},configurable:true});}catch(e){} window.print=()=>{}; });
const errs=[]; ctx.on('page',pg=>{pg.on('pageerror',e=>errs.push(e.message)); pg.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text().slice(0,200));}); pg.on('requestfailed',r=>errs.push('reqfail: '+r.url().slice(0,120)));});
const p=await ctx.newPage(); p.on('dialog',d=>d.accept());
await p.goto(`http://127.0.0.1:${port}/${page0}`); await p.waitForTimeout(2500);

const waitFor=async(fn,ms)=>{const t=Date.now();while(Date.now()-t<ms){ if(await p.evaluate(fn).catch(()=>false)) return Date.now()-t; await p.waitForTimeout(200);} return -1;};
const cleanStar=t=>(String(t).match(/[\*＊]/g)||[]).length;
console.log(`■ ${site} / ${MODE}`);
ok('開いただけでは文章作成を呼ばない', calls===0, 'calls='+calls);
// 計算（基準の例）
await p.fill('#f-name','基準'); await p.click('#f-quick'); await p.keyboard.type('19810610 2228'); await p.click('#f-sex button[data-v=female]');
await p.click('#f-go'); await p.waitForTimeout(6000);
{ const h=await p.evaluate(()=>document.body.innerHTML.replace(/<[^>]+>/g,' ').replace(/\s+/g,'')); const keys=['甲午','8年6ヶ月','0歳〜8歳6ヶ月','8歳6ヶ月〜18歳6ヶ月','乙未','丙申','丁酉'];
  const miss=keys.filter(k=>!h.includes(k)); ok('計算：基準の例（甲午・順行・立運8年6ヶ月・甲午→乙未→丙申→丁酉）', miss.length===0, miss.length?'見つからない:'+miss.join(','):''); }
// 次のお客様 → 相談
const c0=calls;
await p.evaluate(()=>{const b=document.getElementById('jn-next'); if(b) b.click();}); await p.waitForTimeout(1000);
{ const left=await p.evaluate(()=>[document.getElementById('f-name').value,document.getElementById('f-date').value,(document.getElementById('cs-q')||{}).value||''].join('|')); ok('次のお客様へ：前の人の入力が残らない', left.replace(/\|/g,'')==='' , left); }
await p.fill('#f-name','山田花子'); await p.click('#f-quick'); await p.keyboard.type('19850412 1030'); await p.click('#f-sex button[data-v=female]');
const Q1='転職するなら今年と来年のどちらがいいですか';
await p.fill('#cs-q',Q1);
const t1=Date.now(); await p.click('#f-go'); await p.click('#f-go').catch(()=>{}); await p.click('#f-go').catch(()=>{});   // 三度押し
const ms=await waitFor(()=>{const it=document.querySelector('#reading .rd-item:last-child');return it&&it.querySelector('.rd-bar')&&!it.querySelector('.loading');},60000);
await p.waitForTimeout(1500);
const items=await p.evaluate(()=>document.querySelectorAll('#reading .rd-item').length);
const A=await p.evaluate(()=>{const it=document.querySelector('#reading .rd-item:last-child');if(!it) return ''; const op=[...it.querySelectorAll('details.r-fold:not([open])')]; op.forEach(d=>d.open=true); const t=it.querySelector('.rd-body').innerText; op.forEach(d=>d.open=false); return t;});   /* たたんだ「くわしい読み解き」の中も読む（タップで開く欄）*/
{ const need=await p.evaluate(()=>{ try{ const g=kakukyoku(chart); const plain=document.documentElement.classList.contains('bg-on'); if(plain&&typeof window.pkBTypeOf==='function'){ const t=window.pkBTypeOf(g,chart); return t?[t[0].replace(/\s/g,'')]:[]; } const m=String(g.name).match(/（([^）]+)）/); return [g.name].concat(m?[m[1]]:[]).map(x=>x.replace(/（.*$/,'')); }catch(e){ return ['(計算エラー)']; } });
  ok('相談1：鑑定文に格局（ビギナーは生まれ持った型）が入っている（安全装置）', need.length>0&&need.some(n=>A.replace(/\s/g,'').includes(n)), need.join('/')); }
ok('相談1：答えが出る（60秒以内）'+(MODE!=='online'?'（端末の中の答え・30秒以内）':''), ms>=0&&(MODE==='online'||ms<30000) && A.length>200, `${(Date.now()-t1)/1000}秒・${A.length}字`);
ok('相談1：三度押しでも答えは1つ', items===1, 'items='+items);
const cQ1=calls-c0; ok('相談1：文章作成の呼び出し回数'+(site==='beginner'?'（ビギナーは専門用語の書き直しで最大4回）':''), MODE!=='online'? true : (site==='beginner'?(cQ1>=2&&cQ1<=4):cQ1===2), 'calls='+cQ1);
const first=(A.split('\n').map(s=>s.trim()).filter(s=>s.length>8&&!/^(コピー|言葉の意味)/.test(s))[0]||'');
ok('相談1：答えの最初に結論がある', first.length>=10, first.slice(0,80));
if(MODE==='online'){ ok('相談1：年を比べる質問に、年で答えている', /今年|来年|2026|2027|年内/.test(first), first.slice(0,80));
  ok('相談1：くわしい読み解きの見出しだけが残っていない', !/くわしい読み解き\s*$/.test(A.trim()), ''); }
// 今年＝年運の年（立春で切りかわる。1/1〜立春は前の年。先生の決定 2026-11-03）。ツールの計算（chart.now.year＝日本時間のいまの年柱）から取り、暦の1/1では数えない
const NYR=await p.evaluate(()=>{ try{ return chart.now.year; }catch(e){ return null; } }), PRE=await p.evaluate(()=>{ try{ return pkNenInfo().pre; }catch(e){ return false; } });
const calCheck=(t,by)=>{ const G='甲乙丙丁戊己庚辛壬癸', Z='子丑寅卯辰巳午未申酉戌亥', gz=y=>{const i=((y-4)%60+60)%60; return G[i%10]+Z[i%12];}, NY=NYR||new Date().getFullYear(), bad=[];
  for(const m of t.matchAll(/((?:19|20)\d\d)年[（(]?(?:[^）)\n]{0,8}[・：:、])?(\d{1,3})歳/g)){ const e=+m[1]-by; if(+m[2]!==e) bad.push(m[0]+'（正しくは'+e+'歳）'); }
  for(const m of t.matchAll(/((?:19|20)\d\d)年[（(のは：:]([甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥])(?![^\n]{0,3}(?:大運|月|日|時))/g)){ if(m[2]!==gz(+m[1])) bad.push(m[0]+'（正しくは'+gz(+m[1])+'）'); }
  const REL={今年:0,来年:1,再来年:2,昨年:-1,去年:-1}; for(const m of t.matchAll(/(再来年|今年|来年|昨年|去年)[（(の]((?:19|20)\d\d)/g)){ if(+m[2]!==NY+REL[m[1]]) bad.push(m[0]); }
  for(const m of t.matchAll(/(^|[^0-9])([0-9]{2})年[（(]\d{1,3}歳/g)) bad.push(m[0].trim()+'（西暦が2けた）');
  return bad; };
const unStamped=t=>{ const ys={}, ok2={}; for(const m of t.matchAll(/((?:19|20)\d\d)年(?!\d{1,2}月|[0-9]|生|度|代)/g)){ const y=m[1], a=t.slice(m.index+m[0].length,m.index+m[0].length+6), b=t.slice(Math.max(0,m.index-6),m.index); if(/[0-9]$/.test(b)) continue; /* 「〜2027年（丁未・42歳）」の〜のあとの年も数える */ ys[y]=1; if(/^[（(〔]|^の?[甲乙丙丁戊己庚辛壬癸][子丑寅卯辰巳午未申酉戌亥]|^(?:に|には|で|、)?\d{1,3}歳/.test(a)||/\d{1,3}歳(?:になる|を迎える)?[（(]?$/.test(b)||/[（(「『]$/.test(b)) ok2[y]=1; } return Object.keys(ys).filter(y=>!ok2[y]); };
{ const cb=calCheck(A,1985); ok('暦：年齢・年の干支・今年/来年が正しい（相談1）', cb.length===0, cb.slice(0,3).join(' / ')); }
if(PRE) ok('暦：立春前は「今年」に期限（○年2月○日の立春まで）がある（相談1）', !/今年/.test(A)||/立春まで/.test(A), '');
if(MODE==='online'){ const u=unStamped(A); ok('相談1：西暦にツールの干支・年齢が付いている', u.length===0, u.map(y=>{const i=A.indexOf(y+'年');return A.slice(Math.max(0,i-15),i+12).replace(/\n/g,'⏎');}).join(' / ')); }
if(MODE==='online'){ const kinds=await p.evaluate(()=>{ try{ return natalBondLines(chart,false).map(x=>x.kind); }catch(e){ return []; } }); const plainMode=await p.evaluate(()=>document.documentElement.classList.contains('bg-on')); const miss=plainMode?(kinds.length&&!/強く結びつ/.test(A)?['結びつき']:[]):kinds.filter(k=>!A.includes(k)); ok('相談1：命式内の天地徳合・干合を必ず伝える（'+(kinds.join('・')||'なし')+'）', miss.length===0, miss.join('・')); }
ok('相談1：見出しが途中で改行していない', !/【[^】\n]{0,40}\n[^】]{0,40}】/.test(A), (A.match(/【[^】\n]{0,40}\n[^】]{0,40}】/)||[''])[0].replace(/\n/g,'⏎'));
ok('相談1：画面に＊が出ない', cleanStar(A)===0, cleanStar(A));
// 画面の使いやすさ（2026-11-17 UX点検）：目次の帯がはみ出さない・鑑定まとめは1回・五行の見本は入力欄の外・PDFの窓に viewport・ぶつかりの特徴は⚠
{ const U=await p.evaluate(()=>{ const jn=document.getElementById('jumpnav'), vis=e=>e&&e.offsetParent!==null&&getComputedStyle(e).display!=='none';
    const bt=[...jn.querySelectorAll('button')].filter(vis), cut=bt.filter(b=>b.getBoundingClientRect().right>innerWidth+1).map(b=>b.textContent.trim());
    const qm=bt.some(b=>b.classList.contains('pk-qm-tg'));
    const dg=[...document.querySelectorAll('#pk-digest,.pk-digest-a')].filter(e=>vis(e)&&e.innerText.trim()).length;
    const lg=document.getElementById('legend5');
    return {sw:jn.scrollWidth,cw:jn.clientWidth,cut,qm,dg,lgIn:!!(lg&&lg.closest('section.card.panel')),pv:/name="viewport"/.test(String(printHTML)),neg:/neg:true/.test(String(compatBigFeatures))&&/x\.neg\?/.test(String(compatSummaryHTML))}; });
  ok('UX：目次の帯が横にはみ出さず、⚡すぐ答えが切れない（390px）', U.sw<=U.cw+1&&!U.cut.length&&U.qm, JSON.stringify(U.cut)+' sw='+U.sw+'/'+U.cw);
  ok('UX：鑑定まとめは画面に1回だけ', U.dg<=1, 'dg='+U.dg);
  ok('UX：五行の色の見本は入力欄の中に出さない', !U.lgIn);
  ok('UX：鑑定文のPDFの窓に viewport がある', U.pv);
  ok('UX：天戦地冲（ぶつかり）の大きな特徴は🌟ではなく⚠', U.neg); }
// UX点検②（2026-11-18）：目次の帯は1段・相性の答えはいちばん上で帯つき・入口は相性診断タブ・職業の一覧は1つ・言葉の意味は答えの下・？は丸いまま・カルテの削除は書き分け・月の区切りは日付
{ const U2=await p.evaluate(()=>{ const jn=document.getElementById('jumpnav'), vis=e=>e&&e.offsetParent!==null&&getComputedStyle(e).display!=='none';
    const bt=[...jn.querySelectorAll('button')].filter(vis), tops=[...new Set(bt.map(b=>Math.round(b.getBoundingClientRect().top)))];
    const cp=document.getElementById('compat'), cv=document.getElementById('compat-verdict'), nav=document.getElementById('cpnav');
    const order=!!(cp&&cv&&nav&&(nav.compareDocumentPosition(cp)&4)&&(cp.compareDocumentPosition(cv)&4));
    const cc=document.getElementById('compat-card'); const ccHidden=!document.body.classList.contains('mode-compat')?!(cc&&cc.offsetParent):true;
    const fb=String(featBookHTML(chart)); const jobs=(fb.match(/向く仕事＝/g)||[]).length;
    const rc=document.querySelector('#cs-ans .reading-card'), lg=rc&&rc.querySelector('details.r-legend'); const lgLast=!lg||rc.lastElementChild===lg;
    const q=[...document.querySelectorAll('.gl-q')].filter(e=>e.offsetParent).filter(e=>Math.abs(e.offsetWidth-e.offsetHeight)>1).length;
    const kl=/お客様を削除/.test(String(renderClients||''))||/お客様を削除/.test(document.documentElement.innerHTML);
    const ml=pkMonDayLab('2026年12月〜翌1月上旬');
    return {rows:tops.length, n:bt.length, order, ccHidden, jobs, lgLast, q, kl, ml}; });
  ok('UX②：スマホの目次の帯は1段（390px）', U2.rows<=1, 'rows='+U2.rows+' n='+U2.n);
  ok('UX②：相性の答えは「まとめ」より上・目次の帯つき', U2.order);
  ok('UX②：個人鑑定ではお相手の入力欄を出さない（入口は相性診断タブ）', U2.ccHidden);
  ok('UX②：特徴の欄に柱ごとの「向く仕事＝」の一覧を出さない', U2.jobs===0, 'n='+U2.jobs);
  ok('UX②：言葉の意味（木火土金水）は答えの下', U2.lgLast);
  ok('UX②：用語の「？」は丸いまま（縦横同じ）', U2.q===0, 'n='+U2.q);
  ok('UX②：カルテの削除は「お客様を削除」と書き分け', U2.kl);
  ok('UX②：相性の月の区切りは節入りの日付で見せる', /^2026年12月\d+日〜2027年1月\d+日$/.test(U2.ml), U2.ml); }
// UX点検②の続き（2026-11-18）：相性のこれからの年は1つの表に早い順（縁が深まる・三合方合・揺れやすい・運気の谷）
{ const Y=await p.evaluate(()=>{ try{ const h=compatTimingHTML(chart,chart,RELTYPES.love), tb=(h.match(/<table class="cty"/g)||[]).length, fold=/cty-fold/.test(h);
    const ys=[...h.matchAll(/<td class="cty-y">(\d{4})/g)].map(m=>+m[1]), sorted=ys.every((y,i)=>!i||ys[i-1]<y);
    const bg=[...document.scripts].some(s=>/pkCpYearRows\(a,b,d\.good,d\.strain,d\.low\)/.test(s.textContent));
    const isB=/app-beginner/.test(location.pathname);
    return {tb,fold,n:ys.length,sorted,bgOK:!isB||bg}; }catch(e){ return {err:String(e)}; } });
  ok('UX②：相性のこれからの年は1つの表（早い順・年は1行ずつ）', Y.tb===1&&!Y.fold&&Y.sorted&&Y.bgOK, JSON.stringify(Y)); }
// UX点検②の続き（2026-11-18）：ビギナーの「整えたい年」はPROの「運気の谷」と同じ年（compatSelfLowYears をそのまま使う）／「AかBか」の見送りの文の直し
{ const Z=await p.evaluate(()=>{ try{ const isB=/app-beginner/.test(location.pathname);
    const src=[...document.scripts].map(s=>s.textContent).join('\n');
    const bgSame=!isB||(/low=safe\(function\(\)\{return compatSelfLowYears\(a\);\},\[\]\)/.test(src)&&!/個人の判定が△の年と、◦\/△で注意の重なる年だけにする/.test(src));
    const B=window.Bazi, P=[[1981,6,10,22,28,'female'],[1979,3,15,8,0,'male'],[1990,1,1,12,0,'female'],[1975,11,20,6,30,'male']];
    let same=true, info=[]; P.forEach(function(x){ const c=B.computeChart({year:x[0],month:x[1],day:x[2],hour:x[3],minute:x[4],sex:x[5],correctionMode:'none'}); const lo=compatSelfLowYears(c).map(o=>o.year), rw=pkCpYearRows(c,c,[],[],compatSelfLowYears(c)).filter(r=>r.low).map(r=>r.year); if(lo.join()!==rw.join()) same=false; info.push(lo.join('/')); });
    const T='A社のほうが合います。\n今は急いで結論を出さずに見送るのが賢明です。\n・どちらも見送るのがよいでしょう。', o=pkChoiceHoldFix(T,'A社とB社、どちらに転職すべきですか');
    const ab=!/見送/.test(o)&&/条件をよく確かめてから決めましょう/.test(o)&&/^A社のほうが合います。/.test(o)&&pkChoiceHoldFix(T,'転職はいつがいいですか')===T;
    return {bgSame,same,ab,info:info.join(' | ')}; }catch(e){ return {err:String(e)}; } });
  ok('UX②：ビギナーの「整えたい年」はPROの「運気の谷」と同じ年', Z.bgSame&&Z.same, JSON.stringify(Z));
  ok('UX②：「AかBか」で本文の「どちらも見送る」は条件の言い方に（1行目は選ぶ答えのまま）', Z.ab, JSON.stringify(Z)); }
// UX点検②の続き（2026-11-19）：ビギナー1人の鑑定の「静かに整えたい年」はPROの年運の判定「静かに整える時期（△）」（pkYearMk）と同じ年
{ const W=await p.evaluate(()=>{ try{ const isB=/app-beginner/.test(location.pathname); if(!isB||typeof window.pkBgPlainOffline!=='function') return {skip:true,ok:true};
    const B=window.Bazi, P=[[1981,6,10,22,28,'female'],[1979,3,15,8,0,'male'],[1990,1,1,12,0,'female'],[1975,11,20,6,30,'male'],[2001,8,3,3,15,'female'],[1968,4,22,17,0,'male']];
    const keep=chart; let ok=true, info=[], n=0;
    P.forEach(function(x){ const c=B.computeChart({year:x[0],month:x[1],day:x[2],hour:x[3],minute:x[4],sex:x[5],correctionMode:'none'}); chart=c;
      const t=window.pkBgPlainOffline('')||'', m=t.match(/静かに整えたい年：([^。\n]*)/), bg=m?(m[1].match(/\d{4}/g)||[]).join('/'):'';
      const pro=(c.annualFortunes||[]).filter(a=>a.year>=c.now.year&&a.year<c.now.year+10&&pkYearMk(c,a)==='△').map(a=>a.year).join('/');
      if(bg!==pro) ok=false; if(pro) n++; info.push(bg+'='+pro); });
    chart=keep; return {ok,n,info:info.join(' | ')}; }catch(e){ return {ok:false,err:String(e)}; } });
  ok('UX②：ビギナー1人の鑑定の「静かに整えたい年」はPROの年運の判定（整える時期）と同じ年', W.ok&&(W.skip||W.n>0), JSON.stringify(W)); }
// 追加の質問
const c1=calls; await p.fill('#worry','彼から連絡が来るのはいつ頃ですか'); await p.click('#consultBtn'); await p.click('#consultBtn').catch(()=>{});
const ms2=await waitFor(()=>{const it=document.querySelectorAll('#reading .rd-item');const l=it[it.length-1];return it.length>=2&&l.querySelector('.rd-bar')&&!l.querySelector('.loading');},60000);
await p.waitForTimeout(1500);
const items2=await p.evaluate(()=>document.querySelectorAll('#reading .rd-item').length);
const A2=await p.evaluate(()=>{const L=document.querySelectorAll('#reading .rd-item');if(!L.length) return ''; const it=L[L.length-1]; const op=[...it.querySelectorAll('details.r-fold:not([open])')]; op.forEach(d=>d.open=true); const t=it.querySelector('.rd-body').innerText; op.forEach(d=>d.open=false); return t;});
if(process.env.GATE_DUMP){ (await import('fs')).writeFileSync(process.env.GATE_DUMP,A+'\n=====\n'+A2); }
ok('相談2（続けて質問）：答えが出る', ms2>=0 && A2.length>200, A2.length+'字');
{ const f2=(A2.split('\n').map(s=>s.trim()).filter(s=>s.length>8&&!/^(コピー|言葉の意味|ご相談|彼から連絡が来るのはいつ頃ですか|▲|オンライン鑑定|オフライン鑑定|📵|⏩|🔄|端末の中で作った)/.test(s))[0]||''); ok('相談2：「いつ」の質問に、1行目で時期を答えている', /20\d\d年|年内|来年|再来年|\d{1,3}歳|[春夏秋冬]|\d{1,2}月/.test(f2), f2.slice(0,80)); }
if(MODE==='online'){ const u=unStamped(A2); ok('相談2：西暦にツールの干支・年齢が付いている', u.length===0, u.map(y=>{const i=A2.indexOf(y+'年');return A2.slice(Math.max(0,i-15),i+12).replace(/\n/g,'⏎');}).join(' / ')); }
{ const cb=calCheck(A2,1985); ok('暦：年齢・年の干支・今年/来年が正しい（相談2）', cb.length===0, cb.slice(0,3).join(' / ')); }
ok('相談2：二度押しでも答えは1つ増えるだけ', items2===2, 'items='+items2);
if(MODE==='online') ok('相談2：呼び出し回数'+(site==='beginner'?'（ビギナーは専門用語の書き直しで最大4回）':'（2回）'), site==='beginner'?(calls-c1>=2&&calls-c1<=4):calls-c1===2, 'calls='+(calls-c1));
// チャット用コピー・共有
await p.evaluate(()=>{window.__clip='';window.__shared=null;});
await p.evaluate(()=>{ document.querySelectorAll('#reading .rd-item:last-child .rd-more').forEach(d=>d.open=true); }); await p.click('#reading .rd-item:last-child .rd-chat').catch(()=>{}); await p.waitForTimeout(600);
const chat=await p.evaluate(()=>window.__clip||''); { const cb=calCheck(chat,1985); ok('暦：チャット用コピーの年齢・干支・今年/来年が正しい', cb.length===0, cb.slice(0,3).join(' / ')); } ok('チャット用コピーが空でない・＊なし', chat.length>80&&cleanStar(chat)===0, chat.length+'字');
await p.click('#reading .rd-item:last-child .rd-share').catch(()=>{}); await p.waitForTimeout(600);
const sh=await p.evaluate(()=>((window.__shared||{}).text||'')); ok('共有（LINE）の文が空でない・＊なし', sh.length>80&&cleanStar(sh)===0, sh.length+'字');
// カルテ
const k=await p.evaluate(()=>{try{const c=mpLoad().clients.find(x=>x.name==='山田花子');return c?c.readings.map(r=>r.text):[];}catch(e){return ['ERR'];}});
ok('カルテに2件とも保存・空でない・＊なし', k.length>=2&&k.every(t=>t.length>100&&cleanStar(t)===0), k.map(t=>t.length).join(','));
// 鑑定書
const c2=calls;
const [pop]=await Promise.all([ctx.waitForEvent('page',{timeout:10000}).catch(()=>null), p.evaluate(()=>document.getElementById('jn-print').click())]);   // スマホ幅では「☰ 目次」の中にあるので、直接押す（2026-11-17）
if(!pop){ ok('鑑定書が開く', false); } else {
  await pop.waitForLoadState('load').catch(()=>{});
  const t=Date.now(); let txt='';
  _log('   [点検] wait loop start',Date.now()-T00); while(Date.now()-t<70000){ txt=await pop.evaluate(()=>{const o=document.getElementById('sheetsWrap');return o?o.innerText:'';}).catch(()=>''); const busy=await pop.evaluate(()=>/作成しています|作成中|生成中|読み解いています/.test((document.getElementById('sheetsWrap')||{}).innerText||'')).catch(()=>true); if(txt.length>1500&&!busy&&Date.now()-t>4000) break; await pop.waitForTimeout(500); }
  await pop.waitForTimeout(2500); txt=await pop.evaluate(()=>(document.getElementById('sheetsWrap')||{}).innerText||'').catch(()=>txt);

  ok('鑑定書：中身が空でない', txt.length>1500, txt.length+'字');
  ok('鑑定書：＊なし', cleanStar(txt)===0, cleanStar(txt));
  if(MODE==='online') ok('鑑定書：呼び出し回数（目安1〜3回）', calls-c2>=1&&calls-c2<=3, 'calls='+(calls-c2));
  await pop.close(); }
{ const rt=await p.evaluate(()=>(document.getElementById('reading')||{}).innerText||''); ok('1人の相談に相性の書き足しが付かない', !/惹かれ合う星|2人の役割と|この2人だけの読み|2人の合が三合|2人が惹かれ合う|2人の結びつきが強まる/.test(rt), (rt.match(/.{0,20}(惹かれ合う星|2人の役割と|この2人だけの読み|2人の合が三合).{0,20}/)||[''])[0]); }
const _e=errs.filter(x=>!/reqfail: .*gemini/.test(x)&&!(MODE!=='online'&&/ERR_INTERNET_DISCONNECTED/.test(x))); ok('画面のエラー0件', _e.length===0, _e.slice(0,3).join(' | '));

console.log(JSON.stringify(CL)); console.log(`  → ${R.filter(x=>!x.pass).length===0?'合格':'不合格'}（${R.filter(x=>x.pass).length}/${R.length}）  呼び出し合計 ${calls}`);
await b.close(); srv.close();
