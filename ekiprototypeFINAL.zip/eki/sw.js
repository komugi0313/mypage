/* 易占術2026 Service Worker
 * 方針：
 *  - HTML（ナビゲーション）＝ネットワーク優先（常に最新を表示。取れない時だけキャッシュ）
 *  - 画像・アイコン等の重い資産＝キャッシュ優先（2回目以降を高速化）
 *  - AI鑑定などのAPI通信（/api/・googleapis）は一切キャッシュしない（常にオンラインで実行）
 * 更新手順：サイトを更新したら下の VERSION を上げる（古いキャッシュは自動削除される）
 */
const VERSION = 'eki-v1';
const ASSET_CACHE = VERSION + '-assets';
const PAGE_CACHE  = VERSION + '-pages';

/* インストール時に最低限の骨組みだけ先読み（重い画像は初回表示時に自然に貯まる） */
const PRECACHE = [
  './index.html',
  './eki.html',
  './manifest.webmanifest',
  './assets/logo.png',
  './assets/icon-192.png',
  './assets/icon-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(PAGE_CACHE).then(c => c.addAll(PRECACHE)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => !k.startsWith(VERSION)).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);

  if (req.method !== 'GET') return;                       // POST等（鑑定API含む）は素通し
  if (url.pathname.startsWith('/api/')) return;           // 自前API：キャッシュしない
  if (url.hostname.includes('googleapis.com')) return;    // Gemini：キャッシュしない
  if (url.origin !== self.location.origin) return;        // 外部はブラウザ任せ

  // ページ遷移（HTML）＝ネットワーク優先。オフライン時のみキャッシュで代替
  if (req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html')) {
    e.respondWith(
      fetch(req).then(res => {
        const copy = res.clone();
        caches.open(PAGE_CACHE).then(c => c.put(req, copy));
        return res;
      }).catch(() =>
        caches.match(req).then(hit => hit || caches.match('./index.html'))
      )
    );
    return;
  }

  // 画像・アイコン・動画・マニフェスト＝キャッシュ優先（無ければ取得して保存）
  e.respondWith(
    caches.match(req).then(hit => hit || fetch(req).then(res => {
      if (res.ok) {
        const copy = res.clone();
        caches.open(ASSET_CACHE).then(c => c.put(req, copy));
      }
      return res;
    }))
  );
});
