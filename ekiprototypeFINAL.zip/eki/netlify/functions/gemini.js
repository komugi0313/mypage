// Netlify Function：鑑定エンジン（Gemini）のサーバー中継。
// ・APIキーは Netlify の環境変数 GEMINI_API_KEY に保管し、ブラウザには一切出さない・返さない。
// ・フロントは /api/gemini へ POST（netlify.toml のリダイレクトで本関数へ）。
// ※公開前に Netlify 管理画面 → Site settings → Environment variables で GEMINI_API_KEY を設定すること。
const MODEL = 'gemini-2.5-flash';

exports.handler = async (event) => {
  // POST 以外は拒否
  if (event.httpMethod !== 'POST') {
    return json(405, { error: { message: 'Method Not Allowed' } });
  }

  // 簡易オリジンチェック：他サイトからの無断利用を軽く抑止（本格的な対策は下記TODO参照）
  const site = process.env.URL || '';               // Netlify が自動で入れる公開URL
  const origin = event.headers.origin || event.headers.referer || '';
  if (site && origin && !origin.startsWith(site)) {
    return json(403, { error: { message: 'Forbidden' } });
  }

  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    return json(500, { error: { message: 'サーバー設定が未完了です（GEMINI_API_KEY 未設定）' } });
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(key)}`;
  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: event.body,                              // フロントが組み立てた contents / generationConfig をそのまま中継
    });
    const text = await r.text();
    return { statusCode: r.status, headers: { 'Content-Type': 'application/json' }, body: text };
  } catch (e) {
    return json(502, { error: { message: 'AIサービスへの接続に失敗しました' } });
  }
};

function json(statusCode, obj) {
  return { statusCode, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(obj) };
}

// ── 公開前TODO（重要）───────────────────────────────────────────
// この中継は「キーをブラウザに出さない」ためのもの。エンドポイント自体は開いているので、
// 悪用（無断連打でのAPI浪費）を防ぐには、次をサーバー側で必ず追加すること：
//   1) レート制限（IP/セッション単位・バースト制限）
//   2) 会員判定と1日上限（未登録3回・体験5回/日・プレミアム15回/日）のサーバー側での検証
//      ※現在フロントの localStorage 判定は回避可能なので、本番は必ずサーバーで判定・記録する
//   3) 入力サイズの上限チェック（極端に長い body を弾く）
