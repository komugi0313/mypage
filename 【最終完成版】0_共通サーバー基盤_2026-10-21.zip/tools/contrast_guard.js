/* 文字の見えやすさの安全装置（tools/add_contrast_guard.py が3サイトの全ページに埋め込む。直すときはこのファイルを直して再実行）
   文字の色と、その後ろの背景の色を比べて、読みにくい組み合わせ（薄い背景に薄い文字／濃い背景に濃い文字）を見つけたら、
   その文字だけ色を自動で調整する（明るい背景→同じ色みのまま濃く、暗い背景→白く）。計算・鑑定の中身には一切さわらない。
   目安：明るい背景の上の文字はコントラスト比7以上（大きい文字＝24px以上、または18.66px以上の太字は4.5以上）。濃い色の上の白い文字は4.5以上（大きい文字は3以上）。 */
(function(){
  if(window.__pkContrast) return; window.__pkContrast=true;
  function P(c){ var m=c&&c.match(/[\d.]+/g); return m?[+m[0],+m[1],+m[2],m.length>3?+m[3]:1]:null; }
  function L(c){ function f(v){ v/=255; return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4); } return 0.2126*f(c[0])+0.7152*f(c[1])+0.0722*f(c[2]); }
  function CR(a,b){ var x=L(a),y=L(b); return (Math.max(x,y)+0.05)/(Math.min(x,y)+0.05); }
  function mix(a,b,t){ return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t]; }
  function over(f,b){ var a=f[3]==null?1:f[3]; return [f[0]*a+b[0]*(1-a),f[1]*a+b[1]*(1-a),f[2]*a+b[2]*(1-a)]; }
  // 文字の後ろの背景：背景色のある祖先を上へたどる。グラデーションは色の幅を見る。写真などの画像背景は判定しない
  var BG=null, OP=null;   // 1回の点検の中だけ使う覚え書き（同じ祖先を何度も調べない）
  function bgOf(n){
    if(!n||n.nodeType!==1) return {lo:1,hi:1,rgb:[255,255,255]};
    if(BG&&BG.has(n)) return BG.get(n);
    var cs=getComputedStyle(n), bi=cs.backgroundImage, r;
    // 飾りの層（::before／::after に背景がある）が文字の後ろにあるときは、正しく判定できないので触らない
    var deco=false; ['::before','::after'].forEach(function(ps){ try{ var pc=getComputedStyle(n,ps); if(pc.content&&pc.content!=='none'&&(pc.position==='absolute'||pc.position==='fixed')){ var pb=P(pc.backgroundColor); if((pb&&pb[3]>0.3)||(pc.backgroundImage&&pc.backgroundImage!=='none')){ var pw=parseFloat(pc.width)||0, ph=parseFloat(pc.height)||0, nr=n.getBoundingClientRect(); /* 端の細い帯・小さな飾りは文字の後ろにかからないので測ってよい */ var thin=(pw>0&&pw<=12)||(ph>0&&ph<=12)||(nr.width>0&&pw>0&&pw<nr.width*0.2)||(nr.height>0&&ph>0&&ph<nr.height*0.2); if(!thin) deco=true; } } }catch(_e){} });
    if(deco||(bi&&bi!=='none'&&/url\(/.test(bi))) r=null;
    else{
      var parent=bgOf(n.parentElement);
      if(parent===null) r=null;
      else{
        var bc=P(cs.backgroundColor), base=parent.rgb;
        if(bc&&bc[3]>0) base=over(bc,base);
        var cols=(bi&&bi!=='none')?(bi.match(/rgba?\([^)]*\)/g)||[]).map(P).filter(Boolean):[];
        if(cols.length){ var lo=1,hi=0,acc=[0,0,0]; cols.forEach(function(c){ var m=over(c,base), l=L(m); if(l<lo)lo=l; if(l>hi)hi=l; acc[0]+=m[0];acc[1]+=m[1];acc[2]+=m[2]; });
          r={lo:lo,hi:hi,rgb:[acc[0]/cols.length,acc[1]/cols.length,acc[2]/cols.length]}; }
        else if(bc&&bc[3]>0){ var l2=L(base); r={lo:l2,hi:l2,rgb:base}; }
        else r=parent;
      }
    }
    if(BG) BG.set(n,r); return r;
  }
  function opac(n){ if(!n||n.nodeType!==1) return 1; if(OP&&OP.has(n)) return OP.get(n); var o=(+getComputedStyle(n).opacity)*opac(n.parentElement); if(OP) OP.set(n,o); return o; }
  function fix(e){
    var own=''; for(var c=e.firstChild;c;c=c.nextSibling) if(c.nodeType===3) own+=c.nodeValue; if(!own.trim()) return;
    var cs=getComputedStyle(e); if(cs.display==='none'||cs.visibility==='hidden') return;
    var fill=cs.webkitTextFillColor; if(fill&&/rgba\(0, 0, 0, 0\)|transparent/.test(fill)) return;   // 文字そのものがグラデーションのもの
    var fixed=e.hasAttribute('data-pkcg'), fg=P(fixed?(e.getAttribute('data-pkco')||cs.color):cs.color); if(!fg) return;   // 前に直した文字は、元の色で測り直す（背景が変わったら戻す・直し直す）
    var undo=function(){ if(!fixed) return; var o=e.getAttribute('data-pkcg'); if(o) e.style.setProperty('color',o); else e.style.removeProperty('color'); e.removeAttribute('data-pkcg'); e.removeAttribute('data-pkco'); };
    var bg=bgOf(e); if(!bg){ undo(); return; }
    if(bg.hi-bg.lo>0.35){ undo(); return; }                       // 明暗が大きく混ざった背景は判定しない
    var fs=parseFloat(cs.fontSize)||14, bold=(+cs.fontWeight||400)>=700;
    var big=(fs>=24||(fs>=18.66&&bold)), need=big?3:4.5;
    var op=opac(e); if(op<0.6) return;                 // 透明・半透明で隠している途中のもの（通知・ふわっと出る表示など）は触らない
    var a=(fg[3]==null?1:fg[3])*op;
    var light=((bg.lo+bg.hi)/2)>0.4, to=light?[0,0,0]:[255,255,255], c2=null;
    if(light) need=big?4.5:7;
    if(printing&&!light) return;   // 印刷中は、濃い背景の上の文字を白っぽくしない（紙では背景の色が出ないことがあるため）   // 明るい背景の上の文字は一段きびしく（ふつうの文字7以上・大きい文字4.5以上）。濃い色の上の白い文字は4.5のまま（発注者指示 2026-10-21）
    var base=bg.rgb, seen=over([fg[0],fg[1],fg[2],a],base);
    if(CR(seen,base)>=need){ undo(); return; }
    for(var t=0.1;t<=1.0001;t+=0.1){ var cand=mix([fg[0],fg[1],fg[2]],to,t); if(CR(over([cand[0],cand[1],cand[2],a],base),base)>=need){ c2=cand; break; } }
    if(!c2){   // 中くらいの明るさの色の上（白い文字＋黄土色の札など）：白くしても足りないときは、濃い文字にする
      var to2=light?[255,255,255]:[0,0,0];
      for(var t2=0.1;t2<=1.0001;t2+=0.1){ var cand2=mix([fg[0],fg[1],fg[2]],to2,t2); if(CR(over([cand2[0],cand2[1],cand2[2],a],base),base)>=need){ c2=cand2; break; } }
    }
    if(!c2) c2=(CR(to,base)>=CR(light?[255,255,255]:[0,0,0],base))?to:(light?[255,255,255]:[0,0,0]);                                     // 透明度は変えない（隠している表示を出してしまわないように）
    if(!fixed){ e.setAttribute('data-pkcg',e.style.getPropertyValue('color')||''); e.setAttribute('data-pkco',cs.color); }   // 元の色を覚えておく（印刷のとき・背景が変わったときに戻す）
    var nv='rgb('+Math.round(c2[0])+', '+Math.round(c2[1])+', '+Math.round(c2[2])+')'; if(e.style.getPropertyValue('color')!==nv||e.style.getPropertyPriority('color')!=='important') e.style.setProperty('color',nv,'important');   // 同じ色なら触らない（自分の変更で何度も点検が走らないように）
  }
  var SKIP='script,style,noscript,svg,canvas,video,option,select,textarea,input,img,.yomi,.ysr,[aria-hidden="true"]';
  function pass(root){ if(!root||root.nodeType!==1) return;   /* 印刷中も、濃くするほうだけは動く（fix の中で白っぽくするのは止める） */ BG=new Map(); OP=new Map(); var list=[root].concat([].slice.call(root.querySelectorAll('*')));
    for(var i=0;i<list.length;i++){ var e=list[i]; if(e.matches&&e.matches(SKIP)) continue; try{ fix(e); }catch(_e){} } BG=null; OP=null; }
  var tm=null; function full(){ clearTimeout(tm); tm=setTimeout(function(){ pass(document.body); },350); }
  // 印刷：濃くした文字はそのまま印刷する。濃い背景の上で白っぽくした文字だけは、紙では背景の色が出ないことがあるので元に戻してから印刷し、終わったら画面用に戻す
  function unfixAll(){ [].forEach.call(document.querySelectorAll('[data-pkcg]'),function(e){ if(printing){ var f0=P(e.getAttribute('data-pkco')||''), f1=P(e.style.getPropertyValue('color')||''); if(f0&&f1&&L(f1)<=L(f0)) return; }   /* 印刷：濃くした文字はそのまま（紙でも読みやすく）。白っぽくした文字だけ元に戻す（紙では背景の色が出ないことがあるため）。発注者指示 2026-10-21 */ var o=e.getAttribute('data-pkcg'); if(o) e.style.setProperty('color',o); else e.style.removeProperty('color'); e.removeAttribute('data-pkcg'); e.removeAttribute('data-pkco'); }); }
  window.addEventListener('beforeprint',function(){ printing=true; unfixAll(); try{ pass(document.body); }catch(_e){} setTimeout(function(){ try{ pass(document.body); }catch(_e){} },0); });   // 印刷の直前に作り直された文字も濃くする
  window.addEventListener('afterprint',function(){ printing=false; pass(document.body); });
  var printing=false;
  function start(){
    pass(document.body); setTimeout(function(){ pass(document.body); },1500);
    document.addEventListener('click',full,true); document.addEventListener('toggle',full,true); window.addEventListener('resize',full);
    if(window.MutationObserver){ var q=[],qt=null; new MutationObserver(function(rs){ rs.forEach(function(r){ if(r.type==='childList'){ [].forEach.call(r.addedNodes,function(n){ if(n.nodeType===1) q.push(n); else if(n.parentElement) q.push(n.parentElement); }); } else if(r.target&&r.target.nodeType===1){ q.push(r.target); } });
      if(!qt) qt=setTimeout(function(){ var w=q; q=[]; qt=null; w.forEach(function(n){ if(n.isConnected) pass(n); }); },200); })
      .observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','hidden','open']}); }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start); else start();
})();
/* 行末の1〜2文字残り（泣き別れ）を防ぐ：紹介ページ・教科書・申し込み画面にも同じ仕組みを入れる（アプリと同じ処理。横並び（flex/grid）の中では触らない） */
(function(){
  if(window.__pkOrphan) return; window.__pkOrphan=true;   // 行末の1〜2文字残りを防ぐ仕組みは、ページに1つだけ動かす
  function lines(e){ const rg=document.createRange(); rg.selectNodeContents(e); const L={};
    [...rg.getClientRects()].forEach(r=>{ if(!(r.width>0&&r.height>0))return; const k=Math.round((r.top+r.bottom)/8); const o=L[k]||(L[k]={l:1e9,r:-1e9}); o.l=Math.min(o.l,r.left); o.r=Math.max(o.r,r.right); });
    return Object.keys(L).map(Number).sort((a,b)=>a-b).map(k=>L[k]); }
  function isShort(e){ const ls=lines(e); if(ls.length<2) return false; const fs=parseFloat(getComputedStyle(e).fontSize)||14; const z=ls[ls.length-1]; return (z.r-z.l)<fs*2.3; }
  function glue(nodes){ const sp=document.createElement('span'); sp.className='og-t'; sp.style.whiteSpace='nowrap'; nodes[0].parentNode.insertBefore(sp,nodes[0]); nodes.forEach(n=>sp.appendChild(n)); }
  function tail(e){
    const w=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,{acceptNode:n=>n.nodeValue.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP}); let last=null,n; while((n=w.nextNode())) last=n; if(!last) return;
    const v=last.nodeValue.replace(/\s+$/,'');
    if(v.length>=4){ glue([last.splitText(v.length-4)]); return; }
    // 「▾」など短い文字：その前の数文字と一緒にする
    let t=last, p=t.parentNode; while(p&&p!==e&&!t.previousSibling){ t=p; p=p.parentNode; }
    const prev=t.previousSibling; if(!prev) return;
    if(prev.nodeType===3){ const pv=prev.nodeValue; if(pv.trim().length<1) return; glue([prev.splitText(Math.max(0,pv.length-3)),t]); }
    else glue([prev,t]);
  }
  function run(){
    document.querySelectorAll('p,li,h1,h2,h3,h4,label,summary,div,span,b,small,a,button,td').forEach(e=>{
      if(e.dataset.og||!e.offsetParent) return;
      if(e.closest('table:not(.og-ok),svg,select,textarea,[contenteditable],.no-og,#verTag')) return;
      if(/flex|grid/.test(getComputedStyle(e).display)) return;   // 横並び（flex/grid）の中で包むと、文字の途中にすき間ができるので触らない
      let own=false; for(const c of e.childNodes){ if(c.nodeType===3&&c.nodeValue.trim()){own=true;break;} } if(!own) return;
      if((e.textContent||'').trim().length<5) return;
      e.dataset.og='1';
      if(!isShort(e)) return;
      e.style.textWrap='balance'; if(!isShort(e)) return;
      e.style.textWrap=''; tail(e);
    }); }
  let t=null; const sch=()=>{ clearTimeout(t); t=setTimeout(()=>{ try{run();}catch(_e){} },220); };
  try{ new MutationObserver(sch).observe(document.body,{childList:true,subtree:true}); }catch(e){}
  document.addEventListener('toggle',sch,true); document.addEventListener('click',sch,true);
  sch();
})();
