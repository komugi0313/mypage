命式作成ソフト（最新版）— Netlifyデプロイ手順

このZIPには package.json（@netlify/blobs 依存）を同梱済みです。
前回の「Cannot find module '@netlify/blobs'」ビルドエラーは解消されます。

【Netlify（ドラッグ&ドロップ）】
1. Netlifyにログイン → 命式作成ソフト用のサイトを開く（Pocket鑑定/みんかれと間違えないこと）
2. このフォルダごと Deploys にドラッグ&ドロップ
3. index.html＝命式作成ソフトが表示されます
4. AI鑑定を使うなら、Netlifyの環境変数に GEMINI_API_KEY を設定（サーバー側のみ）

【ビルドでエラーが出る場合の代替】
・AI鑑定が不要なら、単一ファイル版 meishiki.html を index.html にリネームして置くだけ
  （functions と package.json を使わない＝ビルド不要でエラーが起きません）
