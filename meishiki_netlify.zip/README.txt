命式作成ソフト — デプロイ手順

【Netlify（ドラッグ&ドロップ）】
1. https://app.netlify.com にログイン
2. このフォルダ（README.txtがある階層）ごと "Sites" 画面にドラッグ&ドロップ
3. 発行されたURLを開く（index.html＝命式ソフトが表示されます）
   ※AI鑑定チャットは functions/gemini.js が /api/gemini として自動で動きます。
     Netlifyの環境変数に GEMINI_API_KEY を設定してください（サーバー側のみ・ブラウザに出ません）。

【その他の静的ホスト（GitHub Pages / Cloudflare Pages / 自前サーバー等）】
・index.html をそのまま配置すればオフラインの命式機能はすべて動きます。
・AIチャットはサーバー関数が無い環境では、画面内「AI鑑定の設定」でGeminiキーを入れると動きます。

【単一ファイル版（別途 meishiki.html）】
・エンジンを内蔵した1ファイル版。どこにでも1つ置くだけで動きます（AIはキー入力 or 上記関数が必要）。
