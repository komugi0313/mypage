/* 易 EKI Pro — Service Worker
   アプリ本体をキャッシュし、オフラインでも開けるようにする。
   ※ AIによる鑑定文生成（Gemini）はオンライン時のみ。立卦・顧客管理・印刷はオフライン可。 */
const CACHE = 'eki-pro-v4';
const ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon-180.png'
];

self.addEventListener('install', e => {
  self.skipWaiting();
  // 1件失敗しても他は残るよう個別に取得（本体index.htmlの取りこぼし防止）
  e.waitUntil(caches.open(CACHE).then(c => Promise.all(ASSETS.map(a => c.add(a).catch(() => {})))));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const sameOrigin = url.origin === location.origin;
  const isFont = /fonts\.(googleapis|gstatic)\.com/.test(url.host);

  // Gemini等の外部API・他オリジンは触らない（常にネットワーク）
  if (!sameOrigin && !isFont) return;

  // ページ遷移：ネット優先 → 失敗時はキャッシュした本体を返す（オフライン起動）
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req)
        .then(r => { const cp = r.clone(); caches.open(CACHE).then(c => c.put(req, cp)); return r; })
        .catch(() => caches.match('./index.html').then(m => m || caches.match('./')))
    );
    return;
  }

  // それ以外（CSS/JS/画像/フォント）：キャッシュ優先 → ネット（取得できたら保存）
  e.respondWith(
    caches.match(req).then(m => m || fetch(req).then(r => {
      if (r && r.status === 200 && (sameOrigin || /fonts\.gstatic/.test(url.host))) {
        const cp = r.clone();
        caches.open(CACHE).then(c => c.put(req, cp));
      }
      return r;
    }).catch(() => m))
  );
});
