# 易 EKI Pro ― 案2「スピリチュアル・テック」デザイン

クリーム × ベージュ × ラベンダー × チャコールの新デザイン版です。
**既存の鑑定ツールの機能・HTML・JSは一切変更していません。** 配色・字体・余白のみ `design-overrides.css` で上書きしています。

---

## 📁 フォルダ構成

```
eki-pro-v2/
├── index.html                 ← LP（案2デザイン・CSSインライン完結）
├── register.html              ← 登録ページ（無料体験の入口）。LPの全CTAはここへ。
│                                収集：名前・メール・性別・都道府県・年代・職業・占い経験。★クレカ登録なし。
├── upgrade.html               ← 有料案内画面（無料期間の終了後に表示）。プラン選択＋支払い（クレカ/銀行振込/PayPay QR）。
│                                規約：利用開始日を1日目として1か月ごと更新／いつでも開始・解約／解約後も期間末まで利用可。
│   ── 動線：LP → register.html（無料体験開始・クレカ不要）→ app/（3日間お試し）→（期間終了）→ upgrade.html（課金）
│   ── ※決済・アカウント作成・無料期間の判定はサーバー側で連携が必要（現状はフロントUI＋ダミー送信）
├── app/
│   ├── index.html             ← 鑑定ツール本体（既存のまま＋上書きCSSのlinkを1行追加）
│   ├── design-overrides.css   ← 案2デザインの上書き（機能は変えない）
│   ├── manifest.json          ← PWA設定
│   ├── sw.js                  ← Service Worker（オフライン対応）
│   ├── icon-192.png / icon-512.png / apple-touch-icon-180.png
└── README.md
```

- LP（`index.html`）の各CTAは `app/index.html`（鑑定ツール）へリンクしています。
- 鑑定ツールは `app/index.html` の `<head>` 末尾に
  `<link rel="stylesheet" href="design-overrides.css">` を1行だけ追加済み（インラインCSSの後＝上書きが有効）。

---

## 🎨 デザイン仕様（案2）

| 用途 | 色 |
|---|---|
| メイン背景 | クリーム `#F5F1E8` |
| セカンダリ | ベージュ `#E8D5C4` |
| アクセント | ラベンダー `#C9B5D4`（白文字が乗る箇所は濃いめ `#8E72A8`） |
| テキスト | チャコール `#3A3A3A` |

- 見出し：Noto Serif JP ／ 本文：Noto Sans JP（Google Fonts）
- 角丸 12〜14px、影 `0 4px 12px rgba(58,58,58,.08)`、余白たっぷり
- レスポンシブ（Mobile First）

---

## 🚀 Netlify へのデプロイ

### A. ドラッグ＆ドロップ（最も簡単）
1. [app.netlify.com](https://app.netlify.com/) にログイン
2. **「Add new site」→「Deploy manually」** を開く
3. この **`eki-pro-v2` フォルダごと** ドロップ
4. 公開完了。
   - LP … `https://<your-site>/`
   - 鑑定ツール … `https://<your-site>/app/`

### B. Netlify CLI
```bash
npm i -g netlify-cli
cd eki-pro-v2
netlify deploy --prod --dir .
```

> 1つのサイトに LP と 鑑定ツールが同居します（LPが `/`、ツールが `/app/`）。
> 別々の2サイトにしたい場合は `index.html` を1サイト、`app/` の中身をもう1サイトとして公開してください（その際 LP のリンク先 `app/index.html` を新URLに変更）。

---

## 🔧 ローカル確認

```bash
cd eki-pro-v2
npx serve -l 5000 .
# LP        → http://localhost:5000/
# 鑑定ツール → http://localhost:5000/app/
```

※ `file://`（ダブルクリックで直接開く）では PWA とAI鑑定が動きません。AI鑑定は HTTP配信＋鑑定画面の「🔑 デモ：Gemini APIキー」にキーを入れて確認してください。

---

## ⚙️ 本番化メモ（エンジニア向け）

- **Gemini APIキー**：デモは画面入力（端末内保存）。本番はサーバー側に隠し、入力欄（`#demoKeyCard`）は削除。
- **申込・決済**：現在はLP/料金のボタンが鑑定ツールへ直行。決済代行はSBペイメントサービス（SBPS）を挟む前提で、「このプランで試す／今すぐ始める」のリンク先を申込ページへ。詳細は `実装仕様_エンジニア向け.md`。
- **PWA**：`app/sw.js` の `CACHE` バージョンを更新時に上げると確実に更新されます。
- 旧デザイン（和紙/金/朱）は別フォルダ `eki-pro/` にそのまま残しています。
