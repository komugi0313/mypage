// Netlify Function：鑑定エンジン（Gemini）のサーバー中継＋サーバー側レート制限。
// ・APIキーは環境変数 GEMINI_API_KEY に保管し、ブラウザには一切出さない。
// ・回数制限は「サーバー側」で強制（localStorage は改ざん可能なので信用しない）。
//   端末ID(x-pk-device)＋IP を Netlify Blobs に日次カウントし、超過なら 429 を返し
//   Gemini を呼ばない＝API浪費を防ぐ。
// ・プラン連携（Stripe）後は、購読状態で上限(getLimits)を引き上げるだけで拡張可能。
// ※要設定：Site settings → Environment variables → GEMINI_API_KEY
//          Blobs は Netlify の通常デプロイ（Git連携 / netlify deploy）で自動有効。

// モデルは環境変数で差し替え可能（コスト最適化のA/B用）。
// 候補: gemini-2.5-flash（現行） / gemini-3.1-flash-lite（約1/2コストの後継Lite）
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

// 上限（1日）。将来プラン別に差し替え。
const LIMITS = {
  free:      { device: 5,   ip: 40  },   // 無料：端末5回/日、同一IP合計40回/日（悪用抑止）
  light:     { device: 50,  ip: 200 },   // おてがる 980円：50回/日（満使用でも利益7割が残る計算）
  unlimited: { device: 150, ip: 400 },   // 使い放題 2480円：フェアユース150回/日（bot対策）
};
const MAX_BODY = 12000; // 極端に長い入力を弾く（トークン浪費・悪用防止）

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: { code: 'METHOD', message: 'Method Not Allowed' } });

  // 簡易オリジンチェック
  const site = process.env.URL || '';
  const origin = event.headers.origin || event.headers.referer || '';
  if (site && origin && !origin.startsWith(site)) return json(403, { error: { code: 'ORIGIN', message: 'Forbidden' } });

  if ((event.body || '').length > MAX_BODY) return json(413, { error: { code: 'TOO_LONG', message: '入力が長すぎます' } });

  const key = process.env.GEMINI_API_KEY;
  if (!key) return json(500, { error: { code: 'NO_KEY', message: 'サーバー設定が未完了です（GEMINI_API_KEY 未設定）' } });

  // 識別子
  const h = lower(event.headers || {});
  const device = clean(h['x-pk-device']) || 'nodev';
  const ip = clean(h['x-nf-client-connection-ip'] || h['x-forwarded-for'] || '').split(',')[0].trim() || 'noip';
  const plan = (clean(h['x-pk-plan']) || 'free').toLowerCase();   // 将来サーバーで購読照合して上書き
  const lim = LIMITS[plan] || LIMITS.free;
  const day = jstDay();

  // レート制限（Blobs が使えない環境ではフェイルオープン＝ヘッダで警告）
  const store = await getStore();
  let limited = false, degraded = false, dCount = 0;
  if (store) {
    try {
      const dKey = `d:${day}:${device}`, ipKey = `i:${day}:${ip}`;
      const dRec = await readCount(store, dKey), ipRec = await readCount(store, ipKey);
      dCount = dRec;
      if (dRec >= lim.device) return limitResp(lim.device, 'device');
      if (ipRec >= lim.ip)     return limitResp(lim.ip, 'ip');
    } catch (e) { degraded = true; }
  } else { degraded = true; }

  // Gemini 呼び出し
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(key)}`;
  let resp;
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: event.body });
    const text = await r.text();
    resp = { statusCode: r.status, headers: baseHeaders(degraded), body: text };
    // 正常応答のときだけカウント加算（失敗した回は数えない）
    if (r.ok && store && !degraded) {
      try {
        await bump(store, `d:${day}:${device}`);
        await bump(store, `i:${day}:${ip}`);
        resp.headers['x-pk-remaining'] = String(Math.max(0, lim.device - (dCount + 1)));
      } catch (e) {}
    }
    return resp;
  } catch (e) {
    return json(502, { error: { code: 'UPSTREAM', message: 'AIサービスへの接続に失敗しました' } });
  }
};

// ---- レート制限の純ロジック（テスト用に分離） ----
async function readCount(store, k) {
  const v = await store.get(k, { type: 'json' }).catch(() => null);
  return (v && typeof v.n === 'number') ? v.n : 0;
}
async function bump(store, k) {
  const cur = await readCount(store, k);
  await store.setJSON(k, { n: cur + 1, t: Date.now() });
  return cur + 1;
}
function limitResp(limit, scope) {
  return json(429, { error: { code: 'LIMIT', scope, limit, message: '本日の無料相談の上限に達しました。プランに登録すると、もっと相談できます。' } });
}

// ---- ユーティリティ ----
async function getStore() {
  try { const { getStore } = require('@netlify/blobs'); return getStore('pk-usage'); }
  catch (e) { return null; } // Blobs 未提供環境（手動zip等）ではフェイルオープン
}
function jstDay() { const d = new Date(Date.now() + 9 * 3600 * 1000); return d.toISOString().slice(0, 10); }
function lower(o) { const r = {}; for (const k in o) r[k.toLowerCase()] = o[k]; return r; }
function clean(s) { return (s == null ? '' : String(s)).replace(/[\r\n]/g, '').slice(0, 200); }
function baseHeaders(degraded) { const h = { 'Content-Type': 'application/json' }; if (degraded) h['x-pk-ratelimit'] = 'degraded'; return h; }
function json(statusCode, obj) { return { statusCode, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(obj) }; }

// ---- テスト用エクスポート（本番動作には影響しない） ----
module.exports.__test = { readCount, bump, LIMITS, jstDay };
