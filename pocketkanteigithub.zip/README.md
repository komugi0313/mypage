# Pocket鑑定（pocket-kantei）

LINE風チャットの四柱推命アプリ。エンジン（pro-bazi.js / pro-adapter.js）が命式・大運・年運などを算出し、index.html が Gemini に渡して鑑定文を生成します。

## 構成
- `index.html` … アプリ本体（UI＋プロンプト組み立て＋各種ロジック）
- `pro-bazi.js` … 四柱推命エンジン（命式・大運・年運・立春/節入り補正・真太陽時）
- `pro-adapter.js` … エンジン→鑑定用データ整形（60干支・十神・納音など）
- `lp.html` … ランディングページ
- `legal.html` … 特商法・プライバシー等
- `verify.html` … 照合（検算）ツール
- `functions/gemini.js` … Netlifyサーバーレス関数（`/api/gemini` 中継）
- `netlify.toml` / `_headers` … Netlify設定

## APIキーの扱い（重要）
- 本番のGeminiキーは **Netlify の環境変数 `GEMINI_API_KEY`** に設定します（コードには絶対に書かない）。
- `functions/gemini.js` がサーバー側でキーを使い、ブラウザには一切出しません。
- ローカル体験用の `test.html`（キー埋め込み）は **.gitignore で除外**しています。GitHubには上げないでください。

## デプロイ
Netlify にこのフォルダを繋ぐ（または Deploy）だけ。`GEMINI_API_KEY`（必要なら `GEMINI_MODEL`）を環境変数に設定してください。
